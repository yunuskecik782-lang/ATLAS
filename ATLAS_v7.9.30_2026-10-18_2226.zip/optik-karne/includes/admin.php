<?php
/**
 * WordPress yönetim menüsü: ATLAS bağlantısı, kayıt ayarları, kurum alanları listesi.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'admin_menu', function () {
	add_menu_page( 'ATLAS', 'ATLAS', OPTIK_KARNE_CAP, 'optik-karne', 'sides_admin_page', plugin_dir_url( OPTIK_KARNE_FILE ) . 'assets/atlas-mark-20-beyaz.png', 30 );
} );

function sides_admin_page() {
	global $wpdb;
	$url = optik_karne_url();
	if ( current_user_can( 'manage_options' ) && isset( $_POST['sides_ayar'] ) && check_admin_referer( 'sides_ayar' ) ) {
		$y = isset( $_POST['yontem'] ) ? sanitize_key( wp_unslash( $_POST['yontem'] ) ) : 'kod_onay';
		update_option( 'sides_kayit_yontemi', in_array( $y, SIDES_YONTEMLER, true ) ? $y : 'kod_onay' );
		update_option( 'sides_eposta_dogrulama', empty( $_POST['dogrulama'] ) ? '0' : '1' );
		update_option( 'sides_ana_sayfa', empty( $_POST['ana_sayfa'] ) ? '0' : '1' );
		update_option( 'sides_tek_oturum', empty( $_POST['tek_oturum'] ) ? '0' : '1' );
		update_option( 'sides_cihaz_dogrulama', empty( $_POST['cihaz_dogrulama'] ) ? '0' : '1' );
		echo '<div class="notice notice-success"><p>Ayarlar kaydedildi.</p></div>';
	}
	$orgs = $wpdb->get_results( 'SELECT * FROM ' . sides_orgs() . ' ORDER BY id' ); // phpcs:ignore
	?>
	<div class="wrap">
		<h1><img src="<?php echo esc_url( plugin_dir_url( OPTIK_KARNE_FILE ) . 'assets/atlas-word.png' ); ?>" alt="ATLAS" height="44" style="vertical-align:middle"> <span style="font-size:14px;font-weight:400;color:#50575e;vertical-align:middle">Akademik Takip ve Analiz Sistemi · Gelişiminin haritasını keşfet.</span></h1>
		<p style="font-size:15px">Akademik Takip ve Analiz Sistemi. Denemeleri, optik okutmayı, analizleri ve karneleri yönetmek için sistemi açın.</p>
		<p><a class="button button-primary button-hero" href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener">ATLAS'ı aç</a></p>
		<p>Giriş ve kayıt adresi: <code><?php echo esc_html( $url ); ?></code></p>

		<?php if ( current_user_can( 'manage_options' ) ) : ?>
		<h2>Kayıt ayarları</h2>
		<form method="post">
			<?php wp_nonce_field( 'sides_ayar' ); ?>
			<input type="hidden" name="sides_ayar" value="1">
			<p><label>Yeni kayıt: <select name="yontem">
				<?php foreach ( array( 'kod_onay' => 'Etkinleştirme koduyla hemen açılır, kodsuz başvuru onayımı bekler', 'sonra_kod' => 'Önce kayıt, sonra girişte etkinleştirme kodu sorulur', 'kod' => 'Yalnızca etkinleştirme koduyla', 'acik' => 'Herkes hemen girer (önerilmez)', 'kapali' => 'Kayıt kapalı' ) as $k => $t ) : ?>
				<option value="<?php echo esc_attr( $k ); ?>" <?php selected( sides_kayit_yontemi(), $k ); ?>><?php echo esc_html( $t ); ?></option>
				<?php endforeach; ?></select></label></p>
			<p class="description">Başvuruları onaylamak ve etkinleştirme kodu üretmek için ATLAS içinde <strong>Ana Hesap</strong> menüsünü kullanın.</p>
			<p><label><input type="checkbox" name="dogrulama" value="1" <?php checked( sides_opt_dogrulama() ); ?>> Kayıtta e-posta doğrulama kodu zorunlu olsun</label></p>
			<p><label><input type="checkbox" name="ana_sayfa" value="1" <?php checked( sides_ana_sayfa() ); ?>> Sitenin ana sayfası ATLAS olsun</label></p>
			<p class="description">Bu siteyi yalnızca ATLAS için kullanıyorsanız (ör. ayrı bir alan adında) işaretleyin: alan adınızı açan kişi doğrudan giriş sayfasını görür, kayıt adresi <code><?php echo esc_html( home_url( '/?sayfa=kaydol' ) ); ?></code> olur. <code>/sides/</code> adresi de çalışmaya devam eder.</p>
			<h2>Hesap güvenliği</h2>
			<p><label><input type="checkbox" name="tek_oturum" value="1" <?php checked( sides_opt_tek_oturum() ); ?>> Tek oturum: bir hesap aynı anda yalnızca bir cihazda açık kalsın (yeni giriş önceki oturumu kapatır)</label></p>
			<p><label><input type="checkbox" name="cihaz_dogrulama" value="1" <?php checked( sides_opt_cihaz_dogrulama() ); ?>> Yeni cihazdan girişte hesabın e-postasına doğrulama kodu gönderilsin</label></p>
			<p class="description">Bu kurallar kurum kullanıcılarına uygulanır; site yöneticisi hesabınız bunların dışındadır. Kurum yöneticileri, kullanıcılarının giriş geçmişini ve açık oturumlarını ATLAS içinde Kullanıcılar ve Yetkiler sayfasından görür.</p>
			<p class="description">Doğrulama kodu WordPress'in e-posta gönderimiyle iletilir. Siteniz e-posta gönderemiyorsa kodlar ulaşmaz; bu durumda bir SMTP eklentisi kurun.</p>
			<?php submit_button( 'Kaydet' ); ?>
		</form>
		<?php endif; ?>

		<h2>Kurum alanları</h2>
		<table class="widefat striped" style="max-width:900px">
			<thead><tr><th>No</th><th>Kurum</th><th>Hesabı açan</th><th>Kullanıcı</th><th>Açılış</th></tr></thead>
			<tbody>
			<?php foreach ( $orgs as $o ) :
				$owner = $o->sahip ? get_userdata( (int) $o->sahip ) : null;
				$n     = count( get_users( array( 'meta_key' => 'sides_org', 'meta_value' => (string) $o->id, 'fields' => 'ID' ) ) );
				?>
				<tr><td><?php echo (int) $o->id; ?></td><td><?php echo esc_html( $o->ad ); ?></td><td><?php echo esc_html( $owner ? $owner->user_email : ( 1 === (int) $o->id ? 'Site yöneticileri' : '—' ) ); ?></td><td><?php echo (int) $n; ?></td><td><?php echo esc_html( mysql2date( 'd.m.Y', $o->olusturma ) ); ?></td></tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<p class="description">1 numaralı alan sitenin kendi kurumudur; WordPress yöneticileri ve editörleri bu alanda “Yönetici” olarak çalışır. Eski sürümdeki tüm veriler bu alana taşındı.</p>

		<h2>Roller</h2>
		<ul style="list-style:disc;padding-left:20px">
			<li><strong>Yönetici:</strong> kurumundaki her şeyi görür ve yönetir; kullanıcı ekler ve yetki verir.</li>
			<li><strong>Personel:</strong> başlangıçta her şeyi görür ve düzenler; yönetici modül bazında “yalnızca görüntüleme” veya “kapalı” yapabilir.</li>
			<li><strong>Gözlemci:</strong> tüm ekranları görür ama hiçbir işlem yapamaz; öğrenci adları ve telefonlar gizlenir.</li>
			<li><strong>Öğretmen (okutma):</strong> yalnızca optik form okutur.</li>
		</ul>
	</div>
	<?php
}

add_shortcode( 'optik_karne', function ( $atts ) {
	$a = shortcode_atts( array( 'yazi' => 'ATLAS\'a giriş' ), $atts );
	return '<div class="wp-block-buttons"><div class="wp-block-button"><a class="wp-block-button__link wp-element-button" href="' . esc_url( optik_karne_url() ) . '">' . esc_html( $a['yazi'] ) . '</a></div></div>';
} );

add_filter( 'plugin_action_links_' . plugin_basename( OPTIK_KARNE_FILE ), function ( $links ) {
	array_unshift( $links, '<a href="' . esc_url( optik_karne_url() ) . '" target="_blank">Aç</a>' );
	return $links;
} );
