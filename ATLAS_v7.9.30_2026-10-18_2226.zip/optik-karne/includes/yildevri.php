<?php
/**
 * v6 T09 dönem üyeliği ve K07 yıl devri.
 *
 * students/<id>.donemler: [ { yil, sinif, sube, bas 'YYYY-MM-DD', bit 'YYYY-MM-DD', devir? } ] — önceki sınıf/şube üyelikleri;
 *   güncel sınıf students.sinif/sube'de kalır. Genel kayıt yolunda (PUT doc/students) sunucu listeyi korur: istemci dönem silemez/değiştiremez,
 *   sınıf ya da şube değişince önceki üyelik eklenir (aynı gün içindeki ikinci düzeltme yeni kayıt üretmez).
 *   Yıl devri durumu: students.durum 'mezun' | 'ayrildi' + pasif: true + ayrilis 'YYYY-MM-DD' (kayıt hiçbir zaman silinmez).
 *
 * Belgeler (coll: sistem; genel uçlardan okunmaz, yedeğe girer):
 *   devir_<islemId> { durum: basladi|tamam|kismi, hedefYil, tarih, yedek {dosya, ad, t}, plan: [ { id, es, eb, ys, yb, d } ],
 *                     ogrenciler: { sid: { eski: {sinif, sube, pasif, durum}, yeni: {sinif, sube, durum} } }, atlanan: { sid: neden }, uid, u, t, geriAlindi, geriAlan }
 *   devir_son       { id } — geri alınabilecek son devir
 * Uçlar (yalnız kurum yöneticisi):
 *   GET  yildevri          son devirler (özet)
 *   POST yildevri/yedek    kurum yedeği alır (yedek.php) → { dosya, ad, t }
 *   POST yildevri/uygula   { islemId, hedefYil, yedek, ogrenciler: [ { id, eskiSinif, eskiSube, yeniSinif, yeniSube, durum: aktif|mezun|ayrildi } ] }
 *   POST yildevri/geriAl   { islemId } — yalnızca son devir; devirden sonra elle değiştirilmiş öğrenciye dokunulmaz
 */
defined( 'ABSPATH' ) || exit;

define( 'SIDES_YD_SINIF', array( '3', '4', 'N5', '5', '6', '7', '8' ) );

/* ---------- T09 ---------- */
function sides_donem_bugun() {
	return ( new DateTime( 'now', new DateTimeZone( 'Europe/Istanbul' ) ) )->format( 'Y-m-d' );
}
function sides_donem_tarih( $v ) {
	return is_string( $v ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) ? $v : '';
}
function sides_donem_temiz( $l ) {
	$o = array();
	foreach ( is_array( $l ) ? $l : array() as $x ) {
		if ( ! is_array( $x ) ) {
			continue;
		}
		$e = array(
			'yil'   => max( 0, min( 2100, (int) ( isset( $x['yil'] ) ? $x['yil'] : 0 ) ) ),
			'sinif' => mb_substr( (string) ( isset( $x['sinif'] ) ? $x['sinif'] : '' ), 0, 12 ),
			'sube'  => mb_substr( (string) ( isset( $x['sube'] ) ? $x['sube'] : '' ), 0, 12 ),
			'bas'   => sides_donem_tarih( isset( $x['bas'] ) ? $x['bas'] : '' ),
			'bit'   => sides_donem_tarih( isset( $x['bit'] ) ? $x['bit'] : '' ),
		);
		if ( ! empty( $x['devir'] ) && preg_match( '/^[A-Za-z0-9_\-]{6,40}$/', (string) $x['devir'] ) ) {
			$e['devir'] = (string) $x['devir'];
		}
		$o[] = $e;
	}
	return array_slice( $o, -60 );
}
function sides_donem_norm( $s, $k ) {
	$v = isset( $s[ $k ] ) ? trim( (string) $s[ $k ] ) : '';
	return 'sube' === $k ? mb_strtoupper( $v, 'UTF-8' ) : strtoupper( $v );
}
/* Önceki üyeliğin başlangıcı: son dönemin bitişi, yoksa kayıt tarihi, yoksa o eğitim yılının ilk günü */
function sides_donem_bas( $org, $s, $son, $bugun, $yil = 0 ) {
	if ( $son && $son['bit'] ) {
		return $son['bit'];
	}
	foreach ( array( 'kayitTarihi', 'kayit' ) as $k ) {
		if ( isset( $s[ $k ] ) && sides_donem_tarih( substr( (string) $s[ $k ], 0, 10 ) ) && substr( (string) $s[ $k ], 0, 10 ) <= $bugun ) {
			return substr( (string) $s[ $k ], 0, 10 );
		}
	}
	$a = sides_egitim_ayar( $org );
	$y = $yil ? $yil : sides_egitim_yili( $org, $bugun );
	$b = sprintf( '%04d-%02d-01', $y, $a['basAy'] );
	return $b <= $bugun ? $b : $bugun;
}
/* PUT doc/students: dönem listesini sunucudaki hâliyle korur; sınıf/şube değiştiyse önceki üyeliği ekler */
function sides_donem_birlestir( $org, $id, $d ) {
	$eski = sides_get_doc( $org, 'students', $id );
	$l    = $eski ? sides_donem_temiz( isset( $eski['donemler'] ) ? $eski['donemler'] : null ) : array();
	if ( $eski && '' !== sides_donem_norm( $eski, 'sinif' ) && ( sides_donem_norm( $eski, 'sinif' ) !== sides_donem_norm( $d, 'sinif' ) || sides_donem_norm( $eski, 'sube' ) !== sides_donem_norm( $d, 'sube' ) ) ) {
		$bugun = sides_donem_bugun();
		$son   = $l ? $l[ count( $l ) - 1 ] : null;
		if ( ! $son || $son['bit'] !== $bugun ) {   // aynı gün içindeki ikinci düzeltme yeni dönem kaydı üretmez
			$l[] = array( 'yil' => sides_egitim_yili( $org, $bugun ), 'sinif' => trim( (string) $eski['sinif'] ), 'sube' => trim( (string) ( isset( $eski['sube'] ) ? $eski['sube'] : '' ) ), 'bas' => sides_donem_bas( $org, $eski, $son, $bugun ), 'bit' => $bugun );
		}
	}
	if ( $l ) {
		$d['donemler'] = array_values( $l );
	} else {
		unset( $d['donemler'] );
	}
	// Yıl devri durumu (pasif, durum, ayrilis) öğrenci düzenleme formu bu alanları göndermediğinde korunur; açıkça pasif:false gelirse öğrenci yeniden etkinleşir
	if ( $eski && ! array_key_exists( 'pasif', $d ) ) {
		foreach ( array( 'pasif', 'durum', 'ayrilis' ) as $k ) {
			if ( isset( $eski[ $k ] ) && ! array_key_exists( $k, $d ) ) {
				$d[ $k ] = $eski[ $k ];
			}
		}
	} elseif ( array_key_exists( 'pasif', $d ) && empty( $d['pasif'] ) ) {
		unset( $d['pasif'], $d['ayrilis'] );
		if ( empty( $d['durum'] ) || in_array( $d['durum'], array( 'mezun', 'ayrildi' ), true ) ) {
			unset( $d['durum'] );
		}
	} elseif ( ! empty( $d['pasif'] ) ) {
		$d['pasif'] = true;
		$d['durum'] = isset( $d['durum'] ) && in_array( $d['durum'], array( 'mezun', 'ayrildi' ), true ) ? $d['durum'] : ( $eski && isset( $eski['durum'] ) ? $eski['durum'] : 'ayrildi' );
	}
	return $d;
}

/* ---------- K07 ---------- */
add_action( 'rest_api_init', function () {
	$ns  = 'optik-karne/v1';
	$yon = function () {
		$c = sides_ctx();
		return ( $c['org'] && 'yonetici' === $c['rol'] && empty( $c['onizleme'] ) ) ? true : sides_deny( 'Yıl devrini yalnızca kurum yöneticisi yapabilir.' );
	};
	register_rest_route( $ns, '/yildevri', array( 'methods' => 'GET', 'callback' => 'sides_rest_yd_liste', 'permission_callback' => $yon ) );
	register_rest_route( $ns, '/yildevri/yedek', array( 'methods' => 'POST', 'callback' => 'sides_rest_yd_yedek', 'permission_callback' => $yon ) );
	register_rest_route( $ns, '/yildevri/uygula', array( 'methods' => 'POST', 'callback' => 'sides_rest_yd_uygula', 'permission_callback' => $yon ) );
	register_rest_route( $ns, '/yildevri/geriAl', array( 'methods' => 'POST', 'callback' => 'sides_rest_yd_geri', 'permission_callback' => $yon ) );
} );

function sides_yd_ozet( $x ) {
	$o = isset( $x['ogrenciler'] ) ? (array) $x['ogrenciler'] : array();
	$s = array( 'gecen' => 0, 'kalan' => 0, 'mezun' => 0, 'ayrildi' => 0 );
	foreach ( $o as $h ) {
		$y = isset( $h['yeni'] ) ? (array) $h['yeni'] : array();
		$e = isset( $h['eski'] ) ? (array) $h['eski'] : array();
		$d = isset( $y['durum'] ) ? $y['durum'] : 'aktif';
		if ( 'mezun' === $d || 'ayrildi' === $d ) {
			$s[ $d ]++;
		} elseif ( isset( $y['sinif'], $e['sinif'] ) && (string) $y['sinif'] === (string) $e['sinif'] ) {
			$s['kalan']++;
		} else {
			$s['gecen']++;
		}
	}
	$at = array();
	foreach ( isset( $x['atlanan'] ) ? (array) $x['atlanan'] : array() as $sid => $n ) {
		$at[] = array( 'id' => (string) $sid, 'neden' => (string) $n );
	}
	return array(
		'islemId'    => isset( $x['islemId'] ) ? $x['islemId'] : '',
		'durum'      => isset( $x['durum'] ) ? $x['durum'] : '',
		'hedefYil'   => (int) ( isset( $x['hedefYil'] ) ? $x['hedefYil'] : 0 ),
		'tarih'      => isset( $x['tarih'] ) ? $x['tarih'] : '',
		't'          => (int) ( isset( $x['t'] ) ? $x['t'] : 0 ),
		'u'          => isset( $x['u'] ) ? $x['u'] : '',
		'yedek'      => isset( $x['yedek'] ) ? $x['yedek'] : null,
		'uygulanan'  => count( $o ),
		'sayilar'    => $s,
		'atlanan'    => $at,
		'planDisi'   => (int) ( isset( $x['planDisi'] ) ? $x['planDisi'] : 0 ),
		'geriAlindi' => ! empty( $x['geriAlindi'] ),
		'geriAlan'   => isset( $x['geriAlan'] ) ? $x['geriAlan'] : null,
	);
}
function sides_rest_yd_liste() {
	global $wpdb;
	$org = sides_org_id();
	$t   = sides_docs();
	$out = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = 'sistem' AND id LIKE %s", $org, 'devir%' ) ) as $r ) { // phpcs:ignore
		if ( 'devir_son' === $r->id || 0 !== strpos( $r->id, 'devir_' ) ) {
			continue;
		}
		$d = json_decode( $r->data, true );
		if ( is_array( $d ) ) {
			$out[] = sides_yd_ozet( $d );
		}
	}
	usort( $out, function ( $a, $b ) { return $b['t'] - $a['t']; } );
	$son = sides_get_doc( $org, 'sistem', 'devir_son' );
	$a   = sides_egitim_ayar( $org );
	return array( 'devirler' => array_slice( $out, 0, 10 ), 'sonId' => $son && ! empty( $son['islemId'] ) ? (string) $son['islemId'] : '', 'egitimYili' => sides_egitim_yili( $org ), 'basAy' => $a['basAy'], 'bugun' => sides_donem_bugun() );
}
function sides_rest_yd_yedek() {
	$org = sides_org_id();
	if ( ! function_exists( 'sides_yedek_yaz' ) ) {
		return new WP_Error( 'sides_yedek', 'Yedekleme bileşeni bulunamadı.', array( 'status' => 500 ) );
	}
	if ( ! sides_rl( 'yd_yedek_' . get_current_user_id(), 10, 600 ) ) {
		return new WP_Error( 'sides_hiz', 'Çok sık yedek isteği; biraz bekleyin.', array( 'status' => 429 ) );
	}
	$x = sides_yedek_kilitli( function () use ( $org ) {
		return sides_yedek_yaz( 'kurum', $org, 'elle' );
	} );
	if ( null === $x ) {
		return new WP_Error( 'sides_yedek', 'Şu anda başka bir yedekleme sürüyor. Bir dakika sonra tekrar deneyin.', array( 'status' => 409 ) );
	}
	if ( is_wp_error( $x ) ) {
		return $x;
	}
	sides_log( $org, 'Yıl devri öncesi veri yedeği alındı' );
	return array( 'dosya' => $x['dosya'], 'ad' => sides_yedek_dosya_adi( $x ), 't' => (int) $x['t'], 'boyut' => (int) $x['boyut'], 'sayilar' => $x['sayilar'] );
}
/* Devirden önce alınmış (en çok 2 saat önce) bu kurumun yedeği mi? */
function sides_yd_yedek_dogrula( $org, $dosya ) {
	if ( ! function_exists( 'sides_yedek_liste' ) || ! is_string( $dosya ) || ! sides_yedek_ad_gecerli( $dosya ) ) {
		return null;
	}
	$l = sides_yedek_liste();
	if ( ! isset( $l[ $dosya ] ) ) {
		return null;
	}
	$x = $l[ $dosya ];
	if ( 'kurum' !== $x['kapsam'] || (int) $x['org'] !== (int) $org || (int) $x['t'] < time() - 2 * HOUR_IN_SECONDS ) {
		return null;
	}
	return array( 'dosya' => $dosya, 'ad' => sides_yedek_dosya_adi( $x ), 't' => (int) $x['t'] );
}
function sides_yd_sube( $v ) {
	$v = mb_strtoupper( trim( preg_replace( '/[^\p{L}\p{N} \-]/u', '', (string) $v ) ), 'UTF-8' );
	return mb_substr( $v, 0, 10 );
}
function sides_rest_yd_uygula( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$p   = (array) $req->get_json_params();
	$iid = isset( $p['islemId'] ) ? (string) $p['islemId'] : '';
	$cur = sides_egitim_yili( $org );
	$hy  = (int) ( isset( $p['hedefYil'] ) ? $p['hedefYil'] : 0 );
	if ( ! preg_match( '/^[A-Za-z0-9_\-]{6,40}$/', $iid ) || $hy < $cur - 1 || $hy > $cur + 1 ) {
		return new WP_Error( 'sides_gecersiz', 'Geçersiz devir isteği (işlem kimliği ya da hedef eğitim yılı).', array( 'status' => 400 ) );
	}
	@set_time_limit( 300 ); // phpcs:ignore
	$kilit = sides_takip_kilit( $org . '|sistem|yildevri' );
	if ( false === $kilit ) {
		return sides_kilit_mesgul();
	}
	$did = 'devir_' . $iid;
	$x   = sides_get_doc( $org, 'sistem', $did );
	$bit = function ( $r ) use ( &$kilit ) {
		sides_takip_kilit_birak( $kilit );
		return $r;
	};
	if ( $x ) {
		unset( $x['id'], $x['token'] );
		if ( ! empty( $x['geriAlindi'] ) ) {
			return $bit( new WP_Error( 'sides_gecersiz', 'Bu devir geri alınmış; yeniden yapmak için sihirbazı baştan başlatın.', array( 'status' => 409 ) ) );
		}
		if ( (int) $x['hedefYil'] !== $hy ) {
			return $bit( new WP_Error( 'sides_gecersiz', 'Bu işlem kimliği başka bir devir için kullanılmış.', array( 'status' => 409 ) ) );
		}
		if ( 'tamam' === $x['durum'] ) {
			return $bit( array_merge( sides_yd_ozet( $x ), array( 'yinelenen' => true ) ) );
		}
	} else {
		$yedek = sides_yd_yedek_dogrula( $org, isset( $p['yedek'] ) ? $p['yedek'] : '' );
		if ( ! $yedek ) {
			return $bit( new WP_Error( 'sides_yedek_yok', 'Devirden önce taze bir kurum yedeği alınmalı (son 2 saat içinde). “Yedek al” adımını tamamlayın.', array( 'status' => 400 ) ) );
		}
		$sonD = sides_get_doc( $org, 'sistem', 'devir_son' );
		if ( $sonD && ! empty( $sonD['islemId'] ) ) {
			$sx = sides_get_doc( $org, 'sistem', 'devir_' . $sonD['islemId'] );
			if ( $sx && empty( $sx['geriAlindi'] ) && (int) $sx['hedefYil'] === $hy ) {
				return $bit( new WP_Error( 'sides_gecersiz', 'Bu eğitim yılı için devir zaten yapıldı (' . ( isset( $sx['tarih'] ) ? $sx['tarih'] : '' ) . '). Yeniden yapmak için önce son devri geri alın.', array( 'status' => 409 ) ) );
			}
		}
		$liste = isset( $p['ogrenciler'] ) && is_array( $p['ogrenciler'] ) ? $p['ogrenciler'] : array();
		if ( ! $liste || count( $liste ) > 5000 ) {
			return $bit( new WP_Error( 'sides_gecersiz', 'Devredilecek öğrenci listesi boş ya da çok uzun.', array( 'status' => 400 ) ) );
		}
		$plan = array();
		$gor  = array();
		foreach ( $liste as $o ) {
			$o   = (array) $o;
			$sid = isset( $o['id'] ) ? (string) $o['id'] : '';
			$d   = isset( $o['durum'] ) ? (string) $o['durum'] : 'aktif';
			$ys  = strtoupper( trim( (string) ( isset( $o['yeniSinif'] ) ? $o['yeniSinif'] : '' ) ) );
			if ( ! preg_match( '/^[A-Za-z0-9_\-]{1,40}$/', $sid ) || isset( $gor[ $sid ] ) || ! in_array( $d, array( 'aktif', 'mezun', 'ayrildi' ), true ) || ( 'aktif' === $d && ! in_array( $ys, SIDES_YD_SINIF, true ) ) ) {
				return $bit( new WP_Error( 'sides_gecersiz', 'Listede geçersiz satır var (öğrenci ' . esc_html( $sid ) . '); sayfayı yenileyip tekrar deneyin.', array( 'status' => 400 ) ) );
			}
			$gor[ $sid ] = 1;
			$plan[]      = array( 'id' => $sid, 'es' => trim( (string) ( isset( $o['eskiSinif'] ) ? $o['eskiSinif'] : '' ) ), 'eb' => trim( (string) ( isset( $o['eskiSube'] ) ? $o['eskiSube'] : '' ) ), 'ys' => 'aktif' === $d ? $ys : '', 'yb' => 'aktif' === $d ? sides_yd_sube( isset( $o['yeniSube'] ) ? $o['yeniSube'] : '' ) : '', 'd' => $d );
		}
		$u = wp_get_current_user();
		$x = array( 'islemId' => $iid, 'durum' => 'basladi', 'hedefYil' => $hy, 'tarih' => sides_donem_bugun(), 't' => time(), 'uid' => (int) $u->ID, 'u' => $u->display_name ? $u->display_name : $u->user_login, 'yedek' => $yedek, 'plan' => $plan, 'ogrenciler' => array(), 'atlanan' => array(), 'geriAlindi' => false );
		if ( false === sides_put_doc( $org, 'sistem', $did, array_merge( $x, array( 'ogrenciler' => (object) array(), 'atlanan' => (object) array() ) ) ) || false === sides_put_doc( $org, 'sistem', 'devir_son', array( 'islemId' => $iid ) ) ) {
			return $bit( new WP_Error( 'sides_db', 'Devir kaydı yazılamadı; hiçbir öğrenci değişmedi.', array( 'status' => 500 ) ) );
		}
	}
	$x['ogrenciler'] = isset( $x['ogrenciler'] ) ? (array) $x['ogrenciler'] : array();
	$x['atlanan']    = isset( $x['atlanan'] ) ? (array) $x['atlanan'] : array();
	$yaz             = function () use ( $org, $did, &$x ) {
		return false !== sides_put_doc( $org, 'sistem', $did, array_merge( $x, array( 'ogrenciler' => (object) $x['ogrenciler'], 'atlanan' => (object) $x['atlanan'] ) ) );
	};
	$bugun = sides_donem_bugun();
	$oy    = $hy - 1;   // devredilen (biten) eğitim yılı
	$hata  = 0;
	$n     = 0;
	$planI = array();
	foreach ( $x['plan'] as $pl ) {
		$sid           = (string) $pl['id'];
		$planI[ $sid ] = 1;
		if ( isset( $x['ogrenciler'][ $sid ] ) || isset( $x['atlanan'][ $sid ] ) ) {
			continue;
		}
		$s = sides_get_doc( $org, 'students', $sid );
		if ( ! $s ) {
			$x['atlanan'][ $sid ] = 'Öğrenci kaydı bulunamadı.';
			continue;
		}
		unset( $s['id'], $s['token'] );
		$dl  = sides_donem_temiz( isset( $s['donemler'] ) ? $s['donemler'] : null );
		$var = null;
		foreach ( $dl as $e ) {
			if ( isset( $e['devir'] ) && $e['devir'] === $iid ) {
				$var = $e;
			}
		}
		if ( $var ) {   // önceki denemede uygulanmış (çökme sonrası): ikinci kez uygulanmaz
			$x['ogrenciler'][ $sid ] = array( 'eski' => array( 'sinif' => $var['sinif'], 'sube' => $var['sube'], 'pasif' => false, 'durum' => null ), 'yeni' => array( 'sinif' => isset( $s['sinif'] ) ? (string) $s['sinif'] : '', 'sube' => isset( $s['sube'] ) ? (string) $s['sube'] : '', 'durum' => ! empty( $s['pasif'] ) && isset( $s['durum'] ) ? $s['durum'] : 'aktif' ) );
			continue;
		}
		if ( ! empty( $s['pasif'] ) ) {
			$x['atlanan'][ $sid ] = 'Öğrenci zaten pasif (mezun ya da ayrılmış).';
			continue;
		}
		if ( sides_donem_norm( $s, 'sinif' ) !== strtoupper( $pl['es'] ) || sides_donem_norm( $s, 'sube' ) !== mb_strtoupper( $pl['eb'], 'UTF-8' ) ) {
			$x['atlanan'][ $sid ] = 'Önizlemeden sonra sınıfı/şubesi değişmiş; dokunulmadı.';
			continue;
		}
		$eski = array( 'sinif' => isset( $s['sinif'] ) ? (string) $s['sinif'] : '', 'sube' => isset( $s['sube'] ) ? (string) $s['sube'] : '', 'pasif' => false, 'durum' => isset( $s['durum'] ) ? $s['durum'] : null );
		$son  = $dl ? $dl[ count( $dl ) - 1 ] : null;
		$dl[] = array( 'yil' => $oy, 'sinif' => $eski['sinif'], 'sube' => $eski['sube'], 'bas' => sides_donem_bas( $org, $s, $son, $bugun, $oy ), 'bit' => $bugun, 'devir' => $iid );
		$s['donemler'] = $dl;
		if ( 'aktif' === $pl['d'] ) {
			$s['sinif'] = $pl['ys'];
			$s['sube']  = $pl['yb'];
			$yeni       = array( 'sinif' => $pl['ys'], 'sube' => $pl['yb'], 'durum' => 'aktif' );
		} else {
			$s['durum']   = $pl['d'];
			$s['pasif']   = true;
			$s['ayrilis'] = $bugun;
			$yeni         = array( 'sinif' => $eski['sinif'], 'sube' => $eski['sube'], 'durum' => $pl['d'] );
		}
		if ( false === sides_put_doc( $org, 'students', $sid, $s ) ) {
			$hata++;
			continue;   // 'kismi': tekrar denemede yalnızca bu öğrenciler işlenir
		}
		$x['ogrenciler'][ $sid ] = array( 'eski' => $eski, 'yeni' => $yeni );
		if ( 0 === ( ++$n % 20 ) ) {
			$yaz();
		}
	}
	// önizlemeden sonra eklenen etkin öğrenciler (planda yok): dokunulmaz, raporda sayılır
	$pd = 0;
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( 'SELECT id, data FROM ' . sides_docs() . " WHERE org = %d AND coll = 'students'", $org ) ) as $r ) { // phpcs:ignore
		$s = json_decode( $r->data, true );
		if ( ! isset( $planI[ $r->id ] ) && is_array( $s ) && empty( $s['pasif'] ) ) {
			$pd++;
		}
	}
	$x['planDisi'] = $pd;
	$x['durum']    = $hata ? 'kismi' : 'tamam';
	$ok            = $yaz();
	sides_takip_kilit_birak( $kilit );
	$oz = sides_yd_ozet( $x );
	sides_log( $org, 'Yıl devri (' . $hy . '–' . ( $hy + 1 ) . '): ' . $oz['sayilar']['gecen'] . ' öğrenci sınıf geçti, ' . $oz['sayilar']['kalan'] . ' kaldı, ' . $oz['sayilar']['mezun'] . ' mezun, ' . $oz['sayilar']['ayrildi'] . ' ayrıldı' . ( $oz['atlanan'] ? ', ' . count( $oz['atlanan'] ) . ' atlandı' : '' ) . ( $hata ? ', ' . $hata . ' kaydedilemedi' : '' ) );
	if ( ! $ok || $hata ) {
		return new WP_Error( 'sides_yd_kismi', 'Devir kısmen uygulandı (' . $oz['uygulanan'] . ' öğrenci); ' . ( $hata ? $hata . ' öğrenci kaydedilemedi. ' : '' ) . '“Uygula”ya tekrar basarsanız yalnızca kalanlar işlenir.', array( 'status' => 409, 'sonuc' => $oz ) );
	}
	return $oz;
}
function sides_rest_yd_geri( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = (array) $req->get_json_params();
	$iid = isset( $p['islemId'] ) ? (string) $p['islemId'] : '';
	if ( ! preg_match( '/^[A-Za-z0-9_\-]{6,40}$/', $iid ) ) {
		return new WP_Error( 'sides_gecersiz', 'Geçersiz işlem kimliği.', array( 'status' => 400 ) );
	}
	@set_time_limit( 300 ); // phpcs:ignore
	$kilit = sides_takip_kilit( $org . '|sistem|yildevri' );
	if ( false === $kilit ) {
		return sides_kilit_mesgul();
	}
	$son = sides_get_doc( $org, 'sistem', 'devir_son' );
	$x   = sides_get_doc( $org, 'sistem', 'devir_' . $iid );
	if ( ! $x || ! $son || (string) $son['islemId'] !== $iid ) {
		sides_takip_kilit_birak( $kilit );
		return new WP_Error( 'sides_gecersiz', 'Yalnızca son yapılan yıl devri geri alınabilir.', array( 'status' => 409 ) );
	}
	if ( ! empty( $x['geriAlindi'] ) ) {
		sides_takip_kilit_birak( $kilit );
		return new WP_Error( 'sides_gecersiz', 'Bu devir zaten geri alınmış.', array( 'status' => 409 ) );
	}
	unset( $x['id'], $x['token'] );
	$geri  = 0;
	$degis = array();
	foreach ( (array) $x['ogrenciler'] as $sid => $h ) {
		$sid = (string) $sid;
		$s   = sides_get_doc( $org, 'students', $sid );
		if ( ! $s ) {
			$degis[] = $sid;
			continue;
		}
		unset( $s['id'], $s['token'] );
		$dl = sides_donem_temiz( isset( $s['donemler'] ) ? $s['donemler'] : null );
		$ix = -1;
		foreach ( $dl as $i => $e ) {
			if ( isset( $e['devir'] ) && $e['devir'] === $iid ) {
				$ix = $i;
			}
		}
		$y    = (array) $h['yeni'];
		$ayni = 'aktif' === $y['durum']
			? ( empty( $s['pasif'] ) && sides_donem_norm( $s, 'sinif' ) === strtoupper( (string) $y['sinif'] ) && sides_donem_norm( $s, 'sube' ) === mb_strtoupper( (string) $y['sube'], 'UTF-8' ) )
			: ( ! empty( $s['pasif'] ) && isset( $s['durum'] ) && $s['durum'] === $y['durum'] );
		if ( $ix < 0 || ! $ayni ) {   // devirden sonra elle değiştirilmiş: dokunulmaz
			$degis[] = $sid;
			continue;
		}
		$e          = (array) $h['eski'];
		$s['sinif'] = (string) $e['sinif'];
		$s['sube']  = (string) $e['sube'];
		unset( $s['pasif'], $s['ayrilis'] );
		if ( ! empty( $e['durum'] ) ) {
			$s['durum'] = $e['durum'];
		} else {
			unset( $s['durum'] );
		}
		array_splice( $dl, $ix, 1 );
		if ( $dl ) {
			$s['donemler'] = array_values( $dl );
		} else {
			unset( $s['donemler'] );
		}
		if ( false !== sides_put_doc( $org, 'students', $sid, $s ) ) {
			$geri++;
		} else {
			$degis[] = $sid;
		}
	}
	$u               = wp_get_current_user();
	$x['geriAlindi'] = true;
	$x['geriAlan']   = array( 't' => time(), 'uid' => (int) $u->ID, 'u' => $u->display_name ? $u->display_name : $u->user_login, 'geri' => $geri, 'degismis' => $degis );
	$x['ogrenciler'] = (object) $x['ogrenciler'];
	$x['atlanan']    = (object) ( isset( $x['atlanan'] ) ? $x['atlanan'] : array() );
	sides_put_doc( $org, 'sistem', 'devir_' . $iid, $x );
	sides_takip_kilit_birak( $kilit );
	sides_log( $org, 'Yıl devri geri alındı (' . $geri . ' öğrenci' . ( $degis ? ', ' . count( $degis ) . ' öğrenci sonradan değiştiği için atlandı' : '' ) . ')' );
	return array( 'islemId' => $iid, 'geri' => $geri, 'degismis' => count( $degis ), 'degismisler' => $degis );
}
