<?php
/* ------------------------------------------------------------------ *
 * v6 K02/K03 Ders oturumları
 * dplan/<id>    { gun 1–7 (Pazartesi=1), bas, bit, ders, ogretmen{u?,ad}, sinif, sube, derslik?, aktif }
 * doturum/<YYYY-MM-DD>_<planId|uid> { tarih, bas, bit, ders, ogretmen{u?,ad}, sinif, sube, planId?, durum plan|yapildi|iptal|telafi,
 *               konu, not, yoklama{sid:V|Y|G|I|H}, telafiIcin? }
 * Plandan gelen oturum, ilk düzenlemede kaydedilir; sınıfı her zaman plandan alınır (istemcinin gönderdiği sınıf yetki için kullanılmaz).
 * Yoklama: POST oturum/yama (kilit + geçmiş). Genel PUT /doc yoklama göndermezse eski yoklama korunur.
 * ------------------------------------------------------------------ */
defined( 'ABSPATH' ) || exit;

define( 'SIDES_OT_ID', '/^(\d{4}-\d{2}-\d{2})_([A-Za-z0-9_\-]{1,53})$/' );
define( 'SIDES_OT_YK', array( 'V', 'Y', 'G', 'I', 'H' ) );

add_action( 'rest_api_init', function () {
	$ns = 'optik-karne/v1';
	register_rest_route( $ns, '/oturum/yama', array( 'methods' => 'POST', 'callback' => 'sides_ot_yama', 'permission_callback' => 'sides_kt_yazar' ) );
	register_rest_route( $ns, '/oturum/ogretmenler', array( 'methods' => 'GET', 'callback' => 'sides_ot_ogretmenler', 'permission_callback' => 'sides_kt_yazar' ) );
} );

/* Öğretmen: kullanıcı kimliği yalnız bu kurumun panel kullanıcısıysa saklanır; ad zorunlu */
function sides_ot_ogretmen( $org, $v ) {
	$v  = is_array( $v ) ? $v : array();
	$o  = array( 'ad' => sides_kt_metin( isset( $v['ad'] ) ? $v['ad'] : '', 80 ) );
	$u  = isset( $v['u'] ) && is_numeric( $v['u'] ) ? (int) $v['u'] : 0;
	if ( $u > 0 ) {
		$c = sides_ctx( $u );
		$k = get_userdata( $u );
		if ( $k && (int) $c['org'] === (int) $org && in_array( $c['rol'], array( 'yonetici', 'personel' ), true ) ) {
			$o['u'] = $u;
			if ( '' === $o['ad'] ) {
				$o['ad'] = mb_substr( $k->display_name, 0, 80 );
			}
		}
	}
	return $o;
}
function sides_ot_plan_denetim( $org, $id, $d ) {
	$eski = sides_get_doc( $org, 'dplan', $id );
	$g    = isset( $d['gun'] ) && is_numeric( $d['gun'] ) ? (int) $d['gun'] : 0;
	$o    = array(
		'gun'      => $g,
		'bas'      => sides_kt_saat( isset( $d['bas'] ) ? $d['bas'] : '' ),
		'bit'      => sides_kt_saat( isset( $d['bit'] ) ? $d['bit'] : '' ),
		'ders'     => sides_kt_metin( isset( $d['ders'] ) ? $d['ders'] : '', 60 ),
		'ogretmen' => sides_ot_ogretmen( $org, isset( $d['ogretmen'] ) ? $d['ogretmen'] : null ),
		'sinif'    => sides_kt_sinif( isset( $d['sinif'] ) ? $d['sinif'] : '' ),
		'sube'     => sides_kt_sube( isset( $d['sube'] ) ? $d['sube'] : '' ),
		'derslik'  => sides_kt_metin( isset( $d['derslik'] ) ? $d['derslik'] : '', 40 ),
		'aktif'    => ! isset( $d['aktif'] ) || ! empty( $d['aktif'] ),
	);
	if ( $g < 1 || $g > 7 ) {
		return sides_kt_hata( 'Gün geçersiz.' );
	}
	if ( ! $o['bas'] || ! $o['bit'] || $o['bas'] >= $o['bit'] ) {
		return sides_kt_hata( 'Başlangıç ve bitiş saatini kontrol edin (bitiş başlangıçtan sonra olmalı).' );
	}
	if ( '' === $o['ders'] || '' === $o['sinif'] ) {
		return sides_kt_hata( 'Ders ve sınıf zorunlu.' );
	}
	if ( '' === $o['ogretmen']['ad'] ) {
		return sides_kt_hata( 'Öğretmen adını yazın.' );
	}
	if ( ! sides_kt_kapsam( $o['sinif'], $o['sube'] ) || ( is_array( $eski ) && ! sides_kt_kapsam( isset( $eski['sinif'] ) ? $eski['sinif'] : '', isset( $eski['sube'] ) ? $eski['sube'] : '' ) ) ) {
		return sides_deny( 'Bu ders planı satırı, yetkili olduğunuz sınıfların dışında.' );
	}
	return $o;
}
/* Henüz kaydedilmemiş oturumun plan satırı (kimlik <tarih>_<planId>, satır etkin ve günü tutuyor) */
function sides_ot_plan_satiri( $org, $id ) {
	if ( ! preg_match( SIDES_OT_ID, $id, $m ) || ! sides_kt_tarih( $m[1] ) ) {
		return null;
	}
	$p = sides_get_doc( $org, 'dplan', $m[2] );
	if ( ! is_array( $p ) || ( isset( $p['aktif'] ) && ! $p['aktif'] ) || (int) ( isset( $p['gun'] ) ? $p['gun'] : 0 ) !== (int) gmdate( 'N', strtotime( $m[1] . ' 12:00:00 UTC' ) ) ) {
		return null;
	}
	return $p;
}
function sides_ot_plandan( $id, $p ) {
	preg_match( SIDES_OT_ID, $id, $m );
	return array(
		'tarih'    => $m[1],
		'bas'      => isset( $p['bas'] ) ? $p['bas'] : '',
		'bit'      => isset( $p['bit'] ) ? $p['bit'] : '',
		'ders'     => isset( $p['ders'] ) ? $p['ders'] : '',
		'ogretmen' => isset( $p['ogretmen'] ) && is_array( $p['ogretmen'] ) ? $p['ogretmen'] : array( 'ad' => '' ),
		'sinif'    => isset( $p['sinif'] ) ? $p['sinif'] : '',
		'sube'     => isset( $p['sube'] ) ? $p['sube'] : '',
		'planId'   => $m[2],
		'durum'    => 'plan',
		'konu'     => '',
		'not'      => '',
		'yoklama'  => (object) array(),
	);
}
function sides_ot_denetim( $org, $id, $d ) {
	if ( ! preg_match( SIDES_OT_ID, $id, $m ) || ! sides_kt_tarih( $m[1] ) ) {
		return sides_kt_hata( 'Geçersiz oturum kimliği.' );
	}
	$eski = sides_get_doc( $org, 'doturum', $id );
	$eski = is_array( $eski ) ? $eski : null;
	$plan = $eski ? null : sides_ot_plan_satiri( $org, $id );
	$o    = array(
		'tarih'    => $m[1],
		'bas'      => sides_kt_saat( isset( $d['bas'] ) ? $d['bas'] : '' ),
		'bit'      => sides_kt_saat( isset( $d['bit'] ) ? $d['bit'] : '' ),
		'ders'     => sides_kt_metin( isset( $d['ders'] ) ? $d['ders'] : '', 60 ),
		'ogretmen' => sides_ot_ogretmen( $org, isset( $d['ogretmen'] ) ? $d['ogretmen'] : null ),
	);
	/* sınıf: kayıtlı oturumda değişmez; plandan gelen oturumda plandan; plansız/telafi oturumunda istemciden */
	if ( $eski ) {
		$o['sinif'] = isset( $eski['sinif'] ) ? (string) $eski['sinif'] : '';
		$o['sube']  = isset( $eski['sube'] ) ? (string) $eski['sube'] : '';
		if ( ! empty( $eski['planId'] ) ) {
			$o['planId'] = (string) $eski['planId'];
		}
	} elseif ( $plan ) {
		$o['sinif']  = isset( $plan['sinif'] ) ? (string) $plan['sinif'] : '';
		$o['sube']   = isset( $plan['sube'] ) ? (string) $plan['sube'] : '';
		$o['planId'] = $m[2];
	} else {
		$o['sinif'] = sides_kt_sinif( isset( $d['sinif'] ) ? $d['sinif'] : '' );
		$o['sube']  = sides_kt_sube( isset( $d['sube'] ) ? $d['sube'] : '' );
	}
	if ( '' === $o['bas'] && $plan ) {
		$o['bas'] = (string) $plan['bas'];
		$o['bit'] = (string) $plan['bit'];
	}
	if ( ! $o['bas'] || ! $o['bit'] || $o['bas'] >= $o['bit'] ) {
		return sides_kt_hata( 'Başlangıç ve bitiş saatini kontrol edin (bitiş başlangıçtan sonra olmalı).' );
	}
	if ( '' === $o['ders'] || '' === $o['sinif'] ) {
		return sides_kt_hata( 'Ders ve sınıf zorunlu.' );
	}
	if ( ! sides_kt_kapsam( $o['sinif'], $o['sube'], true ) ) {
		return sides_deny( 'Bu ders oturumu, yetkili olduğunuz sınıfların dışında.' );
	}
	$du         = isset( $d['durum'] ) ? (string) $d['durum'] : 'plan';
	$o['durum'] = in_array( $du, array( 'plan', 'yapildi', 'iptal', 'telafi' ), true ) ? $du : null;
	if ( null === $o['durum'] ) {
		return sides_kt_hata( 'Geçersiz oturum durumu.' );
	}
	$o['konu'] = sides_kt_metin( isset( $d['konu'] ) ? $d['konu'] : '', 300 );
	$o['not']  = sides_kt_uzun( isset( $d['not'] ) ? $d['not'] : '', 1000 );
	if ( isset( $d['telafiIcin'] ) && '' !== $d['telafiIcin'] ) {
		if ( ! is_scalar( $d['telafiIcin'] ) || ! preg_match( SIDES_OT_ID, (string) $d['telafiIcin'] ) ) {
			return sides_kt_hata( 'Geçersiz telafi bağlantısı.' );
		}
		$o['telafiIcin'] = (string) $d['telafiIcin'];
	}
	$izin = sides_takip_izin( $org );
	$eY   = $eski && isset( $eski['yoklama'] ) ? (array) $eski['yoklama'] : array();
	$Y    = isset( $d['yoklama'] ) && is_array( $d['yoklama'] ) ? sides_kt_harita_birlestir( $d['yoklama'], $eY, $izin, function ( $v ) {
		return in_array( $v, SIDES_OT_YK, true ) ? $v : null;
	} ) : $eY;
	if ( is_wp_error( $Y ) ) {
		return $Y;
	}
	$o['yoklama'] = (object) $Y;
	return $o;
}

/* POST oturum/yama { id, degerler: { sid: V|Y|G|I|H|null } } → güncel oturum (yoksa plandan oluşturulur) */
function sides_ot_yama( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	$id  = isset( $p['id'] ) && is_scalar( $p['id'] ) ? (string) $p['id'] : '';
	$deg = isset( $p['degerler'] ) && is_array( $p['degerler'] ) ? $p['degerler'] : array();
	if ( ! preg_match( SIDES_OT_ID, $id ) || ! $deg || count( $deg ) > 600 ) {
		return sides_kt_hata( 'Geçersiz kayıt.' );
	}
	foreach ( $deg as $k => $v ) {
		if ( ! sides_kt_sid( $k ) || ! ( null === $v || '' === $v || in_array( $v, SIDES_OT_YK, true ) ) ) {
			return sides_kt_hata( 'Geçersiz yoklama değeri.' );
		}
	}
	$kilit = sides_takip_kilit( $org . '|doturum|' . $id );
	if ( false === $kilit ) {
		return sides_kilit_mesgul();
	}
	$sonuc = sides_ot_yama_uygula( $org, $id, $deg );
	sides_takip_kilit_birak( $kilit );
	return $sonuc;
}
function sides_ot_yama_uygula( $org, $id, $deg ) {
	$d = sides_get_doc( $org, 'doturum', $id );
	if ( ! is_array( $d ) ) {
		$p = sides_ot_plan_satiri( $org, $id );
		if ( ! $p ) {
			return sides_kt_hata( 'Ders oturumu bulunamadı; sayfayı yenileyin.', 404 );
		}
		$d = sides_ot_plandan( $id, $p );
	}
	unset( $d['id'], $d['token'] );
	$izin = sides_takip_izin( $org );
	$red  = sides_deny( 'Bu öğrenci, yetkili olduğunuz sınıfların dışında.' );
	if ( ! sides_kt_kapsam( isset( $d['sinif'] ) ? $d['sinif'] : '', isset( $d['sube'] ) ? $d['sube'] : '', true ) ) {
		return sides_deny( 'Bu ders oturumu, yetkili olduğunuz sınıfların dışında.' );
	}
	$Y  = isset( $d['yoklama'] ) ? (array) $d['yoklama'] : array();
	$Y0 = $Y;
	foreach ( $deg as $sid => $v ) {
		$sid = (string) $sid;
		if ( null !== $izin && ! isset( $izin[ $sid ] ) ) {
			return $red;
		}
		if ( null === $v || '' === $v ) {
			unset( $Y[ $sid ] );
		} else {
			$Y[ $sid ] = $v;
		}
	}
	$d['yoklama'] = (object) $Y;
	if ( $Y && ( ! isset( $d['durum'] ) || 'plan' === $d['durum'] ) ) {
		$d['durum'] = 'yapildi';   // yoklaması alınan planlı ders gerçekleşmiş sayılır
	}
	if ( false === sides_put_doc( $org, 'doturum', $id, $d ) ) {
		return new WP_Error( 'sides_db', 'Kaydedilemedi.', array( 'status' => 500 ) );
	}
	sides_tk_gecmis_yaz( $org, 'doturum', $id, 'yoklama', $Y0, $Y );
	$out       = sides_v6_suz( 'doturum', json_decode( wp_json_encode( $d ), true ), $izin );
	$out['id'] = $id;
	return $out;
}

/* GET oturum/ogretmenler → [{ u, ad }] (kurumun yönetici ve personel kullanıcıları; yalnız ad) */
function sides_ot_ogretmenler() {
	$out = array();
	foreach ( sides_org_users( sides_org_id() ) as $u ) {
		if ( in_array( $u['rol'], array( 'yonetici', 'personel' ), true ) ) {
			$out[] = array( 'u' => (int) $u['id'], 'ad' => (string) $u['ad'] );
		}
	}
	$me = wp_get_current_user();
	if ( $me && $me->ID && ! in_array( (int) $me->ID, array_column( $out, 'u' ), true ) ) {
		$out[] = array( 'u' => (int) $me->ID, 'ad' => $me->display_name );
	}
	return $out;
}
