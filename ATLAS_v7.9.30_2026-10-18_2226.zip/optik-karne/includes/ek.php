<?php
/**
 * v7 Ek Kataloğu ve şema tabanlı ek modüller (EK çekirdek).
 *
 * Etkinleştirme durumu (coll: sistem, id: ekmodul; genel /doc ve /all uçlarından okunmaz, yedeğe girer):
 *   { moduller: { EK01: { durum: kapali|pilot|aktif|arsiv, kapsam: herkes|secili, kullanicilar: [uid], sorumlu: { u, ad },
 *                         hedef, kontrol (öğretmen kontrolü notu), degerlendirme, gecmis: [ { t, uid, ad, islem, ... } ] } }, surum }
 *   Varsayılan: EK02, EK03, EK15, EK16 aktif/herkes; diğerleri kapalı. EK12 hiçbir zaman 'herkes' olamaz.
 *
 * Görünürlük kuralı (istemcideki ekRotaAcik ile aynı): yönetici her modülü görür; personel ve gözlemci yalnızca
 * durum pilot/aktif VE (kapsam herkes YA DA kullanıcı listede) VE modül yetkisi ≥ 1 olduğunda görür.
 *
 * Kayıtlar (coll: ekkayit, id: <modül kısa adı>_<uid>): { modul, tarih, sinif?, sube?, ogrenciler?: [studentId], studentId?, alanlar…,
 *   olusturan { u, ad }, olusturma, guncelleme, silindi?, silen?, gecmis: [ { t, u, ad, islem, alanlar } ], islemId }
 *   Kayıtlar genel /doc ve /koleksiyon uçlarından okunmaz (izin listesinde yok); yalnız bu dosyadaki uçlardan geçer.
 *
 * Uçlar (optik-karne/v1):
 *   GET  ek/durum                (ek ≥ 1 ya da sosyal ≥ 1) kullanıcının görebildiği modüller; yöneticiye tam durum + geçmiş
 *   POST ek/durum                (yönetici) { kod, islem: incele|hazirla|pilot|degerlendir|etkinlestir|arsivle|kapat|kapsam, ... }
 *   GET  ek/kayit?modul=&bas=&bit=&sinif=&sube=&ogr=&durum=&silinen=
 *   POST ek/kayit                { modul, id?, islemId, alanlar } oluştur / düzenle
 *   POST ek/kayit/sil            { modul, id }   yumuşak silme
 */
defined( 'ABSPATH' ) || exit;

/* ---------- katalog sözleşmesi ---------- */
function sides_ek_rotalar() {
	return array(
		'EK01' => 'ek.cikti', 'EK02' => 'takip.odev', 'EK03' => 'takip.oturum', 'EK04' => 'ek.tekrar', 'EK05' => 'ek.hatadefter',
		'EK06' => 'ek.bilet', 'EK07' => 'ek.lgs', 'EK08' => 'ek.sure', 'EK09' => 'ek.okuma', 'EK10' => 'ek.kaynak', 'EK11' => 'ek.rutin',
		'EK12' => 'ek.destek', 'EK13' => 'ek.veli', 'EK14' => 'ek.dahili', 'EK15' => 'sosyal.yarisma', 'EK16' => 'sosyal.yarisma',
		'EK17' => 'sosyal.origami', 'EK18' => 'sosyal.stem', 'EK19' => 'sosyal.munazara', 'EK20' => 'sosyal.spor', 'EK21' => 'sosyal.medya',
		'EK22' => 'ek.gozlem', 'EK23' => 'ek.deney', 'EK24' => 'ek.belge',
	);
}
/* Modülün yetki modülü (sides_can): rotanın ilk parçası */
function sides_ek_yetki_mod( $kod ) {
	$r = sides_ek_rotalar();
	return isset( $r[ $kod ] ) ? strtok( $r[ $kod ], '.' ) : 'ek';
}
function sides_ek_varsayilan_tek( $kod ) {
	$acik = in_array( $kod, array( 'EK02', 'EK03', 'EK15', 'EK16' ), true );
	return array( 'durum' => $acik ? 'aktif' : 'kapali', 'kapsam' => $acik ? 'herkes' : 'secili', 'kullanicilar' => array(), 'sorumlu' => null, 'hedef' => '', 'kontrol' => '', 'degerlendirme' => '', 'gecmis' => array() );
}
/* Kurumun etkinleştirme durumu (eksik kodlar varsayılanla tamamlanır). İstek boyunca önbellekte. */
function sides_ek_durum( $org, $tazele = false ) {
	static $c = array();
	$org = (int) $org;
	if ( $tazele || ! isset( $c[ $org ] ) ) {
		$d   = $org ? sides_get_doc( $org, 'sistem', 'ekmodul' ) : null;
		$mod = is_array( $d ) && isset( $d['moduller'] ) && is_array( $d['moduller'] ) ? $d['moduller'] : array();
		$out = array();
		foreach ( array_keys( sides_ek_rotalar() ) as $k ) {
			$e = isset( $mod[ $k ] ) && is_array( $mod[ $k ] ) ? array_merge( sides_ek_varsayilan_tek( $k ), $mod[ $k ] ) : sides_ek_varsayilan_tek( $k );
			if ( ! in_array( $e['durum'], array( 'kapali', 'pilot', 'aktif', 'arsiv' ), true ) ) {
				$e['durum'] = 'kapali';
			}
			if ( 'herkes' !== $e['kapsam'] || 'EK12' === $k ) {
				$e['kapsam'] = 'secili';
			}
			$e['kullanicilar'] = array_values( array_unique( array_map( 'intval', (array) $e['kullanicilar'] ) ) );
			$out[ $k ]         = $e;
		}
		$c[ $org ] = array( 'moduller' => $out, 'surum' => is_array( $d ) && isset( $d['surum'] ) ? (int) $d['surum'] : 0 );
	}
	return $c[ $org ];
}
/* Sözleşme: şu anki kullanıcı bu kurumda bu modülü görebilir mi? (yönetici her zaman) */
function sides_ek_erisim( $org, $kod ) {
	$c = sides_ctx();
	if ( ! $c['org'] || (int) $c['org'] !== (int) $org ) {
		return false;
	}
	if ( 'yonetici' === $c['rol'] ) {
		return true;
	}
	if ( ! in_array( $c['rol'], array( 'personel', 'gozlemci' ), true ) ) {
		return false;
	}
	$st = sides_ek_durum( $org );
	if ( ! isset( $st['moduller'][ $kod ] ) ) {
		return false;
	}
	$e = $st['moduller'][ $kod ];
	if ( ! in_array( $e['durum'], array( 'pilot', 'aktif' ), true ) ) {
		return false;
	}
	$kapsam_ok = ( 'herkes' === $e['kapsam'] && 'EK12' !== $kod ) || in_array( (int) $c['uid'], $e['kullanicilar'], true );
	return $kapsam_ok && sides_can( sides_ek_yetki_mod( $kod ), 1 );
}
/* Açılış yapılandırması (optik-karne.php sides_render_app → OK_CFG.ek): yalnız gerekeni taşır: { kod: { d: durum, a: 0|1 } } */
function sides_ek_boot( $org ) {
	$st  = sides_ek_durum( $org );
	$yon = 'yonetici' === sides_ctx()['rol'];
	$out = array();
	foreach ( $st['moduller'] as $k => $e ) {
		$a = sides_ek_erisim( $org, $k );
		if ( $yon || $a ) {
			$out[ $k ] = array( 'd' => $e['durum'], 'a' => $a ? 1 : 0 );
		}
	}
	return (object) $out;
}

/* ------------------------------------------------------------------ *
 * Şema: modül alanları (tek kaynak). İstemci GET ek/sema ile alır; sunucu doğrulamayı bununla yapar.
 * Alan: k anahtar, t tür (text|textarea|url|date|select|number|checklist|rubrik|tablo|katilim|kullanicilar), l etiket,
 *   max uzunluk, z zorunlu, s seçenekler [[değer, etiket]], min/maks (number), kr ölçütler (rubrik), cols/n (tablo), ic iç not
 *   (gözlemciye, çıktıya, dışa aktarıma gitmez), ust (yazdırmada üst bilgi satırı), b bölüm başlığı, ip ipucu.
 * Modül: kod, kisa (kimlik öneki), form (F kodu), mod (yetki modülü), ogr ('cok'|'tek'|''), ogrZ, sinif (sınıf/şube alanı),
 *   paylasim (ben/modul görünürlüğü), hassas (EK12), durum [[değer, etiket]], baslik (liste başlığı alanları), not (ekran notu).
 * ------------------------------------------------------------------ */
function sides_ek_sema() {
	static $s = null;
	if ( null === $s ) {
		$s = json_decode( <<<'JSON'
{
"ek.okuma":{"kod":"EK09","kisa":"okuma","ad":"Okuma Anlama ve Okuma Kulübü","form":"F08","mod":"ek","ogr":"cok","sinif":1,"baslik":["kitap","bolum"],
 "not":"Sayfa sayısı tek ölçüt değildir: bölüm görevi, kanıtlı yorum ve tartışma kaydı sayfa boş olsa da saklanır. Kullanılan baskı ve çeviri belirtilir; zorlayıcı temalar önceden okunur.",
 "durum":[["onokuma","Ön okuma ve bölüm ataması"],["yorum","Kanıtlı yorum"],["tartisma","Akran tartışması"],["urun","Kısa ürün"],["tamam","Tamamlandı"]],
 "alanlar":[
  {"k":"kitap","t":"text","l":"Kitap ve yazar","max":160,"z":1,"ust":1,"oneri":"kitap"},
  {"k":"baski","t":"text","l":"Baskı / çevirmen","max":120,"ust":1},
  {"k":"duzey","t":"text","l":"Okuma düzeyi / uyarlama","max":80,"ip":"Örneğin daha kısa bölüm"},
  {"k":"bolum","t":"text","l":"Bölüm ve sayfa aralığı","max":80,"ust":1},
  {"k":"sayfa","t":"number","l":"Okunan sayfa (isteğe bağlı)","min":0,"maks":3000},
  {"k":"onOkuma","t":"select","l":"Öğretmen ön okuması","s":[["yapildi","Yapıldı"],["bekliyor","Henüz yapılmadı"]],"ust":1},
  {"k":"ozet","t":"textarea","l":"Bölümün kısa özeti","max":600},
  {"k":"yorum","t":"textarea","l":"Yorum ve destekleyen metin bölümü","max":600,"ip":"Alıntıyı kısa tutun, sayfa bilgisini yazın."},
  {"k":"karar","t":"textarea","l":"Karakterin bir kararı ve başka bir seçenek","max":400},
  {"k":"soru","t":"textarea","l":"Arkadaşa sorulacak soru","max":300},
  {"k":"tartisma","t":"textarea","l":"Tartışmada değişen düşünce","max":300},
  {"k":"urun","t":"textarea","l":"Kısa ürün ve sonraki okuma hedefi","max":400}]},
"ek.kaynak":{"kod":"EK10","kisa":"kaynak","ad":"Öğretmen Kaynak ve Okuma Alanı","form":"F09","mod":"ek","ogr":"","sinif":0,"paylasim":1,"baslik":["kaynak","yazar"],
 "not":"Telifli kitabın tam metni yüklenmez; künye ve kurumun erişimi olan bağlantı tutulur. Kişisel refleksiyon performans değerlendirmesine açılmaz.",
 "durum":[["okunacak","Okunacak"],["denendi","Uygulama denendi"],["degerlendirildi","Değerlendirildi"]],
 "alanlar":[
  {"k":"kaynak","t":"text","l":"Kaynak (künye)","max":200,"z":1,"ust":1,"oneri":"ogretmen"},
  {"k":"yazar","t":"text","l":"Yazar veya kurum","max":160,"ust":1},
  {"k":"tur","t":"select","l":"Tür","s":[["kitap","Kitap"],["rehber","Ücretsiz resmî rehber"],["kurum","Kurum belgesi"]],"ust":1},
  {"k":"dil","t":"select","l":"Dil","s":[["tr","Türkçe"],["en","İngilizce"],["diger","Diğer"]]},
  {"k":"erisim","t":"select","l":"Erişim türü","s":[["ucretsiz","Ücretsiz"],["kurum","Kurum erişimli"],["satin","Satın alınacak"]],"ust":1},
  {"k":"baglanti","t":"url","l":"Erişim bağlantısı","max":300},
  {"k":"bolum","t":"text","l":"Bölüm","max":120},
  {"k":"fikir","t":"textarea","l":"Bu kez denenecek tek uygulama fikri","max":500},
  {"k":"denemeBas","t":"date","l":"Deneme başlangıcı"},
  {"k":"denemeBit","t":"date","l":"Deneme bitişi"},
  {"k":"kanit","t":"textarea","l":"Gözlenen kanıt ve meslektaş görüşmesi","max":500},
  {"k":"degerlendirme","t":"textarea","l":"Değerlendirme ve karar","max":500}]},
"ek.rutin":{"kod":"EK11","kisa":"rutin","ad":"Sınıf Rutinleri ve Olumlu Davranış","form":"F10","mod":"ek","ogr":"cok","sinif":1,"sinifZ":1,"baslik":["rutin","rutinAd"],
 "not":"Gözlenebilir davranış yazılır; kişilik etiketi, teşhis ve herkesin göreceği olumsuz sıralama kullanılmaz. Öğrenci seçimi isteğe bağlıdır.",
 "durum":[["plan","Planlandı"],["prova","Modellendi ve prova edildi"],["takip","Takipte"],["tamam","Tamamlandı"]],
 "alanlar":[
  {"k":"rutin","t":"select","l":"Rutin","z":1,"s":[["baslama","Derse başlama"],["soz","Söz alma"],["materyal","Materyal toplama"],["grup","Grup çalışması"],["diger","Diğer"]],"ust":1},
  {"k":"rutinAd","t":"text","l":"Rutin adı / ayrıntı","max":120,"ust":1},
  {"k":"ortam","t":"text","l":"Gözlem ortamı","max":120,"ust":1},
  {"k":"beklenen","t":"textarea","l":"Beklenen davranış ve öğrencinin göreceği örnek","max":500,"z":1},
  {"k":"modelleme","t":"textarea","l":"Öğretmenin modellemesi ve kısa prova","max":500},
  {"k":"olay","t":"textarea","l":"Gözlenebilir olay (zaman ve davranış)","max":500},
  {"k":"destek","t":"textarea","l":"Öğretmen desteği","max":400},
  {"k":"sonuc","t":"text","l":"Sonuç","max":200},
  {"k":"geriBildirim","t":"textarea","l":"Davranışa özgü geri bildirim cümlesi","max":300},
  {"k":"takipTarih","t":"date","l":"Takip tarihi"}]},
"ek.destek":{"kod":"EK12","kisa":"destek","ad":"Bireysel Destek ve Görüşme","form":"F11","mod":"ek","ogr":"tek","ogrZ":1,"sinif":0,"hassas":1,"baslik":["sorumlu"],
 "not":"Sınırlı erişimli kayıt: yalnız kaydı yazan, kurum yöneticisi ve kayıtta seçilen kişiler görür. Sistem tanı koymaz, psikolojik puan veya tedavi önerisi üretmez. İçerik genel rapora, TV'ye ve veliye gitmez; kaydı kısa tutun.",
 "durum":[["takip","Takipte"],["kapandi","Kapandı"]],
 "alanlar":[
  {"k":"gozlem","t":"textarea","l":"Gözlenen olay ve bağlam","max":500,"z":1},
  {"k":"ifade","t":"textarea","l":"Öğrencinin kendi ifadesi","max":500,"ip":"Öğrencinin sözünü yorumunuzdan ayrı yazın."},
  {"k":"destek","t":"textarea","l":"Kararlaştırılan destek","max":400},
  {"k":"sorumlu","t":"text","l":"Sorumlu","max":80,"ust":1},
  {"k":"takipNot","t":"textarea","l":"Yetkili rehberlik personeliyle takip","max":400},
  {"k":"sonraki","t":"date","l":"Sonraki görüşme","ust":1},
  {"k":"kullanicilar","t":"kullanicilar","l":"Erişim kapsamı (kaydı görebilecek diğer kişiler)"}]},
"ek.veli":{"kod":"EK13","kisa":"veli","ad":"Veli Görüşmesi ve Rapor","form":"F12","mod":"ek","ogr":"tek","ogrZ":1,"sinif":0,"baslik":["amac"],
 "not":"Veliye giden özet ile kurum içi not ayrıdır. İç not hiçbir çıktıya, veli özetine, rapora ya da TV'ye taşınmaz; gözlemci hesabı göremez.",
 "durum":[["takip","Takipte"],["kontrol","Kontrol edildi"]],
 "alanlar":[
  {"k":"veli","t":"text","l":"Veli / görüşen görevli","max":120,"ust":1,"b":"Görüşme"},
  {"k":"bicim","t":"select","l":"Görüşme biçimi","s":[["yuzyuze","Yüz yüze"],["telefon","Telefon"],["cevrimici","Çevrim içi"]],"ust":1},
  {"k":"amac","t":"text","l":"Görüşme amacı","max":200,"z":1},
  {"k":"veliOzet","t":"textarea","l":"Veliyle paylaşılacak kısa ilerleme özeti","max":600,"b":"Veliye giden özet"},
  {"k":"karar","t":"textarea","l":"Birlikte kararlaştırılan takip görevi","max":400},
  {"k":"sonraki","t":"date","l":"Sonraki kontrol tarihi","ust":1},
  {"k":"paylas","t":"checklist","l":"Veli çıktısına eklenecek alanlar","s":[["veliOzet","İlerleme özeti"],["karar","Takip görevi"],["sonraki","Sonraki kontrol tarihi"]]},
  {"k":"icNot","t":"textarea","l":"Kurum içi not (yalnız yetkili personel)","max":600,"ic":1,"b":"İç not"}]},
"ek.dahili":{"kod":"EK14","kisa":"dahili","ad":"Dahili Ders Gelişim ve Uygulama","form":"F01","mod":"ek","ogr":"cok","sinif":1,"baslik":["konu","cikti"],
 "not":"Kurum çıktı kimlikleri resmî akademik çıktı kodlarıyla karıştırılmaz. Akademik test puanı ile kişisel uygulama ayrıntıları tek başarı puanına çevrilmez.",
 "durum":[["islendi","İşlendi"],["kanit","Kanıt bekleniyor"],["destek","Destek gerekiyor"],["dogrulandi","Tekrar doğrulandı"]],
 "alanlar":[
  {"k":"seviye","t":"text","l":"Seviye","max":60,"ust":1},
  {"k":"konu","t":"text","l":"Konu","max":160,"z":1,"ust":1},
  {"k":"cikti","t":"text","l":"Kurum çıktısı (kurum kimliği ve açıklama)","max":200},
  {"k":"boyut","t":"select","l":"Boyut","s":[["bilgi","Bilgi"],["uygulama","Uygulama"],["ikisi","Bilgi ve uygulama"]],"ust":1},
  {"k":"degerlendirme","t":"textarea","l":"Kısa değerlendirme","max":500},
  {"k":"kanit","t":"textarea","l":"Öğretmen kanıtı ve açıklaması","max":500},
  {"k":"destek","t":"textarea","l":"Destek ve tekrar","max":400},
  {"k":"tekrarTarih","t":"date","l":"Tekrar tarihi"}]},
"sosyal.origami":{"kod":"EK17","kisa":"origami","ad":"Origami ve Kâğıt Tasarım","form":"F14","mod":"sosyal","ogr":"cok","sinif":1,"baslik":["etkinlik","etkinlikAd"],
 "not":"Ürün fotoğrafı zorunlu değildir; çizim veya açıklama yeterlidir. Uçak etkinliğinde insanlara yöneltilmeyen boş alan kullanılır. Katılım akademik puana dönüştürülmez.",
 "durum":[["plan","Planlandı"],["yapildi","Yapıldı"],["degerlendirildi","Değerlendirildi"]],
 "alanlar":[
  {"k":"etkinlik","t":"select","l":"Etkinlik","z":1,"s":[["ayrac","Kitap köşesi ayracı"],["ucak","Kâğıt uçak ve kanat deneyi"],["diger","Diğer"]],"ust":1,"b":"Etkinlik planı"},
  {"k":"etkinlikAd","t":"text","l":"Etkinlik adı / ayrıntı","max":120},
  {"k":"malzeme","t":"text","l":"Malzeme ve kâğıt ölçüsü","max":200,"ust":1},
  {"k":"sure","t":"number","l":"Süre (dakika)","min":0,"maks":600},
  {"k":"yonerge","t":"select","l":"Yönerge","s":[["ozgun","Özgün yönerge"],["kaynak","Kaynaktan uyarlandı"]]},
  {"k":"yonergeKaynak","t":"text","l":"Yönerge kaynağı","max":200},
  {"k":"katilim","t":"katilim","l":"Öğrenci katılımı","b":"Katılım"},
  {"k":"zorAdim","t":"textarea","l":"Yönergenin en zor adımı ve çözüm","max":400,"b":"Ürün ve kanıt"},
  {"k":"denemeler","t":"tablo","l":"Denemeler","cols":["Deneme","Değiştirilen özellik","Gözlem","Bir sonraki tasarım"],"n":4},
  {"k":"urun","t":"textarea","l":"Ürün açıklaması / çizim notu","max":400},
  {"k":"simetri","t":"textarea","l":"Simetri veya açı ile ilişki","max":300},
  {"k":"gozlem","t":"textarea","l":"Öğretmen gözlemi","max":400}]},
"sosyal.stem":{"kod":"EK18","kisa":"stem","ad":"STEM ve Üretim Atölyesi","form":"F15","mod":"sosyal","ogr":"cok","sinif":1,"baslik":["soru"],
 "not":"Ölçüm tablosuna yalnız gerçek ölçüm yazılır; örnek beklenen değer sonuç gibi girilmez. Sonuç beklenen gibi çıkmasa da gerçek veri saklanır. Rapor ürün yarışı değil veri, yorum ve iş birliği kanıtıdır.",
 "durum":[["plan","Planlandı"],["yapildi","Yapıldı"],["degerlendirildi","Değerlendirildi"]],
 "alanlar":[
  {"k":"etkinlik","t":"select","l":"Etkinlik","s":[["kopru","Kâğıt köprü"],["tohum","Tohum gözlemi"],["diger","Diğer"]],"ust":1,"b":"Etkinlik planı"},
  {"k":"soru","t":"text","l":"Araştırma sorusu","max":200,"z":1,"ust":1},
  {"k":"tahmin","t":"textarea","l":"Tahmin ve nedeni","max":400},
  {"k":"degisken","t":"text","l":"Değiştirilen koşul (tek değişken)","max":160,"ust":1},
  {"k":"sabit","t":"text","l":"Sabit tutulan koşullar","max":200},
  {"k":"sure","t":"number","l":"Süre (dakika)","min":0,"maks":600},
  {"k":"katilim","t":"katilim","l":"Öğrenci katılımı ve görev","b":"Katılım"},
  {"k":"olcum","t":"tablo","l":"Ölçüm tablosu","cols":["Koşul / tasarım","Ölçüm 1","Ölçüm 2","Ölçüm 3","Ortalama / gözlem"],"n":5,"b":"Ölçüm ve sonuç"},
  {"k":"sonuc","t":"textarea","l":"Sonuç ve tahminle karşılaştırma","max":500},
  {"k":"hata","t":"textarea","l":"Ölçüm hatası ve geliştirilecek adım","max":400}]},
"sosyal.munazara":{"kod":"EK19","kisa":"munazara","ad":"Münazara ve Konuşma Kulübü","form":"F16","mod":"sosyal","ogr":"cok","sinif":1,"baslik":["onerme"],
 "not":"Siyasi veya kişisel hassasiyet içeren konu yerine yaşa uygun okul yaşamı konusu seçilir. Yalnız konuşmacı değil kaynak bulucu ve dinleme rolü de kaydedilir; kazanan tek öğrenme göstergesi değildir.",
 "durum":[["plan","Planlandı"],["yapildi","Yapıldı"],["degerlendirildi","Değerlendirildi"]],
 "alanlar":[
  {"k":"onerme","t":"text","l":"Önerme / konu","max":200,"z":1,"ust":1,"b":"Etkinlik planı"},
  {"k":"takimlar","t":"textarea","l":"Takımlar","max":300},
  {"k":"sure","t":"number","l":"Konuşma süresi (dakika)","min":0,"maks":120,"ust":1},
  {"k":"kaynak","t":"textarea","l":"Kaynaklar ve kanıtlar","max":400},
  {"k":"katilim","t":"katilim","l":"Öğrenci rolleri ve katılım","ip":"Rol: konuşmacı, kaynak bulucu, dinleme…","b":"Katılım"},
  {"k":"karsi","t":"textarea","l":"Karşı argüman ve karşılık","max":400,"b":"Değerlendirme"},
  {"k":"rubrik","t":"rubrik","l":"Rubrik (1–4)","kr":[["kanit","Kanıt"],["aciklik","Açıklık"],["dinleme","Dinleme"],["gorev","Görev paylaşımı"]]},
  {"k":"geriBildirim","t":"textarea","l":"Akran geri bildirimi ve düşünceyi etkileyen kanıt","max":400}]},
"sosyal.spor":{"kod":"EK20","kisa":"spor","ad":"Oyun ve Spor Planı","form":"F16","mod":"sosyal","ogr":"cok","sinif":1,"baslik":["etkinlik"],
 "not":"Kazanmak tek başarı ölçütü değildir; herkesin rolü kayda geçer. Sağlık veya özel gereksinim ayrıntısı bu kayda yazılmaz.",
 "durum":[["plan","Planlandı"],["yapildi","Yapıldı"],["degerlendirildi","Değerlendirildi"]],
 "alanlar":[
  {"k":"etkinlik","t":"text","l":"Etkinlik","max":160,"z":1,"ust":1,"ip":"Örneğin masa tenisi, küçük takım oyunu","b":"Etkinlik planı"},
  {"k":"kural","t":"textarea","l":"Kural, görev ve başarı ölçütü","max":400},
  {"k":"takimlar","t":"textarea","l":"Takımlar ve sıra","max":300},
  {"k":"sure","t":"number","l":"Toplam süre (dakika)","min":0,"maks":600,"ust":1},
  {"k":"katilim","t":"katilim","l":"Katılım ve roller","ip":"Rol: oyuncu, hakem, skor…","b":"Katılım"},
  {"k":"isbirligi","t":"textarea","l":"İş birliği gözlemi","max":400,"b":"Değerlendirme"},
  {"k":"ozDeger","t":"textarea","l":"Öğrenci öz değerlendirmesi özeti","max":400}]},
"sosyal.medya":{"kod":"EK21","kisa":"medya","ad":"Dijital ve Medya Okuryazarlığı","form":"F06","mod":"sosyal","ogr":"cok","sinif":1,"baslik":["icerik"],
 "not":"Öğrencilerden özel hesap veya kişisel veri istenmez. İçerik doğru/yanlış diye otomatik puanlanmaz; doğrulama sınırı yazılır. Yanıtta içerik tarihi ve birincil kaynak birlikte bulunur.",
 "durum":[["plan","Planlandı"],["yapildi","Yapıldı"],["degerlendirildi","Değerlendirildi"]],
 "alanlar":[
  {"k":"icerik","t":"text","l":"İçerik / iddia","max":200,"z":1,"ust":1,"b":"Etkinlik planı"},
  {"k":"kaynak1","t":"text","l":"Birincil kaynak (bağlantı ya da künye)","max":300},
  {"k":"kaynak2","t":"text","l":"Karşılaştırılan ikinci kaynak","max":300},
  {"k":"icerikTarih","t":"date","l":"İçeriğin tarihi","ust":1},
  {"k":"katilim","t":"katilim","l":"Öğrenci katılımı","b":"Katılım"},
  {"k":"dogrulama","t":"textarea","l":"Doğrulama yolu ve sınırı","max":400,"b":"Kanıt ve karar"},
  {"k":"karar","t":"select","l":"Güvenli paylaşım kararı","s":[["paylasilir","Kontrol edildi, paylaşılabilir"],["beklet","Doğrulanamadı, beklet"],["paylasilmaz","Paylaşılmamalı"]]},
  {"k":"gerekce","t":"textarea","l":"Öğrencilerin gerekçesi","max":400}]},
"ek.gozlem":{"kod":"EK22","kisa":"gozlem","ad":"Öğretmen Ders Gözlemi","form":"F09","mod":"ek","ogr":"","sinif":1,"paylasim":1,"baslik":["odak","gozlenen"],
 "not":"Biçimlendirici mesleki gelişim kaydıdır: puan, sıralama ya da otomatik personel kararı yoktur. Gözlenen örnekler ile değerlendirme ayrı alanlarda tutulur.",
 "durum":[["plan","Planlandı"],["gozlendi","Gözlem yapıldı"],["gorusuldu","Kanıtla konuşuldu"],["denendi","Değişiklik denendi"]],
 "alanlar":[
  {"k":"gozlenen","t":"text","l":"Gözlenen öğretmen","max":120,"ust":1},
  {"k":"gozlemci","t":"text","l":"Gözlemi yapan meslektaş","max":120,"ust":1},
  {"k":"ders","t":"text","l":"Ders / oturum","max":120,"ust":1},
  {"k":"odak","t":"text","l":"Öğretmenin seçtiği tek odak","max":200,"z":1},
  {"k":"kanit","t":"textarea","l":"Gözlenen örnekler (kanıt)","max":600},
  {"k":"yorum","t":"textarea","l":"Değerlendirme / yorum","max":400},
  {"k":"refleksiyon","t":"textarea","l":"Öğretmenin kısa refleksiyonu","max":400},
  {"k":"sonrakiDeneme","t":"textarea","l":"Sonraki derste denenecek küçük değişiklik","max":300},
  {"k":"sonrakiTarih","t":"date","l":"Deneme tarihi"}]},
"ek.deney":{"kod":"EK23","kisa":"deney","ad":"Kurum Deneyi ve İyileştirme","form":"F09","mod":"ek","ogr":"","sinif":0,"baslik":["sorun"],
 "not":"Küçük grup verisinden kesin nedensellik veya genelleme yapılmaz; sonuç yerel karar içindir. Pilot verisi mevcut yetki ve gizlilik sınırlarını aşmaz.",
 "durum":[["taslak","Taslak"],["pilot","Pilot"],["degerlendirme","Değerlendirme"],["etkin","Etkin"],["arsiv","Arşiv"]],
 "alanlar":[
  {"k":"sorun","t":"text","l":"Sorun","max":200,"z":1,"ust":1,"b":"Plan"},
  {"k":"baslangic","t":"textarea","l":"Başlangıç göstergesi ve mevcut kanıt","max":500},
  {"k":"hipotez","t":"textarea","l":"Hipotez","max":400,"ip":"Bu küçük değişiklik neyi değiştirecek?"},
  {"k":"degisiklik","t":"textarea","l":"Değiştirilecek tek uygulama","max":400},
  {"k":"pilotGrup","t":"text","l":"Pilot grup","max":160,"ust":1},
  {"k":"bas","t":"date","l":"Pilot başlangıcı","ust":1},
  {"k":"bit","t":"date","l":"Pilot bitişi","ust":1},
  {"k":"olcut","t":"textarea","l":"Ölçüt (neye bakılacak)","max":400},
  {"k":"kanit","t":"textarea","l":"Kanıt / veri","max":600,"b":"Değerlendirme"},
  {"k":"veriKalite","t":"textarea","l":"Veri kalitesi ve eksikler","max":400},
  {"k":"digerEtki","t":"textarea","l":"Olası diğer etkiler ve sınırlılık","max":400},
  {"k":"karar","t":"select","l":"Pilot kararı","s":[["bekliyor","Karar bekliyor"],["devam","Devam"],["genislet","Genişlet"],["geri","Önceki uygulamaya dön"]]},
  {"k":"kararGerekce","t":"textarea","l":"Karar gerekçesi","max":400}]},
"ek.belge":{"kod":"EK24","kisa":"belge","ad":"Belge ve İçerik Merkezi","form":"F01","mod":"ek","ogr":"","sinif":0,"paylasim":1,"baslik":["ad","surumNo"],
 "not":"Belgeler bağlantı olarak tutulur (dosya yüklenmez). Bağlantı ya da sürüm değişince eski sürüm kayıtta korunur. Önizleme bağlantısı, amaç, kaynak ve kontrol eden olmadan \"Hazır\" seçilemez. Hassas kurum belgesi genel öneri listesine konmaz.",
 "durum":[["taslak","Taslak"],["hazir","Hazır"],["arsiv","Arşiv"]],
 "alanlar":[
  {"k":"ad","t":"text","l":"Belge adı","max":160,"z":1,"ust":1},
  {"k":"modul","t":"select","l":"İlgili ek modül","s":[["EK01","EK01"],["EK02","EK02"],["EK03","EK03"],["EK04","EK04"],["EK05","EK05"],["EK06","EK06"],["EK07","EK07"],["EK08","EK08"],["EK09","EK09"],["EK10","EK10"],["EK11","EK11"],["EK12","EK12"],["EK13","EK13"],["EK14","EK14"],["EK15","EK15"],["EK16","EK16"],["EK17","EK17"],["EK18","EK18"],["EK19","EK19"],["EK20","EK20"],["EK21","EK21"],["EK22","EK22"],["EK23","EK23"],["EK24","EK24"]],"ust":1},
  {"k":"dosyaTuru","t":"select","l":"Dosya türü","s":[["pdf","PDF"],["belge","Metin belgesi"],["tablo","Tablo"],["gorsel","Görsel"],["sayfa","Web sayfası"],["basili","Basılı"]],"ust":1},
  {"k":"surumNo","t":"text","l":"Paket / belge sürümü","max":20,"ust":1},
  {"k":"hedef","t":"text","l":"Hedef sınıf / grup","max":120},
  {"k":"sorumlu","t":"text","l":"Sorumlu","max":120},
  {"k":"amac","t":"textarea","l":"Amaç","max":400},
  {"k":"baglanti","t":"url","l":"Belge / önizleme bağlantısı","max":300},
  {"k":"kaynak","t":"text","l":"Kaynak ve lisans","max":200},
  {"k":"kontrol","t":"select","l":"Öğretmen kontrolü","s":[["bekliyor","Kontrol bekliyor"],["yapildi","Kontrol edildi"]]},
  {"k":"kontrolEden","t":"text","l":"Kontrol eden","max":120}]}
}
JSON
			, true );
	}
	return $s;
}

/* ------------------------------------------------------------------ *
 * REST uçları
 * ------------------------------------------------------------------ */
add_action( 'rest_api_init', function () {
	$ns  = 'optik-karne/v1';
	$oku = function () {
		$c = sides_ctx();
		if ( ! $c['org'] || ! in_array( $c['rol'], array( 'yonetici', 'personel', 'gozlemci' ), true ) ) {
			return sides_deny();
		}
		return ( 'yonetici' === $c['rol'] || sides_can( 'ek', 1 ) || sides_can( 'sosyal', 1 ) || sides_can( 'takip', 1 ) ) ? true : sides_deny( 'Ek modüllere erişiminiz kapalı.' );
	};
	$yon = function () {
		$c = sides_ctx();
		return ( $c['org'] && 'yonetici' === $c['rol'] && empty( $c['onizleme'] ) ) ? true : sides_deny( 'Ek Kataloğu yalnızca kurum yöneticisine açıktır.' );
	};
	register_rest_route( $ns, '/ek/durum', array(
		array( 'methods' => 'GET', 'callback' => 'sides_rest_ek_durum', 'permission_callback' => $oku ),
		array( 'methods' => 'POST', 'callback' => 'sides_rest_ek_durum_yaz', 'permission_callback' => $yon ),
	) );
	register_rest_route( $ns, '/ek/sema', array( 'methods' => 'GET', 'callback' => 'sides_rest_ek_sema', 'permission_callback' => $oku ) );
	register_rest_route( $ns, '/ek/kayit', array(
		array( 'methods' => 'GET', 'callback' => 'sides_rest_ek_kayit_liste', 'permission_callback' => $oku ),
		array( 'methods' => 'POST', 'callback' => 'sides_rest_ek_kayit_yaz', 'permission_callback' => $oku ),
	) );
	register_rest_route( $ns, '/ek/kayit/sil', array( 'methods' => 'POST', 'callback' => 'sides_rest_ek_kayit_sil', 'permission_callback' => $oku ) );
	register_rest_route( $ns, '/ek/kayit/geri', array( 'methods' => 'POST', 'callback' => 'sides_rest_ek_kayit_geri', 'permission_callback' => $yon ) );
} );

function sides_ek_hata( $m, $st = 400 ) {
	return new WP_Error( 'sides_ek', $m, array( 'status' => $st ) );
}
function sides_ek_metin( $v, $max, $cok = false ) {
	$v = is_scalar( $v ) ? (string) $v : '';
	$v = $cok ? sanitize_textarea_field( $v ) : sanitize_text_field( $v );
	return mb_substr( trim( $v ), 0, $max );
}
function sides_ek_tarih_ok( $v ) {
	return is_string( $v ) && preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $v, $m ) && checkdate( (int) $m[2], (int) $m[3], (int) $m[1] );
}
/* Kurumun personel/gözlemci kullanıcıları: id => ad */
function sides_ek_personel( $org ) {
	$out = array();
	foreach ( sides_org_users( $org ) as $u ) {
		if ( in_array( $u['rol'], array( 'personel', 'gozlemci', 'yonetici' ), true ) ) {
			$out[ (int) $u['id'] ] = array( 'ad' => $u['ad'], 'rol' => $u['rol'] );
		}
	}
	return $out;
}

/* ---------- etkinleştirme durumu ---------- */
function sides_rest_ek_durum() {
	$org = sides_org_id();
	if ( 'yonetici' !== sides_ctx()['rol'] ) {
		return array( 'ek' => sides_ek_boot( $org ) );
	}
	$st = sides_ek_durum( $org );
	return array( 'ek' => sides_ek_boot( $org ), 'moduller' => $st['moduller'], 'surum' => $st['surum'] );
}
function sides_rest_ek_durum_yaz( $req ) {
	$p     = (array) $req->get_json_params();
	$org   = sides_org_id();
	$kod   = isset( $p['kod'] ) ? (string) $p['kod'] : '';
	$islem = isset( $p['islem'] ) ? (string) $p['islem'] : '';
	if ( ! isset( sides_ek_rotalar()[ $kod ] ) ) {
		return sides_ek_hata( 'Bilinmeyen modül kodu.' );
	}
	$izinli = array( 'incele', 'hazirla', 'kontrol', 'pilot', 'degerlendir', 'etkinlestir', 'arsivle', 'kapat', 'varsayilan' );
	if ( ! in_array( $islem, $izinli, true ) ) {
		return sides_ek_hata( 'Geçersiz işlem.' );
	}
	$kilit = function_exists( 'sides_takip_kilit' ) ? sides_takip_kilit( $org . '|ekmodul' ) : '';
	if ( false === $kilit ) {
		return sides_kilit_mesgul();
	}
	$ham = sides_get_doc( $org, 'sistem', 'ekmodul' );
	$ham = is_array( $ham ) ? $ham : array();
	unset( $ham['id'] );
	$st  = sides_ek_durum( $org, true );
	$e   = $st['moduller'][ $kod ];
	$u   = wp_get_current_user();
	$ad  = $u && $u->ID ? $u->display_name : '';
	$gec = array( 't' => time(), 'uid' => (int) $u->ID, 'ad' => $ad, 'islem' => $islem );
	if ( isset( $p['surum'] ) && (int) $p['surum'] !== (int) $st['surum'] ) {
		if ( $kilit ) {
			sides_takip_kilit_birak( $kilit );
		}
		return sides_ek_hata( 'Katalog bu arada başka bir oturumda değişti. Sayfayı yenileyip tekrar deneyin.', 409 );
	}
	$per = null;
	switch ( $islem ) {
		case 'incele':
			$e['incelendi'] = array( 't' => time(), 'ad' => $ad );
			break;
		case 'hazirla':
			$per    = sides_ek_personel( $org );
			$kapsam = isset( $p['kapsam'] ) && 'herkes' === $p['kapsam'] && 'EK12' !== $kod ? 'herkes' : 'secili';
			$kul    = array();
			foreach ( isset( $p['kullanicilar'] ) && is_array( $p['kullanicilar'] ) ? $p['kullanicilar'] : array() as $x ) {
				$x = (int) $x;
				if ( isset( $per[ $x ] ) && 'yonetici' !== $per[ $x ]['rol'] ) {
					$kul[ $x ] = $x;
				}
			}
			if ( count( $kul ) > 300 ) {
				return sides_ek_hata( 'En çok 300 kullanıcı seçilebilir.' );
			}
			$sor = isset( $p['sorumlu'] ) ? (int) $p['sorumlu'] : 0;
			if ( $sor && ! isset( $per[ $sor ] ) ) {
				if ( $kilit ) {
					sides_takip_kilit_birak( $kilit );
				}
				return sides_ek_hata( 'Sorumlu bu kurumun kullanıcısı değil.' );
			}
			$e['kapsam']       = $kapsam;
			$e['kullanicilar'] = array_values( $kul );
			$e['sorumlu']      = $sor ? array( 'u' => $sor, 'ad' => $per[ $sor ]['ad'] ) : null;
			$e['hedef']        = sides_ek_metin( isset( $p['hedef'] ) ? $p['hedef'] : '', 200 );
			$gec['kapsam']     = $kapsam;
			$gec['kisi']       = count( $kul );
			break;
		case 'kontrol':
			$e['kontrol']      = sides_ek_metin( isset( $p['not'] ) ? $p['not'] : '', 600, true );
			$e['kontrolEden']  = array( 't' => time(), 'ad' => $ad );
			break;
		case 'degerlendir':
			$e['degerlendirme'] = sides_ek_metin( isset( $p['not'] ) ? $p['not'] : '', 600, true );
			break;
		case 'pilot':
			$e['durum'] = 'pilot';
			break;
		case 'etkinlestir':
			$e['durum'] = 'aktif';
			break;
		case 'arsivle':
			$e['durum'] = 'arsiv';
			break;
		case 'kapat':
			$e['durum'] = 'kapali';
			break;
		case 'varsayilan':
			$e = array_merge( sides_ek_varsayilan_tek( $kod ), array( 'gecmis' => $e['gecmis'] ) );
			break;
	}
	$gec['durum']  = $e['durum'];
	$e['gecmis']   = array_slice( array_merge( (array) $e['gecmis'], array( $gec ) ), -100 );
	$mod           = isset( $ham['moduller'] ) && is_array( $ham['moduller'] ) ? $ham['moduller'] : array();
	$mod[ $kod ]   = $e;
	$ham['moduller'] = $mod;
	$ham['surum']    = (int) $st['surum'] + 1;
	$ok              = sides_put_doc( $org, 'sistem', 'ekmodul', $ham );
	if ( $kilit ) {
		sides_takip_kilit_birak( $kilit );
	}
	if ( false === $ok ) {
		return sides_ek_hata( 'Kaydedilemedi. Tekrar deneyin.', 500 );
	}
	$ad_is = array( 'incele' => 'incelendi', 'hazirla' => 'hedef grup ve kapsam kaydedildi', 'kontrol' => 'öğretmen kontrolü notu kaydedildi', 'pilot' => 'pilot başlatıldı', 'degerlendir' => 'değerlendirme kaydedildi', 'etkinlestir' => 'etkinleştirildi', 'arsivle' => 'arşivlendi', 'kapat' => 'kapatıldı', 'varsayilan' => 'varsayılana döndürüldü' );
	sides_log( $org, 'Ek Kataloğu: ' . $kod . ' ' . $ad_is[ $islem ] );
	sides_ek_durum( $org, true );
	return sides_rest_ek_durum();
}

function sides_rest_ek_sema() {
	return sides_ek_sema();
}

/* ---------- kayıtlar ---------- */
/* Modül erişimi: erişim kuralı + modül yetkisi; yazmada gözlemci ve önizleme reddedilir. Şema ya da WP_Error döner. */
function sides_ek_modul_kontrol( $route, $lvl ) {
	$S = sides_ek_sema();
	if ( ! is_string( $route ) || ! isset( $S[ $route ] ) ) {
		return sides_ek_hata( 'Bilinmeyen modül.' );
	}
	$m = $S[ $route ];
	$m['rota'] = $route;
	if ( ! sides_can( $m['mod'], $lvl ) ) {
		return sides_deny( $lvl >= 2 ? 'Bu modülde kayıt yetkiniz yok.' : 'Bu modüle erişiminiz kapalı.' );
	}
	if ( ! sides_ek_erisim( sides_org_id(), $m['kod'] ) ) {
		return sides_deny( 'Bu modül kurumunuzda sizin için etkin değil. Yöneticiniz Ek Kataloğu\'ndan açabilir.' );
	}
	$c = sides_ctx();
	if ( $lvl >= 2 && ( 'gozlemci' === $c['rol'] || ! empty( $c['onizleme'] ) ) ) {
		return sides_deny( 'Gözlemci hesabı kayıt yapamaz.' );
	}
	return $m;
}
function sides_ek_sahip( $d, $uid ) {
	return isset( $d['olusturan']['u'] ) && (int) $d['olusturan']['u'] === (int) $uid;
}
/* Sınıf kısıtlı kullanıcı: kaydın sınıfı ve bütün öğrencileri kapsamda olmalı */
function sides_ek_sinif_ok( $d, $kisit, $izin ) {
	if ( null === $kisit ) {
		return true;
	}
	if ( ! empty( $d['sinif'] ) && ! sides_ogrenci_izinli( array( 'sinif' => $d['sinif'], 'sube' => isset( $d['sube'] ) ? $d['sube'] : '' ), $kisit ) ) {
		return false;
	}
	foreach ( isset( $d['ogrenciler'] ) ? (array) $d['ogrenciler'] : array() as $sid ) {
		if ( ! isset( $izin[ (string) $sid ] ) ) {
			return false;
		}
	}
	return true;
}
function sides_ek_gorunur( $m, $d, $c, $kisit, $izin ) {
	$yon   = 'yonetici' === $c['rol'];
	$sahip = sides_ek_sahip( $d, $c['uid'] );
	if ( ! empty( $m['hassas'] ) ) {
		if ( 'gozlemci' === $c['rol'] ) {
			return false;
		}
		if ( ! $yon && ! $sahip && ! in_array( (int) $c['uid'], array_map( 'intval', isset( $d['kullanicilar'] ) ? (array) $d['kullanicilar'] : array() ), true ) ) {
			return false;
		}
	}
	if ( ! empty( $m['paylasim'] ) && ! $yon && ! $sahip && 'modul' !== ( isset( $d['paylasim'] ) ? $d['paylasim'] : 'ben' ) ) {
		return false;
	}
	return $yon || sides_ek_sinif_ok( $d, $kisit, $izin );
}
/* Düzenleme: hassas kayıtta yalnız yazan ve yönetici; diğerlerinde görebilen her yazma yetkili kullanıcı */
function sides_ek_duzenler( $m, $d, $c ) {
	return 'yonetici' === $c['rol'] || sides_ek_sahip( $d, $c['uid'] ) || empty( $m['hassas'] );
}
/* İstemciye giden kayıt: gözlemciye iç alanlar gitmez */
function sides_ek_cikis( $m, $d, $c ) {
	if ( 'gozlemci' === $c['rol'] ) {
		foreach ( $m['alanlar'] as $a ) {
			if ( ! empty( $a['ic'] ) ) {
				unset( $d[ $a['k'] ] );
			}
		}
		unset( $d['islemId'] );
	}
	$d['duzenle'] = sides_ek_duzenler( $m, $d, $c ) && 'gozlemci' !== $c['rol'] && sides_can( $m['mod'], 2 );
	$d['sil']     = $d['duzenle'] && ( 'yonetici' === $c['rol'] || sides_ek_sahip( $d, $c['uid'] ) );
	return $d;
}
function sides_rest_ek_kayit_liste( $req ) {
	$m = sides_ek_modul_kontrol( (string) $req->get_param( 'modul' ), 1 );
	if ( is_wp_error( $m ) ) {
		return $m;
	}
	global $wpdb;
	$org   = sides_org_id();
	$c     = sides_ctx();
	$kisit = 'yonetici' === $c['rol'] ? null : sides_sinif_kisit();
	$izin  = null === $kisit ? null : sides_izinli_ogrenciler( $org, $kisit );
	$bas   = (string) $req->get_param( 'bas' );
	$bit   = (string) $req->get_param( 'bit' );
	$sinif = sides_ek_metin( $req->get_param( 'sinif' ), 20 );
	$sube  = mb_strtoupper( sides_ek_metin( $req->get_param( 'sube' ), 20 ), 'UTF-8' );
	$ogr   = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $req->get_param( 'ogr' ) );
	$durum = preg_replace( '/[^a-z]/', '', (string) $req->get_param( 'durum' ) );
	$silinen = '1' === (string) $req->get_param( 'silinen' ) && 'yonetici' === $c['rol'];
	$t     = sides_docs();
	$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = 'ekkayit' AND exam_id = %s", $org, $m['rota'] ) ); // phpcs:ignore
	$out   = array();
	foreach ( (array) $rows as $r ) {
		$d = json_decode( $r->data, true );
		if ( ! is_array( $d ) ) {
			continue;
		}
		$d['id'] = $r->id;
		if ( $silinen !== ! empty( $d['silindi'] ) ) {
			continue;
		}
		if ( ! sides_ek_gorunur( $m, $d, $c, $kisit, $izin ) ) {
			continue;
		}
		$tr = isset( $d['tarih'] ) ? (string) $d['tarih'] : '';
		if ( ( sides_ek_tarih_ok( $bas ) && $tr < $bas ) || ( sides_ek_tarih_ok( $bit ) && $tr > $bit ) ) {
			continue;
		}
		if ( '' !== $sinif && ( ! isset( $d['sinif'] ) || (string) $d['sinif'] !== $sinif ) ) {
			continue;
		}
		if ( '' !== $sube && ( ! isset( $d['sube'] ) || (string) $d['sube'] !== $sube ) ) {
			continue;
		}
		if ( '' !== $ogr && ! in_array( $ogr, array_map( 'strval', isset( $d['ogrenciler'] ) ? (array) $d['ogrenciler'] : array() ), true ) ) {
			continue;
		}
		if ( '' !== $durum && ( ! isset( $d['durum'] ) || $d['durum'] !== $durum ) ) {
			continue;
		}
		$out[] = sides_ek_cikis( $m, $d, $c );
	}
	usort( $out, function ( $a, $b ) {
		return strcmp( ( isset( $b['tarih'] ) ? $b['tarih'] : '' ) . ( isset( $b['olusturma'] ) ? $b['olusturma'] : 0 ), ( isset( $a['tarih'] ) ? $a['tarih'] : '' ) . ( isset( $a['olusturma'] ) ? $a['olusturma'] : 0 ) );
	} );
	$fazla = count( $out ) > 500;
	$res   = array( 'kayitlar' => array_slice( $out, 0, 500 ), 'fazla' => $fazla, 'yaz' => sides_can( $m['mod'], 2 ) && 'gozlemci' !== $c['rol'] && empty( $c['onizleme'] ) );
	if ( ! empty( $m['hassas'] ) ) {
		$res['ekip'] = sides_ek_ekip( $org, $m['kod'] );
	}
	return $res;
}
/* Hassas modülde kayda eklenebilecek kişiler: modülün seçili kullanıcıları (adlarıyla) ve yönetici olmayanlar */
function sides_ek_ekip( $org, $kod ) {
	$st  = sides_ek_durum( $org );
	$out = array();
	foreach ( $st['moduller'][ $kod ]['kullanicilar'] as $id ) {
		$c = sides_ctx( (int) $id );
		$u = get_userdata( (int) $id );
		if ( $u && (int) $c['org'] === (int) $org && 'personel' === $c['rol'] && isset( $c['yetki']['ek'] ) && $c['yetki']['ek'] >= 1 ) {
			$out[] = array( 'id' => (int) $id, 'ad' => $u->display_name );
		}
	}
	return $out;
}
/* Şemaya göre doğrulama: temiz alanlar ya da WP_Error */
function sides_ek_dogrula( $m, $g, $org, $c, $ogrenciler ) {
	$o = array();
	foreach ( $m['alanlar'] as $a ) {
		$k = $a['k'];
		$v = isset( $g[ $k ] ) ? $g[ $k ] : null;
		switch ( $a['t'] ) {
			case 'text':
			case 'textarea':
				$v = sides_ek_metin( $v, isset( $a['max'] ) ? (int) $a['max'] : 200, 'textarea' === $a['t'] );
				break;
			case 'url':
				$v = sides_ek_metin( $v, isset( $a['max'] ) ? (int) $a['max'] : 300 );
				if ( '' !== $v && ! preg_match( '#^https?://[^\s<>"]+$#i', $v ) ) {
					return sides_ek_hata( $a['l'] . ': bağlantı http:// ya da https:// ile başlamalı.' );
				}
				$v = '' === $v ? '' : esc_url_raw( $v );
				break;
			case 'date':
				$v = is_string( $v ) && sides_ek_tarih_ok( $v ) ? $v : '';
				break;
			case 'select':
				$ok = array_map( function ( $x ) { return $x[0]; }, $a['s'] );
				$v  = is_string( $v ) && in_array( $v, $ok, true ) ? $v : '';
				break;
			case 'number':
				$v = ( is_numeric( $v ) && (float) $v >= $a['min'] && (float) $v <= $a['maks'] ) ? round( (float) $v, 2 ) : '';
				break;
			case 'checklist':
				$ok = array_map( function ( $x ) { return $x[0]; }, $a['s'] );
				$v  = array_values( array_intersect( $ok, is_array( $v ) ? array_map( 'strval', $v ) : array() ) );
				break;
			case 'rubrik':
				$r = array();
				foreach ( $a['kr'] as $kr ) {
					if ( is_array( $v ) && isset( $v[ $kr[0] ] ) && in_array( (int) $v[ $kr[0] ], array( 1, 2, 3, 4 ), true ) ) {
						$r[ $kr[0] ] = (int) $v[ $kr[0] ];
					}
				}
				$v = (object) $r;
				break;
			case 'tablo':
				$rows = array();
				foreach ( is_array( $v ) ? array_slice( $v, 0, (int) $a['n'] ) : array() as $row ) {
					$cells = array();
					for ( $i = 0; $i < count( $a['cols'] ); $i++ ) {
						$cells[] = sides_ek_metin( is_array( $row ) && isset( $row[ $i ] ) ? $row[ $i ] : '', 80 );
					}
					if ( implode( '', $cells ) !== '' ) {
						$rows[] = $cells;
					}
				}
				$v = $rows;
				break;
			case 'katilim':
				$r = array();
				foreach ( $ogrenciler as $sid ) {
					if ( is_array( $v ) && isset( $v[ $sid ] ) && is_array( $v[ $sid ] ) ) {
						$dd = isset( $v[ $sid ]['d'] ) && in_array( $v[ $sid ]['d'], array( 'K', 'Y', 'I' ), true ) ? $v[ $sid ]['d'] : '';
						$rr = sides_ek_metin( isset( $v[ $sid ]['r'] ) ? $v[ $sid ]['r'] : '', 80 );
						if ( '' !== $dd || '' !== $rr ) {
							$r[ $sid ] = array( 'd' => $dd, 'r' => $rr );
						}
					}
				}
				$v = (object) $r;
				break;
			case 'kullanicilar':
				$ekip = array();
				foreach ( sides_ek_ekip( $org, $m['kod'] ) as $x ) {
					$ekip[ $x['id'] ] = true;
				}
				$r = array();
				foreach ( is_array( $v ) ? $v : array() as $x ) {
					$x = (int) $x;
					if ( isset( $ekip[ $x ] ) && $x !== (int) $c['uid'] ) {
						$r[ $x ] = $x;
					}
				}
				$v = array_values( $r );
				break;
			default:
				$v = '';
		}
		if ( ! empty( $a['z'] ) && ( '' === $v || array() === $v ) ) {
			return sides_ek_hata( $a['l'] . ' alanı zorunludur.' );
		}
		$o[ $k ] = $v;
	}
	return $o;
}
function sides_rest_ek_kayit_yaz( $req ) {
	$p = (array) $req->get_json_params();
	$m = sides_ek_modul_kontrol( isset( $p['modul'] ) ? (string) $p['modul'] : '', 2 );
	if ( is_wp_error( $m ) ) {
		return $m;
	}
	$org   = sides_org_id();
	$c     = sides_ctx();
	$yon   = 'yonetici' === $c['rol'];
	$kisit = $yon ? null : sides_sinif_kisit();
	$izin  = null === $kisit ? null : sides_izinli_ogrenciler( $org, $kisit );
	$g     = isset( $p['alanlar'] ) && is_array( $p['alanlar'] ) ? $p['alanlar'] : array();
	$id    = isset( $p['id'] ) ? (string) $p['id'] : '';
	$islem = isset( $p['islemId'] ) ? (string) $p['islemId'] : '';
	$eski  = null;
	if ( '' !== $id ) {
		if ( ! preg_match( '/^' . $m['kisa'] . '_[A-Za-z0-9]{6,40}$/', $id ) ) {
			return sides_ek_hata( 'Geçersiz kayıt.' );
		}
	} else {
		if ( ! preg_match( '/^[A-Za-z0-9]{6,40}$/', $islem ) ) {
			return sides_ek_hata( 'İşlem kimliği eksik.' );
		}
		$id = $m['kisa'] . '_' . $islem;
	}
	$kilit = function_exists( 'sides_takip_kilit' ) ? sides_takip_kilit( $org . '|ekkayit|' . $id ) : '';
	if ( false === $kilit ) {
		return sides_kilit_mesgul();
	}
	$bitir = function ( $x ) use ( $kilit ) {
		if ( $kilit ) {
			sides_takip_kilit_birak( $kilit );
		}
		return $x;
	};
	$eski = sides_get_doc( $org, 'ekkayit', $id );
	if ( $eski && empty( $p['id'] ) ) {
		// aynı islemId ile tekrar gönderim: ikinci kayıt oluşmaz
		if ( sides_ek_sahip( $eski, $c['uid'] ) ) {
			$eski['tekrar'] = true;
			return $bitir( sides_ek_cikis( $m, $eski, $c ) );
		}
		return $bitir( sides_ek_hata( 'Bu işlem kimliği kullanılmış.', 409 ) );
	}
	if ( ! empty( $p['id'] ) ) {
		if ( ! $eski || ! empty( $eski['silindi'] ) ) {
			return $bitir( sides_ek_hata( 'Kayıt bulunamadı ya da silinmiş.', 404 ) );
		}
		if ( ! sides_ek_gorunur( $m, $eski, $c, $kisit, $izin ) || ! sides_ek_duzenler( $m, $eski, $c ) ) {
			return $bitir( sides_deny( 'Bu kaydı değiştirme yetkiniz yok.' ) );
		}
		if ( isset( $p['surum'] ) && (int) $p['surum'] !== (int) ( isset( $eski['surum'] ) ? $eski['surum'] : 0 ) ) {
			return $bitir( sides_ek_hata( 'Kayıt bu arada başka biri tarafından değiştirildi. Listeyi yenileyip tekrar deneyin.', 409 ) );
		}
	}
	// ortak alanlar
	$tarih = isset( $g['tarih'] ) && sides_ek_tarih_ok( $g['tarih'] ) ? $g['tarih'] : '';
	if ( '' === $tarih ) {
		return $bitir( sides_ek_hata( 'Tarih alanı zorunludur.' ) );
	}
	$yeni = array( 'modul' => $m['rota'], 'tarih' => $tarih );
	if ( ! empty( $m['sinif'] ) ) {
		$snf = sides_ek_metin( isset( $g['sinif'] ) ? $g['sinif'] : '', 20 );
		$sb  = mb_strtoupper( sides_ek_metin( isset( $g['sube'] ) ? $g['sube'] : '', 20 ), 'UTF-8' );
		if ( '' === $snf && ! empty( $m['sinifZ'] ) ) {
			return $bitir( sides_ek_hata( 'Sınıf seçin.' ) );
		}
		$yeni['sinif'] = $snf;
		$yeni['sube']  = '' === $snf ? '' : $sb;
	}
	$ogrenciler = array();
	if ( ! empty( $m['ogr'] ) ) {
		$tum = array();
		foreach ( isset( $g['ogrenciler'] ) && is_array( $g['ogrenciler'] ) ? array_slice( $g['ogrenciler'], 0, 200 ) : array() as $sid ) {
			$sid = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $sid );
			if ( '' !== $sid ) {
				$tum[ $sid ] = $sid;
			}
		}
		$ogrenciler = array_values( $tum );
		if ( 'tek' === $m['ogr'] && count( $ogrenciler ) > 1 ) {
			return $bitir( sides_ek_hata( 'Bu kayıtta yalnız bir öğrenci seçilebilir.' ) );
		}
		if ( ! empty( $m['ogrZ'] ) && ! $ogrenciler ) {
			return $bitir( sides_ek_hata( 'Öğrenci seçin.' ) );
		}
		if ( null !== $izin ) {   // sınıf kısıtı önce: kapsam dışı öğrencinin varlığı da açığa çıkmaz
			foreach ( $ogrenciler as $sid ) {
				if ( ! isset( $izin[ $sid ] ) ) {
					return $bitir( sides_deny( 'Yalnız yetkili olduğunuz sınıfların öğrencileri için kayıt yapabilirsiniz.' ) );
				}
			}
		}
		foreach ( $ogrenciler as $sid ) {
			$s = sides_get_doc( $org, 'students', $sid );
			if ( ! $s ) {
				return $bitir( sides_ek_hata( 'Seçilen öğrencilerden biri bulunamadı.' ) );
			}
			if ( ! empty( $yeni['sinif'] ) && ( (string) $s['sinif'] !== (string) $yeni['sinif'] || ( '' !== $yeni['sube'] && mb_strtoupper( trim( (string) ( isset( $s['sube'] ) ? $s['sube'] : '' ) ), 'UTF-8' ) !== $yeni['sube'] ) ) ) {
				return $bitir( sides_ek_hata( 'Seçilen öğrenciler kaydın sınıf ve şubesinde olmalı.' ) );
			}
		}
		$yeni['ogrenciler'] = $ogrenciler;
	}
	if ( ! $yon && ! sides_ek_sinif_ok( $yeni, $kisit, $izin ) ) {
		return $bitir( sides_deny( 'Yalnız yetkili olduğunuz sınıfların öğrencileri için kayıt yapabilirsiniz.' ) );
	}
	if ( ! empty( $m['durum'] ) ) {
		$dz            = array_map( function ( $x ) { return $x[0]; }, $m['durum'] );
		$yeni['durum'] = isset( $g['durum'] ) && in_array( $g['durum'], $dz, true ) ? $g['durum'] : $dz[0];
	}
	if ( ! empty( $m['paylasim'] ) ) {
		$yeni['paylasim'] = isset( $g['paylasim'] ) && 'modul' === $g['paylasim'] ? 'modul' : 'ben';
	}
	$al = sides_ek_dogrula( $m, $g, $org, $c, $ogrenciler );
	if ( is_wp_error( $al ) ) {
		return $bitir( $al );
	}
	$yeni = array_merge( $yeni, $al );
	// modüle özgü kurallar
	if ( 'EK24' === $m['kod'] && 'hazir' === $yeni['durum'] && ( '' === $yeni['baglanti'] || '' === $yeni['amac'] || '' === $yeni['kaynak'] || '' === $yeni['kontrolEden'] || 'yapildi' !== $yeni['kontrol'] ) ) {
		return $bitir( sides_ek_hata( '"Hazır" için önizleme bağlantısı, amaç, kaynak, öğretmen kontrolü ve kontrol eden gerekir.' ) );
	}
	if ( 'EK23' === $m['kod'] && in_array( $yeni['karar'], array( 'devam', 'genislet', 'geri' ), true ) && ( '' === $yeni['kararGerekce'] || '' === $yeni['veriKalite'] ) ) {
		return $bitir( sides_ek_hata( 'Pilot kararı için karar gerekçesi ve veri kalitesi birlikte yazılmalı.' ) );
	}
	if ( ! empty( $m['hassas'] ) && $eski && ! $yon && ! sides_ek_sahip( $eski, $c['uid'] ) ) {
		$yeni['kullanicilar'] = isset( $eski['kullanicilar'] ) ? $eski['kullanicilar'] : array();
	}
	// iç alanlar: gözlemci zaten yazamaz; değişmeyen alanlar için eski değer korunur
	$u      = wp_get_current_user();
	$ben    = array( 'u' => (int) $c['uid'], 'ad' => $u && $u->ID ? $u->display_name : '' );
	$degisen = array();
	if ( $eski ) {
		foreach ( $yeni as $k => $v ) {
			if ( wp_json_encode( $v ) !== wp_json_encode( isset( $eski[ $k ] ) ? $eski[ $k ] : null ) ) {
				$degisen[] = $k;
			}
		}
		if ( ! $degisen ) {
			return $bitir( sides_ek_cikis( $m, $eski, $c ) );
		}
		$kayit = array_merge( $eski, $yeni );
		unset( $kayit['id'] );
		if ( 'EK24' === $m['kod'] && ( in_array( 'baglanti', $degisen, true ) || in_array( 'surumNo', $degisen, true ) ) && ( '' !== (string) $eski['baglanti'] || '' !== (string) $eski['surumNo'] ) ) {
			$kayit['surumler'] = array_slice( array_merge( isset( $eski['surumler'] ) ? (array) $eski['surumler'] : array(), array( array( 'surumNo' => $eski['surumNo'], 'baglanti' => $eski['baglanti'], 't' => time(), 'ad' => $ben['ad'] ) ) ), -50 );
		}
	} else {
		$kayit = array_merge( $yeni, array( 'olusturan' => $ben, 'olusturma' => time(), 'islemId' => $islem, 'gecmis' => array() ) );
	}
	$kayit['surum']      = ( $eski && isset( $eski['surum'] ) ? (int) $eski['surum'] : 0 ) + 1;
	$kayit['guncelleme'] = time();
	$kayit['gecmis']     = array_slice( array_merge( isset( $kayit['gecmis'] ) ? (array) $kayit['gecmis'] : array(), array( array( 't' => time(), 'u' => $ben['u'], 'ad' => $ben['ad'], 'islem' => $eski ? 'duzenle' : 'olustur', 'alanlar' => $degisen ) ) ), -200 );
	if ( false === sides_put_doc( $org, 'ekkayit', $id, $kayit, $m['rota'] ) ) {
		return $bitir( sides_ek_hata( 'Kaydedilemedi. Tekrar deneyin.', 500 ) );
	}
	sides_log( $org, $m['kod'] . ' ' . $m['ad'] . ': kayıt ' . ( $eski ? 'güncellendi' : 'eklendi' ) . ' (' . $tarih . ')' );
	$kayit['id'] = $id;
	return $bitir( sides_ek_cikis( $m, $kayit, $c ) );
}
function sides_ek_kayit_al( $p, $m, $c ) {
	$org = sides_org_id();
	$id  = isset( $p['id'] ) ? (string) $p['id'] : '';
	if ( ! preg_match( '/^' . $m['kisa'] . '_[A-Za-z0-9]{6,40}$/', $id ) ) {
		return sides_ek_hata( 'Geçersiz kayıt.' );
	}
	$d = sides_get_doc( $org, 'ekkayit', $id );
	if ( ! $d ) {
		return sides_ek_hata( 'Kayıt bulunamadı.', 404 );
	}
	return $d;
}
function sides_rest_ek_kayit_sil( $req ) {
	$p = (array) $req->get_json_params();
	$m = sides_ek_modul_kontrol( isset( $p['modul'] ) ? (string) $p['modul'] : '', 2 );
	if ( is_wp_error( $m ) ) {
		return $m;
	}
	$c   = sides_ctx();
	$org = sides_org_id();
	$d   = sides_ek_kayit_al( $p, $m, $c );
	if ( is_wp_error( $d ) ) {
		return $d;
	}
	$kisit = 'yonetici' === $c['rol'] ? null : sides_sinif_kisit();
	$izin  = null === $kisit ? null : sides_izinli_ogrenciler( $org, $kisit );
	if ( ! sides_ek_gorunur( $m, $d, $c, $kisit, $izin ) || ! ( 'yonetici' === $c['rol'] || sides_ek_sahip( $d, $c['uid'] ) ) ) {
		return sides_deny( 'Kaydı yalnız yazan kişi ya da kurum yöneticisi silebilir.' );
	}
	if ( ! empty( $d['silindi'] ) ) {
		return array( 'ok' => true );
	}
	$u              = wp_get_current_user();
	$id             = $d['id'];
	unset( $d['id'] );
	$d['silindi']   = true;
	$d['silen']     = array( 'u' => (int) $c['uid'], 'ad' => $u->display_name, 't' => time() );
	$d['gecmis']    = array_slice( array_merge( isset( $d['gecmis'] ) ? (array) $d['gecmis'] : array(), array( array( 't' => time(), 'u' => (int) $c['uid'], 'ad' => $u->display_name, 'islem' => 'sil', 'alanlar' => array() ) ) ), -200 );
	$d['surum']     = ( isset( $d['surum'] ) ? (int) $d['surum'] : 0 ) + 1;
	sides_put_doc( $org, 'ekkayit', $id, $d, $m['rota'] );
	sides_log( $org, $m['kod'] . ' ' . $m['ad'] . ': kayıt silindi (' . ( isset( $d['tarih'] ) ? $d['tarih'] : '' ) . ')' );
	return array( 'ok' => true );
}
function sides_rest_ek_kayit_geri( $req ) {
	$p = (array) $req->get_json_params();
	$m = sides_ek_modul_kontrol( isset( $p['modul'] ) ? (string) $p['modul'] : '', 2 );
	if ( is_wp_error( $m ) ) {
		return $m;
	}
	$c = sides_ctx();
	$d = sides_ek_kayit_al( $p, $m, $c );
	if ( is_wp_error( $d ) ) {
		return $d;
	}
	$u  = wp_get_current_user();
	$id = $d['id'];
	unset( $d['id'], $d['silindi'], $d['silen'] );
	$d['gecmis'] = array_slice( array_merge( isset( $d['gecmis'] ) ? (array) $d['gecmis'] : array(), array( array( 't' => time(), 'u' => (int) $c['uid'], 'ad' => $u->display_name, 'islem' => 'geri', 'alanlar' => array() ) ) ), -200 );
	$d['surum']  = ( isset( $d['surum'] ) ? (int) $d['surum'] : 0 ) + 1;
	sides_put_doc( sides_org_id(), 'ekkayit', $id, $d, $m['rota'] );
	sides_log( sides_org_id(), $m['kod'] . ' ' . $m['ad'] . ': silinen kayıt geri alındı' );
	$d['id'] = $id;
	return sides_ek_cikis( $m, $d, $c );
}
