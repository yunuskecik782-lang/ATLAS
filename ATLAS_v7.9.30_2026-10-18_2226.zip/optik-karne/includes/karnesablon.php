<?php
/* Karne tasarımı (v7.2, v7.8): kurumun deneme ve test karnesi tasarımı settings.main.karneTasarim =
   { deneme?, test?, mod?: { deneme?, test? }, sinav: { sinavId: anahtar }, testler: { testId: anahtar } }.
   POST karnesablon/ayar { deneme?: anahtar, test?: anahtar, mod?: { deneme|test: 'ozet'|'detay' }, karsi?: { deneme: 'gecmis'|'kurum' }, sinav?: { id: anahtar|null }, testler?: { id: anahtar|null } }
     — yalnızca bilinen anahtarlar; null sınava/teste özel seçimi kaldırır; gözlemci değiştiremez.
   GET  karnesablon/ayar — tasarım anahtarları, kurumun kayıtlı seçimi (kaydedilmemişse önerilen tasarım; kayitli bayrağıyla)
     ve karnelerdeki LGS geri sayımının tarihi (LGS Modülü, yoksa TV ekranı ayarı; hiçbiri yoksa boş).
   v7.8: kurum hiç seçim yapmamışsa önerilen kurumsal tasarım kullanılır; kayıtlı seçim üzerine yazılmaz (yalnız gönderilen alan saklanır).
   Veli karne sayfası (GET veli/<token>) snapshot.e alanına tasarim (sınava özel > kurum varsayılanı), kmod (özet/detaylı) ve lgsTarihi eklenir. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function sides_ks_tasarimlar() {
	return array( 'kurumsal', 'resmi', 'klasik', 'modern', 'cift', 'siyahbeyaz', 'serit' );
}
define( 'SIDES_KS_OZEL_MAX', 300 );
define( 'SIDES_KS_ONERILEN', 'kurumsal' );

/* Kayıtlı ham değer (doğrulanmış): deneme/test anahtarı ya da '' (seçim yapılmamış) */
function sides_ks_ham( $org ) {
	$s = sides_get_doc( (int) $org, 'settings', 'main' );
	return is_array( $s ) && isset( $s['karneTasarim'] ) && is_array( $s['karneTasarim'] ) ? $s['karneTasarim'] : array();
}
/* Kurumun kayıtlı tasarımları (geçersiz/eksik değer önerilen tasarım sayılır; özel eşlemelerden bilinmeyenler atılır) */
function sides_ks_ayar( $org ) {
	$k   = sides_ks_ham( $org );
	$t   = sides_ks_tasarimlar();
	$out = array( 'kayitli' => array() );
	foreach ( array( 'deneme', 'test' ) as $tur ) {
		$var                     = isset( $k[ $tur ] ) && in_array( $k[ $tur ], $t, true );
		$out[ $tur ]             = $var ? (string) $k[ $tur ] : SIDES_KS_ONERILEN;
		$out['kayitli'][ $tur ] = $var;
	}
	$m          = isset( $k['mod'] ) && is_array( $k['mod'] ) ? $k['mod'] : array();
	$out['mod'] = array();
	foreach ( array( 'deneme', 'test' ) as $tur ) {
		$out['mod'][ $tur ] = isset( $m[ $tur ] ) && in_array( $m[ $tur ], array( 'ozet', 'detay' ), true ) ? $m[ $tur ] : 'detay';
	}
	/* v7.9.27 ders başarı profili karşılaştırması: geçmiş denemeler (varsayılan) ya da kurum ortalaması */
	$ka           = isset( $k['karsi'] ) && is_array( $k['karsi'] ) ? $k['karsi'] : array();
	$out['karsi'] = array( 'deneme' => isset( $ka['deneme'] ) && 'kurum' === $ka['deneme'] ? 'kurum' : 'gecmis' );
	foreach ( array( 'sinav', 'testler' ) as $alan ) {
		$out[ $alan ] = array();
		if ( ! isset( $k[ $alan ] ) || ! is_array( $k[ $alan ] ) ) {
			continue;
		}
		foreach ( $k[ $alan ] as $id => $v ) {
			if ( sides_ks_id_gecerli( $id ) && is_string( $v ) && in_array( $v, $t, true ) ) {
				$out[ $alan ][ (string) $id ] = $v;
			}
		}
	}
	return $out;
}
/* Karnelerdeki LGS geri sayımının tarihi: LGS Modülü'nde girilmiş tarih (settings.main.lgs.tarih) önce, yoksa TV ekranı ayarı (tv/ayar.lgsTarihi;
   panoda gösterilen değerin aynısı). Geçerli değilse boş: karne geri sayım göstermez. Kodda hiçbir tarih yazılı değildir. */
function sides_ks_lgs( $org ) {
	$ok  = function ( $t ) {
		return is_string( $t ) && preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $t, $m ) && checkdate( (int) $m[2], (int) $m[3], (int) $m[1] );
	};
	$set = sides_get_doc( (int) $org, 'settings', 'main' );
	$mod = is_array( $set ) && isset( $set['lgs'] ) && is_array( $set['lgs'] ) && isset( $set['lgs']['tarih'] ) ? trim( (string) $set['lgs']['tarih'] ) : '';
	if ( $ok( $mod ) ) {
		return array( 'tarih' => $mod, 'kaynak' => 'modul' );
	}
	$ham = sides_get_doc( (int) $org, 'tv', 'ayar' );
	$a   = function_exists( 'sides_tv_ayar_disari' ) ? sides_tv_ayar_disari( $ham ) : $ham;
	$tv  = is_array( $a ) && isset( $a['lgsTarihi'] ) ? trim( (string) $a['lgsTarihi'] ) : '';
	return $ok( $tv ) ? array( 'tarih' => $tv, 'kaynak' => 'tv' ) : array( 'tarih' => '', 'kaynak' => '' );
}
function sides_ks_id_gecerli( $id ) {
	return is_string( $id ) || is_int( $id ) ? (bool) preg_match( '/^[A-Za-z0-9_.-]{1,64}$/', (string) $id ) : false;
}
/* Sınavın (ya da testin) çözümlenmiş tasarımı: özel seçim > kurum varsayılanı */
function sides_ks_cozumle( $org, $tur, $id ) {
	$a    = sides_ks_ayar( $org );
	$alan = 'test' === $tur ? 'testler' : 'sinav';
	if ( $id && isset( $a[ $alan ][ (string) $id ] ) ) {
		return $a[ $alan ][ (string) $id ];
	}
	return $a[ 'test' === $tur ? 'test' : 'deneme' ];
}
function sides_ks_yetki( $tur ) {
	$gerek = 'test' === $tur ? array( 'test', 'nehari' ) : array( 'karne', 'nehari' );
	return sides_can( $gerek[0], 2 ) || sides_can( $gerek[1], 2 );
}

function sides_ks_ayar_oku() {
	$org = sides_org_id();
	$res = rest_ensure_response( array( 'tasarimlar' => sides_ks_tasarimlar(), 'onerilen' => SIDES_KS_ONERILEN, 'karneTasarim' => sides_ks_ayar( $org ), 'lgs' => sides_ks_lgs( $org ) ) );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}

function sides_ks_ayar_kaydet( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	if ( ! is_array( $p ) ) {
		$p = array();
	}
	$t       = sides_ks_tasarimlar();
	$degisti = array();
	$yeni    = sides_ks_ayar( $org );
	foreach ( array_keys( $p ) as $alan ) {
		if ( ! in_array( $alan, array( 'deneme', 'test', 'mod', 'karsi', 'sinav', 'testler' ), true ) ) {
			return new WP_Error( 'sides_ks', 'Bilinmeyen alan: ' . sanitize_key( (string) $alan ), array( 'status' => 400 ) );
		}
	}
	foreach ( array( 'deneme', 'test' ) as $tur ) {
		if ( ! array_key_exists( $tur, $p ) ) {
			continue;
		}
		$v = is_string( $p[ $tur ] ) ? $p[ $tur ] : '';
		if ( ! in_array( $v, $t, true ) ) {
			return new WP_Error( 'sides_ks', 'Bilinmeyen karne tasarımı.', array( 'status' => 400 ) );
		}
		if ( ! sides_ks_yetki( $tur ) ) {
			return sides_deny( ( 'test' === $tur ? 'Test' : 'Karne' ) . ' modülünde değişiklik yapma yetkiniz yok.' );
		}
		$yeni[ $tur ] = $v;
		$degisti[]    = ( 'test' === $tur ? 'test' : 'deneme' ) . ': ' . $v;
	}
	$ham     = sides_ks_ham( $org );
	$yeniMod = array();   // v7.8: yalnız gönderilen tür yazılır
	if ( array_key_exists( 'mod', $p ) ) {
		if ( ! is_array( $p['mod'] ) || ! $p['mod'] ) {
			return new WP_Error( 'sides_ks', 'Karne türü seçimi eksik.', array( 'status' => 400 ) );
		}
		foreach ( $p['mod'] as $tur => $v ) {
			if ( ! in_array( $tur, array( 'deneme', 'test' ), true ) || ! in_array( $v, array( 'ozet', 'detay' ), true ) ) {
				return new WP_Error( 'sides_ks', 'Bilinmeyen karne türü (özet ya da detaylı olmalı).', array( 'status' => 400 ) );
			}
			if ( ! sides_ks_yetki( $tur ) ) {
				return sides_deny( ( 'test' === $tur ? 'Test' : 'Karne' ) . ' modülünde değişiklik yapma yetkiniz yok.' );
			}
			$yeniMod[ $tur ] = $v;
			$degisti[]       = 'mod ' . $tur . ': ' . $v;
		}
	}
	$yeniKarsi = array();
	if ( array_key_exists( 'karsi', $p ) ) {
		if ( ! is_array( $p['karsi'] ) || ! $p['karsi'] ) {
			return new WP_Error( 'sides_ks', 'Karşılaştırma seçimi eksik.', array( 'status' => 400 ) );
		}
		foreach ( $p['karsi'] as $tur => $v ) {
			if ( 'deneme' !== $tur || ! in_array( $v, array( 'gecmis', 'kurum' ), true ) ) {
				return new WP_Error( 'sides_ks', 'Bilinmeyen karşılaştırma (geçmiş denemeler ya da kurum ortalaması olmalı).', array( 'status' => 400 ) );
			}
			if ( ! sides_ks_yetki( 'deneme' ) ) {
				return sides_deny( 'Karne modülünde değişiklik yapma yetkiniz yok.' );
			}
			$yeniKarsi['deneme'] = $v;
			$degisti[]           = 'karşılaştırma: ' . $v;
		}
	}
	foreach ( array( 'sinav' => array( 'deneme', 'exams' ), 'testler' => array( 'test', 'testler' ) ) as $alan => $m ) {
		if ( ! array_key_exists( $alan, $p ) ) {
			continue;
		}
		if ( ! is_array( $p[ $alan ] ) || ! $p[ $alan ] ) {
			return new WP_Error( 'sides_ks', 'Sınav seçimi eksik.', array( 'status' => 400 ) );
		}
		if ( ! sides_ks_yetki( $m[0] ) ) {
			return sides_deny( ( 'test' === $m[0] ? 'Test' : 'Karne' ) . ' modülünde değişiklik yapma yetkiniz yok.' );
		}
		foreach ( $p[ $alan ] as $id => $v ) {
			if ( ! sides_ks_id_gecerli( $id ) ) {
				return new WP_Error( 'sides_ks', 'Geçersiz sınav kimliği.', array( 'status' => 400 ) );
			}
			$id = (string) $id;
			if ( null === $v || '' === $v ) {
				if ( isset( $yeni[ $alan ][ $id ] ) ) {
					unset( $yeni[ $alan ][ $id ] );
					$degisti[] = $alan . '/' . $id . ': kaldırıldı';
				}
				continue;
			}
			if ( ! is_string( $v ) || ! in_array( $v, $t, true ) ) {
				return new WP_Error( 'sides_ks', 'Bilinmeyen karne tasarımı.', array( 'status' => 400 ) );
			}
			if ( ! sides_get_doc( $org, $m[1], $id ) ) {
				return new WP_Error( 'sides_ks', ( 'exams' === $m[1] ? 'Deneme' : 'Test' ) . ' bulunamadı.', array( 'status' => 404 ) );
			}
			if ( ! isset( $yeni[ $alan ][ $id ] ) && count( $yeni[ $alan ] ) >= SIDES_KS_OZEL_MAX ) {
				return new WP_Error( 'sides_ks', 'Çok fazla özel seçim var; önce eskilerini kaldırın.', array( 'status' => 400 ) );
			}
			$yeni[ $alan ][ $id ] = $v;
			$degisti[]            = $alan . '/' . $id . ': ' . $v;
		}
	}
	if ( ! $degisti ) {
		return new WP_Error( 'sides_ks', 'Değiştirilecek tasarım gönderilmedi.', array( 'status' => 400 ) );
	}
	$s = sides_get_doc( $org, 'settings', 'main' );
	if ( ! is_array( $s ) ) {
		$s = array();
	}
	unset( $s['id'] );
	$kt = array( 'sinav' => (object) $yeni['sinav'], 'testler' => (object) $yeni['testler'] );
	foreach ( array( 'deneme', 'test' ) as $tur ) {   // kurum hiç seçmediyse alan yazılmaz: önerilen tasarım kendiliğinden kalıcılaşmaz
		if ( array_key_exists( $tur, $p ) || ! empty( $yeni['kayitli'][ $tur ] ) ) {
			$kt[ $tur ] = $yeni[ $tur ];
		}
	}
	$mod = isset( $ham['mod'] ) && is_array( $ham['mod'] ) ? array_intersect_key( $ham['mod'], array( 'deneme' => 1, 'test' => 1 ) ) : array();
	foreach ( $mod as $tur => $v ) {
		if ( ! in_array( $v, array( 'ozet', 'detay' ), true ) ) {
			unset( $mod[ $tur ] );
		}
	}
	$mod = array_merge( $mod, $yeniMod );
	if ( $mod ) {
		$kt['mod'] = $mod;
	}
	$karsi = isset( $ham['karsi'] ) && is_array( $ham['karsi'] ) && isset( $ham['karsi']['deneme'] ) && in_array( $ham['karsi']['deneme'], array( 'gecmis', 'kurum' ), true ) ? array( 'deneme' => $ham['karsi']['deneme'] ) : array();
	$karsi = array_merge( $karsi, $yeniKarsi );
	if ( $karsi ) {
		$kt['karsi'] = $karsi;
	}
	$s['karneTasarim'] = $kt;
	if ( false === sides_put_doc( $org, 'settings', 'main', $s ) ) {
		return new WP_Error( 'sides_db', 'Ayar kaydedilemedi.', array( 'status' => 500 ) );
	}
	sides_log( $org, 'Karne tasarımı güncellendi: ' . implode( ', ', array_slice( $degisti, 0, 10 ) ) );
	$res = rest_ensure_response( array( 'karneTasarim' => sides_ks_ayar( $org ) ) );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}

add_action( 'rest_api_init', function () {
	$izin = function () {
		if ( sides_is_observer() ) {
			return sides_deny( 'Gözlemci hesabının işlem yetkisi yok. Yöneticinizden izin isteyin.' );
		}
		return ( sides_can( 'karne', 2 ) || sides_can( 'test', 2 ) || sides_can( 'nehari', 2 ) ) ? true : sides_deny( 'Karne tasarımını değiştirme yetkiniz yok.' );
	};
	register_rest_route( 'optik-karne/v1', '/karnesablon/ayar', array(
		array(
			'methods'             => 'GET',
			'callback'            => 'sides_ks_ayar_oku',
			'permission_callback' => function () {
				return ( sides_can( 'karne', 1 ) || sides_can( 'test', 1 ) || sides_can( 'nehari', 1 ) ) ? true : sides_deny( 'Yetkiniz yok.' );
			},
		),
		array(
			'methods'             => 'POST',
			'callback'            => 'sides_ks_ayar_kaydet',
			'permission_callback' => $izin,
		),
	) );
} );

/* Veli karne sayfası: karne verisine sınavın çözümlenmiş tasarımı eklenir (rest.php değişmeden) */
add_filter( 'rest_post_dispatch', function ( $res, $server, $req ) {
	if ( ! ( $res instanceof WP_REST_Response ) || $res->is_error() ) {
		return $res;
	}
	if ( ! preg_match( '#^/optik-karne/v1/veli/([a-f0-9]{32})$#', (string) $req->get_route(), $m ) ) {
		return $res;
	}
	$d = $res->get_data();
	if ( ! is_array( $d ) || ! isset( $d['snapshot'] ) || ! is_array( $d['snapshot'] ) || ! isset( $d['snapshot']['e'] ) || ! is_array( $d['snapshot']['e'] ) ) {
		return $res;
	}
	global $wpdb;
	$t   = sides_docs();
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT org, data FROM $t WHERE coll = 'results' AND token = %s", $m[1] ), ARRAY_A ); // phpcs:ignore
	if ( ! $row || ! (int) $row['org'] ) {
		return $res;
	}
	$veri   = json_decode( (string) $row['data'], true );
	$sinav  = is_array( $veri ) && isset( $veri['examId'] ) && sides_ks_id_gecerli( $veri['examId'] ) ? (string) $veri['examId'] : '';
	$d['snapshot']['e']['tasarim'] = sides_ks_cozumle( (int) $row['org'], 'deneme', $sinav );
	$ayar                          = sides_ks_ayar( (int) $row['org'] );
	$d['snapshot']['e']['kmod']    = $ayar['mod']['deneme'];   // v7.8: veli karnesi kurumun özet/detaylı seçimiyle
	$d['snapshot']['e']['kkarsi']  = $ayar['karsi']['deneme'];   // v7.9.27: ders başarı profili karşılaştırması
	$lgs                           = sides_ks_lgs( (int) $row['org'] );
	$d['snapshot']['e']['lgsTarihi'] = $lgs['tarih'];   // 8. sınıf karnesinde LGS geri sayımı (boşsa gösterilmez)
	$res->set_data( $d );
	return $res;
}, 10, 3 );
