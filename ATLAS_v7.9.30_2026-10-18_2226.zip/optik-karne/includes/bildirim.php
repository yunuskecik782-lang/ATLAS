<?php
/**
 * v5.5 · Zil bildirimleri: başkalarının yaptığı işlemler.
 *
 * Kaynak, işlem geçmişidir (sides_docs coll = 'log'; updated_by = işlemi yapan kullanıcı). Zil yalnızca okur;
 * işlem geçmişi değişmez. Kural:
 *   - İşlemi yapan kullanıcı kimliği oturumdaki kullanıcıyla aynıysa bildirim yok (cihazdan bağımsız, kimliğe göre).
 *   - Ana hesap (site yöneticisi): bütün kurumlar. Diğerleri: yalnızca kendi kurumu ve yetkili oldukları modüller
 *     (sayfa yetkisi dahil). Kullanıcı/yedek/sistem kayıtlarını yalnızca kurum yöneticisi görür.
 *   - Sınıf yetkili kullanıcıda ayrıntı (öğrenci adı vb.) gizlenir.
 *   - Aynı kişinin art arda yaptığı aynı tür işlemler (ör. 40 form okutma) tek bildirimde özetlenir.
 *   - updated_by = 0: sistem / dış bağlantı (ön kayıt formu, okutma linki, zamanlanmış iş) olarak işaretlenir.
 * Okundu bilgisi kullanıcı meta'sında: sides_bildirim = { t: bu ana kadar hepsi okundu (ms), ids: [tek tek okunanlar] }.
 *
 * @package SIDES
 */

defined( 'ABSPATH' ) || exit;

/* İşlem metninden modül (eski kayıtlarda da çalışır) */
function sides_bildirim_mod( $m ) {
	$L = array(
		'/^(Test formu okutuldu|Test sonucu|Test |Kazanım)/u'                         => 'test',
		'/^(Form okutuldu|Sonuç|Yönetici okutma|Okutucu okutma)/u'                    => 'karne',
		'/^Soru havuzu/u'                                                             => 'havuz',
		'/^(Kitap|Takviye|Hedef|Workwin|Dahili ders|Etüt|İzin)/u'                     => 'takip',
		'/^(Puan|TV ekranı)/u'                                                        => 'puan',
		'/^Rapor/u'                                                                   => 'rapor',
		'/^Veli raporu/u'                                                             => 'analiz',
		'/^(Aday|Yeni aday)/u'                                                        => 'crm',
		'/^Öğrenci/u'                                                                 => 'kayit',
		'/^(Deneme|Ayarlar güncellendi|LGS)/u'                                        => 'sinav',
		'/^Etkinlik/u'                                                                => 'takvim',
		'/^(Duyuru|Genel duyuru)/u'                                                   => 'sistem',
	);
	foreach ( $L as $re => $mod ) {
		if ( preg_match( $re, (string) $m ) ) {
			return $mod;
		}
	}
	return 'kullanici'; // kullanıcı, yedek, sistem uyarısı ve tanınmayanlar: yalnızca yönetici
}

function sides_bildirim_durum( $uid ) {
	$d = get_user_meta( $uid, 'sides_bildirim', true );
	if ( ! is_array( $d ) || empty( $d['t'] ) ) {
		$d = array( 't' => (int) round( ( microtime( true ) - DAY_IN_SECONDS ) * 1000 ), 'ids' => array() );   // ilk açılışta son 24 saat okunmamış sayılır
	}
	$d['ids'] = isset( $d['ids'] ) && is_array( $d['ids'] ) ? $d['ids'] : array();
	return $d;
}

function sides_bildirim_liste( WP_REST_Request $req ) {
	global $wpdb;
	$c     = sides_ctx();
	$ben   = (int) get_current_user_id();
	$super = sides_is_super() && empty( $c['onizleme'] );
	if ( ! $ben || ( ! $super && ! $c['org'] ) ) {
		return sides_deny( 'Oturum açmanız gerekiyor.' );
	}
	$t      = sides_docs();
	$org_f  = $super ? (int) $req['org'] : (int) $c['org'];
	$mod_f  = preg_replace( '/[^a-z]/', '', (string) $req['mod'] );
	$hedef  = ! empty( $c['onizleme'] ) ? (int) $c['uid'] : $ben;   // önizlemede hedef kullanıcının gözüyle
	$sql    = $org_f
		? $wpdb->prepare( "SELECT org, id, data, updated_by FROM $t WHERE coll = 'log' AND org = %d AND updated_by <> %d ORDER BY id DESC LIMIT 600", $org_f, $hedef ) // phpcs:ignore
		: $wpdb->prepare( "SELECT org, id, data, updated_by FROM $t WHERE coll = 'log' AND updated_by <> %d ORDER BY id DESC LIMIT 600", $hedef ); // phpcs:ignore
	$adlar = array();
	if ( $super ) {
		foreach ( $wpdb->get_results( 'SELECT id, ad FROM ' . sides_orgs() ) as $o ) { // phpcs:ignore
			$adlar[ (int) $o->id ] = $o->ad;
		}
	} else {
		$o                         = sides_org( (int) $c['org'] );
		$adlar[ (int) $c['org'] ] = $o ? $o->ad : '';
	}
	$kisit = ! $super && function_exists( 'sides_sinif_kisit' ) && sides_sinif_kisit();
	$durum = sides_bildirim_durum( $ben );
	$okuid = array_flip( $durum['ids'] );
	$acik  = array();
	$out   = array();
	$son   = null;
	foreach ( (array) $wpdb->get_results( $sql ) as $r ) { // phpcs:ignore
		$x = json_decode( $r->data, true );
		if ( ! is_array( $x ) ) {
			continue;
		}
		$m   = isset( $x['m'] ) ? (string) $x['m'] : '';
		$mod = sides_bildirim_mod( $m );
		if ( $mod_f && $mod_f !== $mod ) {
			continue;
		}
		if ( ! $super ) {
			if ( ! isset( $acik[ $mod ] ) ) {
				$acik[ $mod ] = sides_sayfa_mod_acik( $mod ) || ( in_array( $mod, array( 'sinav', 'karne', 'test', 'havuz', 'kayit' ), true ) && ! empty( $c['yetki']['nehari'] ) );
			}
			if ( ! $acik[ $mod ] ) {
				continue;
			}
		}
		if ( $kisit ) {
			$m = preg_replace( '/:\s.*$/u', ': •••', $m );
		}
		$by   = (int) $r->updated_by;
		$tm   = isset( $x['t'] ) ? (int) $x['t'] : 0;
		$tur  = strtok( $m, ':' );
		$oku  = $tm <= (int) $durum['t'] || isset( $okuid[ $r->id ] );
		// toplu işlem özeti: aynı kurum, aynı kişi, aynı işlem türü, 15 dakika içinde
		if ( $son && $son['org'] === (int) $r->org && $son['_by'] === $by && $son['u'] === ( $x['u'] ?? '' ) && $son['_tur'] === $tur && $son['_ilk'] - $tm < 15 * 60000 ) {
			$son['n']++;
			$son['_ilk'] = $tm;
			if ( ! $oku && count( $son['ids'] ) < 200 ) {
				$son['ids'][] = (string) $r->id;
			}
			$son['okunmadi'] = $son['okunmadi'] || ! $oku;
			continue;
		}
		if ( $son ) {
			$out[] = $son;
		}
		if ( count( $out ) >= 60 ) {
			$son = null;
			break;
		}
		$son = array(
			'id'       => (string) $r->id,
			't'        => $tm,
			'org'      => (int) $r->org,
			'kurum'    => isset( $adlar[ (int) $r->org ] ) ? $adlar[ (int) $r->org ] : '#' . (int) $r->org,
			'u'        => isset( $x['u'] ) ? (string) $x['u'] : '',
			'm'        => $m,
			'mod'      => $mod,
			'sistem'   => 0 === $by,
			'n'        => 1,
			'okunmadi' => ! $oku,
			'ids'      => $oku ? array() : array( (string) $r->id ),
			'_by'      => $by,
			'_tur'     => $tur,
			'_ilk'     => $tm,
		);
	}
	if ( $son ) {
		$out[] = $son;
	}
	$say = 0;
	foreach ( $out as &$o ) {
		unset( $o['_by'], $o['_tur'], $o['_ilk'] );
		$say += $o['okunmadi'] ? 1 : 0;
	}
	unset( $o );
	$res = rest_ensure_response( array( 'liste' => $out, 'okunmamis' => $say, 'super' => $super ) );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}

function sides_bildirim_okundu( WP_REST_Request $req ) {
	$ben = (int) get_current_user_id();
	$p   = $req->get_json_params();
	$d   = sides_bildirim_durum( $ben );
	if ( ! empty( $p['hepsi'] ) ) {
		$d = array( 't' => (int) round( microtime( true ) * 1000 ), 'ids' => array() );
	} elseif ( isset( $p['ids'] ) && is_array( $p['ids'] ) ) {
		foreach ( array_slice( $p['ids'], 0, 200 ) as $id ) {
			if ( preg_match( '/^\d{14}-\d{4}$/', (string) $id ) ) {
				$d['ids'][] = (string) $id;
			}
		}
		$d['ids'] = array_slice( array_values( array_unique( $d['ids'] ) ), -600 );
	} else {
		return new WP_Error( 'sides_gecersiz', 'Geçersiz istek.', array( 'status' => 400 ) );
	}
	update_user_meta( $ben, 'sides_bildirim', $d );
	return array( 'ok' => true );
}

add_action( 'rest_api_init', function () {
	$ns   = 'optik-karne/v1';
	$izin = function () {
		return ( sides_is_panel() || sides_is_super() ) ? true : sides_deny( 'Oturum açmanız gerekiyor.' );
	};
	register_rest_route( $ns, '/bildirim', array( 'methods' => 'GET', 'callback' => 'sides_bildirim_liste', 'permission_callback' => $izin ) );
	register_rest_route( $ns, '/bildirim/okundu', array( 'methods' => 'POST', 'callback' => 'sides_bildirim_okundu', 'permission_callback' => function () {
		if ( sides_onizleme_hedef() ) {
			return sides_deny( 'Önizleme modunda değişiklik yapılamaz.' );
		}
		return ( sides_is_panel() || sides_is_super() ) ? true : sides_deny( 'Oturum açmanız gerekiyor.' );
	} ) );
} );
