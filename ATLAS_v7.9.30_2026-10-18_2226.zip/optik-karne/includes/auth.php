<?php
/**
 * ATLAS giriş, kayıt (e-posta doğrulama kodu ile) ve şifre sıfırlama sayfaları.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function sides_opt_kayit_acik() {
	return 'kapali' !== sides_kayit_yontemi();
}
function sides_opt_dogrulama() {
	return '0' !== (string) get_option( 'sides_eposta_dogrulama', '1' );
}

/* ATLAS'ın kendi çıkış adresi: WordPress'in "çıkış yapmak istiyor musunuz" ekranı hiç görünmez */
function sides_logout_url() {
	return optik_karne_url( array( 'sayfa' => 'cikis', '_sides' => wp_create_nonce( 'sides_cikis' ) ) );
}

function sides_code_hash( $email, $code ) {
	return hash_hmac( 'sha256', strtolower( $email ) . '|' . $code, wp_salt( 'auth' ) );
}
function sides_pending_key( $kind, $email ) {
	return 'sides_' . $kind . '_' . md5( strtolower( $email ) );
}
function sides_send_code( $email, $code, $kind ) {
	if ( 'cihaz' === $kind ) {
		$subj = 'ATLAS giriş doğrulama kodunuz: ' . $code;
		$body = "ATLAS hesabınıza yeni bir cihazdan giriş yapılmak isteniyor (" . sides_ua_kisa() . ").\nGiriş yapan sizseniz şu kodu girin:\n\n    $code\n\nKod 15 dakika geçerlidir. Bu girişi siz yapmıyorsanız kodu kimseyle paylaşmayın ve şifrenizi değiştirin.\n\nATLAS · Akademik Takip ve Analiz Sistemi\n" . optik_karne_url();
		return wp_mail( $email, $subj, $body );
	}
	$subj = 'kayit' === $kind ? 'ATLAS doğrulama kodunuz: ' . $code : 'ATLAS şifre yenileme kodunuz: ' . $code;
	$body = ( 'kayit' === $kind ? "ATLAS hesabınızı oluşturmak için doğrulama kodunuz:\n\n" : "ATLAS şifrenizi yenilemek için kodunuz:\n\n" )
		. "    $code\n\nKod 15 dakika geçerlidir. Bu isteği siz yapmadıysanız bu e-postayı dikkate almayın.\n\nATLAS · Akademik Takip ve Analiz Sistemi\n" . optik_karne_url();
	return wp_mail( $email, $subj, $body );
}

/* /atlas/ isteğinde giriş gerektiren durumlar. Sayfa basılırsa exit eder. */
function sides_auth_route() {
	$sayfa = isset( $_GET['sayfa'] ) ? sanitize_key( wp_unslash( $_GET['sayfa'] ) ) : ''; // phpcs:ignore
	if ( 'POST' === ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : '' ) && isset( $_POST['sides_islem'] ) ) { // phpcs:ignore
		sides_auth_post( sanitize_key( wp_unslash( $_POST['sides_islem'] ) ) ); // phpcs:ignore
		exit;
	}
	if ( 'cikis' === $sayfa ) {
		if ( is_user_logged_in() ) {
			$n = isset( $_GET['_sides'] ) ? sanitize_text_field( wp_unslash( $_GET['_sides'] ) ) : ''; // phpcs:ignore
			if ( ! wp_verify_nonce( $n, 'sides_cikis' ) ) {
				sides_auth_page( 'cikis' ); // bağlantı eskiyse onay düğmesi (yine ATLAS sayfası)
				exit;
			}
			wp_logout();
		}
		wp_safe_redirect( optik_karne_url( array( 'cikti' => 1 ) ) );
		exit;
	}
	if ( 'aydinlatma' === $sayfa ) {
		sides_auth_page( 'aydinlatma' );
		exit;
	}
	if ( is_user_logged_in() ) {
		return;
	}
	if ( 'kaydol' === $sayfa ) {
		sides_auth_page( sides_opt_kayit_acik() ? 'kaydol' : 'giris', sides_opt_kayit_acik() ? array() : array( 'hata' => 'Yeni hesap açma şu anda kapalı.' ) );
	} elseif ( 'sifre' === $sayfa ) {
		sides_auth_page( 'sifre' );
	} else {
		sides_auth_page( 'giris' );
	}
	exit;
}

function sides_post( $k, $len = 190 ) {
	return isset( $_POST[ $k ] ) ? mb_substr( trim( sanitize_text_field( wp_unslash( $_POST[ $k ] ) ) ), 0, $len ) : ''; // phpcs:ignore
}

function sides_auth_post( $islem ) {
	if ( ! isset( $_POST['_sides'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['_sides'] ) ), 'sides_auth' ) ) { // phpcs:ignore
		sides_auth_page( 'giris', array( 'hata' => 'Sayfanın süresi doldu. Lütfen tekrar deneyin.' ) );
		return;
	}
	if ( ! empty( $_POST['web'] ) ) { // bot tuzağı
		sides_auth_page( 'giris' );
		return;
	}
	switch ( $islem ) {
		case 'giris':
			sides_do_login();
			return;
		case 'kaydol':
			sides_do_register();
			return;
		case 'dogrula':
			sides_do_verify();
			return;
		case 'tekrar':
			sides_do_resend();
			return;
		case 'sifre':
			sides_do_reset_request();
			return;
		case 'sifre2':
			sides_do_reset();
			return;
		case 'kod':
			sides_do_kod();
			return;
		case 'cihaz':
			sides_do_cihaz();
			return;
		case 'cihaz_tekrar':
			sides_do_cihaz_tekrar();
			return;
		case 'cikis':
			wp_logout();
			wp_safe_redirect( optik_karne_url( array( 'cikti' => 1 ) ) );
			return;
	}
	sides_auth_page( 'giris' );
}

function sides_do_login() {
	$login = sides_post( 'login' );
	$pass  = isset( $_POST['sifre'] ) ? (string) wp_unslash( $_POST['sifre'] ) : ''; // phpcs:ignore
	if ( ! sides_rl_check( 'giris', 10 ) ) {
		sides_auth_page( 'giris', array( 'hata' => 'Çok fazla deneme yapıldı. 15 dakika sonra tekrar deneyin.', 'login' => $login ) );
		return;
	}
	$hatirla = ! empty( $_POST['hatirla'] ); // phpcs:ignore
	$user    = wp_authenticate( $login, $pass );
	if ( is_wp_error( $user ) ) {
		sides_rl_hit( 'giris', 15 * MINUTE_IN_SECONDS );
		sides_auth_page( 'giris', array( 'hata' => 'E-posta / kullanıcı adı veya şifre hatalı.', 'login' => $login ) );
		return;
	}
	// Tanınmayan cihaz: şifre doğru olsa da hesabın e-postasına gelen kod istenir
	if ( sides_cihaz_gerekli( $user ) ) {
		sides_cihaz_kodu( $user, $hatirla );
		return;
	}
	sides_giris_tamamla( $user, $hatirla, sides_cihaz_taninir( $user->ID ) ? 'kayitli' : '' );
}

function sides_do_register() {
	if ( ! sides_opt_kayit_acik() ) {
		sides_auth_page( 'giris', array( 'hata' => 'Yeni hesap açma şu anda kapalı.' ) );
		return;
	}
	$yontem = sides_kayit_yontemi();
	$f = array( 'ad' => sides_post( 'ad', 80 ), 'kurum' => sides_post( 'kurum', 120 ), 'email' => sanitize_email( sides_post( 'email' ) ), 'kod' => in_array( $yontem, array( 'kod', 'kod_onay' ), true ) ? sides_post( 'kod', 30 ) : '' );
	$p1 = isset( $_POST['sifre'] ) ? (string) wp_unslash( $_POST['sifre'] ) : ''; // phpcs:ignore
	$p2 = isset( $_POST['sifre2'] ) ? (string) wp_unslash( $_POST['sifre2'] ) : ''; // phpcs:ignore
	$err = '';
	if ( ! $f['ad'] || ! $f['kurum'] ) {
		$err = 'Ad soyad ve kurum adını yazın.';
	} elseif ( ! is_email( $f['email'] ) ) {
		$err = 'Geçerli bir e-posta adresi yazın.';
	} elseif ( strlen( $p1 ) < 8 ) {
		$err = 'Şifre en az 8 karakter olmalı.';
	} elseif ( $p1 !== $p2 ) {
		$err = 'Şifreler aynı değil.';
	} elseif ( 'kod' === $yontem && '' === $f['kod'] ) {
		$err = 'Kayıt için etkinleştirme kodu gerekli. Kodunuz yoksa bizimle iletişime geçin.';
	} elseif ( '' !== $f['kod'] && ! sides_kod_bul( $f['kod'] ) ) {
		$err = 'Etkinleştirme kodu geçersiz ya da daha önce kullanılmış.';
	} elseif ( empty( $_POST['aydinlatma'] ) ) { // phpcs:ignore
		$err = 'Devam etmek için aydınlatma metnini okuduğunuzu işaretleyin.';
	} elseif ( email_exists( $f['email'] ) ) {
		$err = 'Bu e-posta ile bir hesap var. Giriş yapın veya şifrenizi yenileyin.';
	} elseif ( ! sides_rl( 'kaydol', 6, HOUR_IN_SECONDS ) ) {
		$err = 'Çok fazla kayıt denemesi yapıldı. Lütfen daha sonra tekrar deneyin.';
	}
	if ( $err ) {
		sides_auth_page( 'kaydol', array_merge( $f, array( 'hata' => $err ) ) );
		return;
	}
	$hash = wp_hash_password( $p1 );
	if ( ! sides_opt_dogrulama() ) {
		sides_finish_register( $f['ad'], $f['kurum'], $f['email'], $hash, $f['kod'] );
		return;
	}
	$code = (string) wp_rand( 100000, 999999 );
	$pend = array( 'ad' => $f['ad'], 'kurum' => $f['kurum'], 'email' => $f['email'], 'kod' => $f['kod'], 'hash' => $hash, 'code' => sides_code_hash( $f['email'], $code ), 'deneme' => 0, 'gonderim' => time() );
	set_transient( sides_pending_key( 'kyt', $f['email'] ), $pend, 15 * MINUTE_IN_SECONDS );
	if ( ! sides_send_code( $f['email'], $code, 'kayit' ) ) {
		delete_transient( sides_pending_key( 'kyt', $f['email'] ) );
		sides_auth_page( 'kaydol', array_merge( $f, array( 'hata' => 'Doğrulama e-postası gönderilemedi. Lütfen biraz sonra tekrar deneyin.' ) ) );
		return;
	}
	sides_auth_page( 'dogrula', array( 'email' => $f['email'] ) );
}

function sides_do_verify() {
	$email = sanitize_email( sides_post( 'email' ) );
	$code  = preg_replace( '/\D/', '', sides_post( 'kod', 12 ) );
	$key   = sides_pending_key( 'kyt', $email );
	$pend  = get_transient( $key );
	if ( ! $pend ) {
		sides_auth_page( 'kaydol', array( 'hata' => 'Doğrulama süresi doldu. Lütfen kaydı tekrar başlatın.', 'email' => $email ) );
		return;
	}
	if ( ! hash_equals( $pend['code'], sides_code_hash( $email, $code ) ) ) {
		$pend['deneme']++;
		if ( $pend['deneme'] >= 5 ) {
			delete_transient( $key );
			sides_auth_page( 'kaydol', array( 'hata' => 'Kod 5 kez hatalı girildi. Lütfen kaydı tekrar başlatın.', 'email' => $email ) );
			return;
		}
		set_transient( $key, $pend, 15 * MINUTE_IN_SECONDS );
		sides_auth_page( 'dogrula', array( 'email' => $email, 'hata' => 'Kod hatalı. Kalan deneme: ' . ( 5 - $pend['deneme'] ) ) );
		return;
	}
	delete_transient( $key );
	if ( email_exists( $email ) ) {
		sides_auth_page( 'giris', array( 'hata' => 'Bu e-posta ile bir hesap zaten var.', 'login' => $email ) );
		return;
	}
	sides_finish_register( $pend['ad'], $pend['kurum'], $email, $pend['hash'], isset( $pend['kod'] ) ? $pend['kod'] : '' );
}

function sides_do_resend() {
	$email = sanitize_email( sides_post( 'email' ) );
	$key   = sides_pending_key( 'kyt', $email );
	$pend  = get_transient( $key );
	if ( ! $pend ) {
		sides_auth_page( 'kaydol', array( 'hata' => 'Doğrulama süresi doldu. Lütfen kaydı tekrar başlatın.', 'email' => $email ) );
		return;
	}
	if ( time() - (int) $pend['gonderim'] < 60 ) {
		sides_auth_page( 'dogrula', array( 'email' => $email, 'hata' => 'Yeni kod için bir dakika bekleyin.' ) );
		return;
	}
	$code             = (string) wp_rand( 100000, 999999 );
	$pend['code']     = sides_code_hash( $email, $code );
	$pend['gonderim'] = time();
	$pend['deneme']   = 0;
	set_transient( $key, $pend, 15 * MINUTE_IN_SECONDS );
	sides_send_code( $email, $code, 'kayit' );
	sides_auth_page( 'dogrula', array( 'email' => $email, 'bilgi' => 'Yeni kod gönderildi.' ) );
}

/* Hesap + kendi kurum alanı oluşturulur. Geçerli lisans koduyla hemen açılır; kodsuzsa ana hesabın onayını bekler. */
function sides_finish_register( $ad, $kurum, $email, $hash, $kod = '' ) {
	$uid = sides_new_wp_user( $email, $ad, $hash, true );
	if ( is_wp_error( $uid ) ) {
		sides_auth_page( 'kaydol', array( 'hata' => $uid->get_error_message(), 'email' => $email, 'ad' => $ad, 'kurum' => $kurum ) );
		return;
	}
	$acik = 'acik' === sides_kayit_yontemi();
	$org  = sides_org_olustur( $kurum, $uid, $acik ? 'aktif' : 'bekliyor' );
	wp_set_current_user( $uid );
	$kodlu = $kod && sides_kod_kullan( $kod, $org );
	sides_log( $org, 'Hesap oluşturuldu: ' . $kurum, $ad );
	if ( ! $kodlu && ! $acik ) {
		sides_mail_sahip( 'ATLAS: yeni kurum başvurusu — ' . $kurum, "Yeni bir kurum kayıt oldu ve onayınızı bekliyor.\n\nKurum: $kurum\nYönetici: $ad\nE-posta: $email" );
	}
	wp_set_auth_cookie( $uid, true, is_ssl() );
	sides_cihaz_kaydet( $uid ); // e-postasını doğrulayarak kayıt olan kişinin cihazı tanınır
	sides_giris_kaydet( $uid, 'yeni' );
	wp_safe_redirect( optik_karne_url( $kodlu || $acik ? array( 'hosgeldin' => 1 ) : array() ) );
}

function sides_do_kod() {
	$c = sides_ctx();
	if ( empty( $c['blok'] ) || 'askida' === $c['blok'] ) {
		wp_safe_redirect( optik_karne_url() );
		return;
	}
	if ( ! sides_rl_check( 'kod', 10 ) ) {
		sides_auth_page( 'blok', array( 'blok' => $c['blok'], 'org' => sides_org( $c['blokOrg'] ), 'hata' => 'Çok fazla deneme yapıldı. Lütfen daha sonra tekrar deneyin.' ) );
		return;
	}
	if ( ! sides_kod_kullan( sides_post( 'kod', 30 ), (int) $c['blokOrg'] ) ) {
		sides_rl_hit( 'kod', HOUR_IN_SECONDS );
		sides_auth_page( 'blok', array( 'blok' => $c['blok'], 'org' => sides_org( $c['blokOrg'] ), 'hata' => 'Etkinleştirme kodu geçersiz ya da daha önce kullanılmış. Kodu kontrol edip tekrar deneyin.' ) );
		return;
	}
	wp_safe_redirect( optik_karne_url( array( 'hosgeldin' => 1 ) ) );
}

function sides_do_reset_request() {
	$email = sanitize_email( sides_post( 'email' ) );
	if ( ! is_email( $email ) ) {
		sides_auth_page( 'sifre', array( 'hata' => 'Geçerli bir e-posta adresi yazın.' ) );
		return;
	}
	if ( ! sides_rl( 'sifre', 5, HOUR_IN_SECONDS ) ) {
		sides_auth_page( 'sifre', array( 'hata' => 'Çok fazla istek yapıldı. Lütfen daha sonra tekrar deneyin.' ) );
		return;
	}
	$u = get_user_by( 'email', $email );
	if ( $u ) {
		$code = (string) wp_rand( 100000, 999999 );
		set_transient( sides_pending_key( 'sfr', $email ), array( 'uid' => $u->ID, 'code' => sides_code_hash( $email, $code ), 'deneme' => 0 ), 15 * MINUTE_IN_SECONDS );
		sides_send_code( $email, $code, 'sifre' );
	}
	// Hesabın var olup olmadığı açığa çıkmasın diye her durumda aynı ekran
	sides_auth_page( 'sifre2', array( 'email' => $email ) );
}

function sides_do_reset() {
	$email = sanitize_email( sides_post( 'email' ) );
	$code  = preg_replace( '/\D/', '', sides_post( 'kod', 12 ) );
	$p1    = isset( $_POST['sifre'] ) ? (string) wp_unslash( $_POST['sifre'] ) : ''; // phpcs:ignore
	$p2    = isset( $_POST['sifre2'] ) ? (string) wp_unslash( $_POST['sifre2'] ) : ''; // phpcs:ignore
	$key   = sides_pending_key( 'sfr', $email );
	$pend  = get_transient( $key );
	if ( strlen( $p1 ) < 8 || $p1 !== $p2 ) {
		sides_auth_page( 'sifre2', array( 'email' => $email, 'hata' => strlen( $p1 ) < 8 ? 'Şifre en az 8 karakter olmalı.' : 'Şifreler aynı değil.' ) );
		return;
	}
	if ( ! $pend || ! hash_equals( $pend['code'], sides_code_hash( $email, $code ) ) ) {
		if ( $pend ) {
			$pend['deneme']++;
			if ( $pend['deneme'] >= 5 ) {
				delete_transient( $key );
			} else {
				set_transient( $key, $pend, 15 * MINUTE_IN_SECONDS );
			}
		}
		sides_auth_page( 'sifre2', array( 'email' => $email, 'hata' => 'Kod hatalı veya süresi dolmuş.' ) );
		return;
	}
	delete_transient( $key );
	reset_password( get_userdata( (int) $pend['uid'] ), $p1 );
	sides_auth_page( 'giris', array( 'bilgi' => 'Şifreniz yenilendi. Yeni şifrenizle giriş yapabilirsiniz.', 'login' => $email ) );
}

/* ------------------------------------------------------------------ *
 * Sayfa şablonu
 * ------------------------------------------------------------------ */
function sides_auth_page( $view, $d = array() ) {
	status_header( in_array( $view, array( 'yetkisiz', 'blok' ), true ) ? 403 : 200 );
	nocache_headers();
	header( 'X-Robots-Tag: noindex, nofollow' );
	$base  = plugin_dir_url( OPTIK_KARNE_FILE ) . 'assets/';
	$ver   = OPTIK_KARNE_VER . '.' . filemtime( dirname( __DIR__ ) . '/assets/auth.css' );
	$url   = optik_karne_url();
	$v     = function ( $k ) use ( $d ) {
		return esc_attr( isset( $d[ $k ] ) ? $d[ $k ] : '' );
	};
	if ( 'giris' === $view && empty( $d['bilgi'] ) && empty( $d['hata'] ) && isset( $_GET['cikti'] ) ) { // phpcs:ignore
		$d['bilgi'] = 'Çıkış yaptınız. Tekrar görüşmek üzere.';
	}
	$titles = array( 'cikis' => 'Çıkış', 'giris' => 'Giriş', 'kaydol' => 'Kayıt ol', 'dogrula' => 'E-postanızı doğrulayın', 'cihaz' => 'Yeni cihaz doğrulaması', 'sifre' => 'Şifremi unuttum', 'sifre2' => 'Yeni şifre belirleyin', 'yetkisiz' => 'Erişim yok', 'aydinlatma' => 'Aydınlatma metni', 'blok' => ( isset( $d['blok'] ) && 'bekliyor' === $d['blok'] ? 'Hesabınızı etkinleştirin' : ( isset( $d['blok'] ) && 'suresi' === $d['blok'] ? 'Kullanım süreniz doldu' : 'Hesabınız askıda' ) ) );
	$title  = isset( $titles[ $view ] ) ? $titles[ $view ] : 'Giriş';
	$nonce  = wp_nonce_field( 'sides_auth', '_sides', false, false ) . '<input type="text" name="web" value="" tabindex="-1" autocomplete="off" class="hp" aria-hidden="true">';
	?><!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="robots" content="noindex,nofollow">
<title><?php echo esc_html( $title ); ?> · ATLAS</title>
<link rel="icon" type="image/png" href="<?php echo esc_url( $base . 'atlas-mark-32.png' ); ?>">
<link rel="apple-touch-icon" href="<?php echo esc_url( $base . 'atlas-mark-192.png' ); ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Rubik:wght@400;500;600;700&display=swap">
<link rel="stylesheet" href="<?php echo esc_url( $base . 'auth.css?v=' . $ver ); ?>">
</head>
<body>
<main class="wrap">
  <div class="card">
    <div class="head">
      <img class="brand" src="<?php echo esc_url( $base . 'atlas-full.png' ); ?>" alt="ATLAS · Akademik Takip ve Analiz Sistemi · Gelişiminin haritasını keşfet." width="240" height="248">
    </div>
    <div class="body">
      <h1><?php echo esc_html( $title ); ?></h1>
      <?php if ( ! empty( $d['hata'] ) ) : ?><div class="msg bad" role="alert"><?php echo esc_html( $d['hata'] ); ?></div><?php endif; ?>
      <?php if ( ! empty( $d['bilgi'] ) ) : ?><div class="msg ok" role="status"><?php echo esc_html( $d['bilgi'] ); ?></div><?php endif; ?>

      <?php if ( 'cikis' === $view ) : ?>
      <p class="lead">ATLAS hesabınızdan çıkış yapmak istediğinize emin misiniz?</p>
      <form method="post" action="<?php echo esc_url( $url ); ?>">
        <?php echo $nonce; // phpcs:ignore ?><input type="hidden" name="sides_islem" value="cikis">
        <button class="btn" type="submit">Çıkış yap</button>
      </form>
      <p class="alt"><a href="<?php echo esc_url( $url ); ?>">Vazgeç, sisteme dön</a></p>

      <?php elseif ( 'giris' === $view ) : ?>
      <form method="post" action="<?php echo esc_url( $url ); ?>" novalidate>
        <?php echo $nonce; // phpcs:ignore ?><input type="hidden" name="sides_islem" value="giris">
        <label class="f"><span>E-posta veya kullanıcı adı</span><input type="text" name="login" value="<?php echo $v( 'login' ); // phpcs:ignore ?>" autocomplete="username" required autofocus></label>
        <label class="f"><span>Şifre</span><input type="password" name="sifre" autocomplete="current-password" required></label>
        <div class="row"><label class="chk"><input type="checkbox" name="hatirla" value="1"> Beni hatırla</label><a href="<?php echo esc_url( optik_karne_url( array( 'sayfa' => 'sifre' ) ) ); ?>">Şifremi unuttum</a></div>
        <button class="btn" type="submit">Giriş</button>
      </form>
      <?php if ( sides_opt_kayit_acik() ) : ?><p class="alt">Hesabınız yok mu? <a href="<?php echo esc_url( optik_karne_url( array( 'sayfa' => 'kaydol' ) ) ); ?>">Kayıt olun</a></p><?php endif; ?>

      <?php elseif ( 'kaydol' === $view ) : ?>
      <p class="lead">Kurumunuz için bir ATLAS alanı açın. Denemeleriniz, öğrencileriniz ve sonuçlarınız yalnızca sizin hesabınızda görünür.</p>
      <form method="post" action="<?php echo esc_url( $url ); ?>" novalidate>
        <?php echo $nonce; // phpcs:ignore ?><input type="hidden" name="sides_islem" value="kaydol">
        <label class="f"><span>Ad soyad</span><input type="text" name="ad" value="<?php echo $v( 'ad' ); // phpcs:ignore ?>" autocomplete="name" required></label>
        <label class="f"><span>Kurum adı</span><input type="text" name="kurum" value="<?php echo $v( 'kurum' ); // phpcs:ignore ?>" placeholder="Örn. Yıldız Eğitim Kurumları" required></label>
        <label class="f"><span>E-posta</span><input type="email" name="email" value="<?php echo $v( 'email' ); // phpcs:ignore ?>" autocomplete="email" required></label>
        <?php if ( in_array( sides_kayit_yontemi(), array( 'kod', 'kod_onay' ), true ) ) : ?>
        <label class="f"><span>Etkinleştirme kodu<?php echo 'kod' === sides_kayit_yontemi() ? '' : ' (varsa)'; ?></span><input class="lic" type="text" name="kod" value="<?php echo $v( 'kod' ); // phpcs:ignore ?>" placeholder="ATLAS-XXXX-XXXX" autocomplete="off" <?php echo 'kod' === sides_kayit_yontemi() ? 'required' : ''; ?>></label>
        <p class="hint"><?php echo 'kod' === sides_kayit_yontemi() ? 'ATLAS ücretli bir sistemdir; hesabınız etkinleştirme koduyla açılır.' : 'Kodunuz varsa hesabınız hemen açılır. Kodunuz yoksa başvurunuz incelenir, onaylandığında e-postayla haber verilir.'; ?></p>
        <?php elseif ( 'sonra_kod' === sides_kayit_yontemi() ) : ?>
        <p class="hint">Kaydınızdan sonra size verilen etkinleştirme kodunu girerek hesabınızı açacaksınız.</p>
        <?php endif; ?>
        <div class="two">
          <label class="f"><span>Şifre</span><input type="password" name="sifre" autocomplete="new-password" minlength="8" required></label>
          <label class="f"><span>Şifre tekrar</span><input type="password" name="sifre2" autocomplete="new-password" minlength="8" required></label>
        </div>
        <p class="hint">Şifre en az 8 karakter olmalı.<?php echo sides_opt_dogrulama() ? ' E-posta adresinize 6 haneli bir doğrulama kodu göndereceğiz.' : ''; ?></p>
        <label class="chk"><input type="checkbox" name="aydinlatma" value="1" required> <span><a href="<?php echo esc_url( optik_karne_url( array( 'sayfa' => 'aydinlatma' ) ) ); ?>" target="_blank" rel="noopener">Aydınlatma metnini</a> okudum ve anladım.</span></label>
        <button class="btn" type="submit"><?php echo sides_opt_dogrulama() ? 'Doğrulama kodu gönder' : 'Hesabı oluştur'; ?></button>
      </form>
      <p class="alt">Hesabınız var mı? <a href="<?php echo esc_url( $url ); ?>">Giriş yapın</a></p>

      <?php elseif ( 'dogrula' === $view ) : ?>
      <p class="lead"><b><?php echo esc_html( isset( $d['email'] ) ? $d['email'] : '' ); ?></b> adresine 6 haneli bir kod gönderdik. Gelen kutunuzda yoksa istenmeyen e-posta klasörüne bakın.</p>
      <form method="post" action="<?php echo esc_url( $url ); ?>" novalidate>
        <?php echo $nonce; // phpcs:ignore ?><input type="hidden" name="sides_islem" value="dogrula"><input type="hidden" name="email" value="<?php echo $v( 'email' ); // phpcs:ignore ?>">
        <label class="f"><span>Doğrulama kodu</span><input class="code" type="text" name="kod" inputmode="numeric" autocomplete="one-time-code" maxlength="6" pattern="[0-9]{6}" placeholder="••••••" required autofocus></label>
        <button class="btn" type="submit">Doğrula ve hesabı oluştur</button>
      </form>
      <form method="post" action="<?php echo esc_url( $url ); ?>" class="inline">
        <?php echo $nonce; // phpcs:ignore ?><input type="hidden" name="sides_islem" value="tekrar"><input type="hidden" name="email" value="<?php echo $v( 'email' ); // phpcs:ignore ?>">
        <p class="alt">Kod gelmedi mi? <button type="submit" class="link">Tekrar gönder</button> · <a href="<?php echo esc_url( optik_karne_url( array( 'sayfa' => 'kaydol' ) ) ); ?>">E-postayı değiştir</a></p>
      </form>

      <?php elseif ( 'cihaz' === $view ) : ?>
      <p class="lead">Hesabınıza bu cihazdan ilk kez giriş yapılıyor. <b><?php echo esc_html( isset( $d['email'] ) ? $d['email'] : '' ); ?></b> adresine 6 haneli bir kod gönderdik. Kodu girdiğinizde bu cihaz hatırlanır.</p>
      <form method="post" action="<?php echo esc_url( $url ); ?>" novalidate>
        <?php echo $nonce; // phpcs:ignore ?><input type="hidden" name="sides_islem" value="cihaz">
        <label class="f"><span>Doğrulama kodu</span><input class="code" type="text" name="kod" inputmode="numeric" autocomplete="one-time-code" maxlength="6" pattern="[0-9]{6}" placeholder="••••••" required autofocus></label>
        <button class="btn" type="submit">Doğrula ve giriş yap</button>
      </form>
      <form method="post" action="<?php echo esc_url( $url ); ?>" class="inline">
        <?php echo $nonce; // phpcs:ignore ?><input type="hidden" name="sides_islem" value="cihaz_tekrar">
        <p class="alt">Kod gelmedi mi? <button type="submit" class="link">Tekrar gönder</button> · <a href="<?php echo esc_url( $url ); ?>">Girişe dön</a></p>
      </form>
      <p class="hint">Hesap güvenliği için her hesap kendi sahibinin e-postasına bağlıdır. Şifrenizi başkalarıyla paylaşmayın.</p>

      <?php elseif ( 'sifre' === $view ) : ?>
      <p class="lead">Hesabınızın e-posta adresini yazın; şifrenizi yenilemek için bir kod gönderelim.</p>
      <form method="post" action="<?php echo esc_url( $url ); ?>" novalidate>
        <?php echo $nonce; // phpcs:ignore ?><input type="hidden" name="sides_islem" value="sifre">
        <label class="f"><span>E-posta</span><input type="email" name="email" autocomplete="email" required autofocus></label>
        <button class="btn" type="submit">Kod gönder</button>
      </form>
      <p class="alt"><a href="<?php echo esc_url( $url ); ?>">Girişe dön</a></p>

      <?php elseif ( 'sifre2' === $view ) : ?>
      <p class="lead">Bu e-postaya kayıtlı bir hesap varsa <b><?php echo esc_html( isset( $d['email'] ) ? $d['email'] : '' ); ?></b> adresine bir kod gönderdik.</p>
      <form method="post" action="<?php echo esc_url( $url ); ?>" novalidate>
        <?php echo $nonce; // phpcs:ignore ?><input type="hidden" name="sides_islem" value="sifre2"><input type="hidden" name="email" value="<?php echo $v( 'email' ); // phpcs:ignore ?>">
        <label class="f"><span>Kod</span><input class="code" type="text" name="kod" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="••••••" required autofocus></label>
        <div class="two">
          <label class="f"><span>Yeni şifre</span><input type="password" name="sifre" autocomplete="new-password" minlength="8" required></label>
          <label class="f"><span>Yeni şifre tekrar</span><input type="password" name="sifre2" autocomplete="new-password" minlength="8" required></label>
        </div>
        <button class="btn" type="submit">Şifreyi yenile</button>
      </form>
      <p class="alt"><a href="<?php echo esc_url( $url ); ?>">Girişe dön</a></p>

      <?php elseif ( 'blok' === $view ) :
		$bk = isset( $d['blok'] ) ? $d['blok'] : '';
		$on = isset( $d['org'] ) && $d['org'] ? $d['org']->ad : '';
		?>
      <?php if ( 'bekliyor' === $bk ) : ?>
      <p class="lead"><b><?php echo esc_html( $on ); ?></b> hesabınız oluşturuldu. Size verilen etkinleştirme kodunu girin; hesabınız hemen açılır.</p>
      <?php elseif ( 'suresi' === $bk ) : ?>
      <p class="lead"><b><?php echo esc_html( $on ); ?></b> için ATLAS kullanım süresi sona erdi. Verileriniz saklanıyor; yeni bir etkinleştirme koduyla kaldığınız yerden devam edebilirsiniz.</p>
      <?php else : ?>
      <p class="lead"><b><?php echo esc_html( $on ); ?></b> hesabı geçici olarak askıya alındı. Bilgi için bizimle iletişime geçin.</p>
      <?php endif; ?>
      <?php if ( 'askida' !== $bk ) : ?>
      <form method="post" action="<?php echo esc_url( $url ); ?>" novalidate>
        <?php echo $nonce; // phpcs:ignore ?><input type="hidden" name="sides_islem" value="kod">
        <label class="f"><span>Etkinleştirme kodu</span><input class="lic big" type="text" name="kod" placeholder="ATLAS-XXXX-XXXX" autocomplete="off" required autofocus></label>
        <button class="btn" type="submit">Hesabı etkinleştir</button>
      </form>
      <?php if ( 'bekliyor' === $bk && 'kod' !== sides_kayit_yontemi() ) : ?>
      <p class="msg warn" style="margin-top:14px">Kodunuz yok mu? Başvurunuz yöneticimize iletildi. Onaylandığında e-postayla haber vereceğiz; o zaman kodsuz da giriş yapabilirsiniz.</p>
      <?php endif; ?>
      <?php endif; ?>
      <p class="alt"><a href="<?php echo esc_url( sides_logout_url() ); ?>">Çıkış yap</a></p>

      <?php elseif ( 'yetkisiz' === $view ) : ?>
      <div class="msg bad">Bu hesap bir ATLAS kurum alanına bağlı değil ya da erişimi kaldırılmış. Kurumunuzun yöneticisinden sizi eklemesini isteyin.</div>
      <p class="alt"><a href="<?php echo esc_url( sides_logout_url() ); ?>">Çıkış yap</a></p>

      <?php elseif ( 'aydinlatma' === $view ) : ?>
      <div class="legal">
        <p class="msg warn">Bu metin bir taslaktır. Yayına almadan önce veri sorumlusu bilgileriyle tamamlanıp hukuki olarak kontrol edilmelidir.</p>
        <p><b>Veri sorumlusu:</b> ATLAS'ı işleten kurum (ad, adres ve iletişim bilgisi eklenecek).</p>
        <p><b>İşlenen veriler:</b> ad soyad, e-posta adresi, kurum adı ve sistemi kullanırken oluşan işlem kayıtları. Kurumların sisteme girdiği öğrenci verilerinin veri sorumlusu ilgili kurumdur.</p>
        <p><b>Amaç:</b> hesabın oluşturulması, kimlik doğrulama, hizmetin sunulması ve güvenliğinin sağlanması.</p>
        <p><b>Hukuki sebep:</b> sözleşmenin kurulması ve ifası, veri sorumlusunun meşru menfaati (6698 sayılı Kanun m.5).</p>
        <p><b>Aktarım:</b> barındırma ve e-posta hizmet sağlayıcıları; yurt dışına aktarım olup olmadığı eklenecek.</p>
        <p><b>Haklarınız:</b> 6698 sayılı Kanun m.11 kapsamındaki haklarınızı veri sorumlusuna başvurarak kullanabilirsiniz.</p>
      </div>
      <p class="alt"><a href="<?php echo esc_url( $url ); ?>">Girişe dön</a></p>
      <?php endif; ?>
    </div>
  </div>
  <p class="foot">ATLAS · Akademik Takip ve Analiz Sistemi</p>
</main>
</body>
</html>
	<?php
}
