<?php
/**
 * v6 Rapor ve analiz — sunucu tarafı.
 *
 * Birleşik Takip Raporu (R02), yönetici günlük özeti ve profil kartları verilerini genel uçlardan alır:
 *   GET koleksiyon/<coll>?bas&bit[&alan=sonTarih]  (ortak.php: modül izni, sınıf kısıtı, v6 süzgeci)
 *   GET puan/ozet?bas&bit                          (puan.php: ortak puan motoru girdisi)
 * Kazanım görevleri (K04) odev koleksiyonuna genel /doc ucuyla yazılır (doğrulama: includes/odev.php).
 *
 * K06: veli raporu bağlantısının donmuş görüntüsünde "Ödevler" ve "Devam" bölümleri bulunur. Bu dosyadaki
 * sides_r2_vr_suz(), analiz2.php anlık görüntüyü yazmadan önce bu bölümlerden öğrencinin ödev iç notlarını
 * ve kontrol eden kişi adlarını içeren hücreleri siler (istemci bunları zaten eklemez; bu ikinci bir güvencedir).
 */
defined( 'ABSPATH' ) || exit;

/* Öğrencinin ödev kayıtlarındaki iç notlar ve kontrol eden adları (veli görüntüsüne giremez) */
function sides_r2_ic_metinler( $org, $sid ) {
	global $wpdb;
	if ( ! $sid || ! function_exists( 'sides_docs' ) ) {
		return array();
	}
	$t    = sides_docs();
	$rows = $wpdb->get_col( $wpdb->prepare( "SELECT data FROM $t WHERE org = %d AND coll = 'odev' AND data LIKE %s", $org, '%' . $wpdb->esc_like( '"' . $sid . '"' ) . '%' ) ); // phpcs:ignore
	$out  = array();
	foreach ( (array) $rows as $j ) {
		$d = json_decode( $j, true );
		if ( ! is_array( $d ) || ! in_array( $sid, array_map( 'strval', isset( $d['ogrenciler'] ) ? (array) $d['ogrenciler'] : array() ), true ) ) {
			continue;
		}
		if ( isset( $d['not'][ $sid ] ) && is_string( $d['not'][ $sid ] ) ) {
			$out[] = trim( $d['not'][ $sid ] );
		}
		if ( isset( $d['kontrol'][ $sid ]['ad'] ) && is_string( $d['kontrol'][ $sid ]['ad'] ) ) {
			$out[] = trim( $d['kontrol'][ $sid ]['ad'] );
		}
	}
	return array_values( array_filter( array_unique( $out ), function ( $x ) {
		return mb_strlen( $x ) >= 3;
	} ) );
}

/* Veli raporu anlık görüntüsü: odev / devam bölümlerinde iç metin geçen hücreler "—" olur */
function sides_r2_vr_suz( $org, $sid, $r ) {
	if ( ! is_array( $r ) || empty( $r['bolumler'] ) || ! is_array( $r['bolumler'] ) ) {
		return $r;
	}
	$ic = sides_r2_ic_metinler( $org, (string) $sid );
	if ( ! $ic ) {
		return $r;
	}
	$temiz = function ( $v ) use ( $ic, &$temiz ) {
		if ( is_array( $v ) ) {
			foreach ( $v as $k => $x ) {
				$v[ $k ] = $temiz( $x );
			}
			return $v;
		}
		if ( ! is_string( $v ) || '' === $v ) {
			return $v;
		}
		foreach ( $ic as $m ) {   // tam sözcük eşleşmesi: kısa bir ad başka sözcüğün parçası olarak silinmez
			if ( preg_match( '/(?<![\p{L}\p{N}])' . preg_quote( $m, '/' ) . '(?![\p{L}\p{N}])/iu', $v ) ) {
				return '—';
			}
		}
		return $v;
	};
	foreach ( $r['bolumler'] as $i => $b ) {
		if ( is_array( $b ) && isset( $b['k'] ) && in_array( $b['k'], array( 'odev', 'devam' ), true ) ) {
			foreach ( array( 'aciklama', 'metin', 'yok', 'tablo', 'tiles', 'liste' ) as $a ) {
				if ( isset( $b[ $a ] ) ) {
					$b[ $a ] = $temiz( $b[ $a ] );
				}
			}
			$r['bolumler'][ $i ] = $b;
		}
	}
	return $r;
}

/* ------------------------------------------------------------------ *
 * v7: Birleşik Takip Raporu şablonları (r2sablon/<id>)
 * { ad, kapsam: 'kisisel'|'kurum', sahip: { u, ad }, ayar: { donem, kirilim, bolum{}, sinif, sube, bas?, bit? }, t }
 * Kişisel şablonu yalnız sahibi görür ve değiştirir; kurum geneli şablonu herkes (raporu görebilen) görür, yalnız yönetici
 * oluşturur / değiştirir / siler. Gözlemci yalnızca kurum şablonlarını uygular. Genel /doc ucunun listesinde yoktur.
 * ------------------------------------------------------------------ */
define( 'SIDES_R2_BOLUM', array( 'etut', 'yoklama', 'izin', 'odev', 'oturum', 'kitap', 'takviye', 'sgunluk', 'puan' ) );
function sides_r2s_gor() {
	return sides_can( 'takip', 1 ) && ( ! function_exists( 'sides_sayfa_herhangi' ) || sides_sayfa_herhangi( array( 'analiz.takiprapor' ), 1 ) );
}
function sides_r2s_kucuk( $s ) {   // Türkçe büyük/küçük harf duyarsız ad karşılaştırması
	return mb_strtolower( str_replace( array( 'I', 'İ' ), array( 'ı', 'i' ), trim( $s ) ), 'UTF-8' );
}
function sides_r2s_yonetici() {
	return 'yonetici' === sides_ctx()['rol'];
}
add_action( 'rest_api_init', function () {
	$ns  = 'optik-karne/v1';
	$gor = function () {
		return sides_r2s_gor() ? true : sides_deny( 'Birleşik Takip Raporu’nu görme yetkiniz yok.' );
	};
	$yaz = function () {
		if ( sides_is_observer() ) {
			return sides_deny( 'Gözlemci hesabı şablon kaydedemez; kurum şablonlarını uygulayabilir.' );
		}
		return sides_r2s_gor() ? true : sides_deny( 'Birleşik Takip Raporu’nu görme yetkiniz yok.' );
	};
	register_rest_route( $ns, '/r2/sablon', array(
		array( 'methods' => 'GET', 'callback' => 'sides_r2s_liste', 'permission_callback' => $gor ),
		array( 'methods' => 'POST', 'callback' => 'sides_r2s_kaydet', 'permission_callback' => $yaz ),
	) );
	register_rest_route( $ns, '/r2/sablon/(?P<id>rs[a-f0-9]{12})', array(
		array( 'methods' => 'DELETE', 'callback' => 'sides_r2s_sil', 'permission_callback' => $yaz ),
	) );
} );
function sides_r2s_disari( $id, $d ) {
	$uid = get_current_user_id();
	$k   = 'kurum' === ( $d['kapsam'] ?? '' ) ? 'kurum' : 'kisisel';
	return array(
		'id'     => $id,
		'ad'     => (string) ( $d['ad'] ?? '' ),
		'kapsam' => $k,
		'sahip'  => isset( $d['sahip']['ad'] ) ? (string) $d['sahip']['ad'] : '',
		'ayar'   => isset( $d['ayar'] ) && is_array( $d['ayar'] ) ? $d['ayar'] : array(),
		't'      => (int) ( $d['t'] ?? 0 ),
		'yaz'    => ! sides_is_observer() && ( 'kurum' === $k ? sides_r2s_yonetici() : (int) ( $d['sahip']['u'] ?? 0 ) === (int) $uid ),
	);
}
/* Kullanıcının görebildiği şablonlar: kurum geneli + kendi kişiselleri (gözlemci: yalnız kurum) */
function sides_r2s_tum( $org ) {
	global $wpdb;
	$uid = (int) get_current_user_id();
	$out = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( 'SELECT id, data FROM ' . sides_docs() . " WHERE org = %d AND coll = 'r2sablon'", $org ) ) as $r ) { // phpcs:ignore
		$d = json_decode( $r->data, true );
		if ( ! is_array( $d ) ) {
			continue;
		}
		if ( 'kurum' === ( $d['kapsam'] ?? '' ) || ( ! sides_is_observer() && (int) ( $d['sahip']['u'] ?? 0 ) === $uid ) ) {
			$out[ $r->id ] = $d;
		}
	}
	return $out;
}
function sides_r2s_liste( WP_REST_Request $req ) {
	$out = array();
	foreach ( sides_r2s_tum( sides_org_id() ) as $id => $d ) {
		$out[] = sides_r2s_disari( $id, $d );
	}
	usort( $out, function ( $a, $b ) {
		return strcmp( $a['kapsam'], $b['kapsam'] ) ?: strnatcasecmp( $a['ad'], $b['ad'] );
	} );
	return array( 'sablonlar' => $out, 'kurumYaz' => sides_r2s_yonetici() );
}
/* Ayar beyaz liste ile temizlenir; tanınmayan alan saklanmaz */
function sides_r2s_ayar( $a ) {
	$a   = is_array( $a ) ? $a : array();
	$tar = '/^\d{4}-\d{2}-\d{2}$/';
	$o   = array(
		'donem'   => in_array( $a['donem'] ?? '', array( 'gun', 'hafta', 'ay', 'aralik', 'yil' ), true ) ? $a['donem'] : 'hafta',
		'kirilim' => in_array( $a['kirilim'] ?? '', array( 'toplu', 'gun', 'hafta', 'ay' ), true ) ? $a['kirilim'] : 'toplu',
		'bolum'   => array(),
		'sinif'   => mb_substr( trim( sanitize_text_field( (string) ( $a['sinif'] ?? '' ) ) ), 0, 20 ),
		'sube'    => mb_substr( trim( sanitize_text_field( (string) ( $a['sube'] ?? '' ) ) ), 0, 10 ),
	);
	foreach ( SIDES_R2_BOLUM as $b ) {
		$o['bolum'][ $b ] = ! empty( $a['bolum'][ $b ] );
	}
	if ( '' === $o['sinif'] ) {
		$o['sube'] = '';
	}
	if ( 'aralik' === $o['donem'] ) {
		$bas = (string) ( $a['bas'] ?? '' );
		$bit = (string) ( $a['bit'] ?? '' );
		if ( ! preg_match( $tar, $bas ) || ! preg_match( $tar, $bit ) || $bit < $bas ) {
			return new WP_Error( 'sides_gecersiz', 'Tarih aralığı şablonu için geçerli başlangıç ve bitiş tarihi gerekir.', array( 'status' => 400 ) );
		}
		$o['bas'] = $bas;
		$o['bit'] = $bit;
	}
	if ( ! in_array( true, $o['bolum'], true ) ) {
		return new WP_Error( 'sides_gecersiz', 'Şablonda en az bir veri başlığı seçili olmalı.', array( 'status' => 400 ) );
	}
	return $o;
}
function sides_r2s_kaydet( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	$p   = is_array( $p ) ? $p : array();
	$id  = isset( $p['id'] ) ? (string) $p['id'] : '';
	$ad  = mb_substr( trim( sanitize_text_field( (string) ( $p['ad'] ?? '' ) ) ), 0, 60 );
	if ( '' === $ad ) {
		return new WP_Error( 'sides_gecersiz', 'Şablona bir ad verin.', array( 'status' => 400 ) );
	}
	$u    = wp_get_current_user();
	$tum  = sides_r2s_tum( $org );
	$eski = null;
	if ( '' !== $id ) {
		if ( ! preg_match( '/^rs[a-f0-9]{12}$/', $id ) || ! isset( $tum[ $id ] ) ) {
			return new WP_Error( 'sides_yok', 'Şablon bulunamadı; listeyi yenileyin.', array( 'status' => 404 ) );
		}
		$eski = $tum[ $id ];
		if ( ! sides_r2s_disari( $id, $eski )['yaz'] ) {
			return sides_deny( 'Kurum geneli şablonu yalnızca yönetici değiştirebilir.' );
		}
	}
	$kapsam = isset( $p['kapsam'] ) ? ( 'kurum' === $p['kapsam'] ? 'kurum' : 'kisisel' ) : ( $eski ? ( $eski['kapsam'] ?? 'kisisel' ) : 'kisisel' );
	if ( 'kurum' === $kapsam && ! sides_r2s_yonetici() ) {
		return sides_deny( 'Kurum geneli şablonu yalnızca yönetici kaydedebilir; şablonu kişisel olarak kaydedin.' );
	}
	if ( $eski && $kapsam !== ( $eski['kapsam'] ?? 'kisisel' ) && (int) ( $eski['sahip']['u'] ?? 0 ) !== (int) $u->ID && 'kurum' !== $kapsam ) {
		return sides_deny( 'Başka kullanıcının şablonu kişisel yapılamaz.' );
	}
	if ( isset( $p['ayar'] ) || ! $eski ) {
		$ayar = sides_r2s_ayar( $p['ayar'] ?? null );
		if ( is_wp_error( $ayar ) ) {
			return $ayar;
		}
	} else {
		$ayar = $eski['ayar'];   // yalnızca yeniden adlandırma
	}
	foreach ( $tum as $tid => $t ) {
		if ( $tid !== $id && ( $t['kapsam'] ?? 'kisisel' ) === $kapsam && sides_r2s_kucuk( (string) ( $t['ad'] ?? '' ) ) === sides_r2s_kucuk( $ad ) ) {
			return new WP_Error( 'sides_ayni', 'Aynı adla bir şablon zaten var; başka bir ad seçin ya da o şablonu güncelleyin.', array( 'status' => 409 ) );
		}
	}
	if ( ! $eski ) {
		$say = count( array_filter( $tum, function ( $t ) use ( $kapsam ) {
			return ( $t['kapsam'] ?? 'kisisel' ) === $kapsam;
		} ) );
		if ( $say >= 30 ) {
			return new WP_Error( 'sides_sinir', 'En fazla 30 ' . ( 'kurum' === $kapsam ? 'kurum' : 'kişisel' ) . ' şablonu kaydedilebilir; kullanmadıklarınızı silin.', array( 'status' => 400 ) );
		}
		$id = 'rs' . bin2hex( random_bytes( 6 ) );
	}
	$d = array(
		'ad'     => $ad,
		'kapsam' => $kapsam,
		'sahip'  => $eski && isset( $eski['sahip'] ) ? $eski['sahip'] : array( 'u' => (int) $u->ID, 'ad' => $u->display_name ),
		'ayar'   => $ayar,
		't'      => time(),
	);
	if ( false === sides_put_doc( $org, 'r2sablon', $id, $d ) ) {
		return new WP_Error( 'sides_db', 'Kaydedilemedi.', array( 'status' => 500 ) );
	}
	if ( 'kurum' === $kapsam ) {
		sides_log( $org, 'Birleşik takip raporu kurum şablonu ' . ( $eski ? 'güncellendi' : 'kaydedildi' ) . ': ' . $ad );
	}
	return sides_r2s_disari( $id, $d );
}
function sides_r2s_sil( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$id  = (string) $req['id'];
	$tum = sides_r2s_tum( $org );
	if ( ! isset( $tum[ $id ] ) ) {
		return new WP_Error( 'sides_yok', 'Şablon bulunamadı; listeyi yenileyin.', array( 'status' => 404 ) );
	}
	if ( ! sides_r2s_disari( $id, $tum[ $id ] )['yaz'] ) {
		return sides_deny( 'Kurum geneli şablonu yalnızca yönetici silebilir.' );
	}
	$wpdb->delete( sides_docs(), array( 'org' => $org, 'coll' => 'r2sablon', 'id' => $id ) );
	if ( 'kurum' === ( $tum[ $id ]['kapsam'] ?? '' ) ) {
		sides_log( $org, 'Birleşik takip raporu kurum şablonu silindi: ' . ( $tum[ $id ]['ad'] ?? '' ) );
	}
	return array( 'ok' => true );
}
