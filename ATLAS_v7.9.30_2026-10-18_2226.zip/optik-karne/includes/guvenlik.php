<?php
/**
 * ATLAS hesap güvenliği ve sınıf yetkisi.
 *
 * - Tek oturum: bir kurum hesabı aynı anda yalnızca bir cihazda açık kalır; yeni giriş diğer oturumları kapatır.
 * - Yeni cihaz doğrulaması: tanınmayan bir tarayıcıdan girişte hesabın e-postasına 6 haneli kod gönderilir.
 * - Giriş geçmişi: son girişler (tarih, cihaz, IP) kurum yöneticisine gösterilir; oturumlar ve tanınan cihazlar sıfırlanabilir.
 * - Sınıf yetkisi: personel ve gözlemci yalnızca kendisine verilen sınıf/şubelerin öğrencilerini, sonuçlarını ve karnelerini alır.
 * Site yöneticisi (ana hesap) oturum ve cihaz kurallarının dışındadır.
 *
 * @package ATLAS
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SIDES_CIHAZ_CEREZ', 'atlas_cihaz' );
define( 'SIDES_BEKLEYEN_CEREZ', 'atlas_bekleyen' );

/* Site geneli ayarlar (WordPress › ATLAS sayfası). Varsayılan: açık. */
function sides_opt_tek_oturum() {
	return '0' !== (string) get_option( 'sides_tek_oturum', '1' );
}
function sides_opt_cihaz_dogrulama() {
	return '0' !== (string) get_option( 'sides_cihaz_dogrulama', '1' );
}

/* Kurallar kurum kullanıcılarına uygulanır (yönetici, personel, gözlemci, öğretmen); site yöneticisi hariç. */
function sides_guvenlik_kapsami( $u ) {
	if ( ! $u || empty( $u->ID ) || user_can( $u, 'manage_options' ) ) {
		return false;
	}
	$c = sides_ctx( $u->ID );
	return '' !== $c['rol'] || ! empty( $c['blok'] );
}

function sides_ip() {
	return isset( $_SERVER['REMOTE_ADDR'] ) ? substr( sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ), 0, 45 ) : ''; // phpcs:ignore
}

/* "Chrome · Windows" gibi kısa cihaz adı */
function sides_ua_kisa( $ua = null ) {
	if ( null === $ua ) {
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) : ''; // phpcs:ignore
	}
	$tar = 'Tarayıcı';
	foreach ( array( 'Edg' => 'Edge', 'OPR/' => 'Opera', 'YaBrowser' => 'Yandex', 'SamsungBrowser' => 'Samsung Internet', 'Firefox/' => 'Firefox', 'FxiOS' => 'Firefox', 'CriOS' => 'Chrome', 'Chrome/' => 'Chrome', 'Safari/' => 'Safari' ) as $k => $v ) {
		if ( false !== strpos( $ua, $k ) ) {
			$tar = $v;
			break;
		}
	}
	$os = 'bilinmeyen sistem';
	foreach ( array( 'iPhone' => 'iPhone', 'iPad' => 'iPad', 'Android' => 'Android', 'Windows' => 'Windows', 'CrOS' => 'Chromebook', 'Mac OS X' => 'macOS', 'Linux' => 'Linux' ) as $k => $v ) {
		if ( false !== strpos( $ua, $k ) ) {
			$os = $v;
			break;
		}
	}
	return $tar . ' · ' . $os;
}

function sides_eposta_maskele( $e ) {
	$p = explode( '@', (string) $e, 2 );
	if ( 2 !== count( $p ) ) {
		return $e;
	}
	$a = $p[0];
	return mb_substr( $a, 0, min( 2, mb_strlen( $a ) ) ) . str_repeat( '•', max( 1, min( 6, mb_strlen( $a ) - 2 ) ) ) . '@' . $p[1];
}

function sides_cerez( $ad, $deger, $sure ) {
	setcookie( $ad, $deger, array( 'expires' => $sure ? time() + $sure : time() - 3600, 'path' => '/', 'domain' => COOKIE_DOMAIN, 'secure' => is_ssl(), 'httponly' => true, 'samesite' => 'Lax' ) );
	if ( $sure ) {
		$_COOKIE[ $ad ] = $deger;
	} else {
		unset( $_COOKIE[ $ad ] );
	}
}

/* ------------------------------------------------------------------ *
 * Tek oturum
 * ------------------------------------------------------------------ */
add_action( 'set_auth_cookie', function ( $cookie, $expire, $expiration, $uid, $scheme, $token = '' ) {
	if ( ! $token || ! sides_opt_tek_oturum() ) {
		return;
	}
	$u = get_userdata( $uid );
	if ( sides_guvenlik_kapsami( $u ) ) {
		WP_Session_Tokens::get_instance( $uid )->destroy_others( $token );
	}
}, 10, 6 );

/* ------------------------------------------------------------------ *
 * Tanınan cihazlar
 * ------------------------------------------------------------------ */
function sides_cihaz_listesi( $uid ) {
	$l = get_user_meta( $uid, 'sides_cihazlar', true );
	return is_array( $l ) ? $l : array();
}
function sides_cihaz_cerezi() {
	$c = isset( $_COOKIE[ SIDES_CIHAZ_CEREZ ] ) ? preg_replace( '/[^a-f0-9]/', '', (string) wp_unslash( $_COOKIE[ SIDES_CIHAZ_CEREZ ] ) ) : ''; // phpcs:ignore
	return 32 === strlen( $c ) ? $c : '';
}
function sides_cihaz_hash( $uid, $c ) {
	return hash_hmac( 'sha256', $uid . '|' . $c, wp_salt( 'auth' ) );
}
function sides_cihaz_taninir( $uid ) {
	$c = sides_cihaz_cerezi();
	if ( ! $c ) {
		return false;
	}
	$h = sides_cihaz_hash( $uid, $c );
	foreach ( sides_cihaz_listesi( $uid ) as $d ) {
		if ( isset( $d['h'] ) && hash_equals( (string) $d['h'], $h ) ) {
			return true;
		}
	}
	return false;
}
/* Bu tarayıcıyı hesabın tanınan cihazlarına ekler (en fazla 10, en eskisi düşer) ya da son kullanımını günceller. */
function sides_cihaz_kaydet( $uid ) {
	$c = sides_cihaz_cerezi();
	if ( ! $c ) {
		$c = bin2hex( random_bytes( 16 ) );
	}
	sides_cerez( SIDES_CIHAZ_CEREZ, $c, 400 * DAY_IN_SECONDS );
	$h = sides_cihaz_hash( $uid, $c );
	$l = array();
	$ilk = time();
	foreach ( sides_cihaz_listesi( $uid ) as $d ) {
		if ( isset( $d['h'] ) && hash_equals( (string) $d['h'], $h ) ) {
			$ilk = isset( $d['ilk'] ) ? (int) $d['ilk'] : $ilk;
			continue;
		}
		$l[] = $d;
	}
	$l[] = array( 'h' => $h, 'ad' => sides_ua_kisa(), 'ilk' => $ilk, 'son' => time(), 'ip' => sides_ip() );
	update_user_meta( $uid, 'sides_cihazlar', array_slice( $l, -10 ) );
}

/* ------------------------------------------------------------------ *
 * Giriş geçmişi
 * ------------------------------------------------------------------ */
function sides_giris_kaydet( $uid, $cihaz ) {
	$l = get_user_meta( $uid, 'sides_girisler', true );
	$l = is_array( $l ) ? $l : array();
	$l[] = array( 't' => time(), 'ip' => sides_ip(), 'ua' => sides_ua_kisa(), 'cihaz' => $cihaz );
	update_user_meta( $uid, 'sides_girisler', array_slice( $l, -30 ) );
}

/* Kimlik doğrulandıktan sonra girişi tamamlar: oturum çerezi, giriş kaydı, yönlendirme. */
function sides_giris_tamamla( $user, $hatirla, $cihaz ) {
	wp_set_auth_cookie( $user->ID, $hatirla, is_ssl() );
	do_action( 'wp_login', $user->user_login, $user );
	if ( sides_guvenlik_kapsami( $user ) ) {
		if ( 'yeni' === $cihaz || sides_cihaz_taninir( $user->ID ) ) {
			sides_cihaz_kaydet( $user->ID );
		}
		sides_giris_kaydet( $user->ID, $cihaz );
	}
	wp_safe_redirect( optik_karne_url() );
}

/* ------------------------------------------------------------------ *
 * Yeni cihaz doğrulaması (giriş sayfası akışı)
 * ------------------------------------------------------------------ */
function sides_cihaz_gerekli( $user ) {
	return sides_opt_cihaz_dogrulama() && sides_guvenlik_kapsami( $user ) && ! sides_cihaz_taninir( $user->ID );
}
function sides_bekleyen() {
	$b = isset( $_COOKIE[ SIDES_BEKLEYEN_CEREZ ] ) ? preg_replace( '/[^a-f0-9]/', '', (string) wp_unslash( $_COOKIE[ SIDES_BEKLEYEN_CEREZ ] ) ) : ''; // phpcs:ignore
	if ( 32 !== strlen( $b ) ) {
		return array( '', null );
	}
	$p = get_transient( 'sides_cihaz_' . $b );
	return array( $b, is_array( $p ) ? $p : null );
}
/* Kod üretir, e-postayla gönderir ve kod sayfasını gösterir. */
function sides_cihaz_kodu( $user, $hatirla, $b = '' ) {
	$b   = $b ? $b : bin2hex( random_bytes( 16 ) );
	$kod = (string) random_int( 100000, 999999 );
	set_transient( 'sides_cihaz_' . $b, array( 'uid' => $user->ID, 'h' => sides_code_hash( $user->user_email, $kod ), 'hatirla' => $hatirla ? 1 : 0, 'n' => 0 ), 15 * MINUTE_IN_SECONDS );
	sides_cerez( SIDES_BEKLEYEN_CEREZ, $b, 15 * MINUTE_IN_SECONDS );
	if ( ! sides_send_code( $user->user_email, $kod, 'cihaz' ) ) {
		delete_transient( 'sides_cihaz_' . $b );
		sides_auth_page( 'giris', array( 'hata' => 'Doğrulama kodu e-postası gönderilemedi. Lütfen kurum yöneticinize bildirin.', 'login' => $user->user_email ) );
		return;
	}
	sides_auth_page( 'cihaz', array( 'email' => sides_eposta_maskele( $user->user_email ) ) );
}
function sides_do_cihaz() {
	list( $b, $p ) = sides_bekleyen();
	$u = $p ? get_userdata( (int) $p['uid'] ) : null;
	if ( ! $u ) {
		sides_auth_page( 'giris', array( 'hata' => 'Doğrulamanın süresi doldu. Lütfen yeniden giriş yapın.' ) );
		return;
	}
	$kod = preg_replace( '/\D/', '', sides_post( 'kod', 12 ) );
	if ( ! hash_equals( (string) $p['h'], sides_code_hash( $u->user_email, $kod ) ) ) {
		$p['n'] = (int) $p['n'] + 1;
		if ( $p['n'] >= 5 ) {
			delete_transient( 'sides_cihaz_' . $b );
			sides_cerez( SIDES_BEKLEYEN_CEREZ, '', 0 );
			sides_auth_page( 'giris', array( 'hata' => 'Çok fazla hatalı kod girildi. Lütfen yeniden giriş yapın.', 'login' => $u->user_email ) );
			return;
		}
		set_transient( 'sides_cihaz_' . $b, $p, 15 * MINUTE_IN_SECONDS );
		sides_auth_page( 'cihaz', array( 'email' => sides_eposta_maskele( $u->user_email ), 'hata' => 'Kod hatalı. E-postadaki 6 haneli kodu yazın.' ) );
		return;
	}
	delete_transient( 'sides_cihaz_' . $b );
	sides_cerez( SIDES_BEKLEYEN_CEREZ, '', 0 );
	sides_giris_tamamla( $u, ! empty( $p['hatirla'] ), 'yeni' );
}
function sides_do_cihaz_tekrar() {
	list( $b, $p ) = sides_bekleyen();
	$u = $p ? get_userdata( (int) $p['uid'] ) : null;
	if ( ! $u ) {
		sides_auth_page( 'giris', array( 'hata' => 'Doğrulamanın süresi doldu. Lütfen yeniden giriş yapın.' ) );
		return;
	}
	if ( ! sides_rl_check( 'cihaz_tekrar', 4 ) ) {
		sides_auth_page( 'cihaz', array( 'email' => sides_eposta_maskele( $u->user_email ), 'hata' => 'Çok fazla kod istendi. Birkaç dakika sonra tekrar deneyin.' ) );
		return;
	}
	sides_rl_hit( 'cihaz_tekrar', 15 * MINUTE_IN_SECONDS );
	sides_cihaz_kodu( $u, ! empty( $p['hatirla'] ), $b );
}

/* ------------------------------------------------------------------ *
 * Sınıf yetkisi: "7" (bütün 7. sınıflar) ya da "7/A" (yalnızca şube)
 * ------------------------------------------------------------------ */
function sides_sinif_norm( $s ) {
	$s = trim( preg_replace( '/\s+/u', ' ', (string) $s ) );
	if ( '' === $s ) {
		return '';
	}
	$p = explode( '/', $s, 2 );
	$g = trim( mb_substr( trim( $p[0] ), 0, 20 ) );
	$b = isset( $p[1] ) ? mb_strtoupper( trim( mb_substr( trim( $p[1] ), 0, 20 ) ), 'UTF-8' ) : '';
	if ( '' === $g ) {
		return '';
	}
	return '' === $b ? $g : $g . '/' . $b;
}
function sides_clean_siniflar( $a ) {
	$out = array();
	foreach ( (array) $a as $s ) {
		$n = sides_sinif_norm( $s );
		if ( '' !== $n ) {
			$out[ $n ] = 1;
		}
	}
	// Anahtarlar PHP'de '3' → 3 tamsayıya döner; katı karşılaştırmalar için metne çevrilir (yalnızca sınıf düzeyi yetkisi).
	return array_slice( array_map( 'strval', array_keys( $out ) ), 0, 80 );
}
function sides_user_siniflar( $uid ) {
	$l = get_user_meta( $uid, 'sides_siniflar', true );
	return is_array( $l ) ? array_values( array_map( 'strval', $l ) ) : array();
}
/* Geçerli kullanıcının sınıf kısıtı; null = kısıt yok (tüm öğrenciler). */
function sides_sinif_kisit( $uid = null ) {
	$c = sides_ctx( $uid );
	if ( ! in_array( $c['rol'], array( 'personel', 'gozlemci' ), true ) ) {
		return null;
	}
	$l = sides_user_siniflar( $c['uid'] );
	return $l ? $l : null;
}
function sides_ogrenci_izinli( $d, $kisit ) {
	if ( null === $kisit ) {
		return true;
	}
	if ( ! is_array( $d ) ) {
		return false;
	}
	$g = sides_sinif_norm( isset( $d['sinif'] ) ? str_replace( '/', ' ', (string) $d['sinif'] ) : '' );
	if ( '' === $g ) {
		return false;
	}
	$b = isset( $d['sube'] ) ? mb_strtoupper( trim( (string) $d['sube'] ), 'UTF-8' ) : '';
	return in_array( $g, $kisit, true ) || ( '' !== $b && in_array( $g . '/' . $b, $kisit, true ) );
}
/* Kısıtlı kullanıcının görebildiği öğrenci kimlikleri: id => true */
function sides_izinli_ogrenciler( $org, $kisit ) {
	global $wpdb;
	static $cache = array();
	$k = $org . '|' . implode( ',', $kisit );
	if ( isset( $cache[ $k ] ) ) {
		return $cache[ $k ];
	}
	$t   = sides_docs();
	$out = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = 'students'", $org ) ) as $r ) { // phpcs:ignore
		if ( sides_ogrenci_izinli( json_decode( $r->data, true ), $kisit ) ) {
			$out[ (string) $r->id ] = true;
		}
	}
	$cache[ $k ] = $out;
	return $out;
}
/* Bir sonuç kaydı (deneme ya da test) kısıtlı kullanıcıya açık mı? */
function sides_sonuc_izinli( $d, $izin ) {
	return null === $izin || ( is_array( $d ) && isset( $d['studentId'] ) && isset( $izin[ (string) $d['studentId'] ] ) );
}
/* Yazma ve silme denetimi: öğrenci ve sonuç kayıtları yalnızca yetkili sınıflar için. Hata ya da null döner. */
function sides_sinif_yazma_denetimi( $org, $coll, $id, $yeni ) {
	if ( ! in_array( $coll, array( 'students', 'results', 'tsonuc', 'lgs', 'kitap', 'hedef', 'workwin', 'sgunluk', 'phareket', 'pgun', 'velirapor' ), true ) ) {
		return null;
	}
	$kisit = sides_sinif_kisit();
	if ( null === $kisit ) {
		return null;
	}
	$eski = sides_get_doc( $org, $coll, $id );
	$red  = sides_deny( 'Bu öğrenci, yetkili olduğunuz sınıfların dışında.' );
	if ( 'students' === $coll ) {
		if ( ( $eski && ! sides_ogrenci_izinli( $eski, $kisit ) ) || ( is_array( $yeni ) && ! sides_ogrenci_izinli( $yeni, $kisit ) ) ) {
			return $red;
		}
		return null;
	}
	$izin = sides_izinli_ogrenciler( $org, $kisit );
	if ( $eski && ! empty( $eski['studentId'] ) && ! isset( $izin[ (string) $eski['studentId'] ] ) ) {
		return $red;
	}
	if ( is_array( $yeni ) && ! empty( $yeni['studentId'] ) && ! isset( $izin[ (string) $yeni['studentId'] ] ) ) {
		return $red;
	}
	return null;
}

/* ------------------------------------------------------------------ *
 * REST: kullanıcının giriş geçmişi, açık oturumları ve tanınan cihazları (kurum yöneticisi)
 * ------------------------------------------------------------------ */
function sides_guvenlik_hedef( WP_REST_Request $req ) {
	$u = get_userdata( (int) $req['id'] );
	/* v7.3.1: site yöneticisinin oturum ve cihazlarını yalnız kendisi ya da ana hesap yönetir (eski sürüm yöneticileri 1 numaralı kurumda görünür) */
	if ( ! $u || (int) sides_ctx( $u->ID )['org'] !== sides_org_id() || ( user_can( $u, 'manage_options' ) && get_current_user_id() !== $u->ID && ! sides_is_super() ) ) {
		return new WP_Error( 'sides_yok', 'Kullanıcı bulunamadı.', array( 'status' => 404 ) );
	}
	return $u;
}
function sides_rest_guvenlik( WP_REST_Request $req ) {
	$u = sides_guvenlik_hedef( $req );
	if ( is_wp_error( $u ) ) {
		return $u;
	}
	$g = get_user_meta( $u->ID, 'sides_girisler', true );
	$g = is_array( $g ) ? array_reverse( $g ) : array();
	$o = array();
	foreach ( WP_Session_Tokens::get_instance( $u->ID )->get_all() as $s ) {
		$o[] = array( 'giris' => isset( $s['login'] ) ? (int) $s['login'] : 0, 'bitis' => isset( $s['expiration'] ) ? (int) $s['expiration'] : 0, 'ip' => isset( $s['ip'] ) ? (string) $s['ip'] : '', 'ua' => sides_ua_kisa( isset( $s['ua'] ) ? (string) $s['ua'] : '' ) );
	}
	usort( $o, function ( $a, $b ) {
		return $b['giris'] - $a['giris'];
	} );
	$c = array();
	foreach ( array_reverse( sides_cihaz_listesi( $u->ID ) ) as $d ) {
		$c[] = array( 'ad' => isset( $d['ad'] ) ? $d['ad'] : '', 'ilk' => isset( $d['ilk'] ) ? (int) $d['ilk'] : 0, 'son' => isset( $d['son'] ) ? (int) $d['son'] : 0, 'ip' => isset( $d['ip'] ) ? $d['ip'] : '' );
	}
	return array(
		'girisler'       => $g,
		'oturumlar'      => $o,
		'cihazlar'       => $c,
		'kapsam'         => sides_guvenlik_kapsami( $u ),
		'tekOturum'      => sides_opt_tek_oturum(),
		'cihazDogrulama' => sides_opt_cihaz_dogrulama(),
	);
}
function sides_rest_guvenlik_islem( WP_REST_Request $req ) {
	$u = sides_guvenlik_hedef( $req );
	if ( is_wp_error( $u ) ) {
		return $u;
	}
	$p     = $req->get_json_params();
	$islem = isset( $p['islem'] ) ? (string) $p['islem'] : '';
	if ( 'oturum' === $islem ) {
		WP_Session_Tokens::get_instance( $u->ID )->destroy_all();
		sides_log( sides_org_id(), 'Kullanıcının tüm oturumları kapatıldı: ' . $u->display_name );
	} elseif ( 'cihaz' === $islem ) {
		delete_user_meta( $u->ID, 'sides_cihazlar' );
		sides_log( sides_org_id(), 'Kullanıcının tanınan cihazları sıfırlandı: ' . $u->display_name );
	} else {
		return new WP_Error( 'sides_gecersiz', 'Geçersiz işlem.', array( 'status' => 400 ) );
	}
	return sides_rest_guvenlik( $req );
}
