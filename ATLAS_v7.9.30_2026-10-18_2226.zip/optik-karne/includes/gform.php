<?php
/**
 * v7.9.25 Kayıt › ÖDS Kayıt (Google Form)
 * Kurum bir Google Form bağlantısı ve formun yanıtlarının toplandığı Google E-Tablo bağlantısını kaydeder.
 * Sunucu e-tabloyu CSV olarak çeker (60 sn önbellek), ATLAS'ta yetkililere tablo olarak gösterilir.
 * ÖDS formu olarak işaretlenen Google Form, herkese açık /ods/ adresinde eski ATLAS kayıt formunun yerine gömülü açılır.
 * Yalnız docs.google.com ve forms.gle adresleri kabul edilir (sunucu başka adrese istek atmaz).
 * Belge: sides_docs coll 'gform', id 'ayar' → { formlar: [ {id, ad, formUrl, gomUrl, veriUrl, csvUrl, ods, olusturma, guncelleme} ] }
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function sides_gf_ayar( $org ) {
	$d = sides_get_doc( (int) $org, 'gform', 'ayar' );
	$L = is_array( $d ) && isset( $d['formlar'] ) && is_array( $d['formlar'] ) ? $d['formlar'] : array();
	return array_values( array_filter( $L, 'is_array' ) );
}
function sides_gf_yaz_ayar( $org, $L ) {
	return false !== sides_put_doc( (int) $org, 'gform', 'ayar', array( 'formlar' => array_values( $L ) ) );
}
function sides_gf_yazabilir() {
	return sides_can( 'kayit', 2 ) && ! sides_is_observer();
}
function sides_gf_hata( $m, $s = 400 ) {
	return new WP_Error( 'sides_gform', $m, array( 'status' => $s ) );
}
function sides_gf_yanit( $d ) {
	$r = rest_ensure_response( $d );
	$r->header( 'Cache-Control', 'no-store, private' );
	return $r;
}

/* ---- Bağlantı çözümleme ---- */
/* Google Form: gömülebilir (embedded=true) yanıtlayan adresi. Düzenleme bağlantısı da kabul edilir (/forms/d/<id>/viewform yanıtlayana açılır). */
function sides_gf_form_url( $u ) {
	$u = trim( (string) $u );
	if ( '' === $u ) {
		return '';
	}
	if ( preg_match( '~^https?://forms\.gle/([A-Za-z0-9_-]{4,40})/?$~', $u, $m ) ) {
		$r = wp_safe_remote_head( 'https://forms.gle/' . $m[1], array( 'redirection' => 0, 'timeout' => 10 ) );
		$loc = is_wp_error( $r ) ? '' : (string) wp_remote_retrieve_header( $r, 'location' );
		if ( ! $loc ) {
			return new WP_Error( 'sides_gform', 'Kısa form bağlantısı (forms.gle) çözülemedi. Formun tam adresini (docs.google.com/forms/...) yapıştırın.' );
		}
		$u = $loc;
	}
	if ( preg_match( '~^https://docs\.google\.com/forms(?:/u/\d+)?/d/e/([A-Za-z0-9_-]{20,120})/(?:viewform|formResponse)~', $u, $m ) ) {
		return 'https://docs.google.com/forms/d/e/' . $m[1] . '/viewform?embedded=true';
	}
	if ( preg_match( '~^https://docs\.google\.com/forms(?:/u/\d+)?/d/([A-Za-z0-9_-]{20,120})(?:/|$)~', $u, $m ) ) {
		return 'https://docs.google.com/forms/d/' . $m[1] . '/viewform?embedded=true';
	}
	return new WP_Error( 'sides_gform', 'Form bağlantısı tanınmadı. Google Form’da “Gönder” › bağlantı simgesinden aldığınız adresi yapıştırın (docs.google.com/forms/... ya da forms.gle/...).' );
}
/* Google E-Tablo: CSV indirme adresi. Web'de yayınlanmış (pub) ya da “bağlantıya sahip herkes görüntüleyebilir” paylaşım bağlantısı. */
function sides_gf_csv_url( $u ) {
	$u = trim( (string) $u );
	if ( '' === $u ) {
		return '';
	}
	$gid = preg_match( '~[#&?]gid=(\d{1,12})~', $u, $g ) ? $g[1] : '';
	if ( preg_match( '~^https://docs\.google\.com/spreadsheets(?:/u/\d+)?/d/e/([A-Za-z0-9_-]{20,160})/pub~', $u, $m ) ) {
		return 'https://docs.google.com/spreadsheets/d/e/' . $m[1] . '/pub?output=csv' . ( '' !== $gid ? '&single=true&gid=' . $gid : '' );
	}
	if ( preg_match( '~^https://docs\.google\.com/spreadsheets(?:/u/\d+)?/d/([A-Za-z0-9_-]{20,120})(?:/|$)~', $u, $m ) ) {
		return 'https://docs.google.com/spreadsheets/d/' . $m[1] . '/export?format=csv&gid=' . ( '' !== $gid ? $gid : '0' );
	}
	return new WP_Error( 'sides_gform', 'E-tablo bağlantısı tanınmadı. Formun Yanıtlar sekmesinden “E-Tablolar’da görüntüle” ile açılan e-tablonun adresini yapıştırın (docs.google.com/spreadsheets/...).' );
}

/* ---- Veri çekme ---- */
function sides_gf_csv_ayristir( $txt ) {
	$txt = (string) $txt;
	if ( 0 === strpos( $txt, "\xEF\xBB\xBF" ) ) {
		$txt = substr( $txt, 3 );
	}
	$fp = fopen( 'php://temp', 'r+' );
	fwrite( $fp, $txt );
	rewind( $fp );
	$rows   = array();
	$kesik  = false;
	while ( false !== ( $r = fgetcsv( $fp, 0, ',', '"', '' ) ) ) {
		if ( count( $rows ) > 5000 ) {
			$kesik = true;
			break;
		}
		$r = array_slice( array_map( function ( $x ) {
			return mb_substr( trim( (string) $x ), 0, 2000 );
		}, (array) $r ), 0, 80 );
		$rows[] = $r;
	}
	fclose( $fp );
	while ( $rows && '' === implode( '', end( $rows ) ) ) {
		array_pop( $rows );
	}
	if ( ! $rows ) {
		return array( 'basliklar' => array(), 'satirlar' => array(), 'kesildi' => false );
	}
	$bas = array_shift( $rows );
	$n   = count( $bas );
	foreach ( $rows as $r ) {
		$n = max( $n, count( $r ) );
	}
	/* sonda tamamen boş sütunları at */
	while ( $n > 0 && '' === trim( (string) ( isset( $bas[ $n - 1 ] ) ? $bas[ $n - 1 ] : '' ) ) && ! array_filter( $rows, function ( $r ) use ( $n ) {
		return isset( $r[ $n - 1 ] ) && '' !== $r[ $n - 1 ];
	} ) ) {
		$n--;
	}
	$B = array();
	for ( $i = 0; $i < $n; $i++ ) {
		$B[] = isset( $bas[ $i ] ) && '' !== $bas[ $i ] ? $bas[ $i ] : 'Sütun ' . ( $i + 1 );
	}
	$S = array();
	foreach ( $rows as $r ) {
		if ( '' === implode( '', $r ) ) {
			continue;
		}
		$S[] = array_pad( array_slice( $r, 0, $n ), $n, '' );
	}
	return array( 'basliklar' => $B, 'satirlar' => $S, 'kesildi' => $kesik );
}
function sides_gf_cek( $csv ) {
	$r = wp_safe_remote_get( $csv, array( 'timeout' => 20, 'redirection' => 4, 'limit_response_size' => 6 * 1024 * 1024, 'headers' => array( 'Accept' => 'text/csv,text/plain;q=0.9,*/*;q=0.1' ) ) );
	if ( is_wp_error( $r ) ) {
		return sides_gf_hata( 'Google E-Tablo’ya ulaşılamadı: ' . $r->get_error_message(), 502 );
	}
	$kod = (int) wp_remote_retrieve_response_code( $r );
	$tip = strtolower( (string) wp_remote_retrieve_header( $r, 'content-type' ) );
	$govde = (string) wp_remote_retrieve_body( $r );
	if ( 200 !== $kod || false !== strpos( $tip, 'html' ) || preg_match( '~^\s*<(?:!doctype|html)~i', $govde ) ) {
		return sides_gf_hata( 'E-tablo okunamadı (' . ( 200 === $kod ? 'giriş sayfası döndü' : 'HTTP ' . $kod ) . '). E-tabloyu “Paylaş › Bağlantıya sahip olan herkes: Görüntüleyen” yapın ya da “Dosya › Paylaş › Web’de yayınla › CSV” bağlantısını kullanın.', 502 );
	}
	return sides_gf_csv_ayristir( $govde );
}
/* Gözlemci: kişisel veri sütunları gizlenir, ad sütunları kısaltılır */
function sides_gf_maskele( $v ) {
	$tur = array();
	foreach ( $v['basliklar'] as $i => $h ) {
		$k = mb_strtolower( (string) $h, 'UTF-8' );
		if ( preg_match( '~tel|gsm|cep|e-?posta|mail|kimlik|\btc\b|t\.c|adres|iban|doğum|dogum~u', $k ) ) {
			$tur[ $i ] = 'gizle';
		} elseif ( preg_match( '~\bad\b|adı|ad soyad|soyad|isim|ismi~u', $k ) ) {
			$tur[ $i ] = 'ad';
		}
	}
	if ( ! $tur ) {
		return $v;
	}
	foreach ( $v['satirlar'] as &$r ) {
		foreach ( $tur as $i => $t ) {
			if ( isset( $r[ $i ] ) && '' !== $r[ $i ] ) {
				$r[ $i ] = 'gizle' === $t ? '•••' : sides_mask_name( $r[ $i ] );
			}
		}
	}
	unset( $r );
	$v['maskeli'] = true;
	return $v;
}

/* ---- REST ---- */
add_action( 'rest_api_init', function () {
	$ns  = 'optik-karne/v1';
	$oku = function () {
		return sides_can( 'kayit', 1 ) ? true : sides_deny();
	};
	$yaz = function () {
		return sides_gf_yazabilir() ? true : sides_deny();
	};
	register_rest_route( $ns, '/gform', array(
		array( 'methods' => 'GET', 'callback' => 'sides_gf_rest_liste', 'permission_callback' => $oku ),
		array( 'methods' => 'POST', 'callback' => 'sides_gf_rest_kaydet', 'permission_callback' => $yaz ),
	) );
	register_rest_route( $ns, '/gform/(?P<id>gf[a-z0-9]{4,24})', array( 'methods' => 'DELETE', 'callback' => 'sides_gf_rest_sil', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/gform/(?P<id>gf[a-z0-9]{4,24})/veri', array( 'methods' => 'GET', 'callback' => 'sides_gf_rest_veri', 'permission_callback' => $oku ) );
} );

function sides_gf_cikis( $org ) {
	$yaz = sides_gf_yazabilir();
	$o   = sides_org( $org );
	$L   = array_map( function ( $f ) use ( $yaz ) {
		$x = array(
			'id'         => (string) $f['id'],
			'ad'         => (string) $f['ad'],
			'gomUrl'     => (string) $f['gomUrl'],
			'ods'        => ! empty( $f['ods'] ),
			'guncelleme' => isset( $f['guncelleme'] ) ? (int) $f['guncelleme'] : 0,
			'veriVar'    => ! empty( $f['csvUrl'] ),
		);
		if ( $yaz ) {   // e-tablo bağlantısı yanıtları açar: yalnız düzenleyebilenlere
			$x['formUrl'] = (string) $f['formUrl'];
			$x['veriUrl'] = (string) $f['veriUrl'];
		}
		return $x;
	}, sides_gf_ayar( $org ) );
	return array(
		'formlar' => $L,
		'yaz'     => $yaz,
		'odsUrl'  => function_exists( 'sides_ods_url_kisa' ) ? array( 'kisa' => sides_ods_url_kisa(), 'tam' => sides_ods_url_tam( $o ) ) : null,
	);
}
function sides_gf_rest_liste() {
	return sides_gf_yanit( sides_gf_cikis( sides_org_id() ) );
}
function sides_gf_rest_kaydet( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = (array) $req->get_json_params();
	$ad  = trim( wp_strip_all_tags( (string) ( isset( $p['ad'] ) ? $p['ad'] : '' ) ) );
	$ad  = mb_substr( $ad, 0, 80 );
	if ( '' === $ad ) {
		return sides_gf_hata( 'Form adı boş olamaz.' );
	}
	$fu  = mb_substr( (string) ( isset( $p['formUrl'] ) ? $p['formUrl'] : '' ), 0, 600 );
	$vu  = mb_substr( (string) ( isset( $p['veriUrl'] ) ? $p['veriUrl'] : '' ), 0, 600 );
	$gom = sides_gf_form_url( $fu );
	if ( is_wp_error( $gom ) ) {
		return sides_gf_hata( $gom->get_error_message() );
	}
	$csv = sides_gf_csv_url( $vu );
	if ( is_wp_error( $csv ) ) {
		return sides_gf_hata( $csv->get_error_message() );
	}
	if ( '' === $gom && '' === $csv ) {
		return sides_gf_hata( 'Form bağlantısı ya da e-tablo bağlantısından en az biri gerekli.' );
	}
	if ( ! sides_rl( 'gform_kaydet_' . $org, 30, 600 ) ) {
		return sides_gf_hata( 'Çok sık kayıt yapıldı; biraz sonra tekrar deneyin.', 429 );
	}
	$L   = sides_gf_ayar( $org );
	$id  = isset( $p['id'] ) && preg_match( '/^gf[a-z0-9]{4,24}$/', (string) $p['id'] ) ? (string) $p['id'] : '';
	$i   = -1;
	foreach ( $L as $k => $f ) {
		if ( $id && $f['id'] === $id ) {
			$i = $k;
		}
	}
	if ( $id && $i < 0 ) {
		return sides_gf_hata( 'Form bulunamadı; sayfayı yenileyin.', 404 );
	}
	if ( $i < 0 && count( $L ) >= 20 ) {
		return sides_gf_hata( 'En fazla 20 form eklenebilir.' );
	}
	$ods = ! empty( $p['ods'] );
	if ( $ods ) {   // tek ÖDS formu: /ods/ adresi bunu açar
		foreach ( $L as $k => $f ) {
			$L[ $k ]['ods'] = false;
		}
	}
	$now = (int) round( microtime( true ) * 1000 );
	$yeni = array(
		'id'         => $i >= 0 ? $L[ $i ]['id'] : 'gf' . strtolower( wp_generate_password( 10, false, false ) ),
		'ad'         => $ad,
		'formUrl'    => esc_url_raw( $fu ),
		'gomUrl'     => $gom,
		'veriUrl'    => esc_url_raw( $vu ),
		'csvUrl'     => $csv,
		'ods'        => $ods,
		'olusturma'  => $i >= 0 && isset( $L[ $i ]['olusturma'] ) ? (int) $L[ $i ]['olusturma'] : $now,
		'guncelleme' => $now,
	);
	$yeni['id'] = preg_replace( '/[^a-z0-9]/', '', $yeni['id'] );
	if ( $i >= 0 ) {
		$L[ $i ] = $yeni;
	} else {
		$L[] = $yeni;
	}
	if ( ! sides_gf_yaz_ayar( $org, $L ) ) {
		return sides_gf_hata( 'Kaydedilemedi.', 500 );
	}
	delete_transient( 'sides_gf_' . $org . '_' . $yeni['id'] );
	sides_log( $org, 'Google Form ' . ( $i >= 0 ? 'güncellendi' : 'eklendi' ) . ': ' . $ad );
	$c       = sides_gf_cikis( $org );
	$c['id'] = $yeni['id'];
	return sides_gf_yanit( $c );
}
function sides_gf_rest_sil( WP_REST_Request $req ) {
	$org = sides_org_id();
	$id  = (string) $req['id'];
	$L   = sides_gf_ayar( $org );
	$ad  = '';
	$K   = array();
	foreach ( $L as $f ) {
		if ( $f['id'] === $id ) {
			$ad = $f['ad'];
		} else {
			$K[] = $f;
		}
	}
	if ( '' === $ad ) {
		return sides_gf_hata( 'Form bulunamadı.', 404 );
	}
	sides_gf_yaz_ayar( $org, $K );
	delete_transient( 'sides_gf_' . $org . '_' . $id );
	sides_log( $org, 'Google Form kaldırıldı: ' . $ad );
	return sides_gf_yanit( sides_gf_cikis( $org ) );
}
function sides_gf_rest_veri( WP_REST_Request $req ) {
	$org = sides_org_id();
	$id  = (string) $req['id'];
	$f   = null;
	foreach ( sides_gf_ayar( $org ) as $x ) {
		if ( $x['id'] === $id ) {
			$f = $x;
		}
	}
	if ( ! $f ) {
		return sides_gf_hata( 'Form bulunamadı.', 404 );
	}
	if ( empty( $f['csvUrl'] ) ) {
		return sides_gf_hata( 'Bu form için e-tablo bağlantısı girilmemiş; yanıtlar çekilemiyor.', 409 );
	}
	$key = 'sides_gf_' . $org . '_' . $id;
	$v   = get_transient( $key );
	$yen = ! empty( $req['yenile'] );
	if ( $yen && ! sides_rl( 'gform_yenile_' . $org, 20, 60 ) ) {
		$yen = false;   // çok sık zorla yenileme: önbellekten ver
	}
	if ( ! is_array( $v ) || $yen || ( isset( $v['csv'] ) && $v['csv'] !== $f['csvUrl'] ) ) {
		$c = sides_gf_cek( $f['csvUrl'] );
		if ( is_wp_error( $c ) ) {
			return $c;
		}
		$v = array_merge( $c, array( 'zaman' => (int) round( microtime( true ) * 1000 ), 'csv' => $f['csvUrl'] ) );
		set_transient( $key, $v, 60 );
	}
	unset( $v['csv'] );
	$v['id']     = $id;
	$v['toplam'] = count( $v['satirlar'] );
	if ( sides_is_observer() ) {
		$v = sides_gf_maskele( $v );
	}
	return sides_gf_yanit( $v );
}

/* ---- Herkese açık /ods/ sayfası: ÖDS olarak işaretli Google Form gömülü açılır (includes/odsform.php sides_ods_sayfa çağırır) ---- */
function sides_gf_ods_form( $org ) {
	foreach ( sides_gf_ayar( $org ) as $f ) {
		if ( ! empty( $f['ods'] ) && ! empty( $f['gomUrl'] ) ) {
			return $f;
		}
	}
	return null;
}
function sides_gf_ods_html( $o, $f ) {
	$org  = (int) $o->id;
	$set  = sides_get_doc( $org, 'settings', 'main' );
	$kur  = isset( $set['kurum'] ) && $set['kurum'] ? (string) $set['kurum'] : (string) $o->ad;
	$logo = function_exists( 'sides_ods_logo_url' ) && function_exists( 'sides_ods_ayar' ) ? sides_ods_logo_url( $o, sides_ods_ayar( $org ) ) : '';
	$src  = (string) $f['gomUrl'];
	if ( ! preg_match( '~^https://docs\.google\.com/forms/~', $src ) ) {
		return '';
	}
	ob_start();
	?><!doctype html>
<html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex">
<title><?php echo esc_html( $f['ad'] . ' · ' . $kur ); ?></title>
<style>
:root{--bg:#eef2f8;--kart:#fff;--ink:#14213d;--muted:#5b6475;--line:#d8dee9}
@media (prefers-color-scheme:dark){:root{--bg:#0f1522;--kart:#182032;--ink:#e8edf6;--muted:#9aa5b8;--line:#2a3448}}
*{box-sizing:border-box}html,body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.5 system-ui,-apple-system,"Segoe UI",Roboto,sans-serif}
header{display:flex;align-items:center;gap:12px;max-width:760px;margin:0 auto;padding:16px}
header img{width:48px;height:48px;object-fit:contain;border-radius:10px;background:#fff}
header b{display:block;font-size:18px}header span{color:var(--muted);font-size:14px}
main{max-width:760px;margin:0 auto 24px;padding:0 16px}
.kart{background:var(--kart);border:1px solid var(--line);border-radius:14px;overflow:hidden}
iframe{display:block;width:100%;height:calc(100vh - 120px);min-height:640px;border:0;background:#fff}
.alt{margin-top:10px;font-size:13px;color:var(--muted);text-align:center}.alt a{color:inherit}
</style></head><body>
<header><?php if ( $logo ) : ?><img src="<?php echo esc_url( $logo ); ?>" alt=""><?php endif; ?><div><b><?php echo esc_html( $kur ); ?></b><span><?php echo esc_html( $f['ad'] ); ?></span></div></header>
<main><div class="kart"><iframe src="<?php echo esc_url( $src ); ?>" title="<?php echo esc_attr( $f['ad'] ); ?>" loading="eager" referrerpolicy="no-referrer-when-downgrade">Yükleniyor…</iframe></div>
<div class="alt">Form açılmazsa <a href="<?php echo esc_url( str_replace( 'embedded=true', '', $src ) ); ?>" target="_blank" rel="noopener">buraya dokunarak yeni sekmede açın</a>.</div></main>
</body></html>
	<?php
	return ob_get_clean();
}
