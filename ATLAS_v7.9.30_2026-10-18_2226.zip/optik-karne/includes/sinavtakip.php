<?php
/* ------------------------------------------------------------------ *
 * v7.9.2 Sınav Takip (Takip › Akademik Takip): 5, 6, 7, 8 ve LGS başlıkları altında öğretmenlerin yüklediği sınav PDF'leri.
 * stsinav/<id> { sinif: 5|6|7|8|LGS, ders, ad, aciklama, soru, secenek, anahtar, dosya{ad,boyut}, olusturan{u,ad}, olusturma, tarih }
 * PDF dosyası uploads/sides-sinav/<id>.pdf içinde (dizin dışarıdan kapalı; yalnız REST üzerinden, yetkiyle ya da açık link belirteciyle).
 * Online çözüm: belge belirteci (token) açıkken ?st=<token> sayfası PDF'i gösterir, öğrenci cevaplarını girer; stsonuc/<id>
 * { sinavId, ad, no, sinif, sube, studentId?, cevap, D, Y, B, net, tarih } olarak puanlanıp kaydedilir.
 * ------------------------------------------------------------------ */
defined( 'ABSPATH' ) || exit;

const SIDES_ST_SINIF = array( '5', '6', '7', '8', 'LGS' );
const SIDES_ST_BOYUT = 25 * MB_IN_BYTES;

function sides_st_dir() {
	$u = wp_upload_dir( null, false );
	$d = trailingslashit( $u['basedir'] ) . 'sides-sinav';
	if ( ! is_dir( $d ) ) {
		wp_mkdir_p( $d );
	}
	$koru = array(
		'.htaccess'  => "# ATLAS sınav dosyaları dışarıdan indirilemez\nRequire all denied\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n",
		'index.php'  => "<?php\n// Silence is golden.\n",
		'web.config' => "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<configuration><system.webServer><authorization><deny users=\"*\" /></authorization></system.webServer></configuration>\n",
	);
	foreach ( $koru as $f => $icerik ) {
		if ( ! file_exists( "$d/$f" ) ) {
			@file_put_contents( "$d/$f", $icerik ); // phpcs:ignore
		}
	}
	return $d;
}
function sides_st_yol( $org, $id ) {
	return sides_st_dir() . '/' . (int) $org . '-' . preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $id ) . '.pdf';
}
function sides_st_hata( $m, $s = 400 ) {
	return new WP_Error( 'sides_gecersiz', $m, array( 'status' => $s ) );
}
function sides_st_id_gecerli( $id ) {
	return is_string( $id ) && preg_match( '/^st[a-z0-9]{6,40}$/', $id );
}
/* Belge çıktısı: dosya ve sonuç sayısı eklenir, token yalnız yetkili listede döner */
function sides_st_cikti( $org, $d, $row_token, $sonucN = null ) {
	global $wpdb;
	$id = (string) $d['id'];
	if ( null === $sonucN ) {
		$t      = sides_docs();
		$sonucN = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE org = %d AND coll = 'stsonuc' AND exam_id = %s", $org, $id ) ); // phpcs:ignore
	}
	$yol = sides_st_yol( $org, $id );
	$d['dosyaVar'] = file_exists( $yol );
	$d['sonucN']   = $sonucN;
	$d['token']    = $row_token ? $row_token : null;
	return $d;
}

add_action( 'rest_api_init', function () {
	$ns  = 'optik-karne/v1';
	$oku = function () {
		return sides_can( 'takip', 1 ) ? true : sides_deny( 'Takip modülünü görme yetkiniz yok.' );
	};
	$yaz = function () {
		return sides_can( 'takip', 2 ) && ! sides_is_observer() ? true : sides_deny( 'Takip modülünde değişiklik yapma yetkiniz yok.' );
	};
	register_rest_route( $ns, '/sinavtakip', array(
		array( 'methods' => 'GET', 'callback' => 'sides_st_liste', 'permission_callback' => $oku ),
		array( 'methods' => 'POST', 'callback' => 'sides_st_kaydet', 'permission_callback' => $yaz ),
	) );
	register_rest_route( $ns, '/sinavtakip/parca', array( 'methods' => 'POST', 'callback' => 'sides_st_parca', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/sinavtakip/(?P<id>st[a-z0-9]{6,40})', array( 'methods' => 'DELETE', 'callback' => 'sides_st_sil', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/sinavtakip/(?P<id>st[a-z0-9]{6,40})/pdf', array( 'methods' => 'GET', 'callback' => 'sides_st_pdf', 'permission_callback' => '__return_true' ) );
	register_rest_route( $ns, '/sinavtakip/(?P<id>st[a-z0-9]{6,40})/link', array( 'methods' => 'POST', 'callback' => 'sides_st_link', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/sinavtakip/(?P<id>st[a-z0-9]{6,40})/sonuc', array( 'methods' => 'GET', 'callback' => 'sides_st_sonuclar', 'permission_callback' => $oku ) );
	register_rest_route( $ns, '/sinavtakip/(?P<id>st[a-z0-9]{6,40})/sonuc/(?P<rid>[A-Za-z0-9_\-]{1,64})', array( 'methods' => 'DELETE', 'callback' => 'sides_st_sonuc_sil', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/st/(?P<token>[a-f0-9]{32})', array(
		array( 'methods' => 'GET', 'callback' => 'sides_st_pub_oku', 'permission_callback' => '__return_true' ),
		array( 'methods' => 'POST', 'callback' => 'sides_st_pub_coz', 'permission_callback' => '__return_true' ),
	) );
} );

function sides_st_liste() {
	global $wpdb;
	$org = sides_org_id();
	$t   = sides_docs();
	$say = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT exam_id, COUNT(*) AS n FROM $t WHERE org = %d AND coll = 'stsonuc' GROUP BY exam_id", $org ) ) as $r ) { // phpcs:ignore
		$say[ (string) $r->exam_id ] = (int) $r->n;
	}
	$out = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, token, data FROM $t WHERE org = %d AND coll = 'stsinav' ORDER BY updated_at DESC", $org ) ) as $r ) { // phpcs:ignore
		$d = json_decode( $r->data, true );
		if ( ! is_array( $d ) ) {
			continue;
		}
		$d['id'] = (string) $r->id;
		$out[]   = sides_st_cikti( $org, $d, $r->token, isset( $say[ $d['id'] ] ) ? $say[ $d['id'] ] : 0 );
	}
	return array( 'sinavlar' => $out );
}
/* Üst veri: yeni (dosya sonra parça parça gelir) ya da düzenleme */
function sides_st_kaydet( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	if ( ! is_array( $p ) ) {
		return sides_st_hata( 'Geçersiz istek.' );
	}
	$id   = isset( $p['id'] ) ? (string) $p['id'] : '';
	$eski = $id ? sides_get_doc( $org, 'stsinav', $id ) : null;
	if ( $id && ( ! sides_st_id_gecerli( $id ) || ! $eski ) ) {
		return sides_st_hata( 'Sınav bulunamadı.', 404 );
	}
	$sinif = isset( $p['sinif'] ) ? strtoupper( sides_kt_metin( $p['sinif'], 3 ) ) : '';
	if ( ! in_array( $sinif, SIDES_ST_SINIF, true ) ) {
		return sides_st_hata( 'Sınıf 5, 6, 7, 8 ya da LGS olmalı.' );
	}
	$ders = sides_kt_metin( isset( $p['ders'] ) ? $p['ders'] : '', 60 );
	$ad   = sides_kt_metin( isset( $p['ad'] ) ? $p['ad'] : '', 120 );
	if ( '' === $ders || '' === $ad ) {
		return sides_st_hata( 'Ders ve sınav adı gerekli.' );
	}
	$soru = isset( $p['soru'] ) ? (int) $p['soru'] : 0;
	$sec  = isset( $p['secenek'] ) && 5 === (int) $p['secenek'] ? 5 : 4;
	if ( $soru < 0 || $soru > 200 ) {
		return sides_st_hata( 'Soru sayısı 0–200 arasında olmalı.' );
	}
	$anahtar = isset( $p['anahtar'] ) && is_string( $p['anahtar'] ) ? strtoupper( preg_replace( '/[^A-Ea-eXx]/', '', $p['anahtar'] ) ) : '';
	if ( '' !== $anahtar && ( ! $soru || strlen( $anahtar ) !== $soru || preg_match( 5 === $sec ? '/[^A-EX]/' : '/[^A-DX]/', $anahtar ) ) ) {
		return sides_st_hata( 'Cevap anahtarı soru sayısı kadar harf olmalı (A–' . ( 5 === $sec ? 'E' : 'D' ) . ', iptal için X).' );
	}
	$c = sides_ctx();
	$u = wp_get_current_user();
	$d = array(
		'sinif'     => $sinif,
		'ders'      => $ders,
		'ad'        => $ad,
		'aciklama'  => sides_kt_uzun( isset( $p['aciklama'] ) ? $p['aciklama'] : '', 600 ),
		'soru'      => $soru,
		'secenek'   => $sec,
		'anahtar'   => $anahtar,
		'tarih'     => sides_kt_tarih( isset( $p['tarih'] ) ? $p['tarih'] : '' ) ? sides_kt_tarih( $p['tarih'] ) : ( $eski && ! empty( $eski['tarih'] ) ? $eski['tarih'] : sides_kt_bugun() ),
		'dosya'     => $eski && isset( $eski['dosya'] ) ? $eski['dosya'] : null,
		'olusturan' => $eski && isset( $eski['olusturan'] ) ? $eski['olusturan'] : array( 'u' => (int) $c['uid'], 'ad' => $u ? (string) $u->display_name : '' ),
		'olusturma' => $eski && isset( $eski['olusturma'] ) ? $eski['olusturma'] : (int) round( microtime( true ) * 1000 ),
	);
	if ( ! $id ) {
		$id = 'st' . substr( bin2hex( random_bytes( 8 ) ), 0, 14 );
	}
	if ( false === sides_put_doc( $org, 'stsinav', $id, $d ) ) {
		return new WP_Error( 'sides_db', 'Kayıt yapılamadı.', array( 'status' => 500 ) );
	}
	sides_log( $org, ( $eski ? 'Sınav Takip: sınav düzenlendi: ' : 'Sınav Takip: sınav eklendi: ' ) . $sinif . ' · ' . $ders . ' · ' . $ad );
	$d['id'] = $id;
	$row     = sides_get_doc( $org, 'stsinav', $id );
	return sides_st_cikti( $org, $d, $row && isset( $row['token'] ) ? $row['token'] : null );
}
/* PDF parça parça gelir (sunucunun yükleme sınırına takılmaz); son parçada %PDF- başlığı ve boyut denetlenir */
function sides_st_parca( WP_REST_Request $req ) {
	$org = sides_org_id();
	$id  = (string) $req->get_param( 'id' );
	$i   = (int) $req->get_param( 'i' );
	$n   = (int) $req->get_param( 'n' );
	if ( ! sides_st_id_gecerli( $id ) || $i < 0 || $n < 1 || $n > 400 || $i >= $n ) {
		return sides_st_hata( 'Geçersiz parça.' );
	}
	$doc = sides_get_doc( $org, 'stsinav', $id );
	if ( ! $doc ) {
		return sides_st_hata( 'Sınav bulunamadı.', 404 );
	}
	$dir = sides_st_dir();
	foreach ( (array) glob( "$dir/parca-*.tmp" ) as $eski ) {
		if ( filemtime( $eski ) < time() - DAY_IN_SECONDS ) {
			@unlink( $eski ); // phpcs:ignore
		}
	}
	$tmp  = "$dir/parca-" . (int) $org . "-$id.tmp";
	$body = $req->get_body();
	if ( '' === $body || strlen( $body ) > 4 * MB_IN_BYTES ) {
		return sides_st_hata( 'Parça boş ya da çok büyük.' );
	}
	$boy = file_exists( $tmp ) ? filesize( $tmp ) : 0;
	if ( 0 === $i && $boy ) {
		@unlink( $tmp ); // phpcs:ignore
		$boy = 0;
	}
	if ( $i > 0 && ! $boy ) {
		return sides_st_hata( 'Yükleme yarıda kesilmiş; dosyayı yeniden seçin.' );
	}
	if ( $boy + strlen( $body ) > SIDES_ST_BOYUT ) {
		@unlink( $tmp ); // phpcs:ignore
		return sides_st_hata( 'Dosya en çok 25 MB olabilir.' );
	}
	if ( false === file_put_contents( $tmp, $body, FILE_APPEND ) ) { // phpcs:ignore
		return new WP_Error( 'sides_db', 'Parça sunucuya yazılamadı (disk dolu olabilir).', array( 'status' => 500 ) );
	}
	if ( $i < $n - 1 ) {
		return array( 'ok' => true, 'i' => $i );
	}
	$h = file_get_contents( $tmp, false, null, 0, 8 ); // phpcs:ignore
	if ( 0 !== strpos( (string) $h, '%PDF-' ) ) {
		@unlink( $tmp ); // phpcs:ignore
		return sides_st_hata( 'Dosya PDF değil. Yalnız PDF yüklenebilir.' );
	}
	$yol = sides_st_yol( $org, $id );
	if ( file_exists( $yol ) ) {
		@unlink( $yol ); // phpcs:ignore
	}
	if ( ! @rename( $tmp, $yol ) ) { // phpcs:ignore
		@unlink( $tmp ); // phpcs:ignore
		return new WP_Error( 'sides_db', 'Dosya kaydedilemedi.', array( 'status' => 500 ) );
	}
	$ad = sides_kt_metin( (string) $req->get_param( 'ad' ), 120 );
	$doc['dosya'] = array( 'ad' => $ad ? $ad : 'sinav.pdf', 'boyut' => (int) filesize( $yol ), 'yukleme' => (int) round( microtime( true ) * 1000 ) );
	unset( $doc['dosyaVar'], $doc['sonucN'] );
	sides_put_doc( $org, 'stsinav', $id, $doc );
	sides_log( $org, 'Sınav Takip: PDF yüklendi: ' . $doc['ad'] . ' (' . size_format( $doc['dosya']['boyut'] ) . ')' );
	$row = sides_get_doc( $org, 'stsinav', $id );
	$doc['id'] = $id;
	return sides_st_cikti( $org, $doc, $row && isset( $row['token'] ) ? $row['token'] : null );
}
function sides_st_sil( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$id  = (string) $req['id'];
	$doc = sides_get_doc( $org, 'stsinav', $id );
	if ( ! $doc ) {
		return sides_st_hata( 'Sınav bulunamadı.', 404 );
	}
	$t = sides_docs();
	$wpdb->delete( $t, array( 'org' => $org, 'coll' => 'stsinav', 'id' => $id ) );
	$wpdb->delete( $t, array( 'org' => $org, 'coll' => 'stsonuc', 'exam_id' => $id ) );
	$yol = sides_st_yol( $org, $id );
	if ( file_exists( $yol ) ) {
		@unlink( $yol ); // phpcs:ignore
	}
	sides_log( $org, 'Sınav Takip: sınav silindi: ' . ( isset( $doc['ad'] ) ? $doc['ad'] : $id ) );
	return array( 'ok' => true );
}
/* Açık link belirteciyle sınavı bulur (kurum engeli ve modül kapalılığı denetlenir) */
function sides_st_token_bul( $token ) {
	global $wpdb;
	$t = sides_docs();
	$r = $wpdb->get_row( $wpdb->prepare( "SELECT org, id, data FROM $t WHERE coll = 'stsinav' AND token = %s", $token ) ); // phpcs:ignore
	if ( ! $r || in_array( 'takip', sides_kapali_moduller( (int) $r->org ), true ) ) {
		return null;
	}
	$o = sides_org( (int) $r->org );
	if ( ! $o || sides_org_blok( $o ) ) {
		return null;
	}
	$d = json_decode( $r->data, true );
	if ( ! is_array( $d ) ) {
		return null;
	}
	$d['id'] = (string) $r->id;
	return array( 'org' => (int) $r->org, 'o' => $o, 'd' => $d );
}
/* PDF: giriş yapmış takip kullanıcısı (kendi kurumu) ya da açık link belirteci (?t=) */
function sides_st_pdf( WP_REST_Request $req ) {
	$id  = (string) $req['id'];
	$tok = preg_replace( '/[^a-f0-9]/', '', (string) $req->get_param( 't' ) );
	$org = 0;
	if ( 32 === strlen( $tok ) ) {
		$x = sides_st_token_bul( $tok );
		if ( ! $x || $x['d']['id'] !== $id ) {
			return sides_st_hata( 'Bağlantı geçersiz ya da kapatılmış.', 404 );
		}
		if ( ! sides_rl( 'st_pdf|' . $tok, 300, 600 ) ) {
			return new WP_Error( 'sides_rl', 'Çok fazla istek. Biraz sonra tekrar deneyin.', array( 'status' => 429 ) );
		}
		$org = $x['org'];
		$doc = $x['d'];
	} else {
		if ( ! is_user_logged_in() || ! sides_can( 'takip', 1 ) ) {
			return sides_deny( 'Bu dosyayı görmek için giriş yapın.' );
		}
		$org = sides_org_id();
		$doc = sides_get_doc( $org, 'stsinav', $id );
		if ( ! $doc ) {
			return sides_st_hata( 'Sınav bulunamadı.', 404 );
		}
	}
	$yol = sides_st_yol( $org, $id );
	if ( ! file_exists( $yol ) ) {
		return sides_st_hata( 'Bu sınavın PDF dosyası henüz yüklenmemiş.', 404 );
	}
	$ad = isset( $doc['dosya']['ad'] ) ? preg_replace( '/[^A-Za-z0-9_\-. ]/', '_', (string) $doc['dosya']['ad'] ) : 'sinav.pdf';
	if ( ! preg_match( '/\.pdf$/i', $ad ) ) {
		$ad .= '.pdf';
	}
	nocache_headers();
	header( 'Content-Type: application/pdf' );
	header( 'Content-Length: ' . filesize( $yol ) );
	header( 'Content-Disposition: ' . ( 'indir' === (string) $req->get_param( 'mod' ) ? 'attachment' : 'inline' ) . '; filename="' . $ad . '"' );
	header( 'X-Content-Type-Options: nosniff' );
	readfile( $yol ); // phpcs:ignore
	exit;
}
function sides_st_link( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$id  = (string) $req['id'];
	$doc = sides_get_doc( $org, 'stsinav', $id );
	if ( ! $doc ) {
		return sides_st_hata( 'Sınav bulunamadı.', 404 );
	}
	$p     = $req->get_json_params();
	$islem = isset( $p['islem'] ) ? (string) $p['islem'] : 'ac';
	if ( 'kapat' === $islem ) {
		$wpdb->update( sides_docs(), array( 'token' => null ), array( 'org' => $org, 'coll' => 'stsinav', 'id' => $id ) );
		sides_log( $org, 'Sınav Takip: online çözüm linki kapatıldı: ' . $doc['ad'] );
		return array( 'token' => null );
	}
	if ( ! file_exists( sides_st_yol( $org, $id ) ) ) {
		return sides_st_hata( 'Önce PDF dosyasını yükleyin.' );
	}
	$tok = bin2hex( random_bytes( 16 ) );
	$wpdb->update( sides_docs(), array( 'token' => $tok ), array( 'org' => $org, 'coll' => 'stsinav', 'id' => $id ) );
	sides_log( $org, 'Sınav Takip: online çözüm linki ' . ( 'yenile' === $islem ? 'yenilendi' : 'açıldı' ) . ': ' . $doc['ad'] );
	return array( 'token' => $tok );
}
function sides_st_sonuclar( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$id  = (string) $req['id'];
	if ( ! sides_get_doc( $org, 'stsinav', $id ) ) {
		return sides_st_hata( 'Sınav bulunamadı.', 404 );
	}
	$t    = sides_docs();
	$out  = array();
	$mask = sides_is_observer();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = 'stsonuc' AND exam_id = %s ORDER BY updated_at DESC", $org, $id ) ) as $r ) { // phpcs:ignore
		$d = json_decode( $r->data, true );
		if ( ! is_array( $d ) ) {
			continue;
		}
		$d['id'] = (string) $r->id;
		if ( $mask ) {
			$d['ad'] = sides_mask_name( $d['ad'] );
		}
		$out[] = $d;
	}
	return array( 'sonuclar' => $out );
}
function sides_st_sonuc_sil( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$wpdb->delete( sides_docs(), array( 'org' => $org, 'coll' => 'stsonuc', 'id' => (string) $req['rid'], 'exam_id' => (string) $req['id'] ) );
	return array( 'ok' => true );
}
/* ---------- öğrenci sayfası (hesapsız; belirteç + hız sınırı) ---------- */
function sides_st_pub_hiz( $yaz, $token ) {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	return sides_rl( ( $yaz ? 'st_y|' : 'st_o|' ) . $ip, $yaz ? 120 : 600, 600 ) && sides_rl( ( $yaz ? 'st_y|' : 'st_o|' ) . $token, $yaz ? 400 : 1500, 600 );
}
function sides_st_pub_oku( WP_REST_Request $req ) {
	$tok = (string) $req['token'];
	if ( ! sides_st_pub_hiz( false, $tok ) ) {
		return new WP_Error( 'sides_rl', 'Çok fazla istek. Biraz sonra tekrar deneyin.', array( 'status' => 429 ) );
	}
	$x = sides_st_token_bul( $tok );
	if ( ! $x ) {
		return sides_st_hata( 'Bu sınav bağlantısı geçersiz ya da kapatılmış.', 404 );
	}
	$d = $x['d'];
	$a = sides_get_doc( $x['org'], 'settings', 'main' );
	return array(
		'kurum' => (string) $x['o']->ad,
		'logo'  => is_array( $a ) && ! empty( $a['logo'] ) && function_exists( 'sides_logo_gecerli' ) && sides_logo_gecerli( $a['logo'] ) ? $a['logo'] : '',
		'sinav' => array( 'id' => $d['id'], 'ad' => $d['ad'], 'ders' => $d['ders'], 'sinif' => $d['sinif'], 'aciklama' => isset( $d['aciklama'] ) ? $d['aciklama'] : '', 'soru' => (int) $d['soru'], 'secenek' => (int) $d['secenek'], 'anahtarVar' => '' !== (string) $d['anahtar'], 'tarih' => isset( $d['tarih'] ) ? $d['tarih'] : '' ),
		'pdf'   => rest_url( 'optik-karne/v1/sinavtakip/' . $d['id'] . '/pdf?t=' . $tok ),
	);
}
function sides_st_pub_coz( WP_REST_Request $req ) {
	$tok = (string) $req['token'];
	if ( ! sides_st_pub_hiz( true, $tok ) ) {
		return new WP_Error( 'sides_rl', 'Çok fazla istek. Biraz sonra tekrar deneyin.', array( 'status' => 429 ) );
	}
	$x = sides_st_token_bul( $tok );
	if ( ! $x ) {
		return sides_st_hata( 'Bu sınav bağlantısı geçersiz ya da kapatılmış.', 404 );
	}
	$d = $x['d'];
	$p = $req->get_json_params();
	if ( ! is_array( $p ) ) {
		return sides_st_hata( 'Geçersiz istek.' );
	}
	$ad = sides_kt_metin( isset( $p['ad'] ) ? $p['ad'] : '', 80 );
	if ( mb_strlen( $ad ) < 3 ) {
		return sides_st_hata( 'Ad soyad yazın.' );
	}
	$soru = (int) $d['soru'];
	$sec  = 5 === (int) $d['secenek'] ? 'ABCDE' : 'ABCD';
	if ( ! $soru || '' === (string) $d['anahtar'] ) {
		return sides_st_hata( 'Bu sınavın cevap anahtarı girilmemiş; online çözüm kapalı.' );
	}
	$cevap = isset( $p['cevap'] ) && is_string( $p['cevap'] ) ? strtoupper( $p['cevap'] ) : '';
	$cevap = preg_replace( '/[^' . $sec . '\-]/', '-', $cevap );
	$cevap = substr( str_pad( $cevap, $soru, '-' ), 0, $soru );
	$key   = (string) $d['anahtar'];
	$D     = 0;
	$Y     = 0;
	$B     = 0;
	$durum = array();
	for ( $i = 0; $i < $soru; $i++ ) {
		$k = $key[ $i ];
		$c = $cevap[ $i ];
		if ( 'X' === $k ) {
			$durum[] = 'iptal';
		} elseif ( '-' === $c ) {
			$B++;
			$durum[] = 'bos';
		} elseif ( $c === $k ) {
			$D++;
			$durum[] = 'dogru';
		} else {
			$Y++;
			$durum[] = 'yanlis';
		}
	}
	$net   = round( $D - $Y / ( strlen( $sec ) - 1 ), 2 );
	$no    = sides_kt_metin( isset( $p['no'] ) ? $p['no'] : '', 12 );
	$sinif = sides_kt_metin( isset( $p['sinif'] ) ? $p['sinif'] : '', 6 );
	$sube  = sides_kt_sube( isset( $p['sube'] ) ? $p['sube'] : '' );
	$sid   = '';
	if ( '' !== $no && '' !== $sinif ) {   // numara ve sınıf uyuşursa kayıtlı öğrenciye bağlanır
		global $wpdb;
		$t = sides_docs();
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = 'students'", $x['org'] ) ) as $r ) { // phpcs:ignore
			$s = json_decode( $r->data, true );
			if ( is_array( $s ) && (string) ( isset( $s['no'] ) ? $s['no'] : '' ) === $no && (string) ( isset( $s['sinif'] ) ? $s['sinif'] : '' ) === $sinif ) {
				$sid = (string) $r->id;
				break;
			}
		}
	}
	$id = 'ss' . substr( bin2hex( random_bytes( 8 ) ), 0, 14 );
	$r  = array( 'sinavId' => $d['id'], 'ad' => $ad, 'no' => $no, 'sinif' => $sinif, 'sube' => $sube, 'studentId' => $sid, 'cevap' => $cevap, 'D' => $D, 'Y' => $Y, 'B' => $B, 'net' => $net, 'soru' => $soru, 'tarih' => (int) round( microtime( true ) * 1000 ) );
	if ( false === sides_put_doc( $x['org'], 'stsonuc', $id, $r, $d['id'] ) ) {
		return new WP_Error( 'sides_db', 'Kayıt yapılamadı.', array( 'status' => 500 ) );
	}
	return array( 'id' => $id, 'D' => $D, 'Y' => $Y, 'B' => $B, 'net' => $net, 'soru' => $soru, 'durum' => $durum, 'anahtar' => $key );
}
