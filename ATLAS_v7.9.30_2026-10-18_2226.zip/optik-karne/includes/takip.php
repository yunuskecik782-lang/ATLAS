<?php
/**
 * Takip Modülü: etüt yoklaması, kitap okuma, takviye ders puanları, izin dönüşü (akademik takip)
 * ve dahili ders seviyeleri ile işleyiş çizelgesi. Ayrıca ana hesabın kurum başına modül açıp kapatması.
 *
 * Kayıtlar kurum belgelerinde tutulur (coll: etut, izin, kitap, takviye, seviye, dgrup).
 * Yoklama, saat, sayfa, puan ve çizelge işaretleri "yama" ile tek tek birleştirilir; böylece aynı anda
 * çalışan iki öğretmen birbirinin girdiğini silmez, sınıf yetkili kullanıcı yalnızca kendi öğrencilerine yazar.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SIDES_TAKIP_COLL', array( 'etut', 'izin', 'kitap', 'takviye', 'seviye', 'dgrup', 'yoklama', 'kutuphane' ) );   /* v7.9.5 kutuphane: kurum kitap listesi { ad, yazar, sayfa, not } */
/* v5.9 Yoklama listesi: yoklama/<YYYY-MM-DD> { tarih, o: { y1: { ad, saat } }, y1: { öğrenci: V|Y|G|I|H }, y2: … } — günde en fazla 30 yoklama */
function sides_yoklama_alan( $a ) {
	return (bool) preg_match( '/^y([1-9]|[12]\d|30)$/', (string) $a );
}

/* ------------------------------------------------------------------ *
 * v7 K02: Etüt sayısı ve saatleri (kurum ayarı). Belge tkayar/etut { slotlar: [ { id: e1…e6, ad, bas, bit } ], guncel }
 * Genel /doc ucunun listesinde olmayan ayrı koleksiyonda durur (genel kayıtla değiştirilemez); yedeğe otomatik girer.
 * Etüt hücre anahtarları e1…e6; yalnız ayardaki ilk N etüde yeni giriş yapılır. Sayı azaltılınca eski kayıtlar silinmez,
 * raporlarda görünmeye devam eder. Varsayılan: mevcut 3 etüt (eski veriler aynen geçerlidir).
 * ------------------------------------------------------------------ */
define( 'SIDES_ETUT_ANAHTAR', array( 'e1', 'e2', 'e3', 'e4', 'e5', 'e6' ) );
/* v7 etüt "Geç": durum kodu L (G zaten "Var/geldi" anlamında). Katılım sayılır, ayrıca raporlanır.
 * Geç dakikası isteğe bağlı ve sonradan girilir: etut/<gün>.gec { "<öğrenci>|eN": 1…240 } — yalnız o etütte durumu L olan öğrenciye.
 * Durum L'den başka bir şeye dönünce o hücrenin dakikası sunucuda silinir (geçmişe yazılır). */
define( 'SIDES_ETUT_DURUM', array( 'G', 'Y', 'I', 'H', 'L' ) );
function sides_etut_gec_anahtar( $k ) {
	return preg_match( '/^([A-Za-z0-9_\-]{1,80})\|(e[1-6])$/', (string) $k, $m ) ? array( $m[1], $m[2] ) : null;
}
function sides_etut_gec_dk( $v ) {
	if ( is_int( $v ) || ( is_float( $v ) && floor( $v ) === $v ) || ( is_string( $v ) && preg_match( '/^\d{1,3}$/', $v ) ) ) {
		$n = (int) $v;
		return $n >= 1 && $n <= 240 ? $n : null;
	}
	return null;
}
function sides_etut_durum_al( $d, $slot, $sid ) {
	return is_array( $d ) && isset( $d[ $slot ] ) && is_array( $d[ $slot ] ) && isset( $d[ $slot ][ $sid ] ) ? $d[ $slot ][ $sid ] : null;
}
function sides_etut_ayar( $org ) {
	$d   = sides_get_doc( $org, 'tkayar', 'etut' );
	$l   = is_array( $d ) && ! empty( $d['slotlar'] ) && is_array( $d['slotlar'] ) ? array_values( $d['slotlar'] ) : array();
	$out = array();
	foreach ( array_slice( $l, 0, 6 ) as $i => $s ) {
		$s     = is_array( $s ) ? $s : array();
		$out[] = array(
			'id'  => 'e' . ( $i + 1 ),
			'ad'  => isset( $s['ad'] ) && '' !== trim( (string) $s['ad'] ) ? (string) $s['ad'] : ( $i + 1 ) . '. Etüt',
			'bas' => isset( $s['bas'] ) && preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', (string) $s['bas'] ) ? (string) $s['bas'] : '',
			'bit' => isset( $s['bit'] ) && preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', (string) $s['bit'] ) ? (string) $s['bit'] : '',
		);
	}
	if ( ! $out ) {
		foreach ( array( 1, 2, 3 ) as $n ) {
			$out[] = array( 'id' => 'e' . $n, 'ad' => $n . '. Etüt', 'bas' => '', 'bit' => '' );
		}
	}
	return array( 'slotlar' => $out, 'guncel' => is_array( $d ) && isset( $d['guncel'] ) ? $d['guncel'] : null );
}
/* Yeni giriş yapılabilen etüt anahtarları (ayardaki ilk N) */
function sides_etut_alanlar( $org ) {
	static $c = array();
	if ( ! isset( $c[ $org ] ) ) {
		$c[ $org ] = array_column( sides_etut_ayar( $org )['slotlar'], 'id' );
	}
	return $c[ $org ];
}
/* Ayarı yönetici ya da sınıf kısıtı olmayan (kurum geneli) Takip/Etüt yazma yetkilisi değiştirir; gözlemci ve sınıf kısıtlı personel değiştiremez */
function sides_etut_ayar_yazar() {
	if ( sides_is_observer() || ! sides_can( 'takip', 2 ) ) {
		return false;
	}
	if ( 'yonetici' === sides_ctx()['rol'] ) {
		return true;
	}
	return null === sides_sinif_kisit() && ( ! function_exists( 'sides_sayfa_herhangi' ) || sides_sayfa_herhangi( array( 'takip.etut' ), 2 ) );
}
add_action( 'rest_api_init', function () {
	register_rest_route( 'optik-karne/v1', '/takip/etut-ayar', array(
		array( 'methods' => 'GET', 'callback' => function () {
			return sides_etut_ayar( sides_org_id() );
		}, 'permission_callback' => function () {
			return sides_can( 'takip', 1 ) ? true : sides_deny( 'Takip modülünü görme yetkiniz yok.' );
		} ),
		array( 'methods' => 'POST', 'callback' => 'sides_etut_ayar_kaydet', 'permission_callback' => function () {
			return sides_etut_ayar_yazar() ? true : sides_deny( 'Etüt sayısı ve saatleri kurum ayarıdır; yalnızca yönetici ya da kurum genelinde Etüt Yoklaması yetkisi olan kullanıcı değiştirebilir.' );
		} ),
	) );
} );
function sides_etut_ayar_kaydet( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	$l   = is_array( $p ) && isset( $p['slotlar'] ) && is_array( $p['slotlar'] ) ? array_values( $p['slotlar'] ) : array();
	if ( count( $l ) < 1 || count( $l ) > 6 ) {
		return new WP_Error( 'sides_gecersiz', 'Etüt sayısı 1 ile 6 arasında olmalı.', array( 'status' => 400 ) );
	}
	$saat = '/^([01]\d|2[0-3]):[0-5]\d$/';
	$out  = array();
	foreach ( $l as $i => $s ) {
		$s   = is_array( $s ) ? $s : array();
		$n   = $i + 1;
		$ad  = mb_substr( trim( sanitize_text_field( isset( $s['ad'] ) ? (string) $s['ad'] : '' ) ), 0, 30 );
		$bas = isset( $s['bas'] ) ? trim( (string) $s['bas'] ) : '';
		$bit = isset( $s['bit'] ) ? trim( (string) $s['bit'] ) : '';
		if ( ( '' !== $bas && ! preg_match( $saat, $bas ) ) || ( '' !== $bit && ! preg_match( $saat, $bit ) ) ) {
			return new WP_Error( 'sides_gecersiz', $n . '. etüdün saati geçersiz (SS:DD biçiminde yazın).', array( 'status' => 400 ) );
		}
		if ( '' !== $bas && '' !== $bit && $bit <= $bas ) {
			return new WP_Error( 'sides_gecersiz', $n . '. etüdün bitiş saati başlangıçtan sonra olmalı.', array( 'status' => 400 ) );
		}
		$out[] = array( 'id' => 'e' . $n, 'ad' => '' !== $ad ? $ad : $n . '. Etüt', 'bas' => $bas, 'bit' => $bit );
	}
	$u    = wp_get_current_user();
	$eski = sides_etut_ayar( $org );
	if ( false === sides_put_doc( $org, 'tkayar', 'etut', array( 'slotlar' => $out, 'guncel' => array( 't' => time(), 'u' => (int) $u->ID, 'ad' => $u->display_name ) ) ) ) {
		return new WP_Error( 'sides_db', 'Kaydedilemedi.', array( 'status' => 500 ) );
	}
	sides_log( $org, 'Etüt ayarı güncellendi: ' . count( $eski['slotlar'] ) . ' → ' . count( $out ) . ' etüt (' . implode( ', ', array_map( function ( $s ) {
		return $s['ad'] . ( $s['bas'] || $s['bit'] ? ' ' . $s['bas'] . '–' . $s['bit'] : '' );
	}, $out ) ) . ')' );
	return sides_etut_ayar( $org );
}

/* ------------------------------------------------------------------ *
 * Kurum başına modül açma / kapama (ana hesap)
 * ------------------------------------------------------------------ */
function sides_kapatilabilir_moduller() {
	return array_values( array_diff( SIDES_MODS, array( 'panel', 'sistem' ) ) );
}
function sides_kapali_moduller( $org ) {
	$h = get_option( 'sides_kurum_moduller', array() );
	$l = is_array( $h ) && isset( $h[ (int) $org ] ) ? (array) $h[ (int) $org ] : array();
	return array_values( array_intersect( $l, sides_kapatilabilir_moduller() ) );
}
function sides_kapali_kaydet( $org, $l ) {
	$h = get_option( 'sides_kurum_moduller', array() );
	$h = is_array( $h ) ? $h : array();
	$l = array_values( array_intersect( (array) $l, sides_kapatilabilir_moduller() ) );
	if ( $l ) {
		$h[ (int) $org ] = $l;
	} else {
		unset( $h[ (int) $org ] );
	}
	update_option( 'sides_kurum_moduller', $h, false );
	return $l;
}
function sides_org_modul_kisit( $org, $y ) {
	if ( ! $org ) {
		return $y;
	}
	foreach ( sides_kapali_moduller( $org ) as $m ) {
		$y[ $m ] = 0;
	}
	return $y;
}

/* ------------------------------------------------------------------ *
 * REST
 * ------------------------------------------------------------------ */
add_action( 'rest_api_init', function () {
	$ns   = 'optik-karne/v1';
	$oku  = function () {
		return sides_can( 'takip', 1 ) ? true : sides_deny( 'Takip modülünü görme yetkiniz yok.' );
	};
	$yaz  = function () {
		return sides_can( 'takip', 2 ) ? true : sides_deny( 'Takip modülünde değişiklik yapma yetkiniz yok.' );
	};
	register_rest_route( $ns, '/takip', array( 'methods' => 'GET', 'callback' => 'sides_takip_hepsi', 'permission_callback' => $oku ) );
	register_rest_route( $ns, '/takip/yama', array( 'methods' => 'POST', 'callback' => 'sides_takip_yama', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/takip/gecmis', array( 'methods' => 'GET', 'callback' => 'sides_takip_gecmis', 'permission_callback' => $oku ) );
	register_rest_route( $ns, '/takip/yapi', array( 'methods' => 'POST', 'callback' => 'sides_takip_yapi', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/takip/kitap/(?P<id>[A-Za-z0-9_\-]{1,64})', array( 'methods' => 'POST', 'callback' => 'sides_takip_kitap_duzen', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/takip/link/(?P<id>[A-Za-z0-9_\-]{1,64})', array(
		array( 'methods' => 'POST', 'callback' => 'sides_takip_link', 'permission_callback' => $yaz ),
		array( 'methods' => 'DELETE', 'callback' => 'sides_takip_link_sil', 'permission_callback' => $yaz ),
	) );
	register_rest_route( $ns, '/tk/(?P<token>[a-f0-9]{32})', array(
		array( 'methods' => 'GET', 'callback' => 'sides_tk_oku', 'permission_callback' => '__return_true' ),
		array( 'methods' => 'POST', 'callback' => 'sides_tk_kaydet', 'permission_callback' => '__return_true' ),
	) );
} );

/* Sınıf yetkili kullanıcının görebildiği öğrenciler (kısıt yoksa null) */
function sides_takip_izin( $org ) {
	$k = sides_sinif_kisit();
	return null === $k ? null : sides_izinli_ogrenciler( $org, $k );
}
function sides_takip_suz_harita( $m, $izin, $ayir = false ) {
	if ( null === $izin || ! is_array( $m ) ) {
		return $m;
	}
	$o = array();
	foreach ( $m as $k => $v ) {
		$sid = $ayir ? strtok( (string) $k, '|' ) : (string) $k;
		if ( isset( $izin[ $sid ] ) ) {
			$o[ $k ] = $v;
		}
	}
	return $o;
}

/* Takip belgesini kullanıcının sınıf kapsamına göre süzer (öğrenci haritaları); kapsam dışı belge için null. /takip ve /koleksiyon aynı kuralı kullanır (T02). */
function sides_takip_suz_belge( $coll, $d, $izin ) {
	if ( null === $izin || ! is_array( $d ) ) {
		return $d;
	}
	if ( 'yoklama' === $coll ) {
		foreach ( array_keys( $d ) as $a ) {
			if ( sides_yoklama_alan( $a ) && is_array( $d[ $a ] ) ) {
				$d[ $a ] = sides_takip_suz_harita( $d[ $a ], $izin );
			}
		}
		return $d;
	}
	switch ( $coll ) {
		case 'etut':
			foreach ( SIDES_ETUT_ANAHTAR as $e ) {   // v7: e1…e6 (ayarda kapatılan etüdün eski kaydı da süzülerek okunur)
				if ( isset( $d[ $e ] ) ) {
					$d[ $e ] = sides_takip_suz_harita( $d[ $e ], $izin );
				}
			}
			if ( isset( $d['gec'] ) ) {   // geç dakikaları: anahtar "öğrenci|eN"
				$d['gec'] = sides_takip_suz_harita( $d['gec'], $izin, true );
			}
			break;
		case 'izin':
			foreach ( array( 'saat', 'durum', 'not', 'uzatma' ) as $a ) {
				if ( isset( $d[ $a ] ) ) {
					$d[ $a ] = sides_takip_suz_harita( $d[ $a ], $izin );
				}
			}
			break;
		case 'kitap':
			if ( empty( $d['studentId'] ) || ! isset( $izin[ (string) $d['studentId'] ] ) ) {
				return null;
			}
			break;
		case 'takviye':
			$d['puan']       = sides_takip_suz_harita( isset( $d['puan'] ) ? $d['puan'] : array(), $izin );
			$d['ogrenciler'] = array_values( array_filter( isset( $d['ogrenciler'] ) ? (array) $d['ogrenciler'] : array(), function ( $s ) use ( $izin ) {
				return isset( $izin[ (string) $s ] );
			} ) );
			break;
		case 'dgrup':
			foreach ( array( 'isaret', 'serbest' ) as $a ) {
				if ( isset( $d[ $a ] ) ) {
					$d[ $a ] = sides_takip_suz_harita( $d[ $a ], $izin, true );
				}
			}
			$d['ogrenciler'] = array_values( array_filter( isset( $d['ogrenciler'] ) ? (array) $d['ogrenciler'] : array(), function ( $s ) use ( $izin ) {
				return isset( $izin[ (string) $s ] );
			} ) );
			break;
	}
	return $d;
}
/* T03: genel /doc kaydında takip belgeleri — hücre değerleri doğrulanır; sınıf kısıtlı kullanıcının kapsam dışı öğrencileri eski hâliyle korunur */
function sides_takip_doc_birlestir( $org, $coll, $id, $d ) {
	$alanlar = array( 'etut' => array_merge( SIDES_ETUT_ANAHTAR, array( 'gec' ) ), 'izin' => array( 'saat', 'durum', 'not', 'uzatma' ), 'takviye' => array( 'puan' ), 'dgrup' => array( 'isaret', 'serbest' ) );
	if ( 'yoklama' === $coll && is_array( $d ) ) {
		$e0 = sides_get_doc( $org, 'yoklama', $id );
		$alanlar['yoklama'] = array_values( array_unique( array_filter( array_merge( array_keys( $d ), is_array( $e0 ) ? array_keys( $e0 ) : array() ), 'sides_yoklama_alan' ) ) );
	}
	if ( ! isset( $alanlar[ $coll ] ) || ! is_array( $d ) ) {
		return $d;
	}
	$hata = new WP_Error( 'sides_gecersiz', 'Geçersiz yoklama/puan değeri.', array( 'status' => 400 ) );
	if ( 'etut' === $coll ) {   // v7: ayarda olmayan etüde genel kayıtla da yeni giriş yapılamaz (eski kayıt aynen gönderilebilir)
		$e0  = sides_get_doc( $org, 'etut', $id );
		$akt = sides_etut_alanlar( $org );
		foreach ( array_keys( $d ) as $a ) {
			if ( preg_match( '/^e\d+$/', (string) $a ) && ( ! in_array( $a, SIDES_ETUT_ANAHTAR, true ) || ( ! in_array( $a, $akt, true ) && (array) $d[ $a ] != ( is_array( $e0 ) && isset( $e0[ $a ] ) ? (array) $e0[ $a ] : array() ) ) ) ) {
				return new WP_Error( 'sides_etut_yok', 'Bu etüt kurum ayarında tanımlı değil; yeni giriş yapılamaz.', array( 'status' => 400 ) );
			}
		}
	}
	foreach ( $alanlar[ $coll ] as $a ) {
		if ( ! isset( $d[ $a ] ) ) {
			continue;
		}
		if ( ! is_array( $d[ $a ] ) ) {
			return $hata;
		}
		foreach ( $d[ $a ] as $k => $v ) {
			$ok = true;
			switch ( $coll . '.' . $a ) {
				case 'etut.e1':
				case 'etut.e2':
				case 'etut.e3':
				case 'etut.e4':
				case 'etut.e5':
				case 'etut.e6':
					$ok = in_array( $v, SIDES_ETUT_DURUM, true );
					break;
				case 'etut.gec':   // "öğrenci|eN" → 1…240 dk; yalnız aynı belgede o etütte durumu L (geç) olan öğrenci
					$p  = sides_etut_gec_anahtar( $k );
					$ok = $p && null !== sides_etut_gec_dk( $v ) && 'L' === sides_etut_durum_al( $d, $p[1], $p[0] );
					break;
				case 'izin.saat':
					$ok = (bool) preg_match( '/^([01]?\d|2[0-3]):[0-5]\d$/', (string) $v );
					break;
				case 'izin.durum':
					$ok = in_array( $v, array( 'G', 'Y', 'I', 'U', 'H' ), true );
					break;
				case 'takviye.puan':
					$ok = is_numeric( $v ) && (int) $v >= 1 && (int) $v <= 10;
					break;
				case 'dgrup.isaret':
					$ok = is_numeric( $v ) && (int) $v >= 1 && (int) $v <= 5;
					break;
			}
			if ( 'yoklama' === $coll ) {
				$ok = in_array( $v, array( 'V', 'Y', 'G', 'I', 'H' ), true );
			}
			if ( ! $ok ) {
				return $hata;
			}
		}
	}
	if ( 'etut' === $coll && isset( $d['gec'] ) ) {   // dakikalar tam sayı olarak saklanır
		$g = array();
		foreach ( (array) $d['gec'] as $k => $v ) {
			$g[ $k ] = sides_etut_gec_dk( $v );
		}
		$d['gec'] = (object) $g;
	}
	$izin = sides_takip_izin( $org );
	if ( null === $izin ) {
		return $d;
	}
	$eski = sides_get_doc( $org, $coll, $id );
	$eski = is_array( $eski ) ? $eski : array();
	$kap  = function ( $k ) use ( $izin ) {
		$p = explode( '|', (string) $k );
		return isset( $izin[ $p[0] ] );
	};
	foreach ( $alanlar[ $coll ] as $a ) {
		$m = array();
		foreach ( isset( $eski[ $a ] ) ? (array) $eski[ $a ] : array() as $k => $v ) {
			if ( ! $kap( $k ) ) {
				$m[ $k ] = $v;   // kapsam dışı: eskisi korunur
			}
		}
		foreach ( isset( $d[ $a ] ) ? (array) $d[ $a ] : array() as $k => $v ) {
			if ( $kap( $k ) ) {
				$m[ $k ] = $v;
			}
		}
		$d[ $a ] = (object) $m;
	}
	if ( in_array( $coll, array( 'takviye', 'dgrup' ), true ) ) {
		$l = array_values( array_filter( isset( $eski['ogrenciler'] ) ? (array) $eski['ogrenciler'] : array(), function ( $s ) use ( $kap ) {
			return ! $kap( $s );
		} ) );
		foreach ( isset( $d['ogrenciler'] ) ? (array) $d['ogrenciler'] : array() as $s ) {
			if ( $kap( $s ) && ! in_array( (string) $s, $l, true ) ) {
				$l[] = (string) $s;
			}
		}
		$d['ogrenciler'] = $l;
	}
	return $d;
}
function sides_takip_hepsi( WP_REST_Request $req ) {
	global $wpdb;
	$org  = sides_org_id();
	$t    = sides_docs();
	$bas  = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $req['bas'] ) ? (string) $req['bas'] : gmdate( 'Y-m-d', time() - 62 * DAY_IN_SECONDS );
	$izin = sides_takip_izin( $org );
	$out  = array_fill_keys( SIDES_TAKIP_COLL, array() );
	$rows = $wpdb->get_results( $wpdb->prepare( "SELECT coll, id, token, data FROM $t WHERE org = %d AND coll IN ('etut','izin','kitap','takviye','seviye','dgrup','yoklama','kutuphane') AND ( coll NOT IN ('etut','yoklama') OR id >= %s) ORDER BY coll, id", $org, $bas ) ); // phpcs:ignore
	foreach ( $rows as $r ) {
		$d = json_decode( $r->data, true );
		if ( ! is_array( $d ) ) {
			continue;
		}
		$tam = 'takviye' === $r->coll && sides_takviye_kapsamda( $d, $izin );   // süzmeden önce: dersin tüm öğrencileri yetkili mi
		if ( null !== $izin ) {
			$d = sides_takip_suz_belge( $r->coll, $d, $izin );
			if ( null === $d ) {
				continue;
			}
		}
		$d['id'] = $r->id;
		if ( 'takviye' === $r->coll ) {   // yazma bağlantısı: yalnız takip yazma yetkisi olana (T04); v7.3.1: sınıf kısıtlıya yalnız tüm öğrencileri kendi sınıflarındaysa
			$d['token'] = $r->token && $tam && sides_can( 'takip', 2 ) && ! sides_is_observer() ? $r->token : null;
		}
		$out[ $r->coll ][] = $d;
	}
	$out['etutAyar'] = sides_etut_ayar( $org );   // v7 K02: etüt sayısı, adları ve saatleri
	return $out;
}

/* Tek tek alan birleştirme: { coll, id, alan, degerler: { anahtar: değer | null } } */
function sides_takip_yama( WP_REST_Request $req ) {
	$org  = sides_org_id();
	$p    = $req->get_json_params();
	$coll = isset( $p['coll'] ) ? (string) $p['coll'] : '';
	$id   = isset( $p['id'] ) ? (string) $p['id'] : '';
	$alan = isset( $p['alan'] ) ? (string) $p['alan'] : '';
	$deg  = isset( $p['degerler'] ) && is_array( $p['degerler'] ) ? $p['degerler'] : array();
	if ( 'etut' === $coll && in_array( $alan, SIDES_ETUT_ANAHTAR, true ) && ! in_array( $alan, sides_etut_alanlar( $org ), true ) ) {   // v7: etüt sırası kurum ayarına göre
		return new WP_Error( 'sides_etut_yok', 'Bu etüt (' . substr( $alan, 1 ) . '. etüt) kurum ayarında tanımlı değil; yeni giriş yapılamaz. Sayfayı yenileyin ya da etüt ayarlarını kontrol edin.', array( 'status' => 400 ) );
	}
	$izinli_alan = array( 'etut' => array_merge( sides_etut_alanlar( $org ), array( 'gec' ) ), 'izin' => array( 'saat', 'durum', 'not', 'uzatma' ), 'kitap' => array( 'okuma' ), 'takviye' => array( 'puan' ), 'dgrup' => array( 'isaret', 'serbest' ) );
	if ( 'yoklama' === $coll && ( 'o' === $alan || sides_yoklama_alan( $alan ) ) ) {
		$izinli_alan['yoklama'] = array( $alan );
	}
	if ( ! isset( $izinli_alan[ $coll ] ) || ! in_array( $alan, $izinli_alan[ $coll ], true ) || ! preg_match( '/^[A-Za-z0-9_\-]{1,64}$/', $id ) || count( $deg ) > 600 ) {
		return new WP_Error( 'sides_gecersiz', 'Geçersiz kayıt.', array( 'status' => 400 ) );
	}
	$kilit = sides_takip_kilit( $org . '|' . $coll . '|' . $id );
	if ( false === $kilit ) {
		return sides_kilit_mesgul();   // T06: kilit alınamadı, hiçbir şey yazılmadı
	}
	$sonuc = sides_takip_yama_uygula( $org, $coll, $id, $alan, $deg );
	sides_takip_kilit_birak( $kilit );
	return $sonuc;
}
/* Aynı kayda aynı anda gelen iki yama birbirinin üzerine yazmasın (MySQL GET_LOCK; desteklenmeyen veritabanında kilitsiz sürer) */
function sides_takip_kilit( $k ) {
	global $wpdb;
	$ad = 'sides_' . md5( $k );
	$e  = $wpdb->suppress_errors( true );
	$ok = $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $ad ) );
	$wpdb->suppress_errors( $e );
	if ( '1' === (string) $ok ) {
		return $ad;
	}
	return '0' === (string) $ok ? false : '';   // T06: false = başka işlem sürüyor (zaman aşımı); '' = veritabanı kilit desteklemiyor (kilitsiz devam)
}
function sides_kilit_mesgul() {
	return new WP_Error( 'sides_mesgul', 'Aynı kayıt şu anda başka bir işlemle güncelleniyor. Birkaç saniye sonra tekrar deneyin; değişikliğiniz kaydedilmedi.', array( 'status' => 503 ) );
}
function sides_takip_kilit_birak( $ad ) {
	global $wpdb;
	if ( $ad ) {
		$e = $wpdb->suppress_errors( true );
		$wpdb->query( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $ad ) );
		$wpdb->suppress_errors( $e );
	}
}
function sides_takip_yama_uygula( $org, $coll, $id, $alan, $deg ) {
	$d = sides_get_doc( $org, $coll, $id );
	if ( ! $d ) {
		if ( ! in_array( $coll, array( 'etut', 'izin', 'yoklama' ), true ) || ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $id ) ) {
			return new WP_Error( 'sides_yok', 'Kayıt bulunamadı; sayfayı yenileyin.', array( 'status' => 404 ) );
		}
		$d = array( 'tarih' => $id );
	}
	unset( $d['id'], $d['token'] );
	$izin = sides_takip_izin( $org );
	$red  = sides_deny( 'Bu öğrenci, yetkili olduğunuz sınıfların dışında.' );
	if ( 'kitap' === $coll && null !== $izin && ( empty( $d['studentId'] ) || ! isset( $izin[ (string) $d['studentId'] ] ) ) ) {
		return $red;
	}
	$m    = isset( $d[ $alan ] ) && is_array( $d[ $alan ] ) ? $d[ $alan ] : array();
	$once = $m;
	foreach ( $deg as $k => $v ) {
		$k = (string) $k;
		if ( 'kitap' === $coll ) {
			if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $k ) ) {
				continue;
			}
		} elseif ( 'yoklama' === $coll && 'o' === $alan ) {
			if ( ! sides_yoklama_alan( $k ) ) {   // yoklama başlığı: anahtar yoklama numarasıdır, öğrenci değil
				return new WP_Error( 'sides_gecersiz', 'Geçersiz yoklama.', array( 'status' => 400 ) );
			}
		} else {
			$sid = 'dgrup' === $coll || 'etut.gec' === $coll . '.' . $alan ? strtok( $k, '|' ) : $k;
			if ( ! preg_match( '/^[A-Za-z0-9_\-|]{1,90}$/', $k ) || ( null !== $izin && ! isset( $izin[ $sid ] ) ) ) {
				return $red;
			}
			if ( 'etut.gec' === $coll . '.' . $alan && ! sides_etut_gec_anahtar( $k ) ) {
				return new WP_Error( 'sides_gecersiz', 'Geçersiz geç süresi kaydı.', array( 'status' => 400 ) );
			}
		}
		if ( null === $v || '' === $v ) {
			unset( $m[ $k ] );
			continue;
		}
		switch ( $coll . '.' . $alan ) {
			case 'etut.e1':
			case 'etut.e2':
			case 'etut.e3':
			case 'etut.e4':
			case 'etut.e5':
			case 'etut.e6':
				$v = in_array( $v, SIDES_ETUT_DURUM, true ) ? $v : null;   // var, yok, izinli, hasta, geç
				break;
			case 'etut.gec':   // geç dakikası: 1…240; o etüt kurum ayarında açık ve öğrencinin durumu "Geç" olmalı
				$v = sides_etut_gec_dk( $v );
				$p = sides_etut_gec_anahtar( $k );
				if ( null !== $v && ( ! in_array( $p[1], sides_etut_alanlar( $org ), true ) || 'L' !== sides_etut_durum_al( $d, $p[1], $p[0] ) ) ) {
					return new WP_Error( 'sides_gec_durum', 'Geç süresi yalnızca o etütte “Geç” olarak işaretlenen öğrenciye yazılabilir.', array( 'status' => 400 ) );
				}
				if ( null === $v ) {
					return new WP_Error( 'sides_gecersiz', 'Geç süresi 1 ile 240 dakika arasında tam sayı olmalı.', array( 'status' => 400 ) );
				}
				break;
			case 'izin.saat':
				$v = preg_match( '/^([01]?\d|2[0-3]):[0-5]\d$/', (string) $v ) ? (string) $v : null;
				break;
			case 'izin.durum':   // v5.7.2: G geldi, Y gelmedi, I izinli, U ulaşılamadı, H hasta
				$v = in_array( $v, array( 'G', 'Y', 'I', 'U', 'H' ), true ) ? $v : null;
				break;
			case 'izin.not':
				$v = mb_substr( sanitize_text_field( (string) $v ), 0, 120 );
				break;
			case 'yoklama.o':
				$v = is_array( $v ) ? array( 'ad' => mb_substr( sanitize_text_field( (string) ( isset( $v['ad'] ) ? $v['ad'] : '' ) ), 0, 40 ), 'saat' => isset( $v['saat'] ) && preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', (string) $v['saat'] ) ? (string) $v['saat'] : '' ) : null;
				break;
			case 'izin.uzatma':   // izni uzatılan öğrencinin dönüş tarihi
				$v = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $v ) ? (string) $v : null;
				break;
			case 'kitap.okuma':
				$v = is_numeric( $v ) && (int) $v >= 0 && (int) $v <= 3000 ? (int) $v : null;
				break;
			case 'takviye.puan':
				$v = is_numeric( $v ) && (int) $v >= 1 && (int) $v <= 10 ? (int) $v : null;
				break;
			case 'dgrup.isaret':
				$v = is_numeric( $v ) && (int) $v >= 1 && (int) $v <= 5 ? (int) $v : null;
				break;
			case 'dgrup.serbest':
				$v = mb_substr( sanitize_text_field( (string) $v ), 0, 200 );
				break;
		}
		if ( 'yoklama' === $coll && sides_yoklama_alan( $alan ) ) {
			$v = in_array( $v, array( 'V', 'Y', 'G', 'I', 'H' ), true ) ? $v : null;   // var, yok, geç, izinli, hasta
		}
		if ( null === $v ) {
			return new WP_Error( 'sides_gecersiz', 'Geçersiz değer.', array( 'status' => 400 ) );
		}
		$m[ $k ] = $v;
	}
	$d[ $alan ] = (object) $m;
	$gec0 = null;
	$gec1 = null;
	if ( 'etut' === $coll && in_array( $alan, SIDES_ETUT_ANAHTAR, true ) && ! empty( $d['gec'] ) && is_array( $d['gec'] ) ) {   // durum "Geç"ten çıkınca o hücrenin dakikası silinir
		$gec1 = $d['gec'];
		foreach ( array_keys( $deg ) as $k ) {
			$gk = $k . '|' . $alan;
			if ( isset( $gec1[ $gk ] ) && ( ! isset( $m[ $k ] ) || 'L' !== $m[ $k ] ) ) {
				unset( $gec1[ $gk ] );
			}
		}
		if ( $gec1 !== $d['gec'] ) {
			$gec0      = $d['gec'];
			$d['gec'] = (object) $gec1;
		}
	}
	if ( false === sides_put_doc( $org, $coll, $id, $d ) ) {
		return new WP_Error( 'sides_db', 'Kaydedilemedi.', array( 'status' => 500 ) );
	}
	sides_tk_gecmis_yaz( $org, $coll, $id, $alan, $once, $m );
	if ( null !== $gec0 ) {
		sides_tk_gecmis_yaz( $org, $coll, $id, 'gec', $gec0, $gec1 );
	}
	return array( 'ok' => true );
}

/* v7.3.1 güvenlik: takviye linki dersin TÜM öğrencilerini açar; sınıf kısıtlı kullanıcı yalnız tamamı kendi sınıflarında olan dersin linkini görür/yönetir */
function sides_takviye_kapsamda( $d, $izin ) {
	if ( null === $izin ) {
		return true;
	}
	foreach ( ( is_array( $d ) && isset( $d['ogrenciler'] ) ? (array) $d['ogrenciler'] : array() ) as $s ) {
		if ( ! isset( $izin[ (string) $s ] ) ) {
			return false;
		}
	}
	return true;
}

/* Takviye ders öğretmen linki */
function sides_takip_link( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$id  = (string) $req['id'];
	$doc = sides_get_doc( $org, 'takviye', $id );
	if ( ! $doc ) {
		return new WP_Error( 'sides_yok', 'Takviye ders bulunamadı.', array( 'status' => 404 ) );
	}
	if ( ! sides_takviye_kapsamda( $doc, sides_takip_izin( $org ) ) ) {
		return sides_deny( 'Bu takviye derste yetkili olduğunuz sınıfların dışında öğrenci var; linki kurum yöneticisi oluşturabilir.' );
	}
	$tok = bin2hex( random_bytes( 16 ) );
	$wpdb->update( sides_docs(), array( 'token' => $tok ), array( 'org' => $org, 'coll' => 'takviye', 'id' => $id ) );
	return array( 'token' => $tok );
}
function sides_takip_link_sil( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	if ( ! sides_takviye_kapsamda( sides_get_doc( $org, 'takviye', (string) $req['id'] ), sides_takip_izin( $org ) ) ) {
		return sides_deny( 'Bu takviye derste yetkili olduğunuz sınıfların dışında öğrenci var; linki kurum yöneticisi kaldırabilir.' );
	}
	$wpdb->update( sides_docs(), array( 'token' => null ), array( 'org' => sides_org_id(), 'coll' => 'takviye', 'id' => (string) $req['id'] ) );
	return array( 'ok' => true );
}

function sides_tk_bul( $token ) {
	global $wpdb;
	$t = sides_docs();
	$r = $wpdb->get_row( $wpdb->prepare( "SELECT org, id, data FROM $t WHERE coll = 'takviye' AND token = %s", $token ) ); // phpcs:ignore
	if ( ! $r || in_array( 'takip', sides_kapali_moduller( (int) $r->org ), true ) ) {
		return null;
	}
	$o = sides_org( (int) $r->org );
	if ( ! $o || sides_org_blok( $o ) ) {
		return null;
	}
	$d = json_decode( $r->data, true );
	return is_array( $d ) ? array( 'org' => (int) $r->org, 'id' => $r->id, 'd' => $d ) : null;
}
function sides_tk_oku( WP_REST_Request $req ) {
	if ( ! sides_tk_bul( (string) $req['token'] ) ) {   // v5.5.1: öğretmen linki kendi hız sınırını kullanır (aynı okul ağındaki öğretmenler birbirini kilitlemesin)
		return sides_tko_cevap( 'sides_tko_oku', $req );
	}
	if ( ! sides_tk_hiz( false, (string) $req['token'] ) ) {
		return new WP_Error( 'sides_rl', 'Çok fazla istek. Biraz sonra tekrar deneyin.', array( 'status' => 429 ) );
	}
	$x = sides_tk_bul( (string) $req['token'] );
	if ( ! $x ) {
		return sides_tko_cevap( 'sides_tko_oku', $req );
	}
	$d    = $x['d'];
	$ogr  = array();
	foreach ( isset( $d['ogrenciler'] ) ? (array) $d['ogrenciler'] : array() as $sid ) {
		$s = sides_get_doc( $x['org'], 'students', (string) $sid );
		if ( $s ) {
			$ogr[] = array( 'id' => (string) $sid, 'ad' => isset( $s['ad'] ) ? $s['ad'] : '', 'no' => isset( $s['no'] ) ? (string) $s['no'] : '', 'sinif' => isset( $s['sinif'] ) ? (string) $s['sinif'] : '', 'sube' => isset( $s['sube'] ) ? (string) $s['sube'] : '' );
		}
	}
	$set = sides_get_doc( $x['org'], 'settings', 'main' );
	return array(
		'ders'       => isset( $d['ders'] ) ? $d['ders'] : '',
		'ogretmen'   => isset( $d['ogretmen'] ) ? $d['ogretmen'] : '',
		'tarih'      => isset( $d['tarih'] ) ? $d['tarih'] : '',
		'kurum'      => $set && isset( $set['kurum'] ) ? $set['kurum'] : '',
		'logo'       => $set && isset( $set['logo'] ) ? $set['logo'] : '',
		'ogrenciler' => $ogr,
		'puan'       => isset( $d['puan'] ) ? (object) $d['puan'] : new stdClass(),
	);
}
function sides_tk_kaydet( WP_REST_Request $req ) {
	if ( ! sides_tk_bul( (string) $req['token'] ) ) {   // v5.5.1: öğretmen linki kendi hız sınırını kullanır (aynı okul ağındaki öğretmenler birbirini kilitlemesin)
		return sides_tko_cevap( 'sides_tko_yaz', $req );
	}
	if ( ! sides_tk_hiz( true, (string) $req['token'] ) ) {
		return new WP_Error( 'sides_rl', 'Çok fazla istek. Biraz sonra tekrar deneyin.', array( 'status' => 429 ) );
	}
	$x = sides_tk_bul( (string) $req['token'] );
	if ( ! $x ) {
		return sides_tko_cevap( 'sides_tko_yaz', $req );
	}
	$kilit = sides_takip_kilit( $x['org'] . '|takviye|' . $x['id'] );
	if ( false === $kilit ) {
		return sides_kilit_mesgul();   // T06: kilit alınamadı, hiçbir şey yazılmadı
	}
	$x     = sides_tk_bul( (string) $req['token'] );   // kilit altında güncel hâli
	$p    = $req->get_json_params();
	$d    = $x['d'];
	$ogr  = array_flip( array_map( 'strval', isset( $d['ogrenciler'] ) ? (array) $d['ogrenciler'] : array() ) );
	$m    = isset( $d['puan'] ) && is_array( $d['puan'] ) ? $d['puan'] : array();
	$say  = 0;
	foreach ( isset( $p['puan'] ) && is_array( $p['puan'] ) ? $p['puan'] : array() as $sid => $v ) {
		$sid = (string) $sid;
		if ( ! isset( $ogr[ $sid ] ) ) {
			continue;
		}
		if ( null === $v || '' === $v ) {
			unset( $m[ $sid ] );
		} elseif ( is_numeric( $v ) && (int) $v >= 1 && (int) $v <= 10 ) {
			$m[ $sid ] = (int) $v;
			$say++;
		}
	}
	$d['puan']  = (object) $m;
	$d['giren'] = array( 'ad' => mb_substr( isset( $d['ogretmen'] ) ? (string) $d['ogretmen'] : '', 0, 80 ), 'yol' => 'link', 't' => time() );   // v7 haftalık rapor
	unset( $d['id'], $d['token'] );
	sides_put_doc( $x['org'], 'takviye', $x['id'], $d );
	sides_takip_kilit_birak( $kilit );
	sides_log( $x['org'], 'Takviye ders puanları öğretmen linkinden girildi: ' . ( isset( $d['ders'] ) ? $d['ders'] : '' ) . ' (' . $say . ' öğrenci)', isset( $d['ogretmen'] ) && $d['ogretmen'] ? $d['ogretmen'] : 'Öğretmen linki' );
	return array( 'ok' => true, 'puan' => $d['puan'] );
}

/* =====================================================================
   v5.3 Dahili ders çizelge yapısı: seviye / grup / şablon belgelerinde alan birleştirme.
   - Yalnızca izin verilen alanlar yazılır; işaret ve serbest değerler (hücre verisi) hiç ezilmez.
   - Yapı (cizelge) değişikliği sürüm denetimlidir: istemcinin bildiği sürüm eskiyse 409 döner
     (başkasının yeni değişikliği sessizce ezilmez). Her yapı kaydında sürüm artar, geçmişe
     tamamlanma paydası (bölüm başına etkin konu sayısı) yazılır.
   - Grup üyeliği ekle/çıkar olarak birleştirilir (aynı anda yapılan iki değişiklik birbirini silmez).
   - Yapı düzenleme yetkisi hücre değerlendirme yetkisinden ayrıdır: varsayılan yalnızca yönetici;
     seviye/_ayar.yapiYetki = 'yazar' ise Takip'te yazma yetkisi olan herkes.
   ===================================================================== */
function sides_takip_yapi_yetkisi( $org ) {
	$c = sides_ctx();
	if ( 'yonetici' === $c['rol'] || ( function_exists( 'sides_is_super' ) && sides_is_super() ) ) {
		return true;
	}
	$a = sides_get_doc( $org, 'seviye', '_ayar' );
	return $a && isset( $a['yapiYetki'] ) && 'yazar' === $a['yapiYetki'] && sides_can( 'takip', 2 );
}
function sides_dd_temiz( $v, $derin = 0 ) {
	if ( $derin > 7 ) {
		return null;
	}
	if ( is_array( $v ) ) {
		$o = array();
		$n = 0;
		foreach ( $v as $k => $x ) {
			if ( ++$n > 800 ) {
				break;
			}
			if ( ! is_int( $k ) ) {
				$k = substr( preg_replace( '/[^A-Za-z0-9_\-|]/', '', (string) $k ), 0, 64 );
				if ( '' === $k ) {
					continue;
				}
			}
			$o[ $k ] = sides_dd_temiz( $x, $derin + 1 );
		}
		return $o;
	}
	if ( is_bool( $v ) || is_null( $v ) || is_int( $v ) || is_float( $v ) ) {
		return $v;
	}
	$s = preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', wp_check_invalid_utf8( (string) $v ) );
	return mb_substr( (string) $s, 0, 2000 );
}
function sides_dd_nesne( $a ) {
	return is_array( $a ) && ! empty( $a ) ? $a : new stdClass();
}
function sides_takip_yapi( WP_REST_Request $req ) {
	$org  = sides_org_id();
	$p    = $req->get_json_params();
	$coll = isset( $p['coll'] ) ? (string) $p['coll'] : '';
	$id   = isset( $p['id'] ) ? (string) $p['id'] : '';
	$al   = isset( $p['alanlar'] ) && is_array( $p['alanlar'] ) ? $p['alanlar'] : array();
	if ( ! in_array( $coll, array( 'seviye', 'dgrup' ), true ) || ! preg_match( '/^[A-Za-z0-9_\-]{1,64}$/', $id ) || strlen( (string) $req->get_body() ) > 262144 ) {
		return new WP_Error( 'sides_gecersiz', 'Geçersiz kayıt.', array( 'status' => 400 ) );
	}
	$izinli = array(
		'seviye' => array( 'ad', 'sira', 'mufredat', 'cizelge', 'tur', 'donem', 'aciklama', 'kaynak', 'yapiYetki' ),
		'dgrup'  => array( 'ad', 'seviye', 'mesul', 'cizelge', 'sablonId', 'sablonSurum' ),
	);
	foreach ( array_keys( $al ) as $k ) {
		if ( ! in_array( $k, $izinli[ $coll ], true ) ) {
			return new WP_Error( 'sides_gecersiz', 'Bu alan değiştirilemez: ' . sanitize_key( $k ), array( 'status' => 400 ) );
		}
	}
	$yapi_mi = array_key_exists( 'cizelge', $al ) || ! empty( $p['sil'] ) || isset( $al['tur'] ) || isset( $al['yapiYetki'] );
	if ( isset( $al['yapiYetki'] ) && '_ayar' !== $id ) {
		return new WP_Error( 'sides_gecersiz', 'Geçersiz ayar.', array( 'status' => 400 ) );
	}
	if ( '_ayar' === $id ) {
		$c = sides_ctx();
		if ( 'seviye' !== $coll || 'yonetici' !== $c['rol'] && ! ( function_exists( 'sides_is_super' ) && sides_is_super() ) ) {
			return sides_deny( 'Çizelge düzenleme yetkisini yalnızca yönetici değiştirebilir.' );
		}
	}
	$kilit = sides_takip_kilit( $org . '|' . $coll . '|' . $id );
	if ( false === $kilit ) {
		return sides_kilit_mesgul();   // T06: kilit alınamadı, hiçbir şey yazılmadı
	}
	$d     = sides_get_doc( $org, $coll, $id );
	$sonuc = sides_takip_yapi_uygula( $org, $coll, $id, $d, $al, $p, $yapi_mi );
	sides_takip_kilit_birak( $kilit );
	return $sonuc;
}
function sides_takip_yapi_uygula( $org, $coll, $id, $d, $al, $p, $yapi_mi ) {
	if ( $d && 'seviye' === $coll && isset( $d['tur'] ) && 'sablon' === $d['tur'] ) {
		$yapi_mi = true;   // şablonlar yapı sayılır
	}
	if ( $yapi_mi && ! sides_takip_yapi_yetkisi( $org ) ) {
		return sides_deny( 'Çizelge yapısını düzenleme yetkiniz yok. Hücre değerlendirmesi yapabilirsiniz; yapı değişikliği için yöneticinize başvurun.' );
	}
	$simdiki = $d && isset( $d['surum'] ) ? (int) $d['surum'] : 0;
	$yapi_d  = array_key_exists( 'cizelge', $al ) || ! empty( $p['sil'] ) || ( $d && isset( $d['tur'] ) && 'sablon' === $d['tur'] );
	if ( $yapi_d ) {
		if ( ! isset( $p['surum'] ) || ! is_numeric( $p['surum'] ) ) {
			return new WP_Error( 'sides_gecersiz', 'Sürüm bilgisi eksik.', array( 'status' => 400 ) );
		}
		if ( (int) $p['surum'] !== $simdiki ) {
			return new WP_Error( 'sides_cakisma', 'Çakışma: bu çizelge siz düzenlerken başka bir kullanıcı tarafından değiştirildi (şu anki sürüm ' . $simdiki . '). Değişikliğiniz kaydedilmedi; güncel hâli yükleyip yeniden deneyin.', array( 'status' => 409, 'surum' => $simdiki ) );
		}
	}
	if ( ! empty( $p['sil'] ) ) {
		if ( ! $d || 'seviye' !== $coll || ! isset( $d['tur'] ) || 'sablon' !== $d['tur'] ) {
			return new WP_Error( 'sides_gecersiz', 'Yalnızca şablonlar buradan silinir.', array( 'status' => 400 ) );
		}
		global $wpdb;
		$wpdb->delete( sides_docs(), array( 'org' => $org, 'coll' => 'seviye', 'id' => $id ) );
		sides_log( $org, 'Dahili ders şablonu silindi: ' . mb_substr( (string) ( isset( $d['ad'] ) ? $d['ad'] : $id ), 0, 80 ) );
		return array( 'ok' => true, 'silindi' => $id );
	}
	$yeni = ! $d;
	if ( $yeni ) {
		$d = 'dgrup' === $coll ? array( 'ogrenciler' => array(), 'isaret' => new stdClass(), 'serbest' => new stdClass() ) : array();
		if ( 'dgrup' === $coll && empty( $al['seviye'] ) ) {
			return new WP_Error( 'sides_gecersiz', 'Grubun seviyesi seçilmeli.', array( 'status' => 400 ) );
		}
	}
	unset( $d['id'], $d['token'] );
	foreach ( $al as $k => $v ) {
		switch ( $k ) {
			case 'ad':
			case 'mesul':
			case 'donem':
				$v = mb_substr( sanitize_text_field( (string) $v ), 0, 'donem' === $k ? 40 : 80 );
				if ( 'ad' === $k && '' === $v ) {
					return new WP_Error( 'sides_gecersiz', 'Ad boş olamaz.', array( 'status' => 400 ) );
				}
				break;
			case 'aciklama':
				$v = mb_substr( sanitize_textarea_field( (string) $v ), 0, 300 );
				break;
			case 'sira':
			case 'sablonSurum':
				$v = max( 0, min( 9999, (int) $v ) );
				break;
			case 'seviye':
			case 'sablonId':
			case 'kaynak':
				$v = (string) $v;
				if ( '' !== $v && ! preg_match( '/^[A-Za-z0-9_\-:]{1,80}$/', $v ) ) {
					return new WP_Error( 'sides_gecersiz', 'Geçersiz kimlik.', array( 'status' => 400 ) );
				}
				break;
			case 'tur':
				$v = 'sablon' === $v ? 'sablon' : '';
				break;
			case 'yapiYetki':
				$v = 'yazar' === $v ? 'yazar' : 'yonetici';
				break;
			case 'mufredat':
				$v = sides_dd_nesne( sides_dd_temiz( is_array( $v ) ? $v : array() ) );
				break;
			case 'cizelge':
				if ( null === $v && 'dgrup' === $coll ) {
					break;   // grubun kendi çizelgesi kaldırılır, seviye çizelgesine döner
				}
				if ( ! is_array( $v ) || count( $v ) > 60 ) {
					return new WP_Error( 'sides_gecersiz', 'Çizelge en fazla 60 bölüm olabilir.', array( 'status' => 400 ) );
				}
				$v = array_values( sides_dd_temiz( $v ) );
				foreach ( $v as $b ) {
					if ( ! is_array( $b ) || empty( $b['i'] ) || ! preg_match( '/^[A-Za-z0-9_\-]{1,40}$/', (string) $b['i'] ) || ( isset( $b['ogeler'] ) && count( (array) $b['ogeler'] ) > 500 ) || ( isset( $b['sutunlar'] ) && count( (array) $b['sutunlar'] ) > 60 ) ) {
						return new WP_Error( 'sides_gecersiz', 'Çizelge bölümü geçersiz (kimlik, en fazla 500 konu ve 60 sütun).', array( 'status' => 400 ) );
					}
					foreach ( array_merge( isset( $b['ogeler'] ) ? (array) $b['ogeler'] : array(), isset( $b['sutunlar'] ) ? (array) $b['sutunlar'] : array() ) as $o ) {
						if ( ! is_array( $o ) || empty( $o['i'] ) || ! preg_match( '/^[A-Za-z0-9_\-]{1,40}$/', (string) $o['i'] ) ) {
							return new WP_Error( 'sides_gecersiz', 'Konu ya da sütun kimliği geçersiz.', array( 'status' => 400 ) );
						}
					}
				}
				break;
		}
		if ( 'cizelge' === $k && null === $v ) {
			unset( $d['cizelge'] );
			continue;
		}
		if ( '' === $v && in_array( $k, array( 'tur', 'sablonId' ), true ) ) {
			unset( $d[ $k ] );
			continue;
		}
		$d[ $k ] = $v;
	}
	if ( 'dgrup' === $coll ) {
		$izin = sides_takip_izin( $org );
		$L    = array_map( 'strval', isset( $d['ogrenciler'] ) ? (array) $d['ogrenciler'] : array() );
		foreach ( array( 'ogrEkle', 'ogrCikar' ) as $n ) {
			$x = isset( $p[ $n ] ) && is_array( $p[ $n ] ) ? $p[ $n ] : array();
			if ( count( $x ) > 400 ) {
				return new WP_Error( 'sides_gecersiz', 'Çok fazla öğrenci.', array( 'status' => 400 ) );
			}
			foreach ( $x as $s ) {
				$s = (string) $s;
				if ( ! preg_match( '/^[A-Za-z0-9_\-]{1,64}$/', $s ) || ( null !== $izin && ! isset( $izin[ $s ] ) ) ) {
					return sides_deny( 'Bu öğrenci, yetkili olduğunuz sınıfların dışında.' );
				}
				$L = 'ogrEkle' === $n ? array_merge( $L, array( $s ) ) : array_diff( $L, array( $s ) );
			}
		}
		$d['ogrenciler'] = array_values( array_unique( $L ) );
		foreach ( array( 'isaret', 'serbest' ) as $a ) {
			$d[ $a ] = sides_dd_nesne( isset( $d[ $a ] ) ? (array) $d[ $a ] : array() );
		}
	}
	if ( isset( $d['mufredat'] ) ) {
		$d['mufredat'] = sides_dd_nesne( (array) $d['mufredat'] );
	}
	if ( $yapi_d ) {
		$d['surum'] = $simdiki + 1;
		$g          = isset( $d['surumGecmis'] ) && is_array( $d['surumGecmis'] ) ? $d['surumGecmis'] : array();
		$gp         = isset( $p['gecmis'] ) && is_array( $p['gecmis'] ) ? $p['gecmis'] : array();
		$u          = wp_get_current_user();
		$g[]        = array(
			's'     => $d['surum'],
			't'     => gmdate( 'c' ),
			'k'     => $u && $u->ID ? mb_substr( $u->display_name, 0, 60 ) : '',
			'not'   => mb_substr( sanitize_text_field( isset( $gp['not'] ) ? (string) $gp['not'] : '' ), 0, 200 ),
			'payda' => sides_dd_nesne( sides_dd_temiz( isset( $gp['payda'] ) && is_array( $gp['payda'] ) ? $gp['payda'] : array() ) ),
		);
		$d['surumGecmis'] = array_slice( $g, -40 );
	}
	if ( false === sides_put_doc( $org, $coll, $id, $d ) ) {
		return new WP_Error( 'sides_db', 'Kaydedilemedi.', array( 'status' => 500 ) );
	}
	if ( $yapi_d ) {
		$tur = 'dgrup' === $coll ? 'grup çizelgesi' : ( isset( $d['tur'] ) && 'sablon' === $d['tur'] ? 'şablon' : 'seviye çizelgesi' );
		sides_log( $org, 'Dahili ders ' . $tur . ' ' . ( $yeni ? 'oluşturuldu' : 'güncellendi' ) . ': ' . mb_substr( (string) ( isset( $d['ad'] ) ? $d['ad'] : $id ), 0, 80 ) . ' (sürüm ' . $d['surum'] . ')' );
	}
	$out = sides_get_doc( $org, $coll, $id );
	if ( 'dgrup' === $coll && is_array( $out ) ) {
		$izin = sides_takip_izin( $org );
		if ( null !== $izin ) {
			foreach ( array( 'isaret', 'serbest' ) as $a ) {
				$out[ $a ] = sides_takip_suz_harita( isset( $out[ $a ] ) ? $out[ $a ] : array(), $izin, true );
			}
			$out['ogrenciler'] = array_values( array_filter( (array) $out['ogrenciler'], function ( $s ) use ( $izin ) {
				return isset( $izin[ (string) $s ] );
			} ) );
		}
	}
	return $out;
}

/* v5.5: Kitap bilgisi düzenleme (ad, toplam sayfa, başlangıç) ve ayrı, onaylı öğrenci değişikliği.
   Günlük okumalar (okuma) hiç gönderilmez ve sunucudaki hâli korunur; kayıt kimliği değişmez. */
function sides_takip_kitap_duzen( WP_REST_Request $req ) {
	$org = sides_org_id();
	$id  = (string) $req['id'];
	$p   = $req->get_json_params();
	$p   = is_array( $p ) ? $p : array();
	$kilit = sides_takip_kilit( $org . '|kitap|' . $id );
	if ( false === $kilit ) {
		return sides_kilit_mesgul();   // T06: kilit alınamadı, hiçbir şey yazılmadı
	}
	$sonuc = sides_takip_kitap_duzen_uygula( $org, $id, $p );
	sides_takip_kilit_birak( $kilit );
	return $sonuc;
}
function sides_takip_kitap_duzen_uygula( $org, $id, $p ) {
	$hata = function ( $m ) {
		return new WP_Error( 'sides_gecersiz', $m, array( 'status' => 400 ) );
	};
	$d = sides_get_doc( $org, 'kitap', $id );
	if ( ! $d ) {
		return new WP_Error( 'sides_yok', 'Kitap bulunamadı; sayfayı yenileyin.', array( 'status' => 404 ) );
	}
	unset( $d['id'], $d['token'] );
	$izin = sides_takip_izin( $org );
	$eski = isset( $d['studentId'] ) ? (string) $d['studentId'] : '';
	if ( null !== $izin && ( '' === $eski || ! isset( $izin[ $eski ] ) ) ) {
		return sides_deny( 'Bu öğrenci, yetkili olduğunuz sınıfların dışında.' );
	}
	$okuma  = isset( $d['okuma'] ) && is_array( $d['okuma'] ) ? $d['okuma'] : array();
	$gunler = array_keys( $okuma );
	sort( $gunler );
	$toplam_okunan = 0;
	foreach ( $okuma as $v ) {
		$toplam_okunan += (int) $v;
	}
	$bugun = ( new DateTime( 'now', new DateTimeZone( 'Europe/Istanbul' ) ) )->format( 'Y-m-d' );
	$islem = isset( $p['islem'] ) ? (string) $p['islem'] : 'bilgi';
	if ( 'ogrenci' === $islem ) {
		$yeni = isset( $p['studentId'] ) ? (string) $p['studentId'] : '';
		if ( ! preg_match( '/^[A-Za-z0-9_\-]{1,64}$/', $yeni ) || empty( $p['onay'] ) || ! isset( $p['eskiStudentId'] ) || (string) $p['eskiStudentId'] !== $eski ) {
			return $hata( 'Öğrenci değişikliği onaylanmadı ya da kitap bu arada başka bir öğrenciye geçti; sayfayı yenileyin.' );
		}
		if ( $yeni === $eski ) {
			return $hata( 'Kitap zaten bu öğrencide.' );
		}
		if ( ! sides_get_doc( $org, 'students', $yeni ) ) {
			return $hata( 'Seçilen öğrenci bulunamadı.' );
		}
		if ( null !== $izin && ! isset( $izin[ $yeni ] ) ) {
			return sides_deny( 'Seçilen öğrenci, yetkili olduğunuz sınıfların dışında.' );
		}
		$d['studentId'] = $yeni;
		$d['ogrDegisim'] = array_slice( array_merge( isset( $d['ogrDegisim'] ) && is_array( $d['ogrDegisim'] ) ? $d['ogrDegisim'] : array(), array( array( 'eski' => $eski, 'yeni' => $yeni, 'zaman' => time(), 'kim' => get_current_user_id() ) ) ), -10 );
	} else {
		$ad = isset( $p['kitap'] ) ? trim( sanitize_text_field( (string) $p['kitap'] ) ) : '';
		if ( '' === $ad || mb_strlen( $ad ) > 120 ) {
			return $hata( 'Kitap adı 1–120 karakter olmalı.' );
		}
		$top = isset( $p['toplam'] ) ? $p['toplam'] : null;
		if ( null !== $top && '' !== $top ) {
			if ( ! is_numeric( $top ) || (int) $top != $top || (int) $top < 1 || (int) $top > 3000 ) {
				return $hata( 'Toplam sayfa 1 ile 3000 arasında bir tam sayı olmalı.' );
			}
			$top = (int) $top;
			if ( $top < $toplam_okunan ) {
				return $hata( 'Toplam sayfa (' . $top . '), şimdiye kadar girilen ' . $toplam_okunan . ' sayfadan az olamaz.' );
			}
		} else {
			$top = null;
		}
		$bas = isset( $p['bas'] ) ? (string) $p['bas'] : '';
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $bas ) || ! strtotime( $bas ) ) {
			return $hata( 'Başlangıç tarihi geçersiz.' );
		}
		if ( $bas > $bugun ) {
			return $hata( 'Başlangıç tarihi bugünden sonra olamaz.' );
		}
		if ( $gunler && $bas > $gunler[0] ) {
			return $hata( 'Başlangıç tarihi ilk okuma kaydından (' . $gunler[0] . ') sonra olamaz.' );
		}
		if ( ! empty( $d['bitis'] ) && $bas > (string) $d['bitis'] ) {
			return $hata( 'Başlangıç tarihi bitiş tarihinden sonra olamaz.' );
		}
		$d['kitap']  = $ad;
		$d['toplam'] = $top;
		$d['bas']    = $bas;
	}
	$d['okuma'] = (object) $okuma;
	if ( false === sides_put_doc( $org, 'kitap', $id, $d ) ) {
		return new WP_Error( 'sides_db', 'Kaydedilemedi.', array( 'status' => 500 ) );
	}
	sides_log( $org, 'ogrenci' === $islem ? 'Kitabın öğrencisi değiştirildi: ' . $d['kitap'] : 'Kitap bilgisi düzenlendi: ' . $d['kitap'] );
	$d['id'] = $id;
	return $d;
}

/* =====================================================================
   v5.5.1 Takviye ders ÖĞRETMEN linkleri (koll. 'tklink')
   Bir link bir öğretmene aittir: izin verilen sınıf/şubeler (siniflar: "5" = tüm şubeler, "5/A"),
   dersler (boş = öğretmenin tüm takviye dersleri) ve isteğe bağlı bitiş tarihi taşır.
   Öğretmen sınıf + ders + tarih seçer, sınıfın tüm öğrencilerine tek seferde puan verir.
   Puanlar mevcut 'takviye' belgesine yazılır (ders+tarih+sınıf+şube eşleşir; yoksa
   deterministik kimlikle bir kez oluşturulur → çift tıklama ikinci kayıt üretmez).
   ===================================================================== */
add_action( 'rest_api_init', function () {
	$ns  = 'optik-karne/v1';
	$yaz = function () {
		return sides_can( 'takip', 2 ) ? true : sides_deny( 'Takip modülünde değişiklik yapma yetkiniz yok.' );
	};
	register_rest_route( $ns, '/takip/olink', array(
		array( 'methods' => 'GET', 'callback' => 'sides_tko_liste', 'permission_callback' => $yaz ),
		array( 'methods' => 'POST', 'callback' => 'sides_tko_kaydet', 'permission_callback' => $yaz ),
	) );
	register_rest_route( $ns, '/takip/olink/(?P<id>[A-Za-z0-9_\-]{1,64})', array(
		array( 'methods' => 'DELETE', 'callback' => 'sides_tko_sil', 'permission_callback' => $yaz ),
	) );
	register_rest_route( $ns, '/takip/olink/(?P<id>[A-Za-z0-9_\-]{1,64})/yenile', array(
		array( 'methods' => 'POST', 'callback' => 'sides_tko_yenile', 'permission_callback' => $yaz ),
	) );
} );

function sides_tko_bugun() {
	return ( new DateTime( 'now', new DateTimeZone( 'Europe/Istanbul' ) ) )->format( 'Y-m-d' );
}
function sides_tko_kucuk( $s ) {
	return mb_strtolower( trim( preg_replace( '/\s+/u', ' ', (string) $s ) ), 'UTF-8' );
}
/* Kısıtlı kullanıcı yalnızca kendi sınıflarını linke koyabilir / görebilir */
function sides_tko_sinif_izinli( $s, $kisit ) {
	if ( null === $kisit ) {
		return true;
	}
	$g = explode( '/', $s, 2 )[0];
	return in_array( $s, $kisit, true ) || in_array( $g, $kisit, true );
}
function sides_tko_temiz_liste( $a, $n, $len ) {
	$out = array();
	foreach ( is_array( $a ) ? $a : array() as $x ) {
		$x = mb_substr( trim( sanitize_text_field( (string) $x ) ), 0, $len );
		if ( '' !== $x && ! in_array( $x, $out, true ) ) {
			$out[] = $x;
		}
	}
	return array_slice( $out, 0, $n );
}
function sides_tko_disari( $id, $d, $tok ) {
	return array(
		'id'       => $id,
		'ogretmen' => isset( $d['ogretmen'] ) ? $d['ogretmen'] : '',
		'brans'    => isset( $d['brans'] ) ? $d['brans'] : '',
		'siniflar' => isset( $d['siniflar'] ) ? array_values( (array) $d['siniflar'] ) : array(),
		'dersler'  => isset( $d['dersler'] ) ? array_values( (array) $d['dersler'] ) : array(),
		'bitis'    => isset( $d['bitis'] ) ? $d['bitis'] : '',
		'olustu'   => isset( $d['olustu'] ) ? $d['olustu'] : '',
		'son'      => isset( $d['son'] ) ? $d['son'] : null,
		'token'    => $tok ? $tok : null,
	);
}
function sides_tko_liste( WP_REST_Request $req ) {
	global $wpdb;
	$org   = sides_org_id();
	$kisit = sides_sinif_kisit();
	$t     = sides_docs();
	$out   = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, token, data FROM $t WHERE org = %d AND coll = 'tklink' ORDER BY id", $org ) ) as $r ) { // phpcs:ignore
		$d = json_decode( $r->data, true );
		if ( ! is_array( $d ) ) {
			continue;
		}
		$ok = true;
		foreach ( isset( $d['siniflar'] ) ? (array) $d['siniflar'] : array() as $s ) {
			$ok = $ok && sides_tko_sinif_izinli( (string) $s, $kisit );
		}
		if ( $ok ) {
			$out[] = sides_tko_disari( $r->id, $d, $r->token );
		}
	}
	$res = rest_ensure_response( $out );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}
function sides_tko_kaydet( WP_REST_Request $req ) {
	global $wpdb;
	$org   = sides_org_id();
	$p     = $req->get_json_params();
	$kisit = sides_sinif_kisit();
	$id    = isset( $p['id'] ) ? (string) $p['id'] : '';
	$ogr   = mb_substr( trim( sanitize_text_field( isset( $p['ogretmen'] ) ? (string) $p['ogretmen'] : '' ) ), 0, 80 );
	$brans = mb_substr( trim( sanitize_text_field( isset( $p['brans'] ) ? (string) $p['brans'] : '' ) ), 0, 80 );
	$bitis = isset( $p['bitis'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $p['bitis'] ) ? (string) $p['bitis'] : '';
	$sin   = array();
	foreach ( isset( $p['siniflar'] ) && is_array( $p['siniflar'] ) ? $p['siniflar'] : array() as $s ) {
		$n = sides_sinif_norm( (string) $s );
		if ( '' !== $n && ! in_array( $n, $sin, true ) ) {
			$sin[] = $n;
		}
	}
	$sin = array_slice( $sin, 0, 40 );
	$der = sides_tko_temiz_liste( isset( $p['dersler'] ) ? $p['dersler'] : array(), 30, 80 );
	if ( '' === $ogr ) {
		return new WP_Error( 'sides_gecersiz', 'Öğretmen adını yazın.', array( 'status' => 400 ) );
	}
	if ( ! $sin ) {
		return new WP_Error( 'sides_gecersiz', 'En az bir sınıf ya da şube seçin.', array( 'status' => 400 ) );
	}
	if ( ! $der && '' === $brans ) {
		// Öğretmenin hiç takviye dersi yoksa ders adı zorunlu (yeni ders bu adla açılır)
		$var = false;
		foreach ( (array) $wpdb->get_col( $wpdb->prepare( 'SELECT data FROM ' . sides_docs() . " WHERE org = %d AND coll = 'takviye'", $org ) ) as $j ) { // phpcs:ignore
			$x   = json_decode( $j, true );
			$var = $var || ( is_array( $x ) && ! empty( $x['ders'] ) && sides_tko_kucuk( isset( $x['ogretmen'] ) ? $x['ogretmen'] : '' ) === sides_tko_kucuk( $ogr ) );
		}
		if ( ! $var ) {
			return new WP_Error( 'sides_gecersiz', 'Bu öğretmenin henüz takviye dersi yok; ders / branş adını yazın ya da ders seçin.', array( 'status' => 400 ) );
		}
	}
	foreach ( $sin as $s ) {
		if ( ! sides_tko_sinif_izinli( $s, $kisit ) ) {
			return sides_deny( 'Yetkili olduğunuz sınıfların dışında bir sınıf seçtiniz: ' . $s );
		}
	}
	$eski = null;
	$tok  = '';
	if ( '' !== $id ) {
		if ( ! preg_match( '/^[A-Za-z0-9_\-]{1,64}$/', $id ) || ! ( $eski = sides_get_doc( $org, 'tklink', $id ) ) ) {
			return new WP_Error( 'sides_yok', 'Link bulunamadı.', array( 'status' => 404 ) );
		}
		foreach ( (array) $eski['siniflar'] as $s ) {
			if ( ! sides_tko_sinif_izinli( (string) $s, $kisit ) ) {
				return sides_deny( 'Bu link yetkili olduğunuz sınıfların dışında.' );
			}
		}
		$tok = (string) $wpdb->get_var( $wpdb->prepare( 'SELECT token FROM ' . sides_docs() . " WHERE org = %d AND coll = 'tklink' AND id = %s", $org, $id ) ); // phpcs:ignore
	} else {
		$id = 'tko' . bin2hex( random_bytes( 6 ) );
	}
	$d = array(
		'ogretmen' => $ogr,
		'brans'    => $brans,
		'siniflar' => $sin,
		'dersler'  => $der,
		'bitis'    => $bitis,
		'olustu'   => $eski && ! empty( $eski['olustu'] ) ? $eski['olustu'] : sides_tko_bugun(),
		'son'      => $eski && isset( $eski['son'] ) ? $eski['son'] : null,
	);
	if ( false === sides_put_doc( $org, 'tklink', $id, $d ) ) {
		return new WP_Error( 'sides_db', 'Kaydedilemedi.', array( 'status' => 500 ) );
	}
	if ( ! $tok ) {
		$tok = bin2hex( random_bytes( 16 ) );
		$wpdb->update( sides_docs(), array( 'token' => $tok ), array( 'org' => $org, 'coll' => 'tklink', 'id' => $id ) );
	}
	sides_log( $org, 'Takviye öğretmen linki ' . ( $eski ? 'güncellendi' : 'oluşturuldu' ) . ': ' . $ogr );
	return sides_tko_disari( $id, $d, $tok );
}
function sides_tko_sahip( $org, $id ) {
	$d = sides_get_doc( $org, 'tklink', $id );
	if ( ! $d ) {
		return new WP_Error( 'sides_yok', 'Link bulunamadı.', array( 'status' => 404 ) );
	}
	$kisit = sides_sinif_kisit();
	foreach ( isset( $d['siniflar'] ) ? (array) $d['siniflar'] : array() as $s ) {
		if ( ! sides_tko_sinif_izinli( (string) $s, $kisit ) ) {
			return sides_deny( 'Bu link yetkili olduğunuz sınıfların dışında.' );
		}
	}
	return $d;
}
function sides_tko_yenile( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$d   = sides_tko_sahip( $org, (string) $req['id'] );
	if ( is_wp_error( $d ) ) {
		return $d;
	}
	$tok = bin2hex( random_bytes( 16 ) );
	$wpdb->update( sides_docs(), array( 'token' => $tok ), array( 'org' => $org, 'coll' => 'tklink', 'id' => (string) $req['id'] ) );
	sides_log( $org, 'Takviye öğretmen linki yenilendi: ' . $d['ogretmen'] );
	return sides_tko_disari( (string) $req['id'], $d, $tok );
}
function sides_tko_sil( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$d   = sides_tko_sahip( $org, (string) $req['id'] );
	if ( is_wp_error( $d ) ) {
		return $d;
	}
	$wpdb->delete( sides_docs(), array( 'org' => $org, 'coll' => 'tklink', 'id' => (string) $req['id'] ) );
	sides_log( $org, 'Takviye öğretmen linki kapatıldı: ' . $d['ogretmen'] );
	return array( 'ok' => true );
}

/* ---- Herkese açık öğretmen sayfası ---- */
function sides_tko_bul( $token ) {
	global $wpdb;
	$t = sides_docs();
	$r = $wpdb->get_row( $wpdb->prepare( "SELECT org, id, data FROM $t WHERE coll = 'tklink' AND token = %s", $token ) ); // phpcs:ignore
	if ( ! $r || in_array( 'takip', sides_kapali_moduller( (int) $r->org ), true ) ) {
		return null;
	}
	$o = sides_org( (int) $r->org );
	if ( ! $o || sides_org_blok( $o ) ) {
		return null;
	}
	$d = json_decode( $r->data, true );
	if ( ! is_array( $d ) ) {
		return null;
	}
	if ( ! empty( $d['bitis'] ) && $d['bitis'] < sides_tko_bugun() ) {
		return 'sure';
	}
	return array( 'org' => (int) $r->org, 'id' => $r->id, 'd' => $d );
}
/* Kurumun öğrencileri (yalnızca linkin sınıflarındakiler): [ 'g|B' => [ id => öğrenci ] ] */
function sides_tko_sinif_ogr( $org, $siniflar ) {
	global $wpdb;
	$out = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( 'SELECT id, data FROM ' . sides_docs() . " WHERE org = %d AND coll = 'students'", $org ) ) as $r ) { // phpcs:ignore
		$s = json_decode( $r->data, true );
		if ( ! is_array( $s ) || ! empty( $s['pasif'] ) ) {
			continue;
		}
		$g = trim( preg_replace( '/\s+/u', ' ', isset( $s['sinif'] ) ? (string) $s['sinif'] : '' ) );
		$b = mb_strtoupper( trim( isset( $s['sube'] ) ? (string) $s['sube'] : '' ), 'UTF-8' );
		if ( '' === $g || ! ( in_array( $g, $siniflar, true ) || ( '' !== $b && in_array( $g . '/' . $b, $siniflar, true ) ) ) ) {
			continue;
		}
		$out[ $g . '|' . $b ][ (string) $r->id ] = array( 'id' => (string) $r->id, 'ad' => isset( $s['ad'] ) ? (string) $s['ad'] : '', 'no' => isset( $s['no'] ) ? (string) $s['no'] : '' );
	}
	ksort( $out, SORT_NATURAL );
	return $out;
}
/* Öğretmenin seçebileceği ders adları */
function sides_tko_dersler( $org, $d ) {
	global $wpdb;
	$l = array();
	if ( ! empty( $d['dersler'] ) ) {
		$l = array_values( (array) $d['dersler'] );
	} else {
		$ben = sides_tko_kucuk( isset( $d['ogretmen'] ) ? $d['ogretmen'] : '' );
		foreach ( (array) $wpdb->get_col( $wpdb->prepare( 'SELECT data FROM ' . sides_docs() . " WHERE org = %d AND coll = 'takviye'", $org ) ) as $j ) { // phpcs:ignore
			$x = json_decode( $j, true );
			if ( is_array( $x ) && ! empty( $x['ders'] ) && sides_tko_kucuk( isset( $x['ogretmen'] ) ? $x['ogretmen'] : '' ) === $ben ) {
				$l[] = (string) $x['ders'];
			}
		}
	}
	if ( ! empty( $d['brans'] ) ) {
		array_unshift( $l, (string) $d['brans'] );
	}
	$out = array();
	foreach ( $l as $x ) {
		$k = sides_tko_kucuk( $x );
		if ( '' !== $k && ! isset( $out[ $k ] ) ) {
			$out[ $k ] = $x;
		}
	}
	return array_values( $out );
}
/* Ders + tarih + sınıf + şube için mevcut takviye belgesi (öğretmeni boş ya da aynı olan) */
function sides_tko_takviye_bul( $org, $ogretmen, $ders, $tarih, $g, $b ) {
	global $wpdb;
	$t = sides_docs();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = 'takviye' ORDER BY id", $org ) ) as $r ) { // phpcs:ignore
		$x = json_decode( $r->data, true );
		if ( ! is_array( $x ) || ( isset( $x['tarih'] ) ? (string) $x['tarih'] : '' ) !== $tarih || sides_tko_kucuk( isset( $x['ders'] ) ? $x['ders'] : '' ) !== sides_tko_kucuk( $ders ) ) {
			continue;
		}
		if ( trim( (string) ( isset( $x['sinif'] ) ? $x['sinif'] : '' ) ) !== $g || mb_strtoupper( trim( (string) ( isset( $x['sube'] ) ? $x['sube'] : '' ) ), 'UTF-8' ) !== $b ) {
			continue;
		}
		$o = sides_tko_kucuk( isset( $x['ogretmen'] ) ? $x['ogretmen'] : '' );
		if ( '' === $o || sides_tko_kucuk( $ogretmen ) === $o ) {
			return array( 'id' => $r->id, 'd' => $x );
		}
	}
	return null;
}
/* İstek parametrelerini doğrular: [ ders, tarih, g, b, öğrenciler(id=>ö) ] ya da WP_Error */
function sides_tko_secim( $x, $p ) {
	$d     = $x['d'];
	$sin   = isset( $d['siniflar'] ) ? array_map( 'strval', (array) $d['siniflar'] ) : array();
	$g     = trim( isset( $p['sinif'] ) ? (string) $p['sinif'] : '' );
	$b     = mb_strtoupper( trim( isset( $p['sube'] ) ? (string) $p['sube'] : '' ), 'UTF-8' );
	$tarih = isset( $p['tarih'] ) ? (string) $p['tarih'] : '';
	$ders  = isset( $p['ders'] ) ? (string) $p['ders'] : '';
	$bugun = sides_tko_bugun();
	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $tarih ) || $tarih > $bugun || $tarih < gmdate( 'Y-m-d', strtotime( $bugun . ' -120 days' ) ) ) {
		return new WP_Error( 'sides_gecersiz', 'Tarih bugün ya da son 120 gün içinde olmalı.', array( 'status' => 400 ) );
	}
	$dl = sides_tko_dersler( $x['org'], $d );
	$dk = array_search( sides_tko_kucuk( $ders ), array_map( 'sides_tko_kucuk', $dl ), true );
	if ( false === $dk ) {
		return new WP_Error( 'sides_yetki', 'Bu ders bu linkin kapsamında değil.', array( 'status' => 403 ) );
	}
	if ( ! in_array( $g, $sin, true ) && ! in_array( $g . '/' . $b, $sin, true ) ) {
		return new WP_Error( 'sides_yetki', 'Bu sınıf bu linkin kapsamında değil.', array( 'status' => 403 ) );
	}
	$all = sides_tko_sinif_ogr( $x['org'], $sin );
	$ogr = isset( $all[ $g . '|' . $b ] ) ? $all[ $g . '|' . $b ] : array();
	return array( $dl[ $dk ], $tarih, $g, $b, $ogr );
}
/* Takviye belgesine göre öğrenci listesi: belge varsa yöneticinin listesi (sınıfta olanlar), yoksa sınıfın tamamı */
function sides_tko_kapsam( $ogr, $tv ) {
	if ( ! $tv ) {
		return $ogr;
	}
	$out = array();
	foreach ( isset( $tv['d']['ogrenciler'] ) ? (array) $tv['d']['ogrenciler'] : array() as $sid ) {
		if ( isset( $ogr[ (string) $sid ] ) ) {
			$out[ (string) $sid ] = $ogr[ (string) $sid ];
		}
	}
	return $out;
}
function sides_tko_yanit( $kap, $tv ) {
	$p = array();
	$m = $tv && isset( $tv['d']['puan'] ) ? (array) $tv['d']['puan'] : array();
	foreach ( $kap as $sid => $s ) {
		if ( isset( $m[ $sid ] ) ) {
			$p[ $sid ] = (int) $m[ $sid ];
		}
	}
	$l = array_values( $kap );
	usort( $l, function ( $a, $b ) {
		return ( (int) $a['no'] <=> (int) $b['no'] ) ?: strcmp( $a['ad'], $b['ad'] );
	} );
	return array( 'ogrenciler' => $l, 'puan' => (object) $p, 'kayitli' => (bool) $tv );
}
function sides_tko_oku( $x, WP_REST_Request $req ) {
	$d   = $x['d'];
	$sin = isset( $d['siniflar'] ) ? array_map( 'strval', (array) $d['siniflar'] ) : array();
	$all = sides_tko_sinif_ogr( $x['org'], $sin );
	$sec = array();
	foreach ( $all as $k => $l ) {
		list( $g, $b ) = explode( '|', $k, 2 );
		$sec[] = array( 'sinif' => $g, 'sube' => $b, 'n' => count( $l ) );
	}
	$set = sides_get_doc( $x['org'], 'settings', 'main' );
	$out = array(
		'mod'      => 'ogretmen',
		'ogretmen' => isset( $d['ogretmen'] ) ? $d['ogretmen'] : '',
		'kurum'    => $set && isset( $set['kurum'] ) ? $set['kurum'] : '',
		'logo'     => $set && isset( $set['logo'] ) ? $set['logo'] : '',
		'dersler'  => sides_tko_dersler( $x['org'], $d ),
		'siniflar' => $sec,
		'bugun'    => sides_tko_bugun(),
		'bitis'    => isset( $d['bitis'] ) ? $d['bitis'] : '',
	);
	if ( '' !== (string) $req['sinif'] ) {
		$s = sides_tko_secim( $x, array( 'sinif' => $req['sinif'], 'sube' => $req['sube'], 'tarih' => $req['tarih'], 'ders' => $req['ders'] ) );
		if ( is_wp_error( $s ) ) {
			return $s;
		}
		list( $ders, $tarih, $g, $b, $ogr ) = $s;
		$tv  = sides_tko_takviye_bul( $x['org'], $out['ogretmen'], $ders, $tarih, $g, $b );
		$out = array_merge( $out, sides_tko_yanit( sides_tko_kapsam( $ogr, $tv ), $tv ) );
	}
	return $out;
}
function sides_tko_yaz( $x, WP_REST_Request $req ) {
	$p = $req->get_json_params();
	$s = sides_tko_secim( $x, is_array( $p ) ? $p : array() );
	if ( is_wp_error( $s ) ) {
		return $s;
	}
	list( $ders, $tarih, $g, $b, $ogr ) = $s;
	$gel = isset( $p['puan'] ) && is_array( $p['puan'] ) ? $p['puan'] : array();
	if ( count( $gel ) > 400 ) {
		return new WP_Error( 'sides_gecersiz', 'Çok fazla öğrenci.', array( 'status' => 400 ) );
	}
	foreach ( $gel as $sid => $v ) {
		if ( null !== $v && '' !== $v && ! ( is_numeric( $v ) && (int) $v == $v && (int) $v >= 1 && (int) $v <= 10 ) ) { // phpcs:ignore
			return new WP_Error( 'sides_gecersiz', 'Puanlar 1 ile 10 arasında tam sayı olmalı.', array( 'status' => 400 ) );
		}
	}
	$ogretmen = isset( $x['d']['ogretmen'] ) ? (string) $x['d']['ogretmen'] : '';
	$anahtar  = md5( $x['org'] . '|' . sides_tko_kucuk( $ders ) . '|' . $tarih . '|' . $g . '|' . $b . '|' . sides_tko_kucuk( $ogretmen ) );
	$k1       = sides_tko_kilit( $x['org'] . '|tko|' . $anahtar );
	$tv       = sides_tko_takviye_bul( $x['org'], $ogretmen, $ders, $tarih, $g, $b );
	$k2       = $tv ? sides_takip_kilit( $x['org'] . '|takviye|' . $tv['id'] ) : '';
	if ( $tv ) {
		$tv = array( 'id' => $tv['id'], 'd' => sides_get_doc( $x['org'], 'takviye', $tv['id'] ) );   // kilit altında güncel hâli
	}
	$kap = sides_tko_kapsam( $ogr, $tv && $tv['d'] ? $tv : null );
	$hata = null;
	foreach ( $gel as $sid => $v ) {
		if ( ! isset( $kap[ (string) $sid ] ) ) {
			$hata = new WP_Error( 'sides_yetki', 'Listede olmayan bir öğrenci gönderildi; sayfayı yenileyin.', array( 'status' => 403 ) );
		}
	}
	$say = 0;
	if ( ! $hata ) {
		$d = $tv && $tv['d'] ? $tv['d'] : array( 'ders' => $ders, 'ogretmen' => $ogretmen, 'tarih' => $tarih, 'sinif' => $g, 'sube' => $b, 'ogrenciler' => array_keys( $ogr ), 'puan' => array(), 'kaynak' => 'ogretmen-linki' );
		$id = $tv ? $tv['id'] : 'tvo' . substr( $anahtar, 0, 20 );
		$m  = isset( $d['puan'] ) && is_array( $d['puan'] ) ? $d['puan'] : array();
		foreach ( $gel as $sid => $v ) {
			if ( null === $v || '' === $v ) {
				unset( $m[ (string) $sid ] );
			} else {
				$m[ (string) $sid ] = (int) $v;
				$say++;
			}
		}
		$d['puan']  = (object) $m;
		$d['giren'] = array( 'ad' => mb_substr( $ogretmen, 0, 80 ), 'yol' => 'link', 't' => time() );   // v7 haftalık rapor: puanı kimin girdiği
		unset( $d['id'], $d['token'] );
		if ( ( $tv || $m ) && false === sides_put_doc( $x['org'], 'takviye', $id, $d ) ) {
			$hata = new WP_Error( 'sides_db', 'Kaydedilemedi.', array( 'status' => 500 ) );
		}
		if ( $tv || $m ) {
			$tv = array( 'id' => $id, 'd' => $d );
			$d['puan'] = $m;
			$tv['d']   = $d;
		}
	}
	sides_takip_kilit_birak( $k2 );
	sides_tko_kilit_birak( $k1 );
	if ( $hata ) {
		return $hata;
	}
	$l = $x['d'];
	$l['son'] = array( 't' => (int) round( microtime( true ) * 1000 ), 'ders' => $ders, 'sinif' => $g . ( $b ? '/' . $b : '' ) );
	sides_put_doc( $x['org'], 'tklink', $x['id'], $l );
	sides_log( $x['org'], 'Takviye puanları öğretmen linkinden girildi: ' . $ders . ' · ' . $g . ( $b ? '/' . $b : '' ) . ' (' . $say . ' öğrenci)', $ogretmen ? $ogretmen : 'Öğretmen linki' );
	return array_merge( array( 'ok' => true, 'kayitId' => $tv ? $tv['id'] : null ), sides_tko_yanit( sides_tko_kapsam( $ogr, $tv ), $tv ) );
}

/* tk/<token>: takviye belgesi linki değilse öğretmen linki olarak dener; yanıt önbelleğe alınmaz */
/* Öğretmen kaydı kilidi: MySQL GET_LOCK; desteklenmiyorsa (ör. SQLite) seçenekler tablosuna benzersiz satır ekleme ile
   (eşzamanlı ikinci istek satır kalkana kadar bekler; 15 sn'den eski kilit bayat sayılır) */
function sides_tko_kilit( $k ) {
	global $wpdb;
	$ad = sides_takip_kilit( $k );
	if ( $ad ) {
		return array( 'm', $ad );
	}
	$n = '_sides_lk_' . md5( $k );
	$e = $wpdb->suppress_errors( true );
	for ( $i = 0; $i < 60; $i++ ) {
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name = %s AND option_value < %s", $n, (string) ( time() - 15 ) ) ); // phpcs:ignore
		if ( $wpdb->query( $wpdb->prepare( "INSERT INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')", $n, (string) time() ) ) ) { // phpcs:ignore
			$wpdb->suppress_errors( $e );
			return array( 'o', $n );
		}
		usleep( 100000 );
	}
	$wpdb->suppress_errors( $e );
	return array( '', '' );
}
function sides_tko_kilit_birak( $l ) {
	global $wpdb;
	if ( 'm' === $l[0] ) {
		sides_takip_kilit_birak( $l[1] );
	} elseif ( 'o' === $l[0] ) {
		$wpdb->delete( $wpdb->options, array( 'option_name' => $l[1] ) );
	}
}
/* Sabit pencereli hız sınırı (her istekte süre uzamaz; pencere dolunca sayaç sıfırlanır) */
function sides_tko_rl( $key, $max, $ttl ) {
	$k = 'sides_tkorl_' . md5( $key );
	$v = get_transient( $k );
	$v = is_array( $v ) && isset( $v['n'], $v['t'] ) && $v['t'] > time() ? $v : array( 'n' => 0, 't' => time() + $ttl );
	if ( $v['n'] >= $max ) {
		return false;
	}
	$v['n']++;
	set_transient( $k, $v, max( 1, $v['t'] - time() ) );
	return true;
}
/* tk/<token> hız sınırı (eski tek ders ve öğretmen linki): IP başına geniş (okulun bütün öğretmenleri aynı ağdan gelebilir), link başına dar */
function sides_tk_hiz( $yaz, $token ) {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$on = $yaz ? 'y|' : 'o|';
	return sides_tko_rl( $on . $ip, $yaz ? 600 : 1500, 600 ) && sides_tko_rl( $on . $token, $yaz ? 120 : 300, 600 );
}
function sides_tko_cevap( $fn, WP_REST_Request $req ) {
	$yaz = 'sides_tko_yaz' === $fn;
	if ( ! sides_tk_hiz( $yaz, (string) $req['token'] ) ) {
		$res = rest_convert_error_to_response( new WP_Error( 'sides_rl', 'Çok fazla istek. Birkaç dakika sonra tekrar deneyin.', array( 'status' => 429 ) ) );
		$res->header( 'Cache-Control', 'no-store' );
		return $res;
	}
	$x = sides_tko_bul( (string) $req['token'] );
	if ( 'sure' === $x ) {
		$r = new WP_Error( 'sides_sure', 'Bu linkin süresi dolmuş. Okul yönetiminden yeni link isteyin.', array( 'status' => 410 ) );
	} elseif ( ! $x ) {
		$r = new WP_Error( 'sides_yok', 'Link geçersiz ya da kaldırılmış.', array( 'status' => 404 ) );
	} else {
		$r = call_user_func( $fn, $x, $req );
	}
	$res = is_wp_error( $r ) ? rest_convert_error_to_response( $r ) : rest_ensure_response( $r );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}

/* ------------------------------------------------------------------ *
 * T11: hücre bazlı değişiklik geçmişi (yoklama, izin dönüşü, kitap, takviye, ders işaretleri)
 * Belge: tkgecmis/<YYYY-MM> { k: [ { t, u, ad, c, i, a, s, e, y } ] } — ay başına en fazla 6000 kayıt; sessiz başlıkla atlanamaz.
 * ------------------------------------------------------------------ */
function sides_tk_gecmis_yaz( $org, $coll, $id, $alan, $once, $sonra ) {
	$deg = array();
	foreach ( array_unique( array_merge( array_keys( (array) $once ), array_keys( (array) $sonra ) ) ) as $k ) {
		$e = isset( $once[ $k ] ) ? $once[ $k ] : null;
		$y = isset( $sonra[ $k ] ) ? $sonra[ $k ] : null;
		if ( $e !== $y ) {
			$deg[] = array( (string) $k, $e, $y );
		}
	}
	if ( ! $deg ) {
		return;
	}
	$u   = wp_get_current_user();
	$ay  = 'g' . gmdate( 'Y-m' );
	$kl  = sides_takip_kilit( $org . '|tkgecmis|' . $ay );
	$doc = sides_get_doc( $org, 'tkgecmis', $ay );
	$L   = is_array( $doc ) && isset( $doc['k'] ) ? (array) $doc['k'] : array();
	foreach ( $deg as $x ) {
		$L[] = array( 't' => time(), 'u' => (int) $u->ID, 'ad' => $u->display_name, 'c' => $coll, 'i' => (string) $id, 'a' => $alan, 's' => $x[0], 'e' => $x[1], 'y' => $x[2] );
	}
	if ( count( $L ) > 6000 ) {
		$L = array_slice( $L, -6000 );
	}
	sides_put_doc( $org, 'tkgecmis', $ay, array( 'k' => $L ) );
	sides_takip_kilit_birak( $kl );
}
/* GET takip/gecmis?coll=&id= → bu ve geçen ayın kayıtlarından ilgili belgeye ait olanlar (yeniden eskiye, en fazla 300); sınıf kapsamına göre süzülür */
function sides_takip_gecmis( WP_REST_Request $req ) {
	$org  = sides_org_id();
	$coll = preg_replace( '/[^a-z]/', '', (string) $req['coll'] );
	$id   = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $req['id'] );
	$izin = sides_takip_izin( $org );
	$mask = sides_is_observer();
	$out  = array();
	foreach ( array( gmdate( 'Y-m' ), gmdate( 'Y-m', strtotime( 'first day of last month' ) ) ) as $ay ) {
		$doc = sides_get_doc( $org, 'tkgecmis', 'g' . $ay );
		foreach ( is_array( $doc ) && isset( $doc['k'] ) ? array_reverse( (array) $doc['k'] ) : array() as $x ) {
			if ( ( $coll && $x['c'] !== $coll ) || ( $id && $x['i'] !== $id ) ) {
				continue;
			}
			$p = explode( '|', (string) $x['s'] );
			if ( null !== $izin && 'kitap' !== $x['c'] && ! isset( $izin[ $p[0] ] ) ) {
				continue;
			}
			if ( $mask ) {
				$x['ad'] = '•••';
			}
			$out[] = $x;
			if ( count( $out ) >= 300 ) {
				break 2;
			}
		}
	}
	return $out;
}
