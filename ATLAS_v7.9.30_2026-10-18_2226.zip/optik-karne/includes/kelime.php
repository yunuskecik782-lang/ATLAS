<?php
/**
 * Günün Kelimeleri (TV panosu, Puan Sistemi modülü): öğrencilerin ekrana bakarken İngilizce kelime ve anlam öğrenmesi.
 *
 * Yerleşik liste: includes/kelime-veri.php (5–8. sınıf ünite temaları + en sık kullanılan kelimeler; özgün). Kurum bunları
 * gizleyebilir, Türkçesini değiştirebilir ve kendi kelimelerini ekleyebilir.
 *
 * Belgeler (coll: kelime):
 *   kelime/yerlesik       { gizli: [yerleşik kimlik…], tr: { kimlik: 'kurumun Türkçesi' } }
 *   kelime/k<id>          kurum kelimesi { en, tr, tur, sinif, konu, ornek, ornekTr, aktif, olusturan: {u, ad}, t }
 * Ayar: tv/ayar belgesinin `kelime` alanı (sides_kelime_ayar_temiz; kayıtta 400, ekrana giderken sınırlanır):
 *   { acik 0|1, siniflar: ['5','6','7','8','genel'] alt kümesi, gunluk 5–30, sure 4–20 sn, anlamGecikme 0–6 sn, ornek 0|1,
 *     gosterim 'karisik'|'blok', aralik 1–10 (karışık: her N duyurudan sonra bir kelime), gecis 'karisik'|<öğretici şablon>, tema, baslik ≤ 40,
 *     ses 0|1 (v7.8: tarayıcının sesiyle telaffuz, panoda varsayılan kapalı), aksan 'en-US'|'en-GB' }
 *   v7.8 şablonları: cevir, harf, eslestir, balon, hafiza, vurgu. Eski geçiş adları (kay, yakin, zipla, bulanik) kayıtta ve okumada
 *   karşılık gelen şablona çevrilir (SIDES_KL_GECIS_ESKI); bilinmeyen değer 400.
 *
 * REST (optik-karne/v1):
 *   GET    kelime/liste                 (puan ≥ 1) yerleşik (gizli işaretli, kurum Türkçesi) + kurum kelimeleri
 *   POST   kelime/oniz                  (puan ≥ 1) { kelime: taslak ayar } → bugünün kelimeleri (kaydetmeden; önizleme)
 *   POST   kelime/ozel                  (puan ≥ 2, gözlemci değil) { islemId, id?, en, tr, tur, sinif, konu, ornek, ornekTr, aktif } ekle / düzenle
 *   DELETE kelime/ozel/<id>             (puan ≥ 2) kurum kelimesini sil
 *   POST   kelime/yerlesik              (puan ≥ 2) { id, gizli?: 0|1, tr?: '' | 'kurumun Türkçesi' } yerleşik kelimeyi gizle / Türkçesini değiştir
 *   POST   kelime/aktar                 (puan ≥ 2) { islemId, satirlar: ['english;türkçe' | 'english - türkçe' | csv satırı…], sinif, konu, onizle } içe aktarma
 * Pano: tv/<token> yanıtına `kelime` yalnızca ayar açıkken eklenir (sides_kelime_pano): bugünün kelimeleri — havuz kararlı
 *   bir karmaya göre sıralanır, gün sayısı × günlük sayı kadar kaydırılır; böylece her gün sıradaki N kelime gelir, havuz bitince başa döner.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SIDES_KL_SINIF', array( '5', '6', '7', '8', 'genel' ) );
define( 'SIDES_KL_TUR', array( 'isim', 'fiil', 'sıfat', 'zarf', 'edat', 'ifade' ) );
define( 'SIDES_KL_GECIS', array( 'karisik', 'secili', 'cevir', 'harf', 'eslestir', 'balon', 'hafiza', 'vurgu', 'bosluk', 'soru', 'resim', 'karistir', 'ritim', 'cumle', 'dogruyanlis', 'sohbet', 'harita', 'ters', 'eksikharf', 'resimsec', 'daktilo', 'tahta', 'tren', 'merdiven', 'hediye', 'sozluk', 'kup', 'ayna', 'tersoru', 'kelimeavi' ) );   // v7.9.26 on yeni şablon · v7.9.14 ters, eksikharf, resimsec   // v7.9.11 secili: işaretli şablonlar karışık · v7.9.12 altı yeni şablon   // v7.9.10 bosluk, soru, resim   // v7.8 öğretici şablonlar (src/kelime.js KL_SABLON)
define( 'SIDES_KL_GECIS_ESKI', array( 'kay' => 'eslestir', 'yakin' => 'balon', 'zipla' => 'vurgu', 'bulanik' => 'harf' ) );
define( 'SIDES_KL_AKSAN', array( 'en-US', 'en-GB' ) );
define( 'SIDES_KL_TEMA', array( 'renkli', 'lacivert', 'pastel' ) );
define( 'SIDES_KL_OZEL_MAX', 2000 );

add_action( 'rest_api_init', function () {
	$ns  = 'optik-karne/v1';
	$oku = function () {
		return sides_can( 'puan', 1 ) ? true : sides_deny( 'Kelime listesi için Puan Sistemi görüntüleme yetkisi gerekir.' );
	};
	$yaz = function () {
		if ( function_exists( 'sides_is_observer' ) && sides_is_observer() ) {
			return sides_deny( 'Gözlemci hesabının işlem yetkisi yok. Yöneticinizden izin isteyin.' );
		}
		return sides_can( 'puan', 2 ) ? true : sides_deny( 'Kelime listesini değiştirmek için Puan Sistemi düzenleme yetkisi gerekir.' );
	};
	register_rest_route( $ns, '/kelime/liste', array( 'methods' => 'GET', 'callback' => 'sides_kelime_liste_oku', 'permission_callback' => $oku ) );
	register_rest_route( $ns, '/kelime/oniz', array( 'methods' => 'POST', 'callback' => 'sides_kelime_oniz', 'permission_callback' => $oku ) );
	register_rest_route( $ns, '/kelime/ozel', array( 'methods' => 'POST', 'callback' => 'sides_kelime_ozel_kaydet', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/kelime/ozel/(?P<id>k[a-f0-9]{8,20})', array( 'methods' => 'DELETE', 'callback' => 'sides_kelime_ozel_sil', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/kelime/yerlesik', array( 'methods' => 'POST', 'callback' => 'sides_kelime_yerlesik_kaydet', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/kelime/aktar', array( 'methods' => 'POST', 'callback' => 'sides_kelime_aktar', 'permission_callback' => $yaz ) );
} );

/* ------------------------------------------------------------------ *
 * Yerleşik liste
 * ------------------------------------------------------------------ */
function sides_kelime_yerlesik() {
	static $L = null;
	if ( null !== $L ) {
		return $L;
	}
	if ( ! function_exists( 'sides_kelime_ham' ) ) {
		require_once __DIR__ . '/kelime-veri.php';
	}
	$tur   = array( 'i' => 'isim', 'f' => 'fiil', 's' => 'sıfat', 'z' => 'zarf', 'e' => 'edat', 'x' => 'ifade' );
	$sinif = 'genel';
	$konu  = '';
	$ids   = array();
	$L     = array();
	foreach ( preg_split( "/\r?\n/", sides_kelime_ham() ) as $s ) {
		$s = trim( $s );
		if ( '' === $s ) {
			continue;
		}
		if ( '## ' === substr( $s, 0, 3 ) ) {
			$p     = array_map( 'trim', explode( '|', substr( $s, 3 ) ) );
			$sinif = in_array( $p[0], SIDES_KL_SINIF, true ) ? $p[0] : 'genel';
			$konu  = isset( $p[1] ) ? $p[1] : '';
			continue;
		}
		if ( '#' === $s[0] ) {
			continue;
		}
		$p = explode( '|', $s );
		if ( count( $p ) < 3 || '' === trim( $p[0] ) || '' === trim( $p[1] ) ) {
			continue;
		}
		$id = $sinif . ':' . trim( preg_replace( '/[^a-z0-9]+/', '_', strtolower( $p[0] ) ), '_' );
		if ( isset( $ids[ $id ] ) ) {
			$n = 2;
			while ( isset( $ids[ $id . '~' . $n ] ) ) {
				$n++;
			}
			$id .= '~' . $n;
		}
		$ids[ $id ] = 1;
		$L[]        = array(
			'id'      => $id,
			'en'      => trim( $p[0] ),
			'tr'      => trim( $p[1] ),
			'tur'     => isset( $tur[ trim( $p[2] ) ] ) ? $tur[ trim( $p[2] ) ] : 'isim',
			'sinif'   => $sinif,
			'konu'    => $konu,
			'ornek'   => isset( $p[3] ) ? trim( $p[3] ) : '',
			'ornekTr' => isset( $p[4] ) ? trim( $p[4] ) : '',
		);
	}
	return $L;
}
function sides_kelime_yerlesik_ayar( $org ) {
	$d = sides_get_doc( (int) $org, 'kelime', 'yerlesik' );
	$g = is_array( $d ) && isset( $d['gizli'] ) && is_array( $d['gizli'] ) ? array_values( array_filter( array_map( 'strval', $d['gizli'] ), 'strlen' ) ) : array();
	$t = is_array( $d ) && isset( $d['tr'] ) && is_array( $d['tr'] ) ? $d['tr'] : array();
	$tr = array();
	foreach ( $t as $k => $v ) {
		if ( is_string( $v ) && '' !== trim( $v ) ) {
			$tr[ (string) $k ] = trim( $v );
		}
	}
	return array( 'gizli' => $g, 'tr' => $tr );
}
/* Kurum kelimeleri (kelime/k…) */
function sides_kelime_ozel_liste( $org ) {
	global $wpdb;
	$t   = sides_docs();
	$out = array();
	$rows = $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = 'kelime' AND id LIKE 'k%%' ORDER BY id", (int) $org ) ); // phpcs:ignore
	foreach ( $rows as $r ) {
		$d = json_decode( $r->data, true );
		if ( ! is_array( $d ) || empty( $d['en'] ) || empty( $d['tr'] ) ) {
			continue;
		}
		$out[] = array(
			'id'        => (string) $r->id,
			'en'        => (string) $d['en'],
			'tr'        => (string) $d['tr'],
			'tur'       => isset( $d['tur'] ) && in_array( $d['tur'], SIDES_KL_TUR, true ) ? $d['tur'] : 'isim',
			'sinif'     => isset( $d['sinif'] ) && in_array( $d['sinif'], SIDES_KL_SINIF, true ) ? $d['sinif'] : 'genel',
			'konu'      => isset( $d['konu'] ) ? (string) $d['konu'] : '',
			'ornek'     => isset( $d['ornek'] ) ? (string) $d['ornek'] : '',
			'ornekTr'   => isset( $d['ornekTr'] ) ? (string) $d['ornekTr'] : '',
			'aktif'     => isset( $d['aktif'] ) && ! $d['aktif'] ? 0 : 1,
			'olusturan' => isset( $d['olusturan'] ) && is_array( $d['olusturan'] ) ? array( 'u' => (int) ( isset( $d['olusturan']['u'] ) ? $d['olusturan']['u'] : 0 ), 'ad' => (string) ( isset( $d['olusturan']['ad'] ) ? $d['olusturan']['ad'] : '' ) ) : null,
			't'         => isset( $d['t'] ) ? (int) $d['t'] : 0,
		);
	}
	return $out;
}

/* ------------------------------------------------------------------ *
 * Ayar
 * ------------------------------------------------------------------ */
function sides_kelime_ayar_vars() {
	return array( 'acik' => 0, 'siniflar' => array( '5', '6', '7', '8', 'genel' ), 'gunluk' => 10, 'sure' => 8, 'anlamGecikme' => 2, 'ornek' => 1, 'gosterim' => 'karisik', 'aralik' => 2, 'gecis' => 'karisik', 'sablonlar' => array( 'cevir', 'harf', 'eslestir' ), 'tema' => 'renkli', 'baslik' => '', 'ses' => 0, 'aksan' => 'en-US', 'kapsam' => 'gunluk', 'tekrar' => 1, 'tekrarSayi' => 2 );
}
function sides_kelime_say( $v, $min, $max, $ad, &$hata ) {
	if ( ! is_int( $v ) && ! is_float( $v ) && ! ( is_string( $v ) && is_numeric( $v ) ) ) {
		$hata[] = $ad . ' sayı olmalı.';
		return null;
	}
	$v = (float) $v;
	if ( $v < $min - 0.0001 || $v > $max + 0.0001 ) {
		$hata[] = $ad . ' ' . $min . '–' . $max . ' aralığında olmalı.';
		$v = max( $min, min( $max, $v ) );
	}
	return (int) round( $v );
}
function sides_kelime_ayar_temiz( $x, &$hata ) {
	$v = sides_kelime_ayar_vars();
	if ( null === $x ) {
		return $v;
	}
	if ( ! is_array( $x ) ) {
		$hata[] = 'Kelimeler ayarı geçersiz.';
		return $v;
	}
	if ( isset( $x['gecis'] ) && is_string( $x['gecis'] ) && isset( SIDES_KL_GECIS_ESKI[ $x['gecis'] ] ) ) {
		$x['gecis'] = SIDES_KL_GECIS_ESKI[ $x['gecis'] ];   // v7.7 ve öncesi geçiş adı
	}
	$o   = $v;
	$bay = function ( $k ) use ( $x, $v, &$hata ) {
		if ( ! array_key_exists( $k, $x ) ) {
			return $v[ $k ];
		}
		if ( in_array( $x[ $k ], array( 0, 1, '0', '1', true, false ), true ) ) {
			return (int) $x[ $k ];
		}
		$hata[] = 'Kelimeler: ' . $k . ' 0 ya da 1 olmalı.';
		return $v[ $k ];
	};
	$sec = function ( $k, $L, $ad ) use ( $x, $v, &$hata ) {
		if ( ! array_key_exists( $k, $x ) ) {
			return $v[ $k ];
		}
		if ( is_string( $x[ $k ] ) && in_array( $x[ $k ], $L, true ) ) {
			return $x[ $k ];
		}
		$hata[] = 'Kelimeler: ' . $ad . ' seçimi geçersiz.';
		return $v[ $k ];
	};
	$say = function ( $k, $min, $max, $ad ) use ( $x, $v, &$hata ) {
		if ( ! array_key_exists( $k, $x ) ) {
			return $v[ $k ];
		}
		$r = sides_kelime_say( $x[ $k ], $min, $max, 'Kelimeler: ' . $ad, $hata );
		return null === $r ? $v[ $k ] : $r;
	};
	$o['acik']         = $bay( 'acik' );
	$o['ornek']        = $bay( 'ornek' );
	$o['ses']          = $bay( 'ses' );
	$o['aksan']        = $sec( 'aksan', SIDES_KL_AKSAN, 'ses (aksan)' );
	$o['gunluk']       = $say( 'gunluk', 5, 100, 'günlük kelime sayısı' );   // v7.9.14: 100'e kadar
	$o['kapsam']       = $sec( 'kapsam', array( 'gunluk', 'tum' ), 'kapsam' );   // v7.9.14 tum: havuzun tamamı her gün (en çok 400)
	$o['tekrar']       = $bay( 'tekrar' );   // v7.9.14 aralıklı tekrar: 1, 3 ve 7 gün önceki kelimelerden birkaçı yeniden
	$o['tekrarSayi']   = $say( 'tekrarSayi', 1, 10, 'tekrar kelime sayısı' );
	$o['sure']         = $say( 'sure', 4, 20, 'kelime süresi' );
	$o['anlamGecikme'] = $say( 'anlamGecikme', 0, 6, 'anlam gecikmesi' );
	$o['aralik']       = $say( 'aralik', 1, 10, 'duyuru aralığı' );
	$o['gosterim']     = $sec( 'gosterim', array( 'karisik', 'blok' ), 'gösterim' );
	$o['gecis']        = $sec( 'gecis', SIDES_KL_GECIS, 'şablon' );
	if ( array_key_exists( 'sablonlar', $x ) ) {   // v7.9.11 seçtiklerim karışık: şablon listesi (karisik / secili dışındaki adlar)
		if ( ! is_array( $x['sablonlar'] ) ) {
			$hata[] = 'Kelimeler: şablon listesi geçersiz.';
		} else {
			$T = array();
			foreach ( $x['sablonlar'] as $s ) {
				$s = (string) $s;
				if ( in_array( $s, SIDES_KL_GECIS, true ) && 'karisik' !== $s && 'secili' !== $s ) {
					$T[ $s ] = 1;
				} else {
					$hata[] = 'Kelimeler: bilinmeyen şablon listede.';
				}
			}
			$o['sablonlar'] = array_values( array_intersect( array_slice( SIDES_KL_GECIS, 2 ), array_keys( $T ) ) );
			if ( ! $o['sablonlar'] ) {
				$o['sablonlar'] = array( 'cevir', 'harf', 'eslestir' );
			}
		}
	}
	$o['tema']         = $sec( 'tema', SIDES_KL_TEMA, 'renk teması' );
	if ( array_key_exists( 'siniflar', $x ) ) {
		if ( ! is_array( $x['siniflar'] ) ) {
			$hata[] = 'Kelimeler: sınıf listesi geçersiz.';
		} else {
			$S = array();
			foreach ( $x['siniflar'] as $s ) {
				$s = (string) $s;
				if ( in_array( $s, SIDES_KL_SINIF, true ) ) {
					$S[ $s ] = 1;
				} else {
					$hata[] = 'Kelimeler: bilinmeyen sınıf.';
				}
			}
			$o['siniflar'] = array_values( array_intersect( SIDES_KL_SINIF, array_keys( $S ) ) );
		}
	}
	if ( array_key_exists( 'baslik', $x ) ) {
		$b = $x['baslik'];
		if ( null === $b || '' === $b ) {
			$o['baslik'] = '';
		} elseif ( ! is_string( $b ) || ! mb_check_encoding( $b, 'UTF-8' ) ) {
			$hata[] = 'Kelimeler: başlık metin olmalı.';
		} else {
			$b = trim( preg_replace( '/[\x00-\x1F\x7F]/u', '', $b ) );
			if ( mb_strlen( $b ) > 40 ) {
				$hata[] = 'Kelimeler: başlık en çok 40 karakter olabilir.';
				$b = rtrim( mb_substr( $b, 0, 40 ) );
			}
			$o['baslik'] = $b;
		}
	}
	return $o;
}
/* tv/ayar kaydında `kelime` alanı denetlenir (includes/tv.php'deki süzgeçten sonra, 11) */
add_filter( 'rest_request_before_callbacks', function ( $res, $handler, $req ) {
	if ( is_wp_error( $res ) || ! in_array( $req->get_method(), array( 'PUT', 'POST' ), true ) || '/optik-karne/v1/doc/tv/ayar' !== (string) $req->get_route() ) {
		return $res;
	}
	if ( ( function_exists( 'sides_is_observer' ) && sides_is_observer() ) || ! sides_can( 'puan', 2 ) ) {
		return $res;
	}
	$d = json_decode( $req->get_body(), true );
	if ( ! is_array( $d ) || ! array_key_exists( 'kelime', $d ) ) {
		return $res;
	}
	$hata        = array();
	$d['kelime'] = sides_kelime_ayar_temiz( $d['kelime'], $hata );
	if ( $hata ) {
		return new WP_Error( 'sides_gecersiz', 'Kelimeler ayarı kaydedilemedi: ' . implode( ' ', array_slice( array_values( array_unique( $hata ) ), 0, 3 ) ), array( 'status' => 400 ) );
	}
	$req->set_body( wp_json_encode( $d, JSON_UNESCAPED_UNICODE ) );
	return $res;
}, 11, 3 );

/* ------------------------------------------------------------------ *
 * Havuz ve günlük seçim
 * ------------------------------------------------------------------ */
/* Etkin havuz: seçili sınıfların gizlenmemiş yerleşik kelimeleri (kurumun Türkçesiyle) + etkin kurum kelimeleri */
function sides_kelime_havuz( $org, $ayar ) {
	$S   = array_flip( $ayar['siniflar'] );
	$ya  = sides_kelime_yerlesik_ayar( $org );
	$giz = array_flip( $ya['gizli'] );
	$out = array();
	foreach ( sides_kelime_yerlesik() as $k ) {
		if ( ! isset( $S[ $k['sinif'] ] ) || isset( $giz[ $k['id'] ] ) ) {
			continue;
		}
		if ( isset( $ya['tr'][ $k['id'] ] ) ) {
			$k['tr'] = $ya['tr'][ $k['id'] ];
		}
		$out[] = $k;
	}
	foreach ( sides_kelime_ozel_liste( $org ) as $k ) {
		if ( $k['aktif'] && isset( $S[ $k['sinif'] ] ) ) {
			$out[] = $k;
		}
	}
	usort( $out, function ( $a, $b ) {
		return strcmp( md5( $a['id'] ), md5( $b['id'] ) );
	} );
	return $out;
}
/* Gün dizini (pano saat diliminde, 1970'ten beri gün) */
function sides_kelime_gun_dizin( DateTime $now ) {
	return (int) floor( ( $now->getTimestamp() + $now->getOffset() ) / 86400 );
}
/* Bugünün kelimeleri: kararlı sıralı havuzda gün × N kaydırma; havuz N'den küçükse hepsi */
function sides_kelime_gun_sec( $havuz, $gunIdx, $n ) {
	$T = count( $havuz );
	if ( ! $T ) {
		return array();
	}
	$n   = min( $n, $T );
	$bas = ( ( $gunIdx * $n ) % $T + $T ) % $T;
	$out = array();
	for ( $i = 0; $i < $n; $i++ ) {
		$out[] = $havuz[ ( $bas + $i ) % $T ];
	}
	return $out;
}
function sides_kelime_pano_alan( $k ) {
	return array( 'id' => $k['id'], 'en' => $k['en'], 'tr' => $k['tr'], 'tur' => $k['tur'], 'ornek' => $k['ornek'], 'ornekTr' => $k['ornekTr'], 'sinif' => $k['sinif'] );
}
/* tv/<token> yanıtı: yalnızca açıkken (includes/tv.php sides_tv_oku çağırır) */
function sides_kelime_pano( $org, $ayarHam, DateTime $now ) {
	$h = array();
	$a = sides_kelime_ayar_temiz( is_array( $ayarHam ) && isset( $ayarHam['kelime'] ) ? $ayarHam['kelime'] : null, $h );
	if ( empty( $a['acik'] ) ) {
		return null;
	}
	return sides_kelime_bugun( $org, $a, $now );
}
/* v7.9.14 Aralıklı tekrar (Ebbinghaus / Leitner aralıkları): 1, 3 ve 7 gün önce gösterilen kelimelerden tekrarSayi kadarı bugün yeniden,
   'tekrar' => gün farkı ile işaretli gelir; pano bunları hatırlatma şablonlarıyla (Türkçeden İngilizceye, eksik harf, çoktan seçmeli…) gösterir. */
function sides_kelime_tekrar( $havuz, $gunIdx, $n, $adet, $bugun ) {
	$out  = array();
	$var  = array();
	foreach ( $bugun as $k ) {
		$var[ $k['id'] ] = 1;
	}
	foreach ( array( 1, 3, 7 ) as $gun ) {
		$L   = sides_kelime_gun_sec( $havuz, $gunIdx - $gun, $n );
		$T   = count( $L );
		if ( ! $T ) {
			continue;
		}
		$bas = ( $gunIdx + $gun ) % $T;   // her gün aynı kelimeler gelmesin
		for ( $i = 0, $al = 0; $i < $T && $al < $adet; $i++ ) {
			$k = $L[ ( $bas + $i ) % $T ];
			if ( isset( $var[ $k['id'] ] ) ) {
				continue;
			}
			$var[ $k['id'] ] = 1;
			$x               = sides_kelime_pano_alan( $k );
			$x['tekrar']     = $gun;
			$out[]           = $x;
			$al++;
		}
	}
	return $out;
}
function sides_kelime_bugun( $org, $a, DateTime $now ) {
	$havuz  = sides_kelime_havuz( $org, $a );
	$gunIdx = sides_kelime_gun_dizin( $now );
	$T      = count( $havuz );
	if ( 'tum' === ( $a['kapsam'] ?? 'gunluk' ) && $T ) {   // bütün havuz, her gün başka sıradan başlayarak (en çok 400 kelime)
		$n   = min( 400, $T );
		$bas = ( $gunIdx * 7 ) % $T;
		$gun = array();
		for ( $i = 0; $i < $n; $i++ ) {
			$gun[] = $havuz[ ( $bas + $i ) % $T ];
		}
	} else {
		$gun = sides_kelime_gun_sec( $havuz, $gunIdx, $a['gunluk'] );
	}
	$kelimeler = array_map( 'sides_kelime_pano_alan', $gun );
	$tekrar    = ! empty( $a['tekrar'] ) && 'tum' !== ( $a['kapsam'] ?? 'gunluk' ) && $T > $a['gunluk'] ? sides_kelime_tekrar( $havuz, $gunIdx, $a['gunluk'], (int) $a['tekrarSayi'], $gun ) : array();
	return array(
		'ayar'      => $a,
		'gun'       => $now->format( 'Y-m-d' ),
		'toplam'    => $T,
		'tekrarN'   => count( $tekrar ),
		'kelimeler' => array_merge( $kelimeler, $tekrar ),
	);
}

/* ------------------------------------------------------------------ *
 * REST: liste, önizleme
 * ------------------------------------------------------------------ */
function sides_kelime_liste_oku() {
	$org = sides_org_id();
	$ya  = sides_kelime_yerlesik_ayar( $org );
	$giz = array_flip( $ya['gizli'] );
	$Y   = array();
	foreach ( sides_kelime_yerlesik() as $k ) {
		$k['gizli'] = isset( $giz[ $k['id'] ] ) ? 1 : 0;
		if ( isset( $ya['tr'][ $k['id'] ] ) ) {
			$k['trOzgun'] = $k['tr'];
			$k['tr']      = $ya['tr'][ $k['id'] ];
		}
		$Y[] = $k;
	}
	return array( 'yerlesik' => $Y, 'ozel' => sides_kelime_ozel_liste( $org ), 'ozelMax' => SIDES_KL_OZEL_MAX );
}
function sides_kelime_tz( $org ) {
	$ayar = sides_get_doc( (int) $org, 'tv', 'ayar' );
	$tz   = is_array( $ayar ) && isset( $ayar['vakit']['tz'] ) ? (string) $ayar['vakit']['tz'] : 'Europe/Istanbul';
	try {
		return new DateTimeZone( $tz );
	} catch ( Exception $e ) {
		return new DateTimeZone( 'Europe/Istanbul' );
	}
}
function sides_kelime_oniz( WP_REST_Request $req ) {
	$org = sides_org_id();
	$b   = $req->get_json_params();
	$h   = array();
	$a   = sides_kelime_ayar_temiz( is_array( $b ) && array_key_exists( 'kelime', $b ) ? $b['kelime'] : null, $h );
	if ( $h ) {
		return new WP_Error( 'sides_gecersiz', 'Kelimeler ayarı geçersiz: ' . implode( ' ', array_slice( array_values( array_unique( $h ) ), 0, 3 ) ), array( 'status' => 400 ) );
	}
	$now = new DateTime( 'now', sides_kelime_tz( $org ) );
	$gun = is_array( $b ) && isset( $b['gun'] ) && is_string( $b['gun'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $b['gun'] ) ? $b['gun'] : '';
	if ( $gun ) {   // belirli bir günün listesi (sınama / "yarın ne gelecek")
		try {
			$now = new DateTime( $gun . ' 12:00:00', sides_kelime_tz( $org ) );
		} catch ( Exception $e ) {
			return new WP_Error( 'sides_gecersiz', 'Gün geçersiz.', array( 'status' => 400 ) );
		}
	}
	return sides_kelime_bugun( $org, $a, $now );
}

/* ------------------------------------------------------------------ *
 * REST: kurum kelimeleri
 * ------------------------------------------------------------------ */
function sides_kelime_metin( $v, $max, $ad, &$hata, $zorunlu = false ) {
	if ( null === $v || '' === $v ) {
		if ( $zorunlu ) {
			$hata[] = $ad . ' boş olamaz.';
		}
		return '';
	}
	if ( ! is_string( $v ) || ! mb_check_encoding( $v, 'UTF-8' ) ) {
		$hata[] = $ad . ' metin olmalı.';
		return '';
	}
	$v = trim( preg_replace( '/\s+/u', ' ', preg_replace( '/[\x00-\x1F\x7F]/u', ' ', $v ) ) );
	if ( '' === $v && $zorunlu ) {
		$hata[] = $ad . ' boş olamaz.';
	}
	if ( mb_strlen( $v ) > $max ) {
		$hata[] = $ad . ' en çok ' . $max . ' karakter olabilir.';
		$v = rtrim( mb_substr( $v, 0, $max ) );
	}
	if ( preg_match( '/[<>]/', $v ) ) {
		$hata[] = $ad . ' içinde < > kullanılamaz.';
		$v = str_replace( array( '<', '>' ), '', $v );
	}
	return $v;
}
/* Tek kelime kaydının alanları (ekleme, düzenleme ve içe aktarma aynı kuralla) */
function sides_kelime_alanlar( $x, &$hata ) {
	$x  = is_array( $x ) ? $x : array();
	$al = function ( $k ) use ( $x ) {
		return isset( $x[ $k ] ) ? $x[ $k ] : null;
	};
	$en = sides_kelime_metin( $al( 'en' ), 60, 'İngilizce kelime', $hata, true );
	if ( '' !== $en && ! preg_match( "/^[A-Za-z0-9 .,'’\-\/()!?&]+$/u", $en ) ) {
		$hata[] = 'İngilizce kelime yalnızca Latin harfleri içermeli.';
	}
	$tur   = $al( 'tur' );
	$sinif = $al( 'sinif' );
	if ( null !== $tur && ! in_array( $tur, SIDES_KL_TUR, true ) ) {
		$hata[] = 'Kelime türü geçersiz.';
	}
	if ( null !== $sinif && ! in_array( (string) $sinif, SIDES_KL_SINIF, true ) ) {
		$hata[] = 'Sınıf geçersiz.';
	}
	$aktif = $al( 'aktif' );
	if ( null !== $aktif && ! in_array( $aktif, array( 0, 1, '0', '1', true, false ), true ) ) {
		$hata[] = 'Etkin değeri 0 ya da 1 olmalı.';
	}
	return array(
		'en'      => $en,
		'tr'      => sides_kelime_metin( $al( 'tr' ), 80, 'Türkçe anlam', $hata, true ),
		'tur'     => in_array( $tur, SIDES_KL_TUR, true ) ? $tur : 'isim',
		'sinif'   => in_array( (string) $sinif, SIDES_KL_SINIF, true ) ? (string) $sinif : 'genel',
		'konu'    => sides_kelime_metin( $al( 'konu' ), 40, 'Konu', $hata ),
		'ornek'   => sides_kelime_metin( $al( 'ornek' ), 120, 'Örnek cümle', $hata ),
		'ornekTr' => sides_kelime_metin( $al( 'ornekTr' ), 140, 'Örneğin Türkçesi', $hata ),
		'aktif'   => null === $aktif || in_array( $aktif, array( 1, '1', true ), true ) ? 1 : 0,
	);
}
function sides_kelime_anahtar( $en, $tr ) {
	return mb_strtolower( trim( $en ), 'UTF-8' ) . '|' . mb_strtolower( trim( $tr ), 'UTF-8' );
}
/* Mevcut (yerleşik + kurum) en|tr anahtarları → kimlik */
function sides_kelime_mevcut( $org ) {
	$M = array();
	foreach ( sides_kelime_yerlesik() as $k ) {
		$M[ sides_kelime_anahtar( $k['en'], $k['tr'] ) ] = $k['id'];
	}
	foreach ( sides_kelime_ozel_liste( $org ) as $k ) {
		$M[ sides_kelime_anahtar( $k['en'], $k['tr'] ) ] = $k['id'];
	}
	return $M;
}
function sides_kelime_islem_id( $v ) {
	return is_string( $v ) && preg_match( '/^[A-Za-z0-9_\-]{6,64}$/', $v ) ? $v : '';
}
function sides_kelime_kullanici() {
	$u = wp_get_current_user();
	return array( 'u' => (int) get_current_user_id(), 'ad' => $u ? (string) $u->display_name : '' );
}
function sides_kelime_ozel_kaydet( WP_REST_Request $req ) {
	$org  = sides_org_id();
	$b    = $req->get_json_params();
	$b    = is_array( $b ) ? $b : array();
	$hata = array();
	$d    = sides_kelime_alanlar( $b, $hata );
	if ( $hata ) {
		return new WP_Error( 'sides_gecersiz', implode( ' ', array_slice( array_values( array_unique( $hata ) ), 0, 3 ) ), array( 'status' => 400 ) );
	}
	$id   = isset( $b['id'] ) && is_string( $b['id'] ) && preg_match( '/^k[a-f0-9]{8,20}$/', $b['id'] ) ? $b['id'] : '';
	$eski = $id ? sides_get_doc( $org, 'kelime', $id ) : null;
	if ( $id && ! $eski ) {
		return new WP_Error( 'sides_yok', 'Kelime bulunamadı.', array( 'status' => 404 ) );
	}
	if ( ! $id ) {
		$islem = sides_kelime_islem_id( isset( $b['islemId'] ) ? $b['islemId'] : null );
		if ( ! $islem ) {
			return new WP_Error( 'sides_gecersiz', 'İşlem kimliği (islemId) gerekli.', array( 'status' => 400 ) );
		}
		$id   = 'k' . substr( md5( $org . '|' . $islem ), 0, 14 );
		$eski = sides_get_doc( $org, 'kelime', $id );   // aynı islemId yeniden gelirse ikinci kayıt oluşmaz
		if ( ! $eski ) {
			$M  = sides_kelime_mevcut( $org );
			$ak = sides_kelime_anahtar( $d['en'], $d['tr'] );
			if ( isset( $M[ $ak ] ) ) {
				return new WP_Error( 'sides_var', 'Bu kelime ve anlam listede zaten var (' . $M[ $ak ] . ').', array( 'status' => 409 ) );
			}
			if ( count( sides_kelime_ozel_liste( $org ) ) >= SIDES_KL_OZEL_MAX ) {
				return new WP_Error( 'sides_gecersiz', 'En çok ' . SIDES_KL_OZEL_MAX . ' kurum kelimesi eklenebilir.', array( 'status' => 400 ) );
			}
		}
	}
	$d['olusturan'] = $eski && isset( $eski['olusturan'] ) ? $eski['olusturan'] : sides_kelime_kullanici();
	$d['t']         = $eski && isset( $eski['t'] ) ? (int) $eski['t'] : time();
	if ( $eski ) {
		$d['duzenleyen'] = sides_kelime_kullanici();
		$d['dt']         = time();
	}
	if ( false === sides_put_doc( $org, 'kelime', $id, $d ) ) {
		return new WP_Error( 'sides_db', 'Kaydedilemedi.', array( 'status' => 500 ) );
	}
	sides_log( $org, ( $eski ? 'Günün kelimeleri: kelime düzenlendi: ' : 'Günün kelimeleri: kelime eklendi: ' ) . $d['en'] . ' = ' . $d['tr'] );
	$d['id'] = $id;
	return $d;
}
function sides_kelime_ozel_sil( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$id  = (string) $req['id'];
	$d   = sides_get_doc( $org, 'kelime', $id );
	if ( ! $d ) {
		return new WP_Error( 'sides_yok', 'Kelime bulunamadı.', array( 'status' => 404 ) );
	}
	$wpdb->delete( sides_docs(), array( 'org' => $org, 'coll' => 'kelime', 'id' => $id ) );
	sides_log( $org, 'Günün kelimeleri: kelime silindi: ' . ( isset( $d['en'] ) ? $d['en'] : $id ) );
	return array( 'ok' => true, 'id' => $id );
}
/* Yerleşik kelime: gizle / göster, Türkçesini değiştir / geri al */
function sides_kelime_yerlesik_kaydet( WP_REST_Request $req ) {
	$org = sides_org_id();
	$b   = $req->get_json_params();
	$b   = is_array( $b ) ? $b : array();
	$id  = isset( $b['id'] ) && is_string( $b['id'] ) ? $b['id'] : '';
	$Y   = null;
	foreach ( sides_kelime_yerlesik() as $k ) {
		if ( $k['id'] === $id ) {
			$Y = $k;
			break;
		}
	}
	if ( ! $Y ) {
		return new WP_Error( 'sides_yok', 'Yerleşik kelime bulunamadı.', array( 'status' => 404 ) );
	}
	$ya   = sides_kelime_yerlesik_ayar( $org );
	$log  = array();
	if ( array_key_exists( 'gizli', $b ) ) {
		if ( ! in_array( $b['gizli'], array( 0, 1, '0', '1', true, false ), true ) ) {
			return new WP_Error( 'sides_gecersiz', 'gizli 0 ya da 1 olmalı.', array( 'status' => 400 ) );
		}
		$g = array_values( array_diff( $ya['gizli'], array( $id ) ) );
		if ( (int) $b['gizli'] ) {
			$g[] = $id;
		}
		$ya['gizli'] = $g;
		$log[]       = (int) $b['gizli'] ? 'gizlendi' : 'yeniden gösterildi';
	}
	if ( array_key_exists( 'tr', $b ) ) {
		$hata = array();
		$tr   = sides_kelime_metin( $b['tr'], 80, 'Türkçe anlam', $hata );
		if ( $hata ) {
			return new WP_Error( 'sides_gecersiz', implode( ' ', $hata ), array( 'status' => 400 ) );
		}
		if ( '' === $tr || $tr === $Y['tr'] ) {
			unset( $ya['tr'][ $id ] );
			$log[] = 'Türkçesi özgün hâline döndü';
		} else {
			$ya['tr'][ $id ] = $tr;
			$log[]           = 'Türkçesi değiştirildi: ' . $tr;
		}
	}
	if ( ! $log ) {
		return new WP_Error( 'sides_gecersiz', 'Değiştirilecek alan yok (gizli ya da tr).', array( 'status' => 400 ) );
	}
	$ya['tr'] = (object) $ya['tr'];
	if ( false === sides_put_doc( $org, 'kelime', 'yerlesik', $ya ) ) {
		return new WP_Error( 'sides_db', 'Kaydedilemedi.', array( 'status' => 500 ) );
	}
	sides_log( $org, 'Günün kelimeleri: ' . $Y['en'] . ' ' . implode( ', ', $log ) );
	$ya['tr'] = (array) $ya['tr'];
	return array( 'id' => $id, 'gizli' => in_array( $id, $ya['gizli'], true ) ? 1 : 0, 'tr' => isset( $ya['tr'][ $id ] ) ? $ya['tr'][ $id ] : $Y['tr'], 'trOzgun' => $Y['tr'] );
}
/* Satır çözümleme: "english;türkçe", "english - türkçe", sekme/virgül ile CSV (en, tr, tür?, konu?, örnek?, örnek Türkçesi?) */
function sides_kelime_satir_coz( $s ) {
	$s = trim( (string) $s );
	if ( '' === $s ) {
		return null;
	}
	if ( false !== strpos( $s, "\t" ) ) {
		$p = explode( "\t", $s );
	} elseif ( false !== strpos( $s, ';' ) ) {
		$p = explode( ';', $s );
	} elseif ( preg_match( '/\s[-–—:=]\s/u', $s ) ) {
		$p = preg_split( '/\s[-–—:=]\s/u', $s, 2 );
	} elseif ( false !== strpos( $s, ',' ) ) {
		$p = str_getcsv( $s );
	} else {
		return array( 'hata' => 'Ayırıcı bulunamadı (; - sekme ya da virgül)' );
	}
	$p = array_map( function ( $x ) {
		return trim( trim( (string) $x ), "\"'" );
	}, $p );
	$tur = isset( $p[2] ) ? mb_strtolower( $p[2], 'UTF-8' ) : '';
	$tm  = array( 'isim' => 'isim', 'noun' => 'isim', 'n' => 'isim', 'i' => 'isim', 'fiil' => 'fiil', 'verb' => 'fiil', 'v' => 'fiil', 'f' => 'fiil', 'sıfat' => 'sıfat', 'sifat' => 'sıfat', 'adjective' => 'sıfat', 'adj' => 'sıfat', 's' => 'sıfat', 'zarf' => 'zarf', 'adverb' => 'zarf', 'adv' => 'zarf', 'z' => 'zarf', 'edat' => 'edat', 'preposition' => 'edat', 'prep' => 'edat', 'e' => 'edat', 'ifade' => 'ifade', 'phrase' => 'ifade', 'x' => 'ifade' );
	return array( 'en' => isset( $p[0] ) ? $p[0] : '', 'tr' => isset( $p[1] ) ? $p[1] : '', 'tur' => isset( $tm[ $tur ] ) ? $tm[ $tur ] : null, 'konu' => isset( $p[3] ) ? $p[3] : null, 'ornek' => isset( $p[4] ) ? $p[4] : null, 'ornekTr' => isset( $p[5] ) ? $p[5] : null );
}
function sides_kelime_aktar( WP_REST_Request $req ) {
	$org = sides_org_id();
	$b   = $req->get_json_params();
	$b   = is_array( $b ) ? $b : array();
	$S   = isset( $b['satirlar'] ) && is_array( $b['satirlar'] ) ? $b['satirlar'] : ( isset( $b['metin'] ) && is_string( $b['metin'] ) ? preg_split( "/\r?\n/", $b['metin'] ) : null );
	if ( null === $S ) {
		return new WP_Error( 'sides_gecersiz', 'satirlar (liste) ya da metin gerekli.', array( 'status' => 400 ) );
	}
	if ( count( $S ) > 500 ) {
		return new WP_Error( 'sides_gecersiz', 'Bir seferde en çok 500 satır aktarılabilir.', array( 'status' => 400 ) );
	}
	$onizle = ! isset( $b['onizle'] ) || ! in_array( $b['onizle'], array( 0, '0', false ), true );
	$sinif  = isset( $b['sinif'] ) && in_array( (string) $b['sinif'], SIDES_KL_SINIF, true ) ? (string) $b['sinif'] : 'genel';
	$hk     = array();
	$konu   = sides_kelime_metin( isset( $b['konu'] ) ? $b['konu'] : '', 40, 'Konu', $hk );
	if ( $hk ) {
		return new WP_Error( 'sides_gecersiz', implode( ' ', $hk ), array( 'status' => 400 ) );
	}
	$islem = sides_kelime_islem_id( isset( $b['islemId'] ) ? $b['islemId'] : null );
	if ( ! $onizle && ! $islem ) {
		return new WP_Error( 'sides_gecersiz', 'İşlem kimliği (islemId) gerekli.', array( 'status' => 400 ) );
	}
	$M     = sides_kelime_mevcut( $org );
	$gor   = array();
	$R     = array();
	$ilk   = true;
	foreach ( $S as $i => $s ) {
		if ( ! is_string( $s ) || '' === trim( $s ) ) {
			continue;
		}
		$c = sides_kelime_satir_coz( $s );
		if ( ! $c ) {
			continue;
		}
		$satir = array( 'no' => $i + 1, 'ham' => mb_substr( trim( $s ), 0, 160 ) );
		if ( isset( $c['hata'] ) ) {
			$R[] = $satir + array( 'durum' => 'hatali', 'neden' => $c['hata'] );
			$ilk = false;
			continue;
		}
		if ( $ilk && preg_match( '/^(english|ingilizce|İngilizce|en|kelime|word)$/iu', $c['en'] ) ) {   // başlık satırı
			$ilk = false;
			continue;
		}
		$ilk  = false;
		$hata = array();
		$d    = sides_kelime_alanlar( array( 'en' => $c['en'], 'tr' => $c['tr'], 'tur' => $c['tur'], 'sinif' => $sinif, 'konu' => null === $c['konu'] || '' === $c['konu'] ? $konu : $c['konu'], 'ornek' => $c['ornek'], 'ornekTr' => $c['ornekTr'] ), $hata );
		if ( $hata ) {
			$R[] = $satir + array( 'durum' => 'hatali', 'neden' => implode( ' ', array_slice( array_values( array_unique( $hata ) ), 0, 2 ) ), 'en' => $d['en'], 'tr' => $d['tr'] );
			continue;
		}
		$ak = sides_kelime_anahtar( $d['en'], $d['tr'] );
		if ( isset( $M[ $ak ] ) ) {
			$R[] = $satir + array( 'durum' => 'var', 'neden' => 'Listede zaten var', 'en' => $d['en'], 'tr' => $d['tr'], 'mevcut' => $M[ $ak ] );
			continue;
		}
		if ( isset( $gor[ $ak ] ) ) {
			$R[] = $satir + array( 'durum' => 'var', 'neden' => 'Aynı satır yukarıda da var', 'en' => $d['en'], 'tr' => $d['tr'] );
			continue;
		}
		$gor[ $ak ] = 1;
		$R[]        = $satir + array( 'durum' => 'yeni', 'kayit' => $d, 'en' => $d['en'], 'tr' => $d['tr'], 'tur' => $d['tur'], 'konu' => $d['konu'], 'ornek' => $d['ornek'] );
	}
	$yeni = array_values( array_filter( $R, function ( $r ) { return 'yeni' === $r['durum']; } ) );
	$say  = array( 'yeni' => count( $yeni ), 'var' => count( array_filter( $R, function ( $r ) { return 'var' === $r['durum']; } ) ), 'hatali' => count( array_filter( $R, function ( $r ) { return 'hatali' === $r['durum']; } ) ) );
	if ( $onizle ) {
		foreach ( $R as &$r ) {
			unset( $r['kayit'] );
		}
		return array( 'onizle' => true, 'satirlar' => $R, 'say' => $say );
	}
	$mevcutN = count( sides_kelime_ozel_liste( $org ) );
	if ( $mevcutN + count( $yeni ) > SIDES_KL_OZEL_MAX ) {
		return new WP_Error( 'sides_gecersiz', 'Kurum kelimesi sınırı aşılıyor (en çok ' . SIDES_KL_OZEL_MAX . '; şu an ' . $mevcutN . ').', array( 'status' => 400 ) );
	}
	$kul = sides_kelime_kullanici();
	$ids = array();
	foreach ( $yeni as $j => $r ) {
		$d = $r['kayit'];
		$id = 'k' . substr( md5( $org . '|' . $islem . '|' . $j ), 0, 14 );   // aynı islemId ile yinelenen istek aynı kimlikleri yazar
		$d['olusturan'] = $kul;
		$d['t']         = time();
		if ( false === sides_put_doc( $org, 'kelime', $id, $d ) ) {
			return new WP_Error( 'sides_db', 'Kaydedilemedi (' . count( $ids ) . ' kelime kaydedildi).', array( 'status' => 500 ) );
		}
		$ids[] = $id;
	}
	if ( $ids ) {
		sides_log( $org, 'Günün kelimeleri: ' . count( $ids ) . ' kelime içe aktarıldı (' . $sinif . ( $konu ? ', ' . $konu : '' ) . ')' );
	}
	return array( 'onizle' => false, 'eklenen' => count( $ids ), 'ids' => $ids, 'say' => $say );
}
