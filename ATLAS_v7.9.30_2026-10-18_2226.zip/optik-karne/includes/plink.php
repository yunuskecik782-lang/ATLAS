<?php
/**
 * v6 R03 Süreli puan ve yoklama giriş linki.
 *
 * Yönetici (Takip yazma yetkisi; puan izni vermek için Puan yazma yetkisi de) bir kişiye hesapsız, süreli ve
 * sınıf/şubeyle sınırlı bir link verir. Link yalnızca BUGÜNE (Europe/Istanbul) giriş yapar:
 *  - Puan: aktif ve puanı tanımlı "tik" kriterleri (isteğe bağlı alt küme); her dokunuş tek hareket (phareket, kaynak 'link').
 *    Kaldırma yalnızca bu linkle girilmiş hareketi iptal eder (kayıt silinmez).
 *  - Yoklama: Yoklama Listesi (yoklama/<YYYY-MM-DD>); yeni yoklama ekleme ve işaretleme, değişiklik geçmişiyle.
 *
 * Belge: plink/<id> { ad, siniflar[], izin{puan,yoklama}, kriterler[], bas 'Y-m-d H:i', bit 'Y-m-d H:i', durum 'aktif'|'kapali',
 *        kapandi?{t,ad}, olustu{t,u,ad}, son?{t,tip,sinif}, say, gunSay{g,n}, gecmis[≤40], tk }
 * Belirteç: 32 rastgele bayt (64 onaltılık). token sütununda yalnızca özeti (SHA-256'nın ilk 40 karakteri) durur;
 * listede kopyalama/karekod için düz hâli wp_salt ile türetilen anahtarla şifreli (AES-256-GCM) saklanır (tk).
 * Genel /all, /koleksiyon ve /doc uçları bu koleksiyonu hiç döndürmez ve yazamaz.
 */
defined( 'ABSPATH' ) || exit;

define( 'SIDES_PL_YK', array( 'V', 'Y', 'G', 'I', 'H' ) );

add_action( 'rest_api_init', function () {
	$ns  = 'optik-karne/v1';
	$yon = function ( $req = null ) {
		if ( sides_is_observer() ) {
			return sides_deny( 'Gözlemci süreli giriş linki oluşturamaz ve göremez.' );
		}
		if ( ! sides_can( 'takip', 2 ) ) {
			return sides_deny( 'Süreli giriş linklerini Takip modülünde değişiklik yetkisi olan kullanıcılar yönetir.' );
		}
		// v7: sayfa yetkisi (Süreli Giriş Linkleri) ve ayrı "paylaşım linki oluşturma" yetkisi sunucuda da uygulanır
		$yaz = $req instanceof WP_REST_Request && 'GET' !== $req->get_method();
		if ( function_exists( 'sides_sayfa_herhangi' ) && ! sides_sayfa_herhangi( array( 'takip.plink' ), $yaz ? 2 : 1 ) ) {
			return sides_deny( 'Süreli Giriş Linkleri sayfasına erişim yetkiniz yok. Yöneticinizden izin isteyin.' );
		}
		if ( $yaz && 'DELETE' !== $req->get_method() && ! preg_match( '#/kapat$#', (string) $req->get_route() ) && function_exists( 'sides_sayfa_harita' ) ) {   // kapatma ve silme serbest
			$h = sides_sayfa_harita();
			if ( isset( $h['_paylas'] ) && 0 === (int) $h['_paylas'] ) {
				return sides_deny( 'Paylaşım bağlantısı oluşturma yetkiniz yok. Yöneticinizden izin isteyin.' );
			}
		}
		return true;
	};
	register_rest_route( $ns, '/takip/plink', array(
		array( 'methods' => 'GET', 'callback' => 'sides_pl_liste', 'permission_callback' => $yon ),
		array( 'methods' => 'POST', 'callback' => 'sides_pl_kaydet', 'permission_callback' => $yon ),
	) );
	register_rest_route( $ns, '/takip/plink/(?P<id>pl[a-f0-9]{12})', array(
		array( 'methods' => 'DELETE', 'callback' => 'sides_pl_sil', 'permission_callback' => $yon ),
	) );
	register_rest_route( $ns, '/takip/plink/(?P<id>pl[a-f0-9]{12})/(?P<islem>yenile|kapat)', array(
		array( 'methods' => 'POST', 'callback' => 'sides_pl_islem', 'permission_callback' => $yon ),
	) );
	/* Herkese açık uçlar: belirteç her istekte yeniden denetlenir (iptal ve süre önbellekten okunmaz) */
	register_rest_route( $ns, '/pl/(?P<token>[a-f0-9]{64})', array(
		array( 'methods' => 'GET', 'callback' => function ( $r ) { return sides_pl_cevap( 'sides_pl_oku', $r, false ); }, 'permission_callback' => '__return_true' ),
	) );
	register_rest_route( $ns, '/pl/(?P<token>[a-f0-9]{64})/(?P<islem>puan|iptal|yoklama)', array(
		array( 'methods' => 'POST', 'callback' => function ( $r ) { $u = $r->get_url_params(); return sides_pl_cevap( 'sides_pl_' . $u['islem'], $r, true ); /* gövdedeki 'islem' alanı yol parametresini ezmesin */ }, 'permission_callback' => '__return_true' ),
	) );
} );

/* ---------------- yardımcılar ---------------- */
function sides_pl_simdi() {
	return new DateTime( 'now', new DateTimeZone( 'Europe/Istanbul' ) );
}
function sides_pl_bugun() {
	return sides_pl_simdi()->format( 'Y-m-d' );
}
function sides_pl_an() {
	return sides_pl_simdi()->format( 'Y-m-d H:i' );
}
function sides_pl_ozet( $tok ) {
	return substr( hash( 'sha256', 'plink|' . $tok ), 0, 40 );
}
function sides_pl_anahtar() {
	return hash( 'sha256', wp_salt( 'auth' ) . '|sides-plink', true );
}
function sides_pl_sifrele( $tok ) {
	if ( ! function_exists( 'openssl_encrypt' ) ) {
		return '';
	}
	$iv  = random_bytes( 12 );
	$tag = '';
	$c   = openssl_encrypt( $tok, 'aes-256-gcm', sides_pl_anahtar(), OPENSSL_RAW_DATA, $iv, $tag );
	return false === $c ? '' : base64_encode( $iv . $tag . $c );
}
function sides_pl_coz( $s ) {
	if ( ! $s || ! function_exists( 'openssl_decrypt' ) ) {
		return '';
	}
	$b = base64_decode( (string) $s, true );
	if ( false === $b || strlen( $b ) < 29 ) {
		return '';
	}
	$p = openssl_decrypt( substr( $b, 28 ), 'aes-256-gcm', sides_pl_anahtar(), OPENSSL_RAW_DATA, substr( $b, 0, 12 ), substr( $b, 12, 16 ) );
	return is_string( $p ) && preg_match( '/^[a-f0-9]{64}$/', $p ) ? $p : '';
}
function sides_pl_ms() {
	return (int) round( microtime( true ) * 1000 );
}
function sides_pl_hata( $kod, $m, $st ) {
	return new WP_Error( $kod, $m, array( 'status' => $st ) );
}
function sides_pl_tr( $an ) {   // 'Y-m-d H:i' → 'd.m.Y H:i'
	return preg_match( '/^(\d{4})-(\d{2})-(\d{2}) (\d{2}:\d{2})$/', (string) $an, $m ) ? $m[3] . '.' . $m[2] . '.' . $m[1] . ' ' . $m[4] : (string) $an;
}
/* aktif | bekliyor | doldu | kapali (sunucu saatiyle) */
function sides_pl_durum( $d ) {
	if ( 'kapali' === ( isset( $d['durum'] ) ? $d['durum'] : '' ) ) {
		return 'kapali';
	}
	$an = sides_pl_an();
	if ( empty( $d['bit'] ) || $an > $d['bit'] ) {
		return 'doldu';
	}
	if ( ! empty( $d['bas'] ) && $an < $d['bas'] ) {
		return 'bekliyor';
	}
	return 'aktif';
}
function sides_pl_zaman( $s ) {   // 'YYYY-MM-DDTHH:MM' ya da 'YYYY-MM-DD HH:MM' → 'Y-m-d H:i' | ''
	if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})[T ]([01]\d|2[0-3]):([0-5]\d)$/', trim( (string) $s ), $m ) || ! checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ) {
		return '';
	}
	return $m[1] . '-' . $m[2] . '-' . $m[3] . ' ' . $m[4] . ':' . $m[5];
}
function sides_pl_dk( $an ) {   // 'Y-m-d H:i' → dakika (karşılaştırma için)
	$d = DateTime::createFromFormat( 'Y-m-d H:i', $an, new DateTimeZone( 'Europe/Istanbul' ) );
	return $d ? (int) floor( $d->getTimestamp() / 60 ) : 0;
}
function sides_pl_kilit( $k ) {
	return function_exists( 'sides_tko_kilit' ) ? sides_tko_kilit( $k ) : array( '', '' );
}
function sides_pl_birak( $l ) {
	if ( function_exists( 'sides_tko_kilit_birak' ) ) {
		sides_tko_kilit_birak( $l );
	}
}
function sides_pl_rl( $k, $max, $ttl ) {
	return function_exists( 'sides_tko_rl' ) ? sides_tko_rl( 'pl|' . $k, $max, $ttl ) : sides_rl( 'pl|' . $k, $max, $ttl );
}
/* v7: isteğe bağlı PIN (4–6 rakam). Belgede yalnız tuzlu HMAC özeti durur: pin { tuz, h, t }; anahtar wp_salt'tan türetilir,
   veritabanı tek başına sızsa da PIN çevrimdışı denenemez. Özet hiçbir yanıtta dönmez (listede yalnız pin: true/false). */
function sides_pl_pin_ozet( $id, $tuz, $pin ) {
	return hash_hmac( 'sha256', $id . '|' . $tuz . '|' . $pin, wp_salt( 'auth' ) . '|sides-plink-pin' );
}
function sides_pl_pin_temiz( $v ) {
	return preg_replace( '/\s+/', '', (string) $v );
}
/* Her okuma/yazma isteğinde: PIN varsa doğru olmalı. Link + IP başına 5 yanlış denemede 15 dakika kilit. */
function sides_pl_pin_denetim( $x, WP_REST_Request $req, $ip ) {
	$p = isset( $x['d']['pin'] ) && is_array( $x['d']['pin'] ) ? $x['d']['pin'] : null;
	if ( ! $p || empty( $p['h'] ) ) {
		return true;
	}
	$k = 'sides_plpin_' . md5( $x['id'] . '|' . $ip );
	$v = get_transient( $k );
	$v = is_array( $v ) ? $v + array( 'n' => 0, 'kilit' => 0 ) : array( 'n' => 0, 'kilit' => 0 );
	if ( (int) $v['kilit'] > time() ) {
		$dk = max( 1, (int) ceil( ( (int) $v['kilit'] - time() ) / 60 ) );
		return sides_pl_hata( 'sides_pl_pin_kilit', 'Çok fazla yanlış PIN denemesi yapıldı. Bu link bu cihazdan yaklaşık ' . $dk . ' dakika kullanılamaz; sonra tekrar deneyin ya da doğru PIN’i okul yönetiminden isteyin.', 429 );
	}
	$h   = $req->get_header( 'x_atlas_pin' );
	$pin = sides_pl_pin_temiz( null !== $h && '' !== $h ? $h : $req->get_param( 'pin' ) );
	if ( '' === $pin ) {
		return sides_pl_hata( 'sides_pl_pin', 'Bu link PIN ile korunuyor. Okul yönetiminin size verdiği PIN’i girin.', 403 );
	}
	if ( preg_match( '/^\d{4,6}$/', $pin ) && hash_equals( (string) $p['h'], sides_pl_pin_ozet( $x['id'], (string) ( $p['tuz'] ?? '' ), $pin ) ) ) {
		if ( $v['n'] ) {
			delete_transient( $k );
		}
		return true;
	}
	$v['n'] = (int) $v['n'] + 1;
	if ( $v['n'] >= 5 ) {
		set_transient( $k, array( 'n' => 0, 'kilit' => time() + 900 ), 900 );
		return sides_pl_hata( 'sides_pl_pin_kilit', 'PIN 5 kez yanlış girildi. Bu link bu cihazdan 15 dakika kullanılamaz; doğru PIN’i okul yönetiminden isteyin.', 429 );
	}
	set_transient( $k, array( 'n' => $v['n'], 'kilit' => 0 ), 900 );
	return sides_pl_hata( 'sides_pl_pin_yanlis', 'PIN yanlış. ' . ( 5 - $v['n'] ) . ' deneme hakkınız kaldı; hak bitince link bu cihazdan 15 dakika kilitlenir.', 403 );
}

/* ---------------- yönetim ---------------- */
function sides_pl_kapsam_izinli( $d, $kisit ) {
	foreach ( isset( $d['siniflar'] ) ? (array) $d['siniflar'] : array() as $s ) {
		if ( ! sides_tko_sinif_izinli( (string) $s, $kisit ) ) {
			return false;
		}
	}
	return true;
}
function sides_pl_disari( $id, $d ) {
	$tok = ! empty( $d['tk'] ) ? sides_pl_coz( $d['tk'] ) : '';
	$gs  = isset( $d['gunSay'] ) && is_array( $d['gunSay'] ) && ( $d['gunSay']['g'] ?? '' ) === sides_pl_bugun() ? (int) $d['gunSay']['n'] : 0;
	return array(
		'id'        => $id,
		'ad'        => isset( $d['ad'] ) ? (string) $d['ad'] : '',
		'siniflar'  => isset( $d['siniflar'] ) ? array_values( (array) $d['siniflar'] ) : array(),
		'izin'      => array( 'puan' => ! empty( $d['izin']['puan'] ), 'yoklama' => ! empty( $d['izin']['yoklama'] ) ),
		'kriterler' => isset( $d['kriterler'] ) ? array_values( (array) $d['kriterler'] ) : array(),
		'bas'       => isset( $d['bas'] ) ? $d['bas'] : '',
		'bit'       => isset( $d['bit'] ) ? $d['bit'] : '',
		'durum'     => sides_pl_durum( $d ),
		'olustu'    => isset( $d['olustu'] ) ? $d['olustu'] : null,
		'kapandi'   => isset( $d['kapandi'] ) ? $d['kapandi'] : null,
		'son'       => isset( $d['son'] ) ? $d['son'] : null,
		'say'       => isset( $d['say'] ) ? (int) $d['say'] : 0,
		'bugunSay'  => $gs,
		'gecmis'    => isset( $d['gecmis'] ) ? array_values( (array) $d['gecmis'] ) : array(),
		'pin'       => ! empty( $d['pin']['h'] ),   // v7: yalnız var/yok; PIN ve özeti hiçbir zaman gönderilmez
		'token'     => $tok ? $tok : null,
	);
}
/* Form için seçilebilir kriterler (aktif "tik" kriterleri; puanı tanımlı olmayanlar işaretli gelir) */
function sides_pl_form_kriter( $org ) {
	$out = array();
	foreach ( sides_puan_docs( $org, 'pkriter' ) as $k ) {
		if ( 'aktif' !== ( $k['durum'] ?? 'aktif' ) || 'manuel' === ( $k['giris'] ?? '' ) ) {
			continue;
		}
		$out[] = array(
			'id'       => $k['id'],
			'ad'       => (string) ( $k['ad'] ?? '' ),
			'grup'     => (string) ( $k['grup'] ?? '' ),
			'yon'      => (string) ( $k['yon'] ?? '-' ),
			'deger'    => isset( $k['deger'] ) && is_numeric( $k['deger'] ) ? (float) $k['deger'] : null,
			'vakitler' => ! empty( $k['vakitler'] ) && is_array( $k['vakitler'] ) ? array_values( array_intersect( SIDES_PUAN_VAKIT, $k['vakitler'] ) ) : array(),
			'sira'     => (float) ( $k['sira'] ?? 0 ),
		);
	}
	usort( $out, function ( $a, $b ) {
		return ( $a['sira'] <=> $b['sira'] ) ?: strcmp( $a['ad'], $b['ad'] );
	} );
	return $out;
}
function sides_pl_liste( WP_REST_Request $req ) {
	global $wpdb;
	$org   = sides_org_id();
	$kisit = sides_sinif_kisit();
	$out   = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( 'SELECT id, data FROM ' . sides_docs() . " WHERE org = %d AND coll = 'plink'", $org ) ) as $r ) { // phpcs:ignore
		$d = json_decode( $r->data, true );
		if ( is_array( $d ) && sides_pl_kapsam_izinli( $d, $kisit ) ) {
			$out[] = sides_pl_disari( $r->id, $d );
		}
	}
	usort( $out, function ( $a, $b ) {
		return (int) ( $b['olustu']['t'] ?? 0 ) <=> (int) ( $a['olustu']['t'] ?? 0 );
	} );
	$res = rest_ensure_response( array(
		'linkler'   => $out,
		'kriterler' => sides_can( 'puan', 1 ) ? sides_pl_form_kriter( $org ) : array(),
		'puanYaz'   => sides_can( 'puan', 2 ),
		'simdi'     => sides_pl_an(),
	) );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}
function sides_pl_kaydet( WP_REST_Request $req ) {
	global $wpdb;
	$org   = sides_org_id();
	$p     = $req->get_json_params();
	$p     = is_array( $p ) ? $p : array();
	$kisit = sides_sinif_kisit();
	$id    = isset( $p['id'] ) ? (string) $p['id'] : '';
	$ad    = mb_substr( trim( sanitize_text_field( isset( $p['ad'] ) ? (string) $p['ad'] : '' ) ), 0, 80 );
	if ( '' === $ad ) {
		return sides_pl_hata( 'sides_gecersiz', 'Linki kullanacak kişinin adını yazın (örn. Nöbetçi öğretmen Ahmet).', 400 );
	}
	$sin = array();
	foreach ( isset( $p['siniflar'] ) && is_array( $p['siniflar'] ) ? $p['siniflar'] : array() as $s ) {
		$n = sides_sinif_norm( (string) $s );
		if ( '' !== $n && ! in_array( $n, $sin, true ) ) {
			$sin[] = $n;
		}
	}
	$sin = array_slice( $sin, 0, 40 );
	if ( ! $sin ) {
		return sides_pl_hata( 'sides_gecersiz', 'En az bir sınıf ya da şube seçin.', 400 );
	}
	foreach ( $sin as $s ) {
		if ( ! sides_tko_sinif_izinli( $s, $kisit ) ) {
			return sides_deny( 'Yetkili olduğunuz sınıfların dışında bir sınıf seçtiniz: ' . $s );
		}
	}
	$pin = sides_pl_pin_temiz( isset( $p['pin'] ) ? $p['pin'] : '' );
	if ( '' !== $pin && ! preg_match( '/^\d{4,6}$/', $pin ) ) {
		return sides_pl_hata( 'sides_gecersiz', 'PIN 4–6 haneli bir sayı olmalı (yalnız rakam).', 400 );
	}
	$iz = array( 'puan' => ! empty( $p['izin']['puan'] ), 'yoklama' => ! empty( $p['izin']['yoklama'] ) );
	if ( ! $iz['puan'] && ! $iz['yoklama'] ) {
		return sides_pl_hata( 'sides_gecersiz', 'Linkle neler girilebileceğini seçin: puan kriterleri ve/veya yoklama.', 400 );
	}
	if ( $iz['puan'] && ! sides_can( 'puan', 2 ) ) {
		return sides_deny( 'Puan sisteminde değişiklik yetkiniz olmadığı için linke puan girişi izni veremezsiniz.' );
	}
	$kri = array();
	if ( $iz['puan'] ) {
		$gecerli = array_column( sides_pl_form_kriter( $org ), 'id' );
		foreach ( isset( $p['kriterler'] ) && is_array( $p['kriterler'] ) ? array_slice( $p['kriterler'], 0, 80 ) : array() as $k ) {
			$k = (string) $k;
			if ( ! in_array( $k, $gecerli, true ) ) {
				return sides_pl_hata( 'sides_gecersiz', 'Seçilen kriterlerden biri bulunamadı ya da arşivde; listeyi yenileyin.', 400 );
			}
			if ( ! in_array( $k, $kri, true ) ) {
				$kri[] = $k;
			}
		}
	}
	$bugun = sides_pl_bugun();
	if ( ! empty( $p['bugun'] ) ) {
		$bas = $bugun . ' 00:00';
		$bit = $bugun . ' 23:59';
	} else {
		$bas = sides_pl_zaman( isset( $p['bas'] ) ? $p['bas'] : '' );
		$bit = sides_pl_zaman( isset( $p['bit'] ) ? $p['bit'] : '' );
		if ( ! $bas || ! $bit ) {
			return sides_pl_hata( 'sides_gecersiz', 'Başlangıç ve bitiş tarih-saatini girin.', 400 );
		}
		if ( $bit <= $bas ) {
			return sides_pl_hata( 'sides_gecersiz', 'Bitiş, başlangıçtan sonra olmalı.', 400 );
		}
		if ( sides_pl_dk( $bit ) - sides_pl_dk( $bas ) > 30 * 1440 ) {
			return sides_pl_hata( 'sides_gecersiz', 'Link en çok 30 gün geçerli olabilir.', 400 );
		}
		if ( sides_pl_dk( $bas ) - sides_pl_dk( sides_pl_an() ) > 30 * 1440 ) {
			return sides_pl_hata( 'sides_gecersiz', 'Başlangıç en çok 30 gün sonrası olabilir.', 400 );
		}
	}
	if ( $bit <= sides_pl_an() ) {
		return sides_pl_hata( 'sides_gecersiz', 'Bitiş zamanı geçmiş olamaz.', 400 );
	}
	$u    = wp_get_current_user();
	$yeni = '' === $id;
	if ( $yeni ) {
		$id = 'pl' . bin2hex( random_bytes( 6 ) );
	} elseif ( ! preg_match( '/^pl[a-f0-9]{12}$/', $id ) ) {
		return sides_pl_hata( 'sides_yok', 'Link bulunamadı.', 404 );
	}
	$kl   = sides_pl_kilit( $org . '|plink|' . $id );
	$eski = $yeni ? null : sides_get_doc( $org, 'plink', $id );
	$hata = null;
	if ( ! $yeni && ! $eski ) {
		$hata = sides_pl_hata( 'sides_yok', 'Link bulunamadı.', 404 );
	} elseif ( $eski && ! sides_pl_kapsam_izinli( $eski, $kisit ) ) {
		$hata = sides_deny( 'Bu link yetkili olduğunuz sınıfların dışında.' );
	} elseif ( $eski && 'kapali' === ( $eski['durum'] ?? '' ) ) {
		$hata = sides_pl_hata( 'sides_kapali', 'Kapatılmış link düzenlenemez; yeni bir link oluşturun.', 409 );
	}
	if ( $hata ) {
		sides_pl_birak( $kl );
		return $hata;
	}
	$d = $eski ? $eski : array( 'olustu' => array( 't' => sides_pl_ms(), 'u' => (int) $u->ID, 'ad' => $u->display_name ), 'durum' => 'aktif', 'say' => 0, 'gecmis' => array() );
	unset( $d['id'] );
	$d   = array_merge( $d, array( 'ad' => $ad, 'siniflar' => $sin, 'izin' => $iz, 'kriterler' => $kri, 'bas' => $bas, 'bit' => $bit ) );
	$pin_not = '';
	if ( '' !== $pin ) {   // v7: yeni ya da değişen PIN (gönderilmezse eski PIN korunur)
		$tuz      = bin2hex( random_bytes( 8 ) );
		$pin_not  = ! empty( $d['pin']['h'] ) ? ' · PIN değiştirildi' : ' · PIN korumalı';
		$d['pin'] = array( 'tuz' => $tuz, 'h' => sides_pl_pin_ozet( $id, $tuz, $pin ), 't' => time() );
	} elseif ( ! empty( $p['pinKaldir'] ) && ! empty( $d['pin'] ) ) {
		unset( $d['pin'] );
		$pin_not = ' · PIN kaldırıldı';
	}
	$tok = '';
	if ( $yeni ) {
		$tok     = bin2hex( random_bytes( 32 ) );
		$d['tk'] = sides_pl_sifrele( $tok );
	}
	$ok = sides_put_doc( $org, 'plink', $id, $d );
	if ( false !== $ok && $yeni ) {
		$wpdb->update( sides_docs(), array( 'token' => sides_pl_ozet( $tok ) ), array( 'org' => $org, 'coll' => 'plink', 'id' => $id ) );
	}
	sides_pl_birak( $kl );
	if ( false === $ok ) {
		return sides_pl_hata( 'sides_db', 'Kaydedilemedi.', 500 );
	}
	$izy = implode( ' + ', array_keys( array_filter( array( 'puan' => $iz['puan'], 'yoklama' => $iz['yoklama'] ) ) ) );
	sides_log( $org, 'Süreli giriş linki ' . ( $yeni ? 'oluşturuldu' : 'güncellendi' ) . ': ' . $ad . ' · ' . implode( ', ', $sin ) . ' · ' . $izy . ' · ' . sides_pl_tr( $bas ) . ' – ' . sides_pl_tr( $bit ) . $pin_not );
	$o = sides_pl_disari( $id, $d );
	if ( $tok ) {
		$o['token'] = $tok;   // şifreleme kullanılamıyorsa düz belirteç yalnızca şimdi görünür
	}
	return $o;
}
function sides_pl_sahip( $org, $id ) {
	$d = sides_get_doc( $org, 'plink', $id );
	if ( ! $d ) {
		return sides_pl_hata( 'sides_yok', 'Link bulunamadı.', 404 );
	}
	if ( ! sides_pl_kapsam_izinli( $d, sides_sinif_kisit() ) ) {
		return sides_deny( 'Bu link yetkili olduğunuz sınıfların dışında.' );
	}
	unset( $d['id'] );
	return $d;
}
/* POST takip/plink/<id>/yenile | kapat */
function sides_pl_islem( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$id  = (string) $req['id'];
	$kl  = sides_pl_kilit( $org . '|plink|' . $id );
	$d   = sides_pl_sahip( $org, $id );
	if ( is_wp_error( $d ) ) {
		sides_pl_birak( $kl );
		return $d;
	}
	if ( 'kapali' === ( $d['durum'] ?? '' ) ) {
		sides_pl_birak( $kl );
		return sides_pl_hata( 'sides_kapali', 'Bu link zaten kapatılmış.', 409 );
	}
	$u   = wp_get_current_user();
	$tok = '';
	if ( 'yenile' === $req->get_url_params()['islem'] ) {
		$tok     = bin2hex( random_bytes( 32 ) );
		$d['tk'] = sides_pl_sifrele( $tok );
	} else {
		$d['durum']   = 'kapali';
		$d['kapandi'] = array( 't' => sides_pl_ms(), 'ad' => $u->display_name );
	}
	$ok = sides_put_doc( $org, 'plink', $id, $d );
	if ( false !== $ok && $tok ) {
		$wpdb->update( sides_docs(), array( 'token' => sides_pl_ozet( $tok ) ), array( 'org' => $org, 'coll' => 'plink', 'id' => $id ) );
	}
	sides_pl_birak( $kl );
	if ( false === $ok ) {
		return sides_pl_hata( 'sides_db', 'Kaydedilemedi.', 500 );
	}
	sides_log( $org, 'Süreli giriş linki ' . ( $tok ? 'yenilendi (eski adres artık açılmaz)' : 'kapatıldı' ) . ': ' . $d['ad'] );
	$o = sides_pl_disari( $id, $d );
	if ( $tok ) {
		$o['token'] = $tok;
	}
	return $o;
}
/* DELETE takip/plink/<id> — yalnızca kapatılmış ya da süresi dolmuş link listeden kaldırılır (girişler puan/yoklama kayıtlarında kalır) */
function sides_pl_sil( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$id  = (string) $req['id'];
	$d   = sides_pl_sahip( $org, $id );
	if ( is_wp_error( $d ) ) {
		return $d;
	}
	if ( ! in_array( sides_pl_durum( $d ), array( 'kapali', 'doldu' ), true ) ) {
		return sides_pl_hata( 'sides_acik', 'Açık link silinemez; önce linki kapatın.', 409 );
	}
	$wpdb->delete( sides_docs(), array( 'org' => $org, 'coll' => 'plink', 'id' => $id ) );
	sides_log( $org, 'Süreli giriş linki listeden kaldırıldı: ' . $d['ad'] );
	return array( 'ok' => true );
}

/* ---------------- herkese açık sayfa ---------------- */
function sides_pl_bul( $tok ) {
	global $wpdb;
	if ( ! preg_match( '/^[a-f0-9]{64}$/', (string) $tok ) ) {
		return null;
	}
	$r = $wpdb->get_row( $wpdb->prepare( 'SELECT org, id, data FROM ' . sides_docs() . " WHERE coll = 'plink' AND token = %s", sides_pl_ozet( $tok ) ) ); // phpcs:ignore
	if ( ! $r ) {
		return null;
	}
	$o = sides_org( (int) $r->org );
	if ( ! $o || sides_org_blok( $o ) ) {
		return null;
	}
	$d = json_decode( $r->data, true );
	return is_array( $d ) ? array( 'org' => (int) $r->org, 'id' => $r->id, 'd' => $d ) : null;
}
/* Kurumda kapalı modüller linkin izinlerinden düşülür */
function sides_pl_izin( $x ) {
	$kap = sides_kapali_moduller( $x['org'] );
	return array(
		'puan'    => ! empty( $x['d']['izin']['puan'] ) && ! in_array( 'puan', $kap, true ),
		'yoklama' => ! empty( $x['d']['izin']['yoklama'] ) && ! in_array( 'takip', $kap, true ),
	);
}
/* Linkin kapsamı; linki oluşturanın sınıf kısıtı sonradan daraldıysa kesişim uygulanır */
function sides_pl_siniflar( $x ) {
	static $c = array();
	if ( isset( $c[ $x['id'] ] ) ) {
		return $c[ $x['id'] ];
	}
	$sin = array_map( 'strval', isset( $x['d']['siniflar'] ) ? (array) $x['d']['siniflar'] : array() );
	$u   = (int) ( $x['d']['olustu']['u'] ?? 0 );
	$k   = $u ? sides_sinif_kisit( $u ) : null;
	if ( null !== $k ) {
		$sin = array_values( array_filter( $sin, function ( $s ) use ( $k ) {
			return sides_tko_sinif_izinli( $s, $k );
		} ) );
	}
	return $c[ $x['id'] ] = $sin;
}
function sides_pl_ogrenci( $x, $sid ) {
	if ( ! preg_match( '/^[A-Za-z0-9_\-]{1,64}$/', (string) $sid ) ) {
		return null;
	}
	$s = sides_get_doc( $x['org'], 'students', (string) $sid );
	if ( ! $s || ! empty( $s['pasif'] ) ) {
		return null;
	}
	$g   = trim( preg_replace( '/\s+/u', ' ', isset( $s['sinif'] ) ? (string) $s['sinif'] : '' ) );
	$b   = mb_strtoupper( trim( isset( $s['sube'] ) ? (string) $s['sube'] : '' ), 'UTF-8' );
	$sin = sides_pl_siniflar( $x );
	if ( '' === $g || ! ( in_array( $g, $sin, true ) || ( '' !== $b && in_array( $g . '/' . $b, $sin, true ) ) ) ) {
		return null;
	}
	return array( 'id' => (string) $sid, 'ad' => isset( $s['ad'] ) ? (string) $s['ad'] : '', 'no' => isset( $s['no'] ) ? (string) $s['no'] : '', 'sinif' => $g, 'sube' => $b );
}
function sides_pl_kim( $x ) {
	return ( isset( $x['d']['ad'] ) ? (string) $x['d']['ad'] : 'Link' ) . ' (link)';
}
/* İstek kabı: hız sınırı → belirteç → süre/iptal → kapsam; yanıt her zaman önbelleksiz */
function sides_pl_cevap( $fn, WP_REST_Request $req, $yaz ) {
	$ip  = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$on  = $yaz ? 'y|' : 'o|';
	$r   = null;
	$x   = null;
	if ( ! sides_pl_rl( $on . $ip, $yaz ? 1500 : 2500, 600 ) ) {   // IP sınırı geniş: okulun bütün öğretmenleri aynı ağdan gelebilir
		$r = sides_pl_hata( 'sides_rl', 'Çok fazla istek. Birkaç dakika sonra tekrar deneyin.', 429 );
	} else {
		$x = sides_pl_bul( (string) $req['token'] );
		if ( ! $x ) {
			$r = sides_pl_rl( 'bad|' . $ip, 30, 600 )
				? sides_pl_hata( 'sides_pl_yok', 'Link geçersiz ya da kaldırılmış. Okul yönetiminden yeni link isteyin.', 404 )
				: sides_pl_hata( 'sides_rl', 'Çok fazla geçersiz link denemesi. Birkaç dakika sonra tekrar deneyin.', 429 );
		} elseif ( ! sides_pl_rl( $on . $x['id'], $yaz ? 400 : 900, 600 ) ) {   // link başına dar
			$r = sides_pl_hata( 'sides_rl', 'Bu link çok sık kullanıldı. Birkaç dakika sonra tekrar deneyin.', 429 );
		} elseif ( is_wp_error( $pe = sides_pl_pin_denetim( $x, $req, $ip ) ) ) {   // v7: PIN her okuma ve yazmada denetlenir
			$r = $pe;
		} else {
			$du = sides_pl_durum( $x['d'] );
			$iz = sides_pl_izin( $x );
			if ( 'kapali' === $du ) {
				$r = sides_pl_hata( 'sides_pl_kapali', 'Bu link okul yönetimi tarafından kapatıldı. Yeni giriş yapılamaz; gerekirse yeni link isteyin.', 410 );
			} elseif ( 'doldu' === $du ) {
				$r = sides_pl_hata( 'sides_pl_sure', 'Bu linkin süresi doldu (son geçerlilik: ' . sides_pl_tr( $x['d']['bit'] ?? '' ) . '). Okul yönetiminden yeni link isteyin.', 410 );
			} elseif ( 'bekliyor' === $du ) {
				$r = sides_pl_hata( 'sides_pl_bekliyor', 'Bu link henüz açılmadı; ' . sides_pl_tr( $x['d']['bas'] ?? '' ) . ' itibarıyla kullanılabilir.', 403 );
			} elseif ( ! $iz['puan'] && ! $iz['yoklama'] ) {
				$r = sides_pl_hata( 'sides_pl_modul', 'Bu linkin izin verdiği bölümler kurumda şu an kapalı.', 403 );
			} elseif ( $yaz && ( $x['d']['gunSay']['g'] ?? '' ) === sides_pl_bugun() && (int) ( $x['d']['gunSay']['n'] ?? 0 ) >= 3000 ) {
				$r = sides_pl_hata( 'sides_rl', 'Bu link için günlük giriş sınırına (3000) ulaşıldı.', 429 );
			} else {
				$r = call_user_func( $fn, $x, $req );
			}
		}
	}
	$res = is_wp_error( $r ) ? rest_convert_error_to_response( $r ) : rest_ensure_response( $r );
	$res->header( 'Cache-Control', 'no-store, private' );
	$res->header( 'X-Robots-Tag', 'noindex, nofollow' );
	$res->header( 'Referrer-Policy', 'no-referrer' );
	return $res;
}
/* Yalnızca bugünün girişi: istemci tarih gönderirse sunucunun bugünüyle aynı olmalı */
function sides_pl_tarih_denetim( $p ) {
	$b = sides_pl_bugun();
	if ( isset( $p['tarih'] ) && (string) $p['tarih'] !== $b ) {
		return sides_pl_hata( 'sides_pl_tarih', 'Bu linkle yalnızca bugünün (' . substr( $b, 8, 2 ) . '.' . substr( $b, 5, 2 ) . '.' . substr( $b, 0, 4 ) . ') kaydı girilebilir; geçmiş ya da ileri tarih kabul edilmez.', 400 );
	}
	return null;
}
/* Bugün girilebilen kriter seçenekleri (linkin alt kümesiyle) */
function sides_pl_kriterler( $x ) {
	$izinli = isset( $x['d']['kriterler'] ) ? array_map( 'strval', (array) $x['d']['kriterler'] ) : array();
	$bugun  = sides_pl_bugun();
	$hg     = (int) gmdate( 'N', strtotime( $bugun . ' 12:00:00' ) );
	$out    = array();
	foreach ( sides_puan_docs( $x['org'], 'pkriter' ) as $k ) {
		if ( 'aktif' !== ( $k['durum'] ?? 'aktif' ) || 'manuel' === ( $k['giris'] ?? '' ) || ( $izinli && ! in_array( (string) $k['id'], $izinli, true ) ) ) {
			continue;
		}
		if ( ! isset( $k['deger'] ) || null === $k['deger'] || '' === $k['deger'] || ! is_numeric( $k['deger'] ) ) {
			continue;
		}
		if ( ! empty( $k['gecerlilik'] ) && sides_puan_tarih_mi( $k['gecerlilik'] ) && $bugun < $k['gecerlilik'] ) {
			continue;
		}
		if ( ! empty( $k['kapsam']['gunler'] ) && is_array( $k['kapsam']['gunler'] ) && ! in_array( $hg, array_map( 'intval', $k['kapsam']['gunler'] ), true ) ) {
			continue;
		}
		$yon   = in_array( $k['yon'] ?? '-', array( '-', '+', '±' ), true ) ? $k['yon'] : '-';
		$dv    = (float) $k['deger'];
		$out[] = array(
			'id'       => (string) $k['id'],
			'ad'       => mb_substr( (string) ( $k['ad'] ?? '' ), 0, 80 ),
			'grup'     => (string) ( $k['grup'] ?? '' ),
			'aciklama' => mb_substr( (string) ( $k['aciklama'] ?? '' ), 0, 160 ),
			'd'        => round( '+' === $yon ? abs( $dv ) : ( '-' === $yon ? -abs( $dv ) : $dv ), 2 ),
			'vakitler' => ! empty( $k['vakitler'] ) && is_array( $k['vakitler'] ) ? array_values( array_intersect( SIDES_PUAN_VAKIT, $k['vakitler'] ) ) : array(),
			'sira'     => (float) ( $k['sira'] ?? 0 ),
		);
	}
	usort( $out, function ( $a, $b ) {
		return ( $a['sira'] <=> $b['sira'] ) ?: strcmp( $a['ad'], $b['ad'] );
	} );
	return $out;
}
/* Öğrencilerin bugünkü puan durumu: etki ve işaretler [hareketId, kriterId, vakit, buLink].
   Etki, uygulamadaki hızlı girişle aynı kuralla hesaplanır (pnGunEtki: iptal ve haftalık ek düzeltmeler hariç; çakışma kuralı
   'gelmeme' ise aynı vakitte gelmeme varken geç gelme sayılmaz). Okuma yalnızca bugünün (ya da tek öğrencinin) satırlarıyla sınırlıdır. */
function sides_pl_puan_durum( $x, $ids ) {
	$bugun = sides_pl_bugun();
	$set   = array_flip( array_map( 'strval', $ids ) );
	$gm    = 'gelmeme' === sides_puan_ayar( $x['org'] )['cakisma'];
	$like  = 1 === count( $ids ) ? '"studentId":"' . reset( $ids ) . '"' : '"tarih":"' . $bugun . '"';
	$H     = array();
	foreach ( sides_puan_docs( $x['org'], 'phareket', $bugun, $bugun, $like ) as $h ) {
		$sid = (string) ( $h['studentId'] ?? '' );
		if ( isset( $set[ $sid ] ) && empty( $h['iptal'] ) && 'haftalik' !== ( $h['kaynak'] ?? '' ) && ( $h['tarih'] ?? '' ) === $bugun ) {
			$H[ $sid ][] = $h;
		}
	}
	$etki = array();
	$is   = array();
	foreach ( $H as $sid => $L ) {
		usort( $L, function ( $a, $b ) {
			return (int) ( $a['t'] ?? 0 ) <=> (int) ( $b['t'] ?? 0 );
		} );
		$gv = array();
		foreach ( $L as $h ) {
			if ( $gm && 'gelmeme' === ( $h['grup'] ?? '' ) && ! empty( $h['vakit'] ) ) {
				$gv[ $h['vakit'] ] = true;
			}
		}
		$e = 0.0;
		foreach ( $L as $h ) {
			if ( ! ( $gm && 'gec' === ( $h['grup'] ?? '' ) && ! empty( $h['vakit'] ) && isset( $gv[ $h['vakit'] ] ) ) ) {
				$e += (float) ( $h['etki'] ?? 0 );
			}
			$is[ $sid ][] = array( (string) $h['id'], (string) ( $h['kriterId'] ?? '' ), $h['vakit'] ?? null, ( $h['linkId'] ?? '' ) === $x['id'] ? 1 : 0 );
		}
		$etki[ $sid ] = round( $e, 4 );
	}
	return array( 'etki' => (object) $etki, 'isaret' => (object) $is );
}
function sides_pl_yoklama_durum( $org, $ids ) {
	$d   = sides_get_doc( $org, 'yoklama', sides_pl_bugun() );
	$set = array_flip( array_map( 'strval', $ids ) );
	$o   = array();
	$m   = array();
	foreach ( is_array( $d ) && isset( $d['o'] ) && is_array( $d['o'] ) ? $d['o'] : array() as $k => $v ) {
		if ( ! sides_yoklama_alan( $k ) || ! is_array( $v ) ) {
			continue;
		}
		$o[]     = array( 'k' => (string) $k, 'n' => (int) substr( $k, 1 ), 'ad' => (string) ( $v['ad'] ?? '' ), 'saat' => (string) ( $v['saat'] ?? '' ) );
		$m[ $k ] = new stdClass();
		if ( isset( $d[ $k ] ) && is_array( $d[ $k ] ) ) {
			$m[ $k ] = (object) array_intersect_key( $d[ $k ], $set );
		}
	}
	usort( $o, function ( $a, $b ) {
		return $a['n'] <=> $b['n'];
	} );
	return array( 'o' => $o, 'm' => (object) $m );
}
/* GET pl/<token>[?sinif=&sube=] */
function sides_pl_oku( $x, WP_REST_Request $req ) {
	$d   = $x['d'];
	$iz  = sides_pl_izin( $x );
	$all = sides_tko_sinif_ogr( $x['org'], sides_pl_siniflar( $x ) );
	$sec = array();
	foreach ( $all as $k => $l ) {
		list( $g, $b ) = explode( '|', $k, 2 );
		$sec[] = array( 'sinif' => $g, 'sube' => $b, 'n' => count( $l ) );
	}
	$set  = sides_get_doc( $x['org'], 'settings', 'main' );
	$ayar = sides_puan_ayar( $x['org'] );
	$out  = array(
		'ad'       => isset( $d['ad'] ) ? (string) $d['ad'] : '',
		'kurum'    => $set && isset( $set['kurum'] ) ? (string) $set['kurum'] : '',
		'logo'     => $set && isset( $set['logo'] ) ? (string) $set['logo'] : '',
		'bas'      => (string) ( $d['bas'] ?? '' ),
		'bit'      => (string) ( $d['bit'] ?? '' ),
		'bugun'    => sides_pl_bugun(),
		'simdi'    => sides_pl_an(),
		'izin'     => $iz,
		'siniflar' => $sec,
	);
	if ( '' !== (string) $req['sinif'] ) {
		$g = trim( (string) $req['sinif'] );
		$b = mb_strtoupper( trim( (string) $req['sube'] ), 'UTF-8' );
		if ( ! isset( $all[ $g . '|' . $b ] ) ) {
			return sides_pl_hata( 'sides_yetki', 'Bu sınıf bu linkin kapsamında değil.', 403 );
		}
		$l = array_values( $all[ $g . '|' . $b ] );
		usort( $l, function ( $p, $q ) {
			return ( (int) $p['no'] <=> (int) $q['no'] ) ?: strcmp( $p['ad'], $q['ad'] );
		} );
		$ids               = array_column( $l, 'id' );
		$out['ogrenciler'] = $l;
		if ( $iz['puan'] ) {
			$out['puan'] = array_merge( array(
				'kriterler' => sides_pl_kriterler( $x ),
				'baslangic' => (float) $ayar['baslangic'],
				'kapali'    => isset( $ayar['kapali'][ sides_puan_hafta_basi( $out['bugun'] ) ] ),
			), sides_pl_puan_durum( $x, $ids ) );
		}
		if ( $iz['yoklama'] ) {
			$out['yoklama'] = sides_pl_yoklama_durum( $x['org'], $ids );
		}
	}
	return $out;
}
/* Kullanım sayacı ve son 40 giriş (denetim için; kilit altında) */
function sides_pl_say( $x, $tip, $s, $detay ) {
	$kl = sides_pl_kilit( $x['org'] . '|plink|' . $x['id'] );
	$d  = sides_get_doc( $x['org'], 'plink', $x['id'] );
	if ( $d ) {
		unset( $d['id'] );
		$b           = sides_pl_bugun();
		$d['say']    = (int) ( $d['say'] ?? 0 ) + 1;
		$d['gunSay'] = array( 'g' => $b, 'n' => ( ( $d['gunSay']['g'] ?? '' ) === $b ? (int) $d['gunSay']['n'] : 0 ) + 1 );
		$d['son']    = array( 't' => sides_pl_ms(), 'tip' => $tip, 'sinif' => $s ? $s['sinif'] . ( $s['sube'] ? '/' . $s['sube'] : '' ) : '' );
		$g           = isset( $d['gecmis'] ) && is_array( $d['gecmis'] ) ? $d['gecmis'] : array();
		array_unshift( $g, array( 't' => sides_pl_ms(), 'tip' => $tip, 'o' => $s ? $s['ad'] : '', 'x' => mb_substr( (string) $detay, 0, 80 ) ) );
		$d['gecmis'] = array_slice( $g, 0, 40 );
		sides_put_doc( $x['org'], 'plink', $x['id'], $d );
	}
	sides_pl_birak( $kl );
}
/* POST pl/<token>/puan { islemId, studentId, kriterId, vakit, tarih } — dokunuş başına bir hareket (aynı islemId ikinci kayıt üretmez) */
function sides_pl_puan( $x, WP_REST_Request $req ) {
	$org = $x['org'];
	$p   = $req->get_json_params();
	$p   = is_array( $p ) ? $p : array();
	if ( ! sides_pl_izin( $x )['puan'] ) {
		return sides_pl_hata( 'sides_yetki', 'Bu link puan girişine izin vermiyor.', 403 );
	}
	$e = sides_pl_tarih_denetim( $p );
	if ( $e ) {
		return $e;
	}
	$bugun = sides_pl_bugun();
	$islem = isset( $p['islemId'] ) ? (string) $p['islemId'] : '';
	if ( ! preg_match( '/^[A-Za-z0-9_\-]{4,40}$/', $islem ) ) {
		return sides_pl_hata( 'sides_gecersiz', 'İşlem kimliği geçersiz.', 400 );
	}
	$s = sides_pl_ogrenci( $x, isset( $p['studentId'] ) ? (string) $p['studentId'] : '' );
	if ( ! $s ) {
		return sides_pl_hata( 'sides_yetki', 'Bu öğrenci bu linkin kapsamında değil.', 403 );
	}
	$var = sides_get_doc( $org, 'phareket', $islem );
	if ( $var ) {
		if ( ( $var['linkId'] ?? '' ) !== $x['id'] || ( $var['studentId'] ?? '' ) !== $s['id'] ) {
			return sides_pl_hata( 'sides_gecersiz', 'Bu işlem kimliği başka bir kayıtta kullanılmış.', 409 );
		}
		return array( 'ok' => true, 'mevcut' => true, 'id' => $islem, 'ogr' => sides_pl_puan_durum( $x, array( $s['id'] ) ) );
	}
	$kid = isset( $p['kriterId'] ) ? (string) $p['kriterId'] : '';
	$opt = null;
	foreach ( sides_pl_kriterler( $x ) as $o ) {
		if ( $o['id'] === $kid ) {
			$opt = $o;
		}
	}
	if ( ! $opt ) {
		return sides_pl_hata( 'sides_yetki', 'Bu kriter bu linkle bugün girilemez.', 403 );
	}
	$vakit = isset( $p['vakit'] ) && '' !== $p['vakit'] && null !== $p['vakit'] ? (string) $p['vakit'] : null;
	if ( $opt['vakitler'] ? ! in_array( $vakit, $opt['vakitler'], true ) : null !== $vakit ) {
		return sides_pl_hata( 'sides_gecersiz', $opt['vakitler'] ? 'Bu kriter için vakit seçilmeli.' : 'Bu kriterde vakit yok.', 400 );
	}
	$ayar = sides_puan_ayar( $org );
	if ( isset( $ayar['kapali'][ sides_puan_hafta_basi( $bugun ) ] ) ) {
		return sides_pl_hata( 'sides_puan', 'Bu hafta kapatılmış; linkten puan girilemez.', 409 );
	}
	$kl  = sides_pl_kilit( $org . '|phgun|' . $s['id'] . '|' . $bugun );
	$var = sides_get_doc( $org, 'phareket', $islem );   // aynı işlem kilit beklerken yazılmış olabilir
	if ( $var ) {
		sides_pl_birak( $kl );
		return array( 'ok' => true, 'mevcut' => true, 'id' => $islem, 'ogr' => sides_pl_puan_durum( $x, array( $s['id'] ) ) );
	}
	$kr     = sides_get_doc( $org, 'pkriter', $kid );
	$grup   = (string) ( $kr['grup'] ?? '' );
	$ayni   = sides_puan_docs( $org, 'phareket', $bugun, $bugun, '"studentId":"' . $s['id'] . '"' );
	$tekrar = max( 1, (int) ( $kr['tekrar'] ?? 1 ) );
	$aktif  = 0;
	$hata   = null;
	foreach ( $ayni as $h ) {
		if ( empty( $h['iptal'] ) && ( $h['kriterId'] ?? '' ) === $kid && ( $h['vakit'] ?? null ) === $vakit && 'haftalik' !== ( $h['kaynak'] ?? '' ) ) {
			$aktif++;
		}
		if ( 'engelle' === $ayar['cakisma'] && $vakit && in_array( $grup, array( 'gec', 'gelmeme' ), true ) && empty( $h['iptal'] ) && ( $h['grup'] ?? '' ) === ( 'gec' === $grup ? 'gelmeme' : 'gec' ) && ( $h['vakit'] ?? null ) === $vakit ) {
			$hata = sides_pl_hata( 'sides_puan', 'Aynı vakitte geç gelme ve gelmeme birlikte işaretlenemez.', 409 );
		}
	}
	if ( $aktif >= $tekrar ) {
		$hata = sides_pl_hata( 'sides_puan', 'Bu öğrenci için "' . $opt['ad'] . '" bugün zaten işaretli. Yinelenen kayıt oluşturulmadı.', 409 );
	}
	if ( ! $hata ) {
		$d = array(
			'studentId' => $s['id'], 'tarih' => $bugun, 'kriterId' => $kid, 'grup' => $grup, 'vakit' => $vakit,
			'ad' => $opt['ad'], 'deger' => isset( $kr['deger'] ) && is_numeric( $kr['deger'] ) ? (float) $kr['deger'] : null, 'surum' => (int) ( $kr['surum'] ?? 1 ),
			'etki' => (float) $opt['d'], 'kaynak' => 'link', 'hedefHafta' => null, 'gerekce' => '', 'ogretmen' => array( 'id' => 0, 'ad' => sides_pl_kim( $x ) ),
			't' => sides_pl_ms(), 'kayitGunu' => $bugun, 'iptal' => null, 'kanaat' => null, 'izinDurum' => null, 'olay' => '',
			'linkId' => $x['id'], 'aktor' => 'shared_link',
		);
		if ( false === sides_put_doc( $org, 'phareket', $islem, $d ) ) {
			$hata = sides_pl_hata( 'sides_db', 'Kayıt yazılamadı.', 500 );
		}
	}
	sides_pl_birak( $kl );
	if ( $hata ) {
		return $hata;
	}
	$et = ( $opt['d'] > 0 ? '+' : '' ) . $opt['d'];
	$va = $vakit ? ' (' . $vakit . ')' : '';
	sides_log( $org, 'Puan (süreli link): ' . $s['ad'] . ' · ' . $opt['ad'] . $va . ' · ' . $et . ' · ' . $bugun, sides_pl_kim( $x ) );
	sides_pl_say( $x, 'puan', $s, $opt['ad'] . $va . ' ' . $et );
	return array( 'ok' => true, 'mevcut' => false, 'id' => $islem, 'ogr' => sides_pl_puan_durum( $x, array( $s['id'] ) ) );
}
/* POST pl/<token>/iptal { id, tarih } — yalnızca bu linkle bugün girilmiş hareket iptal edilir (kayıt silinmez) */
function sides_pl_iptal( $x, WP_REST_Request $req ) {
	$org = $x['org'];
	$p   = $req->get_json_params();
	$p   = is_array( $p ) ? $p : array();
	if ( ! sides_pl_izin( $x )['puan'] ) {
		return sides_pl_hata( 'sides_yetki', 'Bu link puan girişine izin vermiyor.', 403 );
	}
	$e = sides_pl_tarih_denetim( $p );
	if ( $e ) {
		return $e;
	}
	$id = isset( $p['id'] ) ? preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $p['id'] ) : '';
	$h  = $id ? sides_get_doc( $org, 'phareket', $id ) : null;
	if ( ! $h ) {
		return sides_pl_hata( 'sides_yok', 'İşaret bulunamadı; liste yenileniyor.', 404 );
	}
	if ( ( $h['linkId'] ?? '' ) !== $x['id'] ) {
		return sides_pl_hata( 'sides_yetki', 'Yalnızca bu linkle girilen işaretler kaldırılabilir.', 403 );
	}
	$s = sides_pl_ogrenci( $x, (string) ( $h['studentId'] ?? '' ) );
	if ( ! $s ) {
		return sides_pl_hata( 'sides_yetki', 'Bu öğrenci bu linkin kapsamında değil.', 403 );
	}
	$bugun = sides_pl_bugun();
	if ( ( $h['tarih'] ?? '' ) !== $bugun ) {
		return sides_pl_hata( 'sides_pl_tarih', 'Yalnızca bugünün işaretleri kaldırılabilir.', 409 );
	}
	if ( ! empty( $h['iptal'] ) ) {
		return array( 'ok' => true, 'mevcut' => true, 'ogr' => sides_pl_puan_durum( $x, array( $s['id'] ) ) );
	}
	$ayar = sides_puan_ayar( $org );
	if ( isset( $ayar['kapali'][ sides_puan_hafta_basi( $bugun ) ] ) ) {
		return sides_pl_hata( 'sides_puan', 'Bu hafta kapatılmış; linkten değişiklik yapılamaz.', 409 );
	}
	unset( $h['id'] );
	$h['iptal'] = array( 't' => sides_pl_ms(), 'ogretmen' => array( 'id' => 0, 'ad' => sides_pl_kim( $x ) ), 'gerekce' => 'İşaret kaldırıldı (süreli link)' );
	if ( false === sides_put_doc( $org, 'phareket', $id, $h ) ) {
		return sides_pl_hata( 'sides_db', 'Kayıt yazılamadı.', 500 );
	}
	sides_log( $org, 'Puan iptali (süreli link): ' . $s['ad'] . ' · ' . ( $h['ad'] ?? '' ) . ' · ' . $bugun, sides_pl_kim( $x ) );
	sides_pl_say( $x, 'iptal', $s, ( $h['ad'] ?? '' ) . ( ! empty( $h['vakit'] ) ? ' (' . $h['vakit'] . ')' : '' ) );
	return array( 'ok' => true, 'mevcut' => false, 'ogr' => sides_pl_puan_durum( $x, array( $s['id'] ) ) );
}
/* Değişiklik geçmişi (takip.php sides_tk_gecmis_yaz ile aynı biçim; aktör linkin adı) */
function sides_pl_gecmis_yaz( $x, $coll, $id, $alan, $once, $sonra ) {
	$deg = array();
	foreach ( array_unique( array_merge( array_keys( (array) $once ), array_keys( (array) $sonra ) ) ) as $k ) {
		$e = isset( $once[ $k ] ) ? $once[ $k ] : null;
		$y = isset( $sonra[ $k ] ) ? $sonra[ $k ] : null;
		if ( $e !== $y ) {
			$deg[] = array( (string) $k, $e, $y );
		}
	}
	if ( ! $deg ) {
		return;
	}
	$org = $x['org'];
	$ay  = 'g' . gmdate( 'Y-m' );
	$kl  = sides_pl_kilit( $org . '|tkgecmis|' . $ay );
	$doc = sides_get_doc( $org, 'tkgecmis', $ay );
	$L   = is_array( $doc ) && isset( $doc['k'] ) ? (array) $doc['k'] : array();
	foreach ( $deg as $z ) {
		$L[] = array( 't' => time(), 'u' => 0, 'ad' => sides_pl_kim( $x ), 'c' => $coll, 'i' => (string) $id, 'a' => $alan, 's' => $z[0], 'e' => $z[1], 'y' => $z[2], 'link' => $x['id'] );
	}
	if ( count( $L ) > 6000 ) {
		$L = array_slice( $L, -6000 );
	}
	sides_put_doc( $org, 'tkgecmis', $ay, array( 'k' => $L ) );
	sides_pl_birak( $kl );
}
/* POST pl/<token>/yoklama { islem: 'ekle', islemId, ad } | { islem: 'isaret', k, sid, d, once? } — yoklama/<bugün> */
function sides_pl_yoklama( $x, WP_REST_Request $req ) {
	$org = $x['org'];
	$p   = $req->get_json_params();
	$p   = is_array( $p ) ? $p : array();
	if ( ! sides_pl_izin( $x )['yoklama'] ) {
		return sides_pl_hata( 'sides_yetki', 'Bu link yoklama girişine izin vermiyor.', 403 );
	}
	$e = sides_pl_tarih_denetim( $p );
	if ( $e ) {
		return $e;
	}
	$id    = sides_pl_bugun();
	$islem = isset( $p['islem'] ) ? (string) $p['islem'] : '';
	if ( 'ekle' === $islem ) {
		$iid = isset( $p['islemId'] ) ? (string) $p['islemId'] : '';
		if ( ! preg_match( '/^[A-Za-z0-9_\-]{4,40}$/', $iid ) ) {
			return sides_pl_hata( 'sides_gecersiz', 'İşlem kimliği geçersiz.', 400 );
		}
		$ad = mb_substr( trim( sanitize_text_field( isset( $p['ad'] ) ? (string) $p['ad'] : '' ) ), 0, 40 );
	} elseif ( 'isaret' === $islem ) {
		$k = isset( $p['k'] ) ? (string) $p['k'] : '';
		$v = isset( $p['d'] ) && '' !== $p['d'] && null !== $p['d'] ? (string) $p['d'] : null;
		if ( ! sides_yoklama_alan( $k ) || ( null !== $v && ! in_array( $v, SIDES_PL_YK, true ) ) ) {
			return sides_pl_hata( 'sides_gecersiz', 'Geçersiz yoklama değeri.', 400 );
		}
		$s = sides_pl_ogrenci( $x, isset( $p['sid'] ) ? (string) $p['sid'] : '' );
		if ( ! $s ) {
			return sides_pl_hata( 'sides_yetki', 'Bu öğrenci bu linkin kapsamında değil.', 403 );
		}
	} else {
		return sides_pl_hata( 'sides_gecersiz', 'Geçersiz işlem.', 400 );
	}
	$kl = sides_pl_kilit( $org . '|yoklama|' . $id );   // uygulama içi yoklama yamasıyla aynı kilit adı
	$d  = sides_get_doc( $org, 'yoklama', $id );
	$d  = $d ? $d : array( 'tarih' => $id );
	unset( $d['id'], $d['token'] );
	$o    = isset( $d['o'] ) && is_array( $d['o'] ) ? $d['o'] : array();
	$hata = null;
	$sonuc = null;
	if ( 'ekle' === $islem ) {
		$tk  = 'sides_plyk_' . md5( $org . '|' . $x['id'] . '|' . $id . '|' . $iid );
		$onc = get_transient( $tk );
		if ( $onc && isset( $o[ $onc ] ) ) {
			$sonuc = array( 'ok' => true, 'mevcut' => true, 'k' => $onc );
		} else {
			$n = 0;
			foreach ( $o as $kk => $vv ) {
				if ( sides_yoklama_alan( $kk ) && $vv ) {
					$n = max( $n, (int) substr( $kk, 1 ) );
				}
			}
			$n++;
			if ( $n > 30 ) {
				$hata = sides_pl_hata( 'sides_gecersiz', 'Bir günde en fazla 30 yoklama alınabilir.', 409 );
			} else {
				$once       = $o;
				$o[ 'y' . $n ] = array( 'ad' => $ad, 'saat' => sides_pl_simdi()->format( 'H:i' ) );
				$d['o']     = (object) $o;
				if ( false === sides_put_doc( $org, 'yoklama', $id, $d ) ) {
					$hata = sides_pl_hata( 'sides_db', 'Kaydedilemedi.', 500 );
				} else {
					set_transient( $tk, 'y' . $n, 900 );
					sides_pl_gecmis_yaz( $x, 'yoklama', $id, 'o', $once, $o );
					$sonuc = array( 'ok' => true, 'mevcut' => false, 'k' => 'y' . $n );
				}
			}
		}
	} else {
		if ( empty( $o[ $k ] ) ) {
			$hata = sides_pl_hata( 'sides_yok', 'Bu yoklama bulunamadı (silinmiş olabilir); liste yenileniyor.', 404 );
		} else {
			$m   = isset( $d[ $k ] ) && is_array( $d[ $k ] ) ? $d[ $k ] : array();
			$cur = isset( $m[ $s['id'] ] ) ? (string) $m[ $s['id'] ] : '';
			if ( array_key_exists( 'once', $p ) && (string) $p['once'] !== $cur && $cur !== (string) $v ) {
				$ad2  = array( 'V' => 'Var', 'Y' => 'Yok', 'G' => 'Geç', 'I' => 'İzinli', 'H' => 'Hasta' );
				$hata = new WP_Error( 'sides_surum', $s['ad'] . ' az önce başka biri tarafından işaretlendi (' . ( $ad2[ $cur ] ?? 'boş' ) . '). Yeni değer gösteriliyor; gerekirse tekrar dokunun.', array( 'status' => 409, 'mevcut' => $cur ) );
			} else {
				$once = $m;
				if ( null === $v ) {
					unset( $m[ $s['id'] ] );
				} else {
					$m[ $s['id'] ] = $v;
				}
				$d[ $k ] = (object) $m;
				if ( false === sides_put_doc( $org, 'yoklama', $id, $d ) ) {
					$hata = sides_pl_hata( 'sides_db', 'Kaydedilemedi.', 500 );
				} else {
					sides_pl_gecmis_yaz( $x, 'yoklama', $id, $k, $once, $m );
					$sonuc = array( 'ok' => true, 'k' => $k, 'sid' => $s['id'], 'v' => $v );
				}
			}
		}
	}
	sides_pl_birak( $kl );
	if ( $hata ) {
		return $hata;
	}
	if ( empty( $sonuc['mevcut'] ) ) {
		$on = isset( $o[ $sonuc['k'] ]['ad'] ) && '' !== $o[ $sonuc['k'] ]['ad'] ? $o[ $sonuc['k'] ]['ad'] : substr( $sonuc['k'], 1 ) . '. yoklama';
		if ( 'ekle' === $islem ) {
			sides_log( $org, 'Yoklama başlatıldı (süreli link): ' . $on . ' · ' . $id, sides_pl_kim( $x ) );
			sides_pl_say( $x, 'yoklamaEkle', null, $on );
		} else {
			$ad2 = array( 'V' => 'Var', 'Y' => 'Yok', 'G' => 'Geç', 'I' => 'İzinli', 'H' => 'Hasta' );
			sides_pl_say( $x, 'yoklama', $s, $on . ': ' . ( null === $v ? 'işaret kaldırıldı' : $ad2[ $v ] ) );
		}
	}
	if ( 'ekle' === $islem ) {
		$sonuc['o'] = sides_pl_yoklama_durum( $org, array() )['o'];
	}
	return $sonuc;
}
