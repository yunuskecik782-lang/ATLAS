<?php
/**
 * ATLAS veri yedekleme ve geri yükleme.
 *
 * Yedek dosyası (.sidesyedek) gzip ile sıkıştırılmış, her satırı bir JSON nesnesi olan metindir:
 *   başlık · {"s":seçenek} · {"u":kullanıcı} · {"o":kurum} · {"k":kod} · {"d":kayıt} · {"son":{sayılar}}
 * Satır satır yazılıp okunduğu için büyük veride de bellek sorunu çıkmaz.
 *
 * Otomatik yedekler: her gece (site geneli), her eklenti güncellemesinden önce ve her geri yüklemeden önce.
 * Dosyalar wp-content/uploads/sides-yedek klasöründe, tahmin edilemeyen adlarla ve dışarıdan erişime kapalı tutulur.
 *
 * @package SIDES
 */

defined( 'ABSPATH' ) || exit;

define( 'SIDES_YEDEK_SURUM', 1 );
define( 'SIDES_YEDEK_TURLER', array( 'gunluk', 'guncelleme', 'elle', 'geri-oncesi', 'yuklenen' ) );
define( 'SIDES_YEDEK_SECENEKLER', array( 'sides_kayit_yontemi', 'sides_eposta_dogrulama', 'sides_yedek_ayar' ) );

function sides_yedek_ayar() {
	$a = get_option( 'sides_yedek_ayar' );
	$a = is_array( $a ) ? $a : array();
	return array(
		'gunluk' => isset( $a['gunluk'] ) ? (bool) $a['gunluk'] : true,
		'sakla'  => isset( $a['sakla'] ) ? max( 1, min( 10, (int) $a['sakla'] ) ) : 2,
	);
}

function sides_yedek_dir() {
	$u = wp_upload_dir( null, false );
	$d = trailingslashit( $u['basedir'] ) . 'sides-yedek';
	if ( ! is_dir( $d ) ) {
		wp_mkdir_p( $d );
	}
	$koru = array(
		'.htaccess'  => "# ATLAS yedekleri dışarıdan indirilemez\nRequire all denied\n<IfModule !mod_authz_core.c>\nOrder allow,deny\nDeny from all\n</IfModule>\n",
		'index.php'  => "<?php\n// Silence is golden.\n",
		'web.config' => "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n<configuration><system.webServer><authorization><deny users=\"*\" /></authorization></system.webServer></configuration>\n",
	);
	foreach ( $koru as $f => $icerik ) {
		if ( ! file_exists( "$d/$f" ) ) {
			@file_put_contents( "$d/$f", $icerik ); // phpcs:ignore
		}
	}
	return $d;
}

/* Yedek dizini (dosya adı → bilgi) */
function sides_yedek_dizin() {
	$l = get_option( 'sides_yedekler' );
	return is_array( $l ) ? $l : array();
}
function sides_yedek_dizin_kaydet( $l ) {
	update_option( 'sides_yedekler', $l, false );
}
function sides_yedek_ad_gecerli( $dosya ) {
	return is_string( $dosya ) && preg_match( '/^sides-[a-z\-]+-(site|k\d+)-\d{8}-\d{6}-[a-f0-9]{16}\.sidesyedek$/', $dosya );
}
function sides_yedek_yol( $dosya ) {
	return sides_yedek_ad_gecerli( $dosya ) ? sides_yedek_dir() . '/' . $dosya : '';
}
function sides_yedek_liste() {
	$l   = sides_yedek_dizin();
	$dir = sides_yedek_dir();
	$deg = false;
	foreach ( $l as $k => $x ) {
		if ( ! file_exists( "$dir/$k" ) ) {
			unset( $l[ $k ] );
			$deg = true;
		}
	}
	if ( $deg ) {
		sides_yedek_dizin_kaydet( $l );
	}
	uasort( $l, function ( $a, $b ) {
		return $b['t'] - $a['t'];
	} );
	return $l;
}

/* Aynı türden (ve aynı kurumdan) eski yedekler silinir */
function sides_yedek_temizle() {
	$ayar = sides_yedek_ayar();
	$l    = sides_yedek_liste();
	$grup = array();
	foreach ( $l as $k => $x ) {
		$grup[ $x['tur'] . '|' . $x['kapsam'] . '|' . (int) $x['org'] ][] = $k;
	}
	$dir = sides_yedek_dir();
	foreach ( $grup as $g => $dosyalar ) {
		list( $tur, $kapsam ) = explode( '|', $g );
		$sakla = 'gunluk' === $tur ? $ayar['sakla'] : ( 'elle' === $tur ? ( 'site' === $kapsam ? 5 : 3 ) : 2 );
		foreach ( array_slice( $dosyalar, $sakla ) as $k ) {
			@unlink( "$dir/$k" ); // phpcs:ignore
			unset( $l[ $k ] );
		}
	}
	sides_yedek_dizin_kaydet( $l );
}

function sides_yedek_satir( $gz, $a ) {
	return false !== gzwrite( $gz, wp_json_encode( $a, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "\n" );
}

/**
 * Yedek alır. $kapsam 'site' (tüm kurumlar, kodlar, kullanıcılar ve ayarlar) veya 'kurum' (tek kurumun verileri).
 */
function sides_yedek_yaz( $kapsam, $org, $tur ) {
	global $wpdb;
	if ( ! function_exists( 'gzopen' ) ) {
		return new WP_Error( 'sides_yedek', 'Sunucuda sıkıştırma (zlib) desteği yok; yedek alınamadı.', array( 'status' => 500 ) );
	}
	@set_time_limit( 300 ); // phpcs:ignore
	$site  = 'site' === $kapsam;
	$org   = $site ? 0 : (int) $org;
	$docs  = sides_docs();
	$orgs  = sides_orgs();
	$kodT  = $wpdb->prefix . 'sides_kodlar';
	$dir   = sides_yedek_dir();
	$dosya = 'sides-' . $tur . '-' . ( $site ? 'site' : 'k' . $org ) . '-' . gmdate( 'Ymd-His' ) . '-' . bin2hex( random_bytes( 8 ) ) . '.sidesyedek';
	$yol   = "$dir/$dosya";
	$gz    = @gzopen( $yol, 'wb6' ); // phpcs:ignore
	if ( ! $gz ) {
		update_option( 'sides_yedek_hata', array( 't' => time(), 'm' => 'Yedek klasörüne yazılamadı: ' . $dir ), false );
		return new WP_Error( 'sides_yedek', 'Yedek dosyası oluşturulamadı. Sunucudaki yükleme klasörünün yazılabilir olduğundan emin olun.', array( 'status' => 500 ) );
	}
	$o      = $site ? null : sides_org( $org );
	$sayi   = array();
	$orgSay = array();
	$satir  = 0;
	$ok     = sides_yedek_satir( $gz, array(
		'sides_yedek' => SIDES_YEDEK_SURUM,
		'surum'       => OPTIK_KARNE_VER,
		'db'          => SIDES_DB_VER,
		't'           => time(),
		'site'        => home_url(),
		'kapsam'      => $site ? 'site' : 'kurum',
		'org'         => $o ? array( 'id' => (int) $o->id, 'ad' => $o->ad ) : null,
		'tur'         => $tur,
	) );
	if ( $site ) {
		foreach ( SIDES_YEDEK_SECENEKLER as $s ) {
			$v = get_option( $s, null );
			if ( null !== $v ) {
				$ok = $ok && sides_yedek_satir( $gz, array( 's' => array( 'ad' => $s, 'v' => $v ) ) );
			}
		}
	}
	// kullanıcılar (site yedeğinde şifre özetleriyle; kurum yedeğinde yalnızca ad, e-posta, rol ve yetkiler)
	$q = array( 'meta_key' => 'sides_org', 'number' => -1 ); // phpcs:ignore
	if ( ! $site ) {
		$q['meta_value'] = $org; // phpcs:ignore
	}
	foreach ( get_users( $q ) as $u ) {
		$x = array(
			'id'    => (int) $u->ID,
			'login' => $u->user_login,
			'email' => $u->user_email,
			'ad'    => $u->display_name,
			'roller'=> array_values( (array) $u->roles ),
			'meta'  => array(
				'sides_org'    => (int) get_user_meta( $u->ID, 'sides_org', true ),
				'sides_rol'    => (string) get_user_meta( $u->ID, 'sides_rol', true ),
				'sides_yetki'  => get_user_meta( $u->ID, 'sides_yetki', true ),
				'sides_avatar' => (string) get_user_meta( $u->ID, 'sides_avatar', true ),
				'sides_sayfa'  => get_user_meta( $u->ID, 'sides_sayfa', true ),
			),
		);
		if ( $site ) {
			$x['pass'] = $u->user_pass;
		}
		$ok = $ok && sides_yedek_satir( $gz, array( 'u' => $x ) );
		$sayi['kullanici'] = ( isset( $sayi['kullanici'] ) ? $sayi['kullanici'] : 0 ) + 1;
	}
	$ol = $site ? $wpdb->get_results( "SELECT * FROM $orgs ORDER BY id", ARRAY_A ) : $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $orgs WHERE id = %d", $org ), ARRAY_A ); // phpcs:ignore
	foreach ( (array) $ol as $r ) {
		$ok = $ok && sides_yedek_satir( $gz, array( 'o' => $r ) );
	}
	if ( $site ) {
		foreach ( (array) $wpdb->get_results( "SELECT * FROM $kodT ORDER BY kod", ARRAY_A ) as $r ) { // phpcs:ignore
			$ok = $ok && sides_yedek_satir( $gz, array( 'k' => $r ) );
		}
	}
	$off = 0;
	do {
		$rows = $site
			? $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $docs ORDER BY org, coll, id LIMIT 200 OFFSET %d", $off ), ARRAY_A ) // phpcs:ignore
			: $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $docs WHERE org = %d ORDER BY coll, id LIMIT 200 OFFSET %d", $org, $off ), ARRAY_A ); // phpcs:ignore
		foreach ( (array) $rows as $r ) {
			$ok = $ok && sides_yedek_satir( $gz, array( 'd' => $r ) );
			$c  = $r['coll'];
			$sayi[ $c ] = ( isset( $sayi[ $c ] ) ? $sayi[ $c ] : 0 ) + 1;
			if ( $site ) {
				$orgSay[ $r['org'] ][ $c ] = ( isset( $orgSay[ $r['org'] ][ $c ] ) ? $orgSay[ $r['org'] ][ $c ] : 0 ) + 1;
			}
			$satir++;
		}
		$off += 200;
	} while ( $rows && count( $rows ) === 200 && $ok );
	$ok = $ok && sides_yedek_satir( $gz, array( 'son' => array( 'sayilar' => $sayi, 'orgSayilari' => $orgSay, 'satir' => $satir ) ) );
	gzclose( $gz );
	if ( ! $ok ) {
		@unlink( $yol ); // phpcs:ignore
		update_option( 'sides_yedek_hata', array( 't' => time(), 'm' => 'Yedek yazılırken disk hatası oluştu.' ), false );
		return new WP_Error( 'sides_yedek', 'Yedek yazılırken hata oluştu (disk dolu olabilir).', array( 'status' => 500 ) );
	}
	$bilgi = array(
		'dosya'       => $dosya,
		'tur'         => $tur,
		'kapsam'      => $site ? 'site' : 'kurum',
		'org'         => $org,
		'orgAd'       => $o ? $o->ad : '',
		't'           => time(),
		'boyut'       => (int) filesize( $yol ),
		'surum'       => OPTIK_KARNE_VER,
		'sayilar'     => $sayi,
		'orgSayilari' => $orgSay,
	);
	$l           = sides_yedek_dizin();
	$l[ $dosya ] = $bilgi;
	sides_yedek_dizin_kaydet( $l );
	delete_option( 'sides_yedek_hata' );
	sides_yedek_temizle();
	return $bilgi;
}

/* Dosyayı satır satır okur; $fn(satır dizisi) false dönerse durur */
function sides_yedek_oku( $yol, $fn ) {
	$gz = @gzopen( $yol, 'rb' ); // phpcs:ignore
	if ( ! $gz ) {
		return new WP_Error( 'sides_yedek', 'Yedek dosyası açılamadı.', array( 'status' => 400 ) );
	}
	$ilk = true;
	while ( ! gzeof( $gz ) ) {
		$l = gzgets( $gz );
		if ( false === $l ) {
			break;
		}
		$l = trim( $l );
		if ( '' === $l ) {
			continue;
		}
		$a = json_decode( $l, true );
		if ( ! is_array( $a ) || ( $ilk && empty( $a['sides_yedek'] ) ) ) {
			gzclose( $gz );
			return new WP_Error( 'sides_yedek', $ilk ? 'Bu dosya bir ATLAS yedeği değil.' : 'Yedek dosyası bozuk (okunamayan satır).', array( 'status' => 400 ) );
		}
		$ilk = false;
		if ( false === $fn( $a ) ) {
			break;
		}
	}
	gzclose( $gz );
	return true;
}
/* Başlık ve sayılar (dosyanın tamamı okunarak) */
function sides_yedek_ozet( $yol ) {
	$bas = null;
	$son = null;
	$r   = sides_yedek_oku( $yol, function ( $a ) use ( &$bas, &$son ) {
		if ( null === $bas ) {
			$bas = $a;
		} elseif ( isset( $a['son'] ) ) {
			$son = $a['son'];
		}
	} );
	if ( is_wp_error( $r ) ) {
		return $r;
	}
	if ( ! $son ) {
		return new WP_Error( 'sides_yedek', 'Yedek dosyası eksik: dosyanın sonu gelmemiş (indirme yarım kalmış olabilir).', array( 'status' => 400 ) );
	}
	return array( 'bas' => $bas, 'son' => $son );
}

/**
 * Geri yükleme.
 * $hedef = 0: tüm site (yalnızca site yedeğinden). $hedef > 0: yalnızca o kurumun verileri değiştirilir;
 * dosya site yedeğiyse $kaynak numaralı kurumun satırları alınır.
 */
function sides_yedek_geri( $yol, $hedef, $kaynak = 0 ) {
	global $wpdb;
	@set_time_limit( 600 ); // phpcs:ignore
	$oz = sides_yedek_ozet( $yol );
	if ( is_wp_error( $oz ) ) {
		return $oz;
	}
	$bas  = $oz['bas'];
	$site = 'site' === $bas['kapsam'];
	if ( ! $hedef && ! $site ) {
		return new WP_Error( 'sides_yedek', 'Tüm siteyi geri yüklemek için site geneli bir yedek gerekir.', array( 'status' => 400 ) );
	}
	if ( $hedef && $site && ! $kaynak ) {
		$kaynak = $hedef;
	}
	if ( $hedef && ! sides_org( $hedef ) ) {
		return new WP_Error( 'sides_yedek', 'Hedef kurum bulunamadı.', array( 'status' => 404 ) );
	}
	// geri yüklemeden önce mevcut durumun güvenlik yedeği
	$guv = sides_yedek_yaz( $hedef ? 'kurum' : 'site', $hedef, 'geri-oncesi' );
	if ( is_wp_error( $guv ) ) {
		return new WP_Error( 'sides_yedek', 'Geri yüklemeden önce güvenlik yedeği alınamadığı için işlem yapılmadı. ' . $guv->get_error_message(), array( 'status' => 500 ) );
	}
	$docs = sides_docs();
	$orgs = sides_orgs();
	$kodT = $wpdb->prefix . 'sides_kodlar';
	$wpdb->query( 'START TRANSACTION' ); // phpcs:ignore
	if ( $hedef ) {
		$wpdb->query( $wpdb->prepare( "DELETE FROM $docs WHERE org = %d", $hedef ) ); // phpcs:ignore
	} else {
		$wpdb->query( "DELETE FROM $docs" ); // phpcs:ignore
		$wpdb->query( "DELETE FROM $orgs" ); // phpcs:ignore
		$wpdb->query( "DELETE FROM $kodT" ); // phpcs:ignore
	}
	$harita = array();
	$sonuc  = array( 'kayit' => 0, 'kullanici' => 0, 'eksikKullanici' => array(), 'bosToken' => 0 );
	$hata   = '';
	$r      = sides_yedek_oku( $yol, function ( $a ) use ( $wpdb, $hedef, $kaynak, $site, $docs, $orgs, $kodT, &$harita, &$sonuc, &$hata ) {
		if ( isset( $a['s'] ) ) {
			if ( ! $hedef && in_array( $a['s']['ad'], SIDES_YEDEK_SECENEKLER, true ) ) {
				update_option( $a['s']['ad'], $a['s']['v'] );
			}
		} elseif ( isset( $a['u'] ) ) {
			$x = $a['u'];
			if ( $hedef && $site && (int) $x['meta']['sides_org'] !== (int) $kaynak ) {
				return;
			}
			$u = get_user_by( 'email', $x['email'] );
			if ( ! $u ) {
				if ( $hedef || empty( $x['pass'] ) ) {
					$sonuc['eksikKullanici'][] = $x['ad'] . ' (' . $x['email'] . ')';
					return;
				}
				$login = $x['login'];
				if ( username_exists( $login ) ) {
					$login .= wp_rand( 10, 99 );
				}
				$uid = wp_insert_user( array( 'user_login' => $login, 'user_email' => $x['email'], 'user_pass' => wp_generate_password( 24 ), 'display_name' => $x['ad'], 'role' => in_array( 'ogretmen', (array) $x['roller'], true ) ? 'ogretmen' : 'sides_uye' ) );
				if ( is_wp_error( $uid ) ) {
					$sonuc['eksikKullanici'][] = $x['ad'] . ' (' . $x['email'] . ')';
					return;
				}
				$wpdb->update( $wpdb->users, array( 'user_pass' => $x['pass'] ), array( 'ID' => $uid ) );
				clean_user_cache( $uid );
				$u = get_userdata( $uid );
			} elseif ( $hedef ) {
				$simdiki = (int) get_user_meta( $u->ID, 'sides_org', true );
				/* v7.3.1 güvenlik: kurum geri yüklemesi sitenin diğer hesaplarını (yönetici, yazar…) kuruma bağlayamaz */
				if ( function_exists( 'sides_salt_atlas_uyesi' ) && ! sides_salt_atlas_uyesi( $u ) ) {
					$sonuc['eksikKullanici'][] = $x['ad'] . ' (' . $x['email'] . ', ATLAS dışı site hesabı)';
					return;
				}
				if ( $simdiki && $simdiki !== (int) $hedef ) {
					$sonuc['eksikKullanici'][] = $x['ad'] . ' (' . $x['email'] . ', başka kurumda)';
					return;
				}
			}
			$harita[ (int) $x['id'] ] = (int) $u->ID;
			update_user_meta( $u->ID, 'sides_org', $hedef ? (int) $hedef : (int) $x['meta']['sides_org'] );
			$mt = isset( $x['meta'] ) && is_array( $x['meta'] ) ? $x['meta'] : array();
			if ( isset( $mt['sides_rol'] ) && in_array( $mt['sides_rol'], SIDES_ROLLER, true ) ) {
				update_user_meta( $u->ID, 'sides_rol', $mt['sides_rol'] );
			}
			if ( isset( $mt['sides_yetki'] ) && is_array( $mt['sides_yetki'] ) ) {
				update_user_meta( $u->ID, 'sides_yetki', sides_clean_yetki( $mt['sides_yetki'] ) );
			}
			if ( isset( $mt['sides_sayfa'] ) && is_array( $mt['sides_sayfa'] ) ) {
				update_user_meta( $u->ID, 'sides_sayfa', function_exists( 'sides_sayfa_temizle' ) ? sides_sayfa_temizle( $mt['sides_sayfa'] ) : $mt['sides_sayfa'] );
			}
			if ( isset( $mt['sides_avatar'] ) && is_scalar( $mt['sides_avatar'] ) && '' !== $mt['sides_avatar'] ) {
				update_user_meta( $u->ID, 'sides_avatar', $mt['sides_avatar'] );
			}
			$sonuc['kullanici']++;
		} elseif ( isset( $a['o'] ) ) {
			if ( $hedef ) {
				return; // kurum geri yüklemesinde lisans bilgileri (durum, bitiş) değişmez
			}
			$o = array_intersect_key( (array) $a['o'], array_flip( array( 'id', 'ad', 'anahtar', 'sahip', 'olusturma', 'durum', 'bitis', 'plan', 'notlar' ) ) );
			if ( isset( $harita[ (int) $o['sahip'] ] ) ) {
				$o['sahip'] = $harita[ (int) $o['sahip'] ];
			}
			if ( false === $wpdb->insert( $orgs, $o ) ) {
				$hata = 'Kurum kaydı yazılamadı: ' . $wpdb->last_error;
				return false;
			}
		} elseif ( isset( $a['k'] ) ) {
			if ( ! $hedef && false === $wpdb->insert( $kodT, array_intersect_key( (array) $a['k'], array_flip( array( 'kod', 'plan', 'gun', 'durum', 'notlar', 'olusturma', 'kullanan', 'kullanma' ) ) ) ) ) {
				$hata = 'Kod kaydı yazılamadı: ' . $wpdb->last_error;
				return false;
			}
		} elseif ( isset( $a['d'] ) ) {
			/* v7.3.1 güvenlik: yalnız bilinen sütunlar yazılır (sütun adları wpdb tarafından kaçırılmaz); kimlikler biçim denetiminden geçer */
			$d = array_intersect_key( (array) $a['d'], array_flip( array( 'org', 'coll', 'id', 'exam_id', 'token', 'data', 'snapshot', 'updated_at', 'updated_by' ) ) );
			if ( ! isset( $d['coll'], $d['id'], $d['data'] ) || ! is_scalar( $d['coll'] ) || ! is_scalar( $d['id'] ) || ! preg_match( '/^[A-Za-z0-9_]{1,20}$/', (string) $d['coll'] ) || strlen( (string) $d['id'] ) > 64 ) {
				return;
			}
			/* v7.9.27 güvenlik: geri yüklenen görseller gerçekten resim mi? İçerik getimagesizefromstring ile doğrulanır, tür içerikten
			   alınır (yedekteki 'm' alanına güvenilmez). Resim olmayan kayıt atlanır ve sayılır. */
			if ( 'gorsel' === (string) $d['coll'] ) {
				$gv  = json_decode( (string) $d['data'], true );
				$bin = is_array( $gv ) && isset( $gv['b'] ) && is_string( $gv['b'] ) ? base64_decode( $gv['b'], true ) : false;
				$bil = $bin ? @getimagesizefromstring( $bin ) : false; // phpcs:ignore
				$tur = $bil && isset( $bil['mime'] ) ? strtolower( (string) $bil['mime'] ) : '';
				if ( ! in_array( $tur, array( 'image/jpeg', 'image/png', 'image/webp', 'image/gif' ), true ) ) {
					$sonuc['atlananGorsel'] = ( isset( $sonuc['atlananGorsel'] ) ? $sonuc['atlananGorsel'] : 0 ) + 1;
					return;
				}
				$gv['m']   = $tur;
				$d['data'] = wp_json_encode( $gv );
			}
			if ( $hedef ) {
				if ( $site && (int) $d['org'] !== (int) $kaynak ) {
					return;
				}
				$d['org'] = (int) $hedef;
				if ( ! empty( $d['token'] ) && $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $docs WHERE token = %s", $d['token'] ) ) ) { // phpcs:ignore
					$d['token'] = null;
					$sonuc['bosToken']++;
				}
			}
			if ( isset( $harita[ (int) $d['updated_by'] ] ) ) {
				$d['updated_by'] = $harita[ (int) $d['updated_by'] ];
			}
			if ( false === $wpdb->insert( $docs, $d ) ) {
				$hata = 'Kayıt yazılamadı (' . $d['coll'] . '/' . $d['id'] . '): ' . $wpdb->last_error;
				return false;
			}
			$sonuc['kayit']++;
		}
	} );
	if ( is_wp_error( $r ) || $hata ) {
		$wpdb->query( 'ROLLBACK' ); // phpcs:ignore
		return new WP_Error( 'sides_yedek', ( $hata ? $hata : $r->get_error_message() ) . ' Değişiklikler geri alındı. Sorun sürerse "Geri yükleme öncesi" yedeğinden dönebilirsiniz.', array( 'status' => 500 ) );
	}
	$wpdb->query( 'COMMIT' ); // phpcs:ignore
	$t = wp_date( 'd.m.Y H:i', (int) $bas['t'] );
	if ( $hedef ) {
		sides_log( $hedef, 'Veriler yedekten geri yüklendi (' . $t . ' tarihli yedek)' );
	} else {
		foreach ( (array) $wpdb->get_col( "SELECT id FROM $orgs" ) as $oid ) { // phpcs:ignore
			sides_log( (int) $oid, 'Site verileri yedekten geri yüklendi (' . $t . ' tarihli yedek)' );
		}
	}
	$sonuc['guvenlik'] = $guv['dosya'];
	return $sonuc;
}

/* ------------------------------------------------------------------ *
 * Otomatik yedekler
 * ------------------------------------------------------------------ */
function sides_yedek_kilitli( $fn ) {
	if ( get_transient( 'sides_yedek_kilit' ) ) {
		return null;
	}
	set_transient( 'sides_yedek_kilit', 1, 10 * MINUTE_IN_SECONDS );
	try {
		return $fn();
	} finally {
		delete_transient( 'sides_yedek_kilit' );
	}
}
add_action( 'sides_gunluk_yedek', function () {
	if ( sides_yedek_ayar()['gunluk'] ) {
		sides_yedek_kilitli( function () {
			return sides_yedek_yaz( 'site', 0, 'gunluk' );
		} );
	}
} );
function sides_yedek_zamanla() {
	if ( ! wp_next_scheduled( 'sides_gunluk_yedek' ) ) {
		$t = new DateTime( 'tomorrow 03:00', wp_timezone() );
		wp_schedule_event( $t->getTimestamp(), 'daily', 'sides_gunluk_yedek' );
	}
}
add_action( 'init', 'sides_yedek_zamanla' );

/* Eklenti sürümü değiştiyse (güncelleme sonrası ilk açılış) veritabanı güncellenmeden önce yedek alınır */
function sides_yedek_guncelleme_oncesi() {
	global $wpdb;
	$onceki = get_option( 'optik_karne_surum' );
	if ( OPTIK_KARNE_VER === $onceki ) {
		return;
	}
	update_option( 'optik_karne_surum', OPTIK_KARNE_VER );
	$docs = sides_docs();
	if ( ! get_option( 'sides_db_ver' ) || $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $docs ) ) !== $docs ) {
		return; // ilk kurulum: yedeklenecek veri yok
	}
	sides_yedek_kilitli( function () {
		return sides_yedek_yaz( 'site', 0, 'guncelleme' );
	} );
}

/* ------------------------------------------------------------------ *
 * REST: /yedek
 * ------------------------------------------------------------------ */
function sides_yedek_yetkili() {
	if ( sides_is_super() ) {
		return true;
	}
	$c = sides_ctx();
	return $c['org'] && 'yonetici' === $c['rol'] && empty( $c['blok'] );
}
/* Kurum yöneticisi kendi kurum yedeklerini ve (yalnızca kendi kurumuna dönmek için) otomatik site yedeklerini görür */
function sides_yedek_gorunur( $x ) {
	if ( sides_is_super() ) {
		return true;
	}
	$org = sides_org_id();
	return ( 'kurum' === $x['kapsam'] && (int) $x['org'] === $org ) || ( 'site' === $x['kapsam'] && in_array( $x['tur'], array( 'gunluk', 'guncelleme' ), true ) );
}
function sides_yedek_disari( $x ) {
	$super = sides_is_super();
	$org   = sides_org_id();
	$out   = array(
		'dosya'  => $x['dosya'],
		'tur'    => $x['tur'],
		'kapsam' => $x['kapsam'],
		't'      => (int) $x['t'],
		'boyut'  => (int) $x['boyut'],
		'surum'  => isset( $x['surum'] ) ? $x['surum'] : '',
	);
	if ( 'kurum' === $x['kapsam'] ) {
		$out['org']     = (int) $x['org'];
		$out['orgAd']   = $x['orgAd'];
		$out['sayilar'] = $x['sayilar'];
		$out['indir']   = true;
	} else {
		$out['sayilar']  = $super ? $x['sayilar'] : ( isset( $x['orgSayilari'][ $org ] ) ? $x['orgSayilari'][ $org ] : array() );
		$out['kurumlar'] = $super ? count( (array) $x['orgSayilari'] ) : null;
		$out['indir']    = $super;
	}
	$out['sil'] = $super || ( 'kurum' === $x['kapsam'] && in_array( $x['tur'], array( 'elle', 'yuklenen' ), true ) );
	return $out;
}

add_action( 'rest_api_init', function () {
	$ns   = 'optik-karne/v1';
	$yetk = function () {
		return sides_yedek_yetkili() ? true : sides_deny( 'Yedekleme yalnızca kurum yöneticisine açıktır.' );
	};
	$sup  = function () {
		return sides_is_super() ? true : sides_deny( 'Bu işlem yalnızca ana hesaba açıktır.' );
	};
	register_rest_route( $ns, '/yedek', array( 'methods' => 'GET', 'callback' => 'sides_rest_yedek_liste', 'permission_callback' => $yetk ) );
	register_rest_route( $ns, '/yedek/al', array( 'methods' => 'POST', 'callback' => 'sides_rest_yedek_al', 'permission_callback' => $yetk ) );
	register_rest_route( $ns, '/yedek/indir', array( 'methods' => 'GET', 'callback' => 'sides_rest_yedek_indir', 'permission_callback' => $yetk ) );
	register_rest_route( $ns, '/yedek/indir-link', array( 'methods' => 'POST', 'callback' => 'sides_rest_yedek_indir_link', 'permission_callback' => $yetk ) );
	register_rest_route( $ns, '/yedek/is', array( 'methods' => 'GET', 'callback' => 'sides_rest_ydis_durum', 'permission_callback' => $yetk ) );
	register_rest_route( $ns, '/yedek/hazirla', array( 'methods' => 'POST', 'callback' => 'sides_rest_ydis_hazirla', 'permission_callback' => $yetk ) );
	register_rest_route( $ns, '/yedek/adim', array( 'methods' => 'POST', 'callback' => 'sides_rest_ydis_adim', 'permission_callback' => $yetk ) );
	register_rest_route( $ns, '/yedek/yukle', array( 'methods' => 'POST', 'callback' => 'sides_rest_yedek_yukle', 'permission_callback' => $yetk ) );
	register_rest_route( $ns, '/yedek/parca', array( 'methods' => 'POST', 'callback' => 'sides_rest_yedek_parca', 'permission_callback' => $yetk ) );
	register_rest_route( $ns, '/yedek/geri', array( 'methods' => 'POST', 'callback' => 'sides_rest_yedek_geri', 'permission_callback' => $yetk ) );
	register_rest_route( $ns, '/yedek/koruma', array( 'methods' => 'POST', 'callback' => 'sides_rest_yedek_koruma', 'permission_callback' => $yetk ) );
	register_rest_route( $ns, '/yedek/sil', array( 'methods' => 'POST', 'callback' => 'sides_rest_yedek_sil', 'permission_callback' => $yetk ) );
	register_rest_route( $ns, '/yedek/ayar', array( 'methods' => 'POST', 'callback' => 'sides_rest_yedek_ayar', 'permission_callback' => $sup ) );
} );

function sides_rest_yedek_liste() {
	$l   = array_values( array_map( 'sides_yedek_disari', array_filter( sides_yedek_liste(), 'sides_yedek_gorunur' ) ) );
	$out = array( 'liste' => $l, 'maxYukleme' => (int) wp_max_upload_size(), 'super' => sides_is_super(), 'zlib' => function_exists( 'gzopen' ) );
	if ( sides_is_super() ) {
		global $wpdb;
		$out['ayar']     = sides_yedek_ayar();
		$out['sonraki']  = (int) wp_next_scheduled( 'sides_gunluk_yedek' );
		$out['hata']     = get_option( 'sides_yedek_hata' ) ? get_option( 'sides_yedek_hata' ) : null;
		$out['kurumlar'] = array_map( function ( $o ) {
			return array( 'id' => (int) $o->id, 'ad' => $o->ad );
		}, (array) $wpdb->get_results( 'SELECT id, ad FROM ' . sides_orgs() . ' ORDER BY ad' ) ); // phpcs:ignore
	}
	return $out;
}
function sides_rest_yedek_al( WP_REST_Request $req ) {
	$p      = $req->get_json_params();
	$kapsam = sides_is_super() && isset( $p['kapsam'] ) && 'site' === $p['kapsam'] ? 'site' : 'kurum';
	$org    = sides_org_id();
	if ( 'kurum' === $kapsam && ! $org ) {
		return new WP_Error( 'sides_yedek', 'Kurum alanınız bulunamadı.', array( 'status' => 400 ) );
	}
	$x = sides_yedek_kilitli( function () use ( $kapsam, $org ) {
		return sides_yedek_yaz( $kapsam, $org, 'elle' );
	} );
	if ( null === $x ) {
		return new WP_Error( 'sides_yedek', 'Şu anda başka bir yedekleme sürüyor. Bir dakika sonra tekrar deneyin.', array( 'status' => 409 ) );
	}
	if ( is_wp_error( $x ) ) {
		return $x;
	}
	if ( 'kurum' === $kapsam ) {
		sides_log( $org, 'Veri yedeği alındı' );
	}
	return sides_yedek_disari( $x );
}
function sides_yedek_izinli_dosya( $dosya, $indir = false ) {
	$l = sides_yedek_liste();
	if ( ! sides_yedek_ad_gecerli( $dosya ) || ! isset( $l[ $dosya ] ) || ! sides_yedek_gorunur( $l[ $dosya ] ) ) {
		return new WP_Error( 'sides_yedek', 'Yedek bulunamadı.', array( 'status' => 404 ) );
	}
	if ( $indir && ! sides_is_super() && 'kurum' !== $l[ $dosya ]['kapsam'] ) {
		return new WP_Error( 'sides_yedek', 'Site geneli yedekleri yalnızca ana hesap indirebilir.', array( 'status' => 403 ) );
	}
	return $l[ $dosya ];
}
/* v5.5: indirme adresi kısa ömürlü ve kullanıcıya bağlı bir anahtarla (k) çalışır; oturum (nonce) da gerekir.
   Hata yanıtı dosya gibi kaydedilmesin diye bağlantı yalnızca POST /yedek/indir-link ile üretilir. */
function sides_rest_yedek_indir( WP_REST_Request $req ) {
	$k   = preg_replace( '/[^a-f0-9]/', '', (string) $req->get_param( 'k' ) );
	$tok = 32 === strlen( $k ) ? get_transient( 'sides_ydl_' . $k ) : false;
	if ( ! is_array( $tok ) || (int) $tok['uid'] !== get_current_user_id() || (string) $tok['dosya'] !== (string) $req->get_param( 'dosya' ) || (int) $tok['bitis'] < time() ) {
		return new WP_Error( 'sides_yedek_link', 'İndirme bağlantısının süresi dolmuş ya da geçersiz. Veri Yedekleme sayfasında “Hazır Yedeği İndir”e yeniden basın.', array( 'status' => 403 ) );
	}
	$x = sides_yedek_izinli_dosya( (string) $tok['dosya'], true );
	if ( is_wp_error( $x ) ) {
		return $x;
	}
	$yol = sides_yedek_yol( $x['dosya'] );
	if ( ! $yol || ! is_readable( $yol ) || ! filesize( $yol ) ) {
		return new WP_Error( 'sides_yedek', 'Yedek dosyası sunucuda bulunamadı ya da boş.', array( 'status' => 404 ) );
	}
	$ad = sides_yedek_dosya_adi( $x );
	@set_time_limit( 0 ); // phpcs:ignore
	@ini_set( 'zlib.output_compression', 'Off' ); // phpcs:ignore
	while ( ob_get_level() ) {
		ob_end_clean(); // tamponlu çıktı büyük dosyada belleği doldurmasın
	}
	nocache_headers();
	header( 'Content-Type: application/octet-stream' );
	header( 'Content-Disposition: attachment; filename="' . $ad . '"; filename*=UTF-8\'\'' . rawurlencode( $ad ) );
	header( 'Content-Length: ' . filesize( $yol ) );
	header( 'X-Content-Type-Options: nosniff' );
	$f = fopen( $yol, 'rb' ); // phpcs:ignore
	while ( $f && ! feof( $f ) ) {
		echo fread( $f, 1048576 ); // phpcs:ignore
		flush();
	}
	if ( $f ) {
		fclose( $f ); // phpcs:ignore
	}
	exit;
}
/* Anlamlı dosya adı: kurum, kurum no, tarih-saat, ATLAS sürümü */
function sides_yedek_dosya_adi( $x ) {
	$kim = 'site' === $x['kapsam'] ? 'site' : ( ( $x['orgAd'] ? $x['orgAd'] : 'kurum' ) . '-k' . (int) $x['org'] );
	$ad  = sanitize_file_name( remove_accents( 'ATLAS-yedek-' . $kim . '-' . wp_date( 'Y-m-d-Hi', (int) $x['t'] ) . '-v' . ( ! empty( $x['surum'] ) ? $x['surum'] : OPTIK_KARNE_VER ) ) );
	return $ad . '.atlasyedek';
}
function sides_rest_yedek_indir_link( WP_REST_Request $req ) {
	$p = $req->get_json_params();
	$x = sides_yedek_izinli_dosya( isset( $p['dosya'] ) ? (string) $p['dosya'] : '', true );
	if ( is_wp_error( $x ) ) {
		return $x;
	}
	$yol = sides_yedek_yol( $x['dosya'] );
	if ( ! $yol || ! is_readable( $yol ) || ! filesize( $yol ) ) {
		return new WP_Error( 'sides_yedek', 'Yedek dosyası sunucuda bulunamadı ya da boş.', array( 'status' => 404 ) );
	}
	$k     = bin2hex( random_bytes( 16 ) );
	$bitis = time() + 15 * MINUTE_IN_SECONDS;
	set_transient( 'sides_ydl_' . $k, array( 'uid' => get_current_user_id(), 'dosya' => $x['dosya'], 'bitis' => $bitis ), 15 * MINUTE_IN_SECONDS );
	$url = add_query_arg( array( 'dosya' => $x['dosya'], 'k' => $k, '_wpnonce' => wp_create_nonce( 'wp_rest' ) ), rest_url( 'optik-karne/v1/yedek/indir' ) );
	return array( 'url' => esc_url_raw( $url ), 'ad' => sides_yedek_dosya_adi( $x ), 'boyut' => (int) filesize( $yol ), 'bitis' => $bitis, 'dosya' => $x['dosya'] );
}

/* ------------------------------------------------------------------ *
 * v5.5: “Yedeği Hazırla ve İndir” — kurum yedeği parça parça (her adım birkaç saniye) hazırlanır.
 * İş kurum başına tek kayıttır (option sides_ydis_k<org>): sayfa yenilenirse aynı iş kaldığı yerden sürer,
 * kullanıcı sayfadan ayrılsa da WP-Cron ile tamamlanır. Dosya önce .part adıyla yazılır; yalnızca “son” satırı
 * yazıldıktan sonra asıl adına çevrilip yedek listesine eklenir (yarım dosya tam yedek gibi sunulmaz).
 * ------------------------------------------------------------------ */
function sides_ydis_anahtar( $org ) {
	return 'sides_ydis_k' . (int) $org;
}
function sides_ydis_al( $org ) {
	$x = get_option( sides_ydis_anahtar( $org ) );
	if ( ! is_array( $x ) ) {
		return null;
	}
	if ( 'hazirlaniyor' === $x['durum'] && (int) $x['guncel'] < time() - 30 * MINUTE_IN_SECONDS ) {
		$x['durum'] = 'hata';
		$x['hata']  = 'Yedek hazırlığı yarıda kaldı (30 dakikadır ilerlemedi).';
		@unlink( sides_yedek_dir() . '/' . $x['gecici'] ); // phpcs:ignore
		sides_ydis_kaydet( $x );
	}
	return $x;
}
function sides_ydis_kaydet( $x ) {
	update_option( sides_ydis_anahtar( $x['org'] ), $x, false );
}
function sides_ydis_baslat( $org ) {
	global $wpdb;
	$dir = sides_yedek_dir();
	foreach ( (array) glob( "$dir/*.part" ) as $eski ) {
		if ( filemtime( $eski ) < time() - DAY_IN_SECONDS ) {
			@unlink( $eski ); // phpcs:ignore
		}
	}
	$onceki = sides_ydis_al( $org );
	if ( $onceki && 'hazir' !== $onceki['durum'] && ! empty( $onceki['gecici'] ) ) {
		@unlink( "$dir/" . $onceki['gecici'] ); // phpcs:ignore
	}
	$docs  = sides_docs();
	$dosya = 'sides-elle-k' . (int) $org . '-' . gmdate( 'Ymd-His' ) . '-' . bin2hex( random_bytes( 8 ) ) . '.sidesyedek';
	$x     = array(
		'id'      => bin2hex( random_bytes( 8 ) ),
		'org'     => (int) $org,
		'uid'     => get_current_user_id(),
		'durum'   => 'hazirlaniyor',
		'asama'   => 'bas',
		't0'      => time(),
		'guncel'  => time(),
		'toplam'  => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $docs WHERE org = %d", $org ) ), // phpcs:ignore
		'yazilan' => 0,
		'imlec'   => array( '', '' ),
		'sayi'    => array(),
		'dosya'   => $dosya,
		'gecici'  => $dosya . '.part',
		'hata'    => '',
		'boyut'   => 0,
	);
	sides_ydis_kaydet( $x );
	return $x;
}
function sides_ydis_hata( $x, $m ) {
	$x['durum'] = 'hata';
	$x['hata']  = $m;
	@unlink( sides_yedek_dir() . '/' . $x['gecici'] ); // phpcs:ignore
	update_option( 'sides_yedek_hata', array( 't' => time(), 'm' => $m ), false );
	sides_log( $x['org'], 'Veri yedeği hazırlanamadı: ' . $m, 'Sistem' );
	return $x;
}
function sides_ydis_adim( $x, $butce = 5.0 ) {
	global $wpdb;
	if ( ! $x || 'hazirlaniyor' !== $x['durum'] ) {
		return $x;
	}
	$kilit = 'sides_ydis_kilit_' . (int) $x['org'];
	if ( get_transient( $kilit ) ) {
		return $x; // başka bir adım sürüyor (ör. arka plan): aynı iş ikinci kez yürütülmez
	}
	set_transient( $kilit, 1, 2 * MINUTE_IN_SECONDS );
	try {
		@set_time_limit( 120 ); // phpcs:ignore
		$bas = microtime( true );
		$dir = sides_yedek_dir();
		$yol = "$dir/" . $x['gecici'];
		if ( ! function_exists( 'gzopen' ) ) {
			return $x = sides_ydis_hata( $x, 'Sunucuda sıkıştırma (zlib) desteği yok.' );
		}
		$gz = @gzopen( $yol, 'ab6' ); // phpcs:ignore
		if ( ! $gz ) {
			return $x = sides_ydis_hata( $x, 'Yedek klasörüne yazılamadı (wp-content/uploads/sides-yedek).' );
		}
		$ok  = true;
		$org = (int) $x['org'];
		$o   = sides_org( $org );
		if ( 'bas' === $x['asama'] ) {
			$ok = sides_yedek_satir( $gz, array( 'sides_yedek' => SIDES_YEDEK_SURUM, 'surum' => OPTIK_KARNE_VER, 'db' => SIDES_DB_VER, 't' => (int) $x['t0'], 'site' => home_url(), 'kapsam' => 'kurum', 'org' => $o ? array( 'id' => (int) $o->id, 'ad' => $o->ad ) : null, 'tur' => 'elle' ) );
			foreach ( get_users( array( 'meta_key' => 'sides_org', 'meta_value' => $org, 'number' => -1 ) ) as $u ) { // phpcs:ignore
				$ok = $ok && sides_yedek_satir( $gz, array( 'u' => array( 'id' => (int) $u->ID, 'login' => $u->user_login, 'email' => $u->user_email, 'ad' => $u->display_name, 'roller' => array_values( (array) $u->roles ),
					'meta' => array( 'sides_org' => $org, 'sides_rol' => (string) get_user_meta( $u->ID, 'sides_rol', true ), 'sides_yetki' => get_user_meta( $u->ID, 'sides_yetki', true ), 'sides_avatar' => (string) get_user_meta( $u->ID, 'sides_avatar', true ), 'sides_sayfa' => get_user_meta( $u->ID, 'sides_sayfa', true ) ) ) ) );
				$x['sayi']['kullanici'] = ( isset( $x['sayi']['kullanici'] ) ? $x['sayi']['kullanici'] : 0 ) + 1;
			}
			$r  = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . sides_orgs() . ' WHERE id = %d', $org ), ARRAY_A ); // phpcs:ignore
			$ok = $ok && ( ! $r || sides_yedek_satir( $gz, array( 'o' => $r ) ) );
			$x['asama'] = 'docs';
		}
		$docs = sides_docs();
		while ( $ok && 'docs' === $x['asama'] && microtime( true ) - $bas < $butce ) {
			list( $c, $i ) = $x['imlec'];
			$rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM $docs WHERE org = %d AND ( coll > %s OR ( coll = %s AND id > %s ) ) ORDER BY coll, id LIMIT 200", $org, $c, $c, $i ), ARRAY_A ); // phpcs:ignore
			foreach ( (array) $rows as $r ) {
				$ok = $ok && sides_yedek_satir( $gz, array( 'd' => $r ) );
				$x['sayi'][ $r['coll'] ] = ( isset( $x['sayi'][ $r['coll'] ] ) ? $x['sayi'][ $r['coll'] ] : 0 ) + 1;
				$x['yazilan']++;
				$x['imlec'] = array( $r['coll'], $r['id'] );
			}
			if ( count( (array) $rows ) < 200 ) {
				$x['asama'] = 'son';
			}
		}
		if ( $ok && 'son' === $x['asama'] ) {
			$ok = sides_yedek_satir( $gz, array( 'son' => array( 'sayilar' => $x['sayi'], 'orgSayilari' => array(), 'satir' => $x['yazilan'] ) ) );
		}
		gzclose( $gz );
		if ( ! $ok ) {
			return $x = sides_ydis_hata( $x, 'Yedek yazılırken disk hatası oluştu (disk dolu olabilir).' );
		}
		if ( 'son' === $x['asama'] ) {
			if ( ! @rename( $yol, "$dir/" . $x['dosya'] ) ) { // phpcs:ignore
				return $x = sides_ydis_hata( $x, 'Hazırlanan dosya yerine taşınamadı.' );
			}
			$x['boyut']  = (int) filesize( "$dir/" . $x['dosya'] );
			$x['durum']  = 'hazir';
			$x['asama']  = 'bitti';
			$x['bitti']  = time();
			$l           = sides_yedek_dizin();
			$l[ $x['dosya'] ] = array( 'dosya' => $x['dosya'], 'tur' => 'elle', 'kapsam' => 'kurum', 'org' => $org, 'orgAd' => $o ? $o->ad : '', 't' => (int) $x['t0'], 'boyut' => $x['boyut'], 'surum' => OPTIK_KARNE_VER, 'sayilar' => $x['sayi'], 'orgSayilari' => array() );
			sides_yedek_dizin_kaydet( $l );
			delete_option( 'sides_yedek_hata' );
			sides_yedek_temizle();
			sides_log( $org, 'Veri yedeği hazırlandı (' . size_format( $x['boyut'] ) . ', ' . $x['yazilan'] . ' kayıt)' );
		}
		return $x;
	} finally {
		$x['guncel'] = time();
		sides_ydis_kaydet( $x );
		delete_transient( $kilit );
		if ( 'hazirlaniyor' === $x['durum'] && ! wp_next_scheduled( 'sides_ydis_cron', array( (int) $x['org'] ) ) ) {
			wp_schedule_single_event( time() + 20, 'sides_ydis_cron', array( (int) $x['org'] ) );   // kullanıcı ayrılsa da tamamlanır
		}
	}
}
add_action( 'sides_ydis_cron', function ( $org ) {
	$x = sides_ydis_al( (int) $org );
	if ( $x && 'hazirlaniyor' === $x['durum'] && (int) $x['guncel'] < time() - 15 ) {
		sides_ydis_adim( $x, 20.0 );
	}
} );
/* İstemciye giden iş bilgisi: anahtar, dosya yolu, ayrıntılı tanı yok */
function sides_ydis_disari( $x ) {
	if ( ! $x ) {
		return array( 'durum' => 'yok' );
	}
	$out = array( 'id' => $x['id'], 'durum' => $x['durum'], 't0' => (int) $x['t0'], 'toplam' => (int) $x['toplam'], 'yazilan' => (int) $x['yazilan'], 'hata' => $x['hata'], 'sayilar' => $x['sayi'] );
	$out['yuzde'] = 'hazir' === $x['durum'] ? 100 : ( $x['toplam'] ? min( 99, (int) floor( $x['yazilan'] * 100 / $x['toplam'] ) ) : 0 );
	if ( 'hazir' === $x['durum'] ) {
		$l = sides_yedek_liste();
		if ( ! isset( $l[ $x['dosya'] ] ) ) {
			return array( 'durum' => 'yok' ); // dosya silinmiş ya da eskiyip temizlenmiş
		}
		$out['dosya'] = $x['dosya'];
		$out['boyut'] = (int) $x['boyut'];
		$out['ad']    = sides_yedek_dosya_adi( $l[ $x['dosya'] ] );
		$out['bitti'] = isset( $x['bitti'] ) ? (int) $x['bitti'] : 0;
	}
	return $out;
}
function sides_rest_ydis_durum() {
	return sides_ydis_disari( sides_ydis_al( sides_org_id() ) );
}
function sides_rest_ydis_hazirla( WP_REST_Request $req ) {
	$org = sides_org_id();
	if ( ! $org ) {
		return new WP_Error( 'sides_yedek', 'Kurum alanınız bulunamadı.', array( 'status' => 400 ) );
	}
	$p = $req->get_json_params();
	$x = sides_ydis_al( $org );
	// süren iş yeniden başlatılmaz; az önce hazırlanmış yedek (10 dk) “yeni” istenmedikçe yeniden kullanılır
	if ( ! $x || 'hata' === $x['durum'] || ( 'hazir' === $x['durum'] && ( ! empty( $p['yeni'] ) || (int) $x['bitti'] < time() - 10 * MINUTE_IN_SECONDS || 'yok' === sides_ydis_disari( $x )['durum'] ) ) ) {
		$x = sides_ydis_baslat( $org );
	}
	return sides_ydis_disari( sides_ydis_adim( $x ) );
}
function sides_rest_ydis_adim() {
	$x = sides_ydis_al( sides_org_id() );
	if ( ! $x ) {
		return array( 'durum' => 'yok' );
	}
	return sides_ydis_disari( sides_ydis_adim( $x ) );
}

function sides_rest_yedek_yukle( WP_REST_Request $req ) {
	$f = $req->get_file_params();
	$f = isset( $f['dosya'] ) ? $f['dosya'] : null;
	if ( ! $f || ! empty( $f['error'] ) || ! is_uploaded_file( $f['tmp_name'] ) ) {
		$e = $f && ! empty( $f['error'] ) && in_array( (int) $f['error'], array( UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE ), true ) ? 'Dosya sunucunun yükleme sınırından büyük (en fazla ' . size_format( wp_max_upload_size() ) . ').' : 'Dosya yüklenemedi.';
		return new WP_Error( 'sides_yedek', $e, array( 'status' => 400 ) );
	}
	return sides_yedek_kaydet_yuklenen( $f['tmp_name'], true );
}
/* Büyük dosyalar parça parça gelir (sunucunun yükleme sınırına takılmaz) */
function sides_rest_yedek_parca( WP_REST_Request $req ) {
	$id = preg_replace( '/[^a-f0-9]/', '', (string) $req->get_param( 'id' ) );
	$i  = (int) $req->get_param( 'i' );
	$n  = (int) $req->get_param( 'n' );
	if ( 24 !== strlen( $id ) || $i < 0 || $n < 1 || $n > 2000 || $i >= $n ) {
		return new WP_Error( 'sides_yedek', 'Geçersiz parça.', array( 'status' => 400 ) );
	}
	$dir = sides_yedek_dir();
	foreach ( (array) glob( "$dir/parca-*.tmp" ) as $eski ) {
		if ( filemtime( $eski ) < time() - DAY_IN_SECONDS ) {
			@unlink( $eski ); // phpcs:ignore
		}
	}
	$tmp  = "$dir/parca-" . get_current_user_id() . "-$id.tmp";
	$body = $req->get_body();
	if ( '' === $body || strlen( $body ) > 4 * MB_IN_BYTES ) {
		return new WP_Error( 'sides_yedek', 'Parça boş ya da çok büyük.', array( 'status' => 400 ) );
	}
	$boy = file_exists( $tmp ) ? filesize( $tmp ) : 0;
	if ( 0 === $i && $boy ) {
		@unlink( $tmp ); // phpcs:ignore
		$boy = 0;
	}
	if ( $i > 0 && ! $boy ) {
		return new WP_Error( 'sides_yedek', 'Yükleme yarıda kesilmiş; dosyayı yeniden seçin.', array( 'status' => 400 ) );
	}
	if ( false === file_put_contents( $tmp, $body, FILE_APPEND ) ) { // phpcs:ignore
		return new WP_Error( 'sides_yedek', 'Parça sunucuya yazılamadı (disk dolu olabilir).', array( 'status' => 500 ) );
	}
	if ( $i < $n - 1 ) {
		return array( 'ok' => true, 'i' => $i );
	}
	$r = sides_yedek_kaydet_yuklenen( $tmp, false );
	if ( file_exists( $tmp ) ) {
		@unlink( $tmp ); // phpcs:ignore
	}
	return $r;
}
function sides_yedek_kaydet_yuklenen( $kaynak, $yuklenen ) {
	$bas = null;
	$r   = sides_yedek_oku( $kaynak, function ( $a ) use ( &$bas ) {
		$bas = $a;
		return false;
	} );
	if ( is_wp_error( $r ) ) {
		return $r;
	}
	if ( ! $bas ) {
		return new WP_Error( 'sides_yedek', 'Bu dosya bir ATLAS yedeği değil.', array( 'status' => 400 ) );
	}
	if ( 'site' === $bas['kapsam'] && ! sides_is_super() ) {
		return new WP_Error( 'sides_yedek', 'Bu bir site geneli yedek; yalnızca ana hesap geri yükleyebilir. Kurumunuzun yedek dosyasını seçin.', array( 'status' => 403 ) );
	}
	$org   = 'site' === $bas['kapsam'] ? 0 : sides_org_id();
	$dosya = 'sides-yuklenen-' . ( $org ? 'k' . $org : 'site' ) . '-' . gmdate( 'Ymd-His' ) . '-' . bin2hex( random_bytes( 8 ) ) . '.sidesyedek';
	$yol   = sides_yedek_dir() . '/' . $dosya;
	if ( ! ( $yuklenen ? @move_uploaded_file( $kaynak, $yol ) : @rename( $kaynak, $yol ) ) ) { // phpcs:ignore
		return new WP_Error( 'sides_yedek', 'Dosya sunucuya kaydedilemedi.', array( 'status' => 500 ) );
	}
	$oz = sides_yedek_ozet( $yol );
	if ( is_wp_error( $oz ) ) {
		@unlink( $yol ); // phpcs:ignore
		return $oz;
	}
	$x           = array(
		'dosya'       => $dosya,
		'tur'         => 'yuklenen',
		'kapsam'      => $bas['kapsam'],
		'org'         => $org,
		'orgAd'       => $bas['org'] ? $bas['org']['ad'] : '',
		't'           => (int) $bas['t'],
		'boyut'       => (int) filesize( $yol ),
		'surum'       => isset( $bas['surum'] ) ? $bas['surum'] : '',
		'sayilar'     => $oz['son']['sayilar'],
		'orgSayilari' => isset( $oz['son']['orgSayilari'] ) ? $oz['son']['orgSayilari'] : array(),
	);
	$l           = sides_yedek_dizin();
	$l[ $dosya ] = $x;
	sides_yedek_dizin_kaydet( $l );
	sides_yedek_temizle();
	return sides_yedek_disari( $x ) + array( 'kaynakSite' => isset( $bas['site'] ) ? $bas['site'] : '', 'kaynakKurum' => $bas['org'] );
}
function sides_rest_yedek_geri( WP_REST_Request $req ) {
	$p = $req->get_json_params();
	$x = sides_yedek_izinli_dosya( isset( $p['dosya'] ) ? (string) $p['dosya'] : '' );
	if ( is_wp_error( $x ) ) {
		return $x;
	}
	$super = sides_is_super();
	if ( $super && 'site' === $x['kapsam'] && empty( $p['org'] ) ) {
		$hedef  = 0;
		$kaynak = 0;
	} elseif ( $super && 'site' === $x['kapsam'] ) {
		$hedef  = (int) $p['org'];
		$kaynak = (int) $p['org'];
	} elseif ( $super && ! empty( $p['org'] ) ) {
		$hedef  = (int) $p['org'];
		$kaynak = 0;
	} else {
		$hedef  = sides_org_id();
		$kaynak = 'site' === $x['kapsam'] ? $hedef : 0;
	}
	if ( 'site' === $x['kapsam'] && $kaynak && empty( $x['orgSayilari'][ $kaynak ] ) ) {
		return new WP_Error( 'sides_yedek', 'Bu yedekte kurumunuza ait veri yok.', array( 'status' => 400 ) );
	}
	$r = sides_yedek_kilitli( function () use ( $x, $hedef, $kaynak ) {
		return sides_yedek_geri( sides_yedek_yol( $x['dosya'] ), $hedef, $kaynak );
	} );
	if ( null === $r ) {
		return new WP_Error( 'sides_yedek', 'Şu anda başka bir yedekleme işlemi sürüyor. Bir dakika sonra tekrar deneyin.', array( 'status' => 409 ) );
	}
	return $r;
}
function sides_rest_yedek_sil( WP_REST_Request $req ) {
	$p = $req->get_json_params();
	$x = sides_yedek_izinli_dosya( isset( $p['dosya'] ) ? (string) $p['dosya'] : '' );
	if ( is_wp_error( $x ) ) {
		return $x;
	}
	if ( ! sides_yedek_disari( $x )['sil'] ) {
		return new WP_Error( 'sides_yedek', 'Otomatik yedekler silinemez; en eskisi kendiliğinden silinir.', array( 'status' => 403 ) );
	}
	@unlink( sides_yedek_yol( $x['dosya'] ) ); // phpcs:ignore
	$l = sides_yedek_dizin();
	unset( $l[ $x['dosya'] ] );
	sides_yedek_dizin_kaydet( $l );
	return array( 'ok' => true );
}
function sides_rest_yedek_ayar( WP_REST_Request $req ) {
	$p = $req->get_json_params();
	$a = sides_yedek_ayar();
	if ( isset( $p['gunluk'] ) ) {
		$a['gunluk'] = (bool) $p['gunluk'];
	}
	if ( isset( $p['sakla'] ) ) {
		$a['sakla'] = max( 1, min( 10, (int) $p['sakla'] ) );
	}
	update_option( 'sides_yedek_ayar', $a );
	sides_yedek_temizle();
	return sides_rest_yedek_liste();
}

/* T12: yedek klasörünün dışarıdan indirilemediğini sınar (sunucu kendi adresine istek atar). Sonuç: korunuyor | acik | sinanamadi */
function sides_rest_yedek_koruma() {
	$d   = sides_yedek_dir();
	$ad  = 'koruma-testi-' . wp_generate_password( 12, false ) . '.txt';
	$ic  = 'ATLAS-' . wp_generate_password( 24, false );
	if ( false === @file_put_contents( "$d/$ad", $ic ) ) { // phpcs:ignore
		return array( 'durum' => 'sinanamadi', 'mesaj' => 'Yedek klasörüne deneme dosyası yazılamadı.' );
	}
	$u   = wp_upload_dir( null, false );
	$url = trailingslashit( $u['baseurl'] ) . 'sides-yedek/' . $ad;
	$r   = wp_remote_get( $url, array( 'timeout' => 8, 'sslverify' => false, 'redirection' => 2 ) );
	@unlink( "$d/$ad" ); // phpcs:ignore
	if ( is_wp_error( $r ) ) {
		return array( 'durum' => 'sinanamadi', 'mesaj' => 'Sunucu kendi adresine ulaşamadı (' . $r->get_error_message() . '). Elle deneyin: bir yedeğin adresini tarayıcıda açmayı deneyin.' );
	}
	$kod = (int) wp_remote_retrieve_response_code( $r );
	if ( 200 === $kod && false !== strpos( (string) wp_remote_retrieve_body( $r ), $ic ) ) {
		return array( 'durum' => 'acik', 'kod' => $kod, 'mesaj' => 'Yedek dosyaları adresini bilen biri tarafından indirilebilir. Barındırma firmanızdan wp-content/uploads/sides-yedek klasörüne web erişimini kapatmasını isteyin (NGINX için: location ^~ /wp-content/uploads/sides-yedek/ { deny all; }).' );
	}
	return array( 'durum' => 'korunuyor', 'kod' => $kod, 'mesaj' => 'Yedek klasörü dışarıdan açılmıyor (yanıt kodu ' . $kod . ').' );
}
