<?php
/**
 * v7 Bilgi Yarışması — EK15 sunumlu bilgi yarışması, EK16 telefon katılımlı canlı yarışma.
 *
 * Kayıtlar (sides_docs; genel /doc, /all ve /koleksiyon uçları bu koleksiyonları döndürmez; yedeğe girer):
 *   ydeste/<yd…>  soru destesi { ad, kategori, ders, unite, konu, sinif, durum taslak|kontrol|onayli|arsiv, surum,
 *                 sorular[{ id, v, soru, secenekler[2–4], dogru, aciklama, sure 5–240, konu, ornek? }], olusturan, onaylayan, gecmis[] }
 *   yoyun/<yo…>   oyun { tip canli|sunum, desteId, desteSurum, ad, ders, unite, konu, sinif, sorular (oyun başlarken dondurulan kopya),
 *                 puanTuru dogruluk|hiz, faz lobi|soru|cevap|bitti, no, bas, son (sunucu ms; duraklama kadar ötelenir), durak {t, neden},
 *                 v (durum sürümü), oyuncular { pid: { ad, kh (anahtar özeti), ih, t, cikti? } }, sonuc { no: { pid: [secim, ms, puan, dogru] } },
 *                 puanDisi { no: { gerekce, t, u, ad, hesap } }, atlandi { no: 1 }, takimlar[], tpuan { ti: [0|1…] } (sunum), olaylar[], kural }
 *                 PIN yalnızca token sütununda ('yp' + 6 hane) durur; oyun bitince ya da 12 saat sonra silinir.
 *   ycevap/<oyun>_<no>_<pid>  tek yanıt (exam_id = <oyun>_<no>): { s, ms, t, op } — birincil anahtar tek yanıtı garanti eder.
 *
 * Yetki: Sosyal ≥ 1 okur (rapor, deste), Sosyal ≥ 2 deste ve oyun yönetir (gözlemci hiçbir zaman); EK15/EK16 erişimi sides_ek_erisim ile.
 * Oyunu yalnız sahibi (oluşturan) ya da kurum yöneticisi yönetir; PIN yalnız onlara gönderilir.
 * Herkese açık oyuncu uçları (yr/katil, yr/durum, yr/cevap): PIN yalnız oyunu bulur; sonraki her istek oyuncu kimliği + anahtarla.
 * Doğru seçenek ve açıklama soru kapanmadan oyuncu yanıtına girmez. Süre sunucu saatine göredir.
 * R09: kurum sistemi kapalıyken etkin oyun sunucuda duraklatılır (kalan süre korunur); yanıt, katılım ve ilerletme durur.
 *
 * v7.8 Hazır Soru Bankası: data/yarisma/*.json (ATLAS özgün; biçim: kategori ders|kultur|dahili|atolye, sinif, ders, atolye, kaynak, desteler[]).
 *   Her dosya ve soru sunucuda doğrulanır; hatalı kayıt atlanır ve rapora yazılır (sides_yr_kutuphane). Salt okunur REST: yarisma/kutuphane.
 *   "Hemen oyna": yarisma/oyun desteId = 'hz:<deste kimliği>'; "Kurumuma kopyala": yarisma/kutuphane/<id>/kopyala (taslak ya da onaylı).
 *   Toplu ekleme: yarisma/iceaktar (Excel/CSV satırları istemcide gruplanır, sunucuda yeniden doğrulanır).
 * Soru alanları (v7.8): zorluk ''|kolay|orta|zor, puan 0 (puansız) | 100 (standart, varsayılan) | 200 (çift). Eski sorularda puan yoksa 100 sayılır.
 */
defined( 'ABSPATH' ) || exit;

define( 'SIDES_YR_MAX_SORU', 72 );
define( 'SIDES_YR_MAX_OYUNCU', 60 );
define( 'SIDES_YR_PIN_OMUR', 12 * 3600 );
define( 'SIDES_YR_KURAL', 'v2: soru puanı 100 standart, 200 çift, 0 puansız; doğruluk = doğru başına soru puanı ÷ 100 (standart 1); hız = round(soru puanı × 10 × (1 − aktif süre / (2 × soru süresi))), ilk 0,5 sn tam puan (standart 1000)' );
define( 'SIDES_YR_KUTUPHANE', dirname( __DIR__ ) . '/data/yarisma' );

add_action( 'rest_api_init', function () {
	$ns  = 'optik-karne/v1';
	$oku = function () {
		return sides_yr_izin( 1 ) ? true : sides_deny( 'Bilgi yarışmasını görme yetkiniz yok.' );
	};
	$yaz = function () {
		if ( sides_is_observer() ) {
			return sides_deny( 'Gözlemci hesabı bilgi yarışmasında değişiklik yapamaz.' );
		}
		return sides_yr_izin( 2 ) ? true : sides_deny( 'Deste ve yarışma oluşturmak için Sosyal Aktiviteler modülünde değişiklik yetkisi gerekir.' );
	};
	$gid = '(?P<id>yo[a-f0-9]{12})';
	$did = '(?P<id>yd[a-z0-9]{6,20})';
	register_rest_route( $ns, '/yarisma', array( 'methods' => 'GET', 'callback' => 'sides_yr_ozet', 'permission_callback' => $oku ) );
	register_rest_route( $ns, '/yarisma/deste', array( 'methods' => 'POST', 'callback' => 'sides_yr_deste_kaydet', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/yarisma/deste/' . $did, array(
		array( 'methods' => 'GET', 'callback' => 'sides_yr_deste_oku', 'permission_callback' => $oku ),
		array( 'methods' => 'DELETE', 'callback' => 'sides_yr_deste_sil', 'permission_callback' => $yaz ),
	) );
	register_rest_route( $ns, '/yarisma/deste/' . $did . '/durum', array( 'methods' => 'POST', 'callback' => 'sides_yr_deste_durum', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/yarisma/oyun', array( 'methods' => 'POST', 'callback' => 'sides_yr_oyun_yeni', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/yarisma/kurulum', array( 'methods' => 'POST', 'callback' => 'sides_yr_kurulum_kaydet', 'permission_callback' => $yaz ) );   // v7.9.21 kayıtlı yarışma kurulumu (takımlar ve kişilerle)
	register_rest_route( $ns, '/yarisma/kurulum/(?P<id>kr[a-f0-9]{12})', array( 'methods' => 'DELETE', 'callback' => 'sides_yr_kurulum_sil', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/yarisma/oyun/' . $gid, array(
		array( 'methods' => 'GET', 'callback' => 'sides_yr_oyun_oku', 'permission_callback' => $oku ),
		array( 'methods' => 'DELETE', 'callback' => 'sides_yr_oyun_sil', 'permission_callback' => $yaz ),
	) );
	register_rest_route( $ns, '/yarisma/oyun/' . $gid . '/kontrol', array( 'methods' => 'POST', 'callback' => 'sides_yr_oyun_kontrol', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/yarisma/oyun/' . $gid . '/sunum', array( 'methods' => 'POST', 'callback' => 'sides_yr_sunum_kaydet', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/yarisma/oyun/' . $gid . '/giris', array( 'methods' => 'GET', 'callback' => 'sides_yr_giris_oku', 'permission_callback' => $yaz ) );      // v7.9.15 puan girişi (ikinci kişi)
	register_rest_route( $ns, '/yarisma/oyun/' . $gid . '/isaret', array( 'methods' => 'POST', 'callback' => 'sides_yr_isaret', 'permission_callback' => $yaz ) );      // v7.9.15 tek hücre: doğru / joker / ceza
	register_rest_route( $ns, '/yarisma/oyun/' . $gid . '/giris-link', array( 'methods' => 'POST', 'callback' => 'sides_yr_giris_link', 'permission_callback' => $yaz ) );   // v7.9.17 puan girişi linki (oluştur / yenile / kapat)
	register_rest_route( $ns, '/yarisma/oyun/' . $gid . '/puandisi', array( 'methods' => 'POST', 'callback' => 'sides_yr_puandisi', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/yarisma/oyun/' . $gid . '/rapor', array( 'methods' => 'GET', 'callback' => 'sides_yr_rapor', 'permission_callback' => $oku ) );
	// v7.8 Hazır Soru Bankası (salt okunur) ve toplu ekleme
	$kid = '(?P<kid>[a-z0-9][a-z0-9-]{2,40})';
	register_rest_route( $ns, '/yarisma/kutuphane', array( 'methods' => 'GET', 'callback' => 'sides_yr_kut_liste', 'permission_callback' => $oku ) );
	register_rest_route( $ns, '/yarisma/kutuphane/' . $kid, array( 'methods' => 'GET', 'callback' => 'sides_yr_kut_oku', 'permission_callback' => $oku ) );
	register_rest_route( $ns, '/yarisma/kutuphane/' . $kid . '/kopyala', array( 'methods' => 'POST', 'callback' => 'sides_yr_kut_kopyala', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/yarisma/kutuphane-sec', array( 'methods' => 'POST', 'callback' => 'sides_yr_kut_sec', 'permission_callback' => $yaz ) );   // v7.9.15 seçilen sorulardan deste
	register_rest_route( $ns, '/yarisma/iceaktar', array( 'methods' => 'POST', 'callback' => 'sides_yr_iceaktar', 'permission_callback' => $yaz ) );
	// herkese açık oyuncu uçları (hesapsız; PIN + oyuncu anahtarı)
	register_rest_route( $ns, '/yr/katil', array( 'methods' => 'POST', 'callback' => 'sides_yr_katil', 'permission_callback' => '__return_true' ) );
	register_rest_route( $ns, '/yr/puan', array( 'methods' => 'POST', 'callback' => 'sides_yr_puan_link', 'permission_callback' => '__return_true' ) );   // v7.9.17 hesapsız puan girişi (link anahtarı)
	register_rest_route( $ns, '/yr/durum', array( 'methods' => 'POST', 'callback' => 'sides_yr_durum', 'permission_callback' => '__return_true' ) );
	register_rest_route( $ns, '/yr/cevap', array( 'methods' => 'POST', 'callback' => 'sides_yr_cevap', 'permission_callback' => '__return_true' ) );
} );

/* ---------------- yardımcılar ---------------- */
function sides_yr_ms() {
	return (int) round( microtime( true ) * 1000 );
}
function sides_yr_hata( $kod, $m, $st, $ek = array() ) {
	return new WP_Error( $kod, $m, array_merge( array( 'status' => $st ), $ek ) );
}
function sides_yr_kim() {
	$u = wp_get_current_user();
	return array( 'u' => (int) $u->ID, 'ad' => $u && $u->ID ? ( $u->display_name ? $u->display_name : $u->user_login ) : 'Sistem' );
}
function sides_yr_izin( $lvl, $kodlar = array( 'EK15', 'EK16' ) ) {
	$org = sides_org_id();
	if ( ! $org || ! sides_can( 'sosyal', $lvl ) ) {
		return false;
	}
	if ( ! function_exists( 'sides_ek_erisim' ) ) {
		return true;
	}
	foreach ( (array) $kodlar as $k ) {
		if ( sides_ek_erisim( $org, $k ) ) {
			return true;
		}
	}
	return false;
}
/* Düz metin: HTML yorumlanmaz (istemci her yerde kaçırır); denetim karakterleri atılır, uzunluk sınırlanır */
function sides_yr_temiz( $v, $max, $cok = false ) {
	$s = is_scalar( $v ) ? wp_check_invalid_utf8( (string) $v ) : '';
	$s = preg_replace( '/[\x00-\x08\x0B\x0C\x0E-\x1F\x7F]/u', '', $s );
	$s = $cok ? preg_replace( "/\n{3,}/", "\n\n", preg_replace( "/[ \t]+/u", ' ', str_replace( array( "\r\n", "\r" ), "\n", $s ) ) ) : preg_replace( '/\s+/u', ' ', $s );
	return mb_substr( trim( (string) $s ), 0, $max );
}
function sides_yr_res( $d, $st = 200 ) {
	$r = rest_ensure_response( $d );
	$r->set_status( $st );
	$r->header( 'Cache-Control', 'no-store' );
	return $r;
}
function sides_yr_hash( $k ) {
	return hash_hmac( 'sha256', (string) $k, wp_salt( 'auth' ) );
}
function sides_yr_rastgele( $bayt ) {
	return bin2hex( random_bytes( $bayt ) );
}
/* Oyun kilidi: MySQL GET_LOCK; desteklenmeyen veritabanında (ör. SQLite) birincil anahtarla satır kilidi. false = meşgul */
function sides_yr_kilit( $org, $gid, $bekle = 5 ) {
	global $wpdb;
	$ad = 'sides_' . md5( 'yr|' . $org . '|' . $gid );
	$e  = $wpdb->suppress_errors( true );
	$ok = $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, %d)', $ad, (int) $bekle ) );
	$wpdb->suppress_errors( $e );
	if ( '1' === (string) $ok ) {
		return array( 'g', $ad );
	}
	if ( '0' === (string) $ok ) {
		return false;
	}
	$t   = sides_docs();
	$id  = 'k' . $gid;
	$son = microtime( true ) + max( 0.05, (float) $bekle );
	while ( true ) {
		$e = $wpdb->suppress_errors( true );
		$n = $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO $t (org, coll, id, exam_id, data, updated_at, updated_by) VALUES (%d, 'ykilit', %s, '', %s, %s, 0)", $org, $id, (string) time(), current_time( 'mysql', true ) ) ); // phpcs:ignore
		$wpdb->suppress_errors( $e );
		if ( 1 === (int) $n ) {
			return array( 'r', $org, $id );
		}
		$v = (int) $wpdb->get_var( $wpdb->prepare( "SELECT data FROM $t WHERE org = %d AND coll = 'ykilit' AND id = %s", $org, $id ) ); // phpcs:ignore
		if ( $v && $v < time() - 10 ) {   // yarım kalmış eski kilit
			$wpdb->query( $wpdb->prepare( "DELETE FROM $t WHERE org = %d AND coll = 'ykilit' AND id = %s AND data = %s", $org, $id, (string) $v ) ); // phpcs:ignore
			continue;
		}
		if ( microtime( true ) >= $son ) {
			return false;
		}
		usleep( 15000 );
	}
}
function sides_yr_birak( $l ) {
	global $wpdb;
	if ( ! $l ) {
		return;
	}
	if ( 'g' === $l[0] ) {
		$e = $wpdb->suppress_errors( true );
		$wpdb->query( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $l[1] ) );
		$wpdb->suppress_errors( $e );
	} else {
		$t = sides_docs();
		for ( $i = 0; $i < 6; $i++ ) {
			if ( false !== $wpdb->query( $wpdb->prepare( "DELETE FROM $t WHERE org = %d AND coll = 'ykilit' AND id = %s", $l[1], $l[2] ) ) ) { // phpcs:ignore
				break;
			}
			usleep( 30000 + 40000 * $i );
		}
	}
}
/* Kayıt (eş zamanlı yazmada veritabanı kısa süre meşgul olabilir: birkaç kez dener) */
function sides_yr_kaydet( $org, $coll, $id, $d ) {
	for ( $i = 0; $i < 4; $i++ ) {
		if ( false !== sides_put_doc( $org, $coll, $id, $d ) ) {
			return true;
		}
		usleep( 40000 + 60000 * $i );
	}
	return false;
}
function sides_yr_mesgul() {
	return sides_yr_hata( 'sides_yr_mesgul', 'Yarışma şu anda başka bir işlemi kaydediyor. Bir saniye sonra tekrar deneyin.', 503 );
}
/* R09: kurum sistemi kapalıysa bakım belgesi, değilse null (hızlı yol: kapalı kurum listesinde değilse sorgu yok) */
function sides_yr_sistem( $org ) {
	return function_exists( 'sides_bakim_kapali' ) ? sides_bakim_kapali( (int) $org ) : null;
}
function sides_yr_sistem_mesaj( $b ) {
	$m = $b && isset( $b['mesaj'] ) ? trim( (string) $b['mesaj'] ) : '';
	return '' !== $m ? $m : 'ATLAS kısa bir süre için beklemede. Yarışma kaldığı yerden devam edecek.';
}

/* ---------------- deste ---------------- */
function sides_yr_kategoriler() {
	return array( 'ders', 'dahili', 'kultur', 'teknoloji', 'karma', 'atolye', 'yarisma' );   // v7.9.17 yarisma: Yarışma soruları
}
function sides_yr_atolyeler() {
	return array( 'origami' => 'Origami', 'stem' => 'STEM', 'munazara' => 'Münazara', 'spor' => 'Oyun ve spor', 'medya' => 'Dijital ve medya okuryazarlığı' );
}
function sides_yr_zorluklar() {
	return array( 'kolay', 'orta', 'zor' );
}
function sides_yr_puanlar() {
	return array( 0, 100, 200 );
}
/* Soru puanı (eski kayıtlarda alan yoksa standart 100) */
function sides_yr_soru_puan( $q ) {
	return isset( $q['puan'] ) && is_numeric( $q['puan'] ) && in_array( (int) $q['puan'], sides_yr_puanlar(), true ) ? (int) $q['puan'] : 100;
}
function sides_yr_zorluk_say( $L ) {
	$z = array( 'kolay' => 0, 'orta' => 0, 'zor' => 0, 'bos' => 0 );
	foreach ( (array) $L as $q ) {
		$k = isset( $q['zorluk'] ) && isset( $z[ $q['zorluk'] ] ) && 'bos' !== $q['zorluk'] ? $q['zorluk'] : 'bos';
		$z[ $k ]++;
	}
	return $z;
}
function sides_yr_soru_ozet( $q ) {
	return md5( wp_json_encode( array( $q['soru'], $q['secenekler'], $q['dogru'], $q['aciklama'], $q['sure'], $q['konu'], isset( $q['zorluk'] ) ? (string) $q['zorluk'] : '', sides_yr_soru_puan( $q ), sides_yr_medya_ozet( $q ) ) ) );
}
/* v7.9.15 Soru medyası: görsel (kurum görseli g…, https adresi ya da küçük data:image), video bağlantısı (YouTube, Vimeo, https .mp4/.webm), ses (metin okunur | nota melodisi | https ses dosyası); medyaNe soru|cevap|ikisi.
   Dönüş: yalnız dolu alanları içeren dizi ya da hata metni. Kurum destesi ve Hazır Soru Bankası aynı kuralları kullanır. */
function sides_yr_medya_ozet( $q ) {
	$o = array();
	foreach ( array( 'gorsel', 'video', 'ses', 'medyaNe', 'bolum', 'bilgi', 'bilgiVideo', 'yedek' ) as $k ) {
		if ( isset( $q[ $k ] ) && '' !== $q[ $k ] && array() !== $q[ $k ] ) {
			$o[ $k ] = $q[ $k ];
		}
	}
	return $o;
}
function sides_yr_ses_dilleri() {
	return array( 'tr-TR', 'en-US', 'en-GB', 'de-DE', 'fr-FR', 'ar-SA' );
}
function sides_yr_medya_temiz( $q ) {
	$out = array();
	$g   = isset( $q['gorsel'] ) && is_string( $q['gorsel'] ) ? trim( $q['gorsel'] ) : '';
	if ( '' !== $g ) {
		if ( preg_match( '/^g[a-f0-9]{16,40}$/', $g ) ) {
			$out['gorsel'] = $g;
		} elseif ( preg_match( '#^data:image/(svg\+xml|png|jpeg|webp);base64,[A-Za-z0-9+/=]+$#', $g ) ) {
			if ( strlen( $g ) > 60000 ) {
				return 'görsel verisi 60 KB’tan büyük (büyük görseli dosya olarak yükleyin)';
			}
			$out['gorsel'] = $g;
		} elseif ( preg_match( '#^https://[^\s<>"\']{8,500}$#', $g ) && false === strpos( $g, 'javascript:' ) ) {
			$out['gorsel'] = esc_url_raw( $g );
		} else {
			return 'görsel; kurum görseli, https adresi ya da küçük bir data:image olmalı';
		}
	}
	$v = isset( $q['video'] ) && is_string( $q['video'] ) ? trim( $q['video'] ) : '';
	if ( '' !== $v ) {
		if ( ! preg_match( '#^https://(?:www\.|m\.)?(?:youtube\.com/(?:watch\?|embed/|shorts/|live/)|youtu\.be/|youtube-nocookie\.com/embed/|vimeo\.com/|player\.vimeo\.com/video/)[^\s<>"\']{1,300}$#', $v ) && ! preg_match( '#^https://[^\s<>"\']{5,300}\.(?:mp4|webm)(?:\?[^\s<>"\']*)?$#i', $v ) ) {
			return 'video bağlantısı YouTube, Vimeo ya da https ile biten bir .mp4/.webm adresi olmalı';
		}
		$out['video'] = esc_url_raw( $v );
	}
	$s = isset( $q['ses'] ) && is_array( $q['ses'] ) ? $q['ses'] : null;
	if ( $s && isset( $s['tur'] ) && '' !== $s['tur'] && 'yok' !== $s['tur'] ) {
		$tur = (string) $s['tur'];
		if ( 'metin' === $tur ) {
			$m = sides_yr_temiz( isset( $s['metin'] ) ? $s['metin'] : '', 300, true );
			if ( '' === $m ) {
				return 'okunacak ses metni boş';
			}
			$dil = isset( $s['dil'] ) && in_array( $s['dil'], sides_yr_ses_dilleri(), true ) ? $s['dil'] : 'tr-TR';
			$hiz = isset( $s['hiz'] ) && is_numeric( $s['hiz'] ) ? max( 5, min( 15, (int) round( 10 * (float) $s['hiz'] ) ) ) / 10 : 0.9;
			$out['ses'] = array( 'tur' => 'metin', 'metin' => $m, 'dil' => $dil, 'hiz' => $hiz );
		} elseif ( 'nota' === $tur ) {
			$n = isset( $s['nota'] ) && is_string( $s['nota'] ) ? trim( preg_replace( '/\s+/', ' ', $s['nota'] ) ) : '';
			if ( '' === $n || mb_strlen( $n ) > 400 || ! preg_match( '/^[A-Ga-g#b0-9 .,:\-|rR]+$/', $n ) ) {
				return 'melodi notaları boş, 400 karakterden uzun ya da geçersiz (örnek: C4 E4 G4:2 r C5)';
			}
			$tempo = isset( $s['tempo'] ) && is_numeric( $s['tempo'] ) ? max( 40, min( 240, (int) $s['tempo'] ) ) : 120;
			$out['ses'] = array( 'tur' => 'nota', 'nota' => $n, 'tempo' => $tempo );
		} elseif ( 'url' === $tur ) {
			$u = isset( $s['url'] ) && is_string( $s['url'] ) ? trim( $s['url'] ) : '';
			if ( ! preg_match( '#^https://[^\s<>"\']{5,300}\.(?:mp3|ogg|wav|m4a)(?:\?[^\s<>"\']*)?$#i', $u ) ) {
				return 'ses bağlantısı https ile biten bir .mp3/.ogg/.wav/.m4a adresi olmalı';
			}
			$out['ses'] = array( 'tur' => 'url', 'url' => esc_url_raw( $u ) );
		} else {
			return 'ses türü metin, nota ya da url olmalı';
		}
		if ( isset( $s['oto'] ) ) {
			$out['ses']['oto'] = ! empty( $s['oto'] ) ? 1 : 0;
		}
	}
	if ( $out ) {
		$ne = isset( $q['medyaNe'] ) && in_array( $q['medyaNe'], array( 'soru', 'cevap', 'ikisi' ), true ) ? $q['medyaNe'] : 'soru';
		if ( 'soru' !== $ne ) {
			$out['medyaNe'] = $ne;
		}
	}
	/* v7.9.17 bölüm (kategori geçiş ekranı), bilgi notu (soru çözülürken yayınlanır), yedek (eşitlik bozma) */
	$bo = sides_yr_temiz( isset( $q['bolum'] ) ? $q['bolum'] : '', 60 );
	if ( '' !== $bo ) {
		$out['bolum'] = $bo;
	}
	if ( isset( $q['bilgi'] ) && '' !== $q['bilgi'] ) {
		$bi = sides_yr_temiz( $q['bilgi'], 601, true );
		if ( mb_strlen( $bi ) > 600 ) {
			return 'bilgi notu en çok 600 karakter olmalı';
		}
		if ( '' !== $bi ) {
			$out['bilgi'] = $bi;
		}
	}
	$bv = isset( $q['bilgiVideo'] ) && is_string( $q['bilgiVideo'] ) ? trim( $q['bilgiVideo'] ) : '';
	if ( '' !== $bv ) {
		$v = sides_yr_medya_temiz( array( 'video' => $bv ) );
		if ( is_string( $v ) ) {
			return 'bilgi videosu: ' . $v;
		}
		$out['bilgiVideo'] = $v['video'];
	}
	if ( ! empty( $q['yedek'] ) ) {
		$out['yedek'] = 1;
	}
	return $out;
}
/* v7.9.17 Deste bölümleri: [{ ad, metin, video }] — bölüm giriş ekranında yayınlanır */
function sides_yr_bolumler_temiz( $L ) {
	$out = array();
	$gor = array();
	foreach ( ( is_array( $L ) ? array_slice( array_values( $L ), 0, 20 ) : array() ) as $b ) {
		if ( ! is_array( $b ) ) {
			continue;
		}
		$ad = sides_yr_temiz( isset( $b['ad'] ) ? $b['ad'] : '', 60 );
		if ( '' === $ad || isset( $gor[ $ad ] ) ) {
			continue;
		}
		$gor[ $ad ] = 1;
		$x          = array( 'ad' => $ad );
		$m          = sides_yr_temiz( isset( $b['metin'] ) ? $b['metin'] : '', 400, true );
		if ( '' !== $m ) {
			$x['metin'] = $m;
		}
		$v = sides_yr_medya_temiz( array( 'video' => isset( $b['video'] ) ? $b['video'] : '', 'gorsel' => isset( $b['gorsel'] ) ? $b['gorsel'] : '' ) );
		if ( is_string( $v ) ) {
			return 'Bölüm “' . $ad . '”: ' . $v;
		}
		$out[] = $x + $v;
	}
	return $out;
}
/* v7.9.15 Sunumlu yarışma ayarı: puan durumu ekranı, Banko (×2) / Viziko (×3) joker hakları (takım başına), geri sayım ve sesler, tema */
function sides_yr_sunum_ayar_temiz( $a ) {
	$a = is_array( $a ) ? $a : array();
	$pd = isset( $a['puanDurumu'] ) && in_array( $a['puanDurumu'], array( 'her', 'istek', 'n3', 'n5', 'bolum' ), true ) ? $a['puanDurumu'] : 'her';
	$n  = function ( $k, $vars, $max ) use ( $a ) {
		return isset( $a[ $k ] ) && is_numeric( $a[ $k ] ) ? max( 0, min( $max, (int) $a[ $k ] ) ) : $vars;
	};
	return array(
		'puanDurumu' => $pd,
		'banko'      => $n( 'banko', 0, 5 ),
		'riziko'     => $n( 'riziko', 0, 5 ),
		'birim'      => isset( $a['birim'] ) && 100 === (int) $a['birim'] ? 100 : 10,   // soru puanı 100 → tabloda 10 (çift puan 20); 100 seçilirse 100/200
		'sesler'     => ! isset( $a['sesler'] ) || ! empty( $a['sesler'] ) ? 1 : 0,
		'geriSayim'  => ! isset( $a['geriSayim'] ) || ! empty( $a['geriSayim'] ) ? 1 : 0,
		'tema'       => isset( $a['tema'] ) && in_array( $a['tema'], array( 'klasik', 'studyo', 'neon', 'tahta', 'renkli', 'gokyuzu', 'pastel', 'defter', 'modern' ), true ) ? $a['tema'] : 'studyo',
		'puanli'     => ! empty( $a['puanli'] ) ? 1 : 0,
		'tablo'      => isset( $a['tablo'] ) && in_array( $a['tablo'], array( 'kartlar', 'tabela', 'sutun', 'tablo' ), true ) ? $a['tablo'] : 'kartlar',   // v7.9.19 puan tablosu görünümü
		'sayac'      => isset( $a['sayac'] ) && in_array( $a['sayac'], array( 'halka', 'dijital', 'kum', 'fitil', 'dev', 'siren', 'kronometre', 'pil' ), true ) ? $a['sayac'] : 'halka',
		'bankoD'     => sides_yr_joker_carpan( $a, 2 )[0],
		'bankoY'     => sides_yr_joker_carpan( $a, 2 )[1],
		'rizikoD'    => sides_yr_joker_carpan( $a, 3 )[0],
		'rizikoY'    => sides_yr_joker_carpan( $a, 3 )[1],
		'alarm'      => isset( $a['alarm'] ) && in_array( (int) $a['alarm'], array( 0, 1, 2 ), true ) ? (int) $a['alarm'] : 2,   // v7.9.20 son 10 sn alarmı: 0 kapalı, 1 çerçeve, 2 çerçeve + ekran
		'bolumEkrani' => ! isset( $a['bolumEkrani'] ) || ! empty( $a['bolumEkrani'] ) ? 1 : 0,
	);
}
/* Joker kipi: takım başına Banko (×2) ya da Riziko (×3) hakkı varsa puan = soru puanı × çarpan (jokerli yanlışta soru puanı düşer), birim 10 ya da 100; yoksa her doğru 1 puan (eski kural). Ceza / düzeltme (takım başına tam sayı) toplama eklenir. */
function sides_yr_sunum_joker_kip( $g ) {
	$a = isset( $g['sunumAyar'] ) ? (array) $g['sunumAyar'] : array();
	return ( isset( $a['banko'] ) ? (int) $a['banko'] : 0 ) > 0 || ( isset( $a['riziko'] ) ? (int) $a['riziko'] : 0 ) > 0 || ! empty( $a['puanli'] );   // v7.9.17 puanlı kip (jokersiz de soru puanı × birim)
}
function sides_yr_sunum_puan( $g, $ti ) {
	$PD  = (array) $g['puanDisi'];
	$tp  = isset( $g['tpuan'] ) ? (array) $g['tpuan'] : array();
	$jk  = isset( $g['joker'] ) ? (array) $g['joker'] : array();
	$kip = sides_yr_sunum_joker_kip( $g );
	$ay  = sides_yr_sunum_ayar_temiz( isset( $g['sunumAyar'] ) ? $g['sunumAyar'] : array() );
	$cz  = isset( $g['ceza'] ) ? (array) $g['ceza'] : array();
	$p   = 0;
	$gno = isset( $g['no'] ) ? (int) $g['no'] : 0;
	$as  = isset( $g['asama'] ) ? (string) $g['asama'] : 'cevap';   // eski oyunlarda aşama yok: kayıtlı soruya kadar açıklanmış sayılır
	foreach ( $g['sorular'] as $no => $q ) {
		if ( isset( $PD[ $no ] ) ) {
			continue;
		}
		$acik = 'bitti' === $g['faz'] || $no < $gno || ( $no === $gno && in_array( $as, array( 'cevap', 'puan', 'tablo', 'kapanis', 'bolum' ), true ) );   // v7.9.18 jokerli yanlış, cevap açıklanınca düşer
		$p   += sides_yr_sunum_soru_puan( $q, ! empty( $tp[ $ti ][ $no ] ), isset( $jk[ $ti ][ $no ] ) ? (int) $jk[ $ti ][ $no ] : 0, $kip, $ay['birim'], $acik, $ay );
	}
	return $p + ( isset( $cz[ $ti ] ) ? (int) $cz[ $ti ] : 0 );
}
function sides_yr_sunum_soru_puan( $q, $dogru, $j, $kip, $birim, $acik = true, $ay = null ) {
	if ( ! $kip ) {
		return $dogru ? 1 : 0;
	}
	$sp = (int) round( sides_yr_soru_puan( $q ) * $birim / 100 );
	if ( ! $j ) {
		return $dogru ? $sp : 0;
	}
	$c = sides_yr_joker_carpan( $ay, $j );   // v7.9.20 Banko / Riziko artı ve eksi puanı ayarlanır
	return $dogru ? (int) round( $sp * $c[0] ) : ( $acik ? -(int) round( $sp * $c[1] ) : 0 );
}
function sides_yr_joker_carpan( $ay, $j ) {
	$a = is_array( $ay ) ? $ay : array();
	$k = 2 === (int) $j ? 'banko' : 'riziko';
	$d = isset( $a[ $k . 'D' ] ) && in_array( (float) $a[ $k . 'D' ], array( 1.5, 2.0, 2.5, 3.0, 4.0, 5.0 ), true ) ? (float) $a[ $k . 'D' ] : ( 2 === (int) $j ? 2.0 : 3.0 );
	$y = isset( $a[ $k . 'Y' ] ) && is_numeric( $a[ $k . 'Y' ] ) && in_array( (float) $a[ $k . 'Y' ], array( 0.0, 0.5, 1.0, 1.5, 2.0, 3.0 ), true ) ? (float) $a[ $k . 'Y' ] : 1.0;
	return array( $d, $y );
}
function sides_yr_deste_temizle( $p, $eski ) {
	$ad = sides_yr_temiz( isset( $p['ad'] ) ? $p['ad'] : '', 120 );
	if ( '' === $ad ) {
		return sides_yr_hata( 'sides_gecersiz', 'Deste adı gerekli.', 400 );
	}
	$kat = isset( $p['kategori'] ) && in_array( $p['kategori'], sides_yr_kategoriler(), true ) ? $p['kategori'] : 'ders';
	$L   = isset( $p['sorular'] ) && is_array( $p['sorular'] ) ? array_values( $p['sorular'] ) : array();
	if ( count( $L ) > SIDES_YR_MAX_SORU ) {
		return sides_yr_hata( 'sides_gecersiz', 'Bir destede en çok ' . SIDES_YR_MAX_SORU . ' soru olabilir.', 400 );
	}
	$onceki = array();
	foreach ( ( $eski && isset( $eski['sorular'] ) ? (array) $eski['sorular'] : array() ) as $q ) {
		if ( isset( $q['id'] ) ) {
			$onceki[ $q['id'] ] = $q;
		}
	}
	$out = array();
	$ids = array();
	foreach ( $L as $i => $q ) {
		$q  = is_array( $q ) ? $q : array();
		$no = $i + 1;
		$id = isset( $q['id'] ) && is_string( $q['id'] ) && preg_match( '/^q[a-z0-9]{4,24}$/', $q['id'] ) && ! isset( $ids[ $q['id'] ] ) ? $q['id'] : 'q' . sides_yr_rastgele( 5 );
		$ids[ $id ] = 1;
		$soru = sides_yr_temiz( isset( $q['soru'] ) ? $q['soru'] : '', 300, true );
		if ( '' === $soru ) {
			return sides_yr_hata( 'sides_gecersiz', $no . '. sorunun metni boş.', 400 );
		}
		$sec = array();
		foreach ( ( isset( $q['secenekler'] ) && is_array( $q['secenekler'] ) ? array_values( $q['secenekler'] ) : array() ) as $s ) {
			$s = sides_yr_temiz( $s, 120 );
			if ( '' === $s ) {
				return sides_yr_hata( 'sides_gecersiz', $no . '. soruda boş seçenek var; boş seçeneği silin ya da doldurun.', 400 );
			}
			$sec[] = $s;
		}
		if ( count( $sec ) < 2 || count( $sec ) > 4 ) {
			return sides_yr_hata( 'sides_gecersiz', $no . '. soruda 2–4 seçenek olmalı.', 400 );
		}
		$dg = isset( $q['dogru'] ) && is_numeric( $q['dogru'] ) ? (int) $q['dogru'] : -1;
		if ( $dg < 0 || $dg >= count( $sec ) ) {
			return sides_yr_hata( 'sides_gecersiz', $no . '. soru için doğru seçeneği işaretleyin.', 400 );
		}
		$sure = isset( $q['sure'] ) && is_numeric( $q['sure'] ) ? (int) $q['sure'] : 20;
		$zr   = isset( $q['zorluk'] ) && is_string( $q['zorluk'] ) ? $q['zorluk'] : '';
		if ( '' !== $zr && ! in_array( $zr, sides_yr_zorluklar(), true ) ) {
			return sides_yr_hata( 'sides_gecersiz', $no . '. soruda zorluk kolay, orta ya da zor olmalı.', 400 );
		}
		$pu = isset( $q['puan'] ) && '' !== $q['puan'] ? $q['puan'] : 100;
		if ( ! is_numeric( $pu ) || ! in_array( (int) $pu, sides_yr_puanlar(), true ) ) {
			return sides_yr_hata( 'sides_gecersiz', $no . '. soruda puan 0 (puansız), 100 (standart) ya da 200 (çift) olmalı.', 400 );
		}
		$y    = array(
			'id'         => $id,
			'soru'       => $soru,
			'secenekler' => $sec,
			'dogru'      => $dg,
			'aciklama'   => sides_yr_temiz( isset( $q['aciklama'] ) ? $q['aciklama'] : '', 400, true ),
			'sure'       => max( 5, min( 240, $sure ) ),
			'konu'       => sides_yr_temiz( isset( $q['konu'] ) ? $q['konu'] : '', 120 ),
			'zorluk'     => $zr,
			'puan'       => (int) $pu,
		);
		$m = sides_yr_medya_temiz( $q );
		if ( is_string( $m ) ) {
			return sides_yr_hata( 'sides_gecersiz', $no . '. soru: ' . $m . '.', 400 );
		}
		$y     += $m;
		$o      = isset( $onceki[ $id ] ) ? $onceki[ $id ] : null;
		$y['v'] = $o ? ( sides_yr_soru_ozet( $o + array( 'konu' => '', 'aciklama' => '' ) ) === sides_yr_soru_ozet( $y ) ? (int) ( isset( $o['v'] ) ? $o['v'] : 1 ) : (int) ( isset( $o['v'] ) ? $o['v'] : 1 ) + 1 ) : 1;
		if ( ! empty( $q['ornek'] ) ) {
			$y['ornek'] = true;
		}
		if ( ! empty( $q['kagitSiksiz'] ) ) {
			$y['kagitSiksiz'] = true;   // v7.9.20 soru kâğıdında şıklar basılmaz (onayı etkilemez)
		}
		$out[] = $y;
	}
	$atl = isset( $p['atolye'] ) && is_string( $p['atolye'] ) && isset( sides_yr_atolyeler()[ $p['atolye'] ] ) ? $p['atolye'] : '';
	$bl  = sides_yr_bolumler_temiz( isset( $p['bolumler'] ) ? $p['bolumler'] : array() );
	if ( is_string( $bl ) ) {
		return sides_yr_hata( 'sides_gecersiz', $bl, 400 );
	}
	return array(
		'bolumler' => $bl,
		'ad'       => $ad,
		'kategori' => $kat,
		'atolye'   => 'atolye' === $kat ? $atl : '',
		'ders'     => sides_yr_temiz( isset( $p['ders'] ) ? $p['ders'] : '', 40 ),
		'unite'    => sides_yr_temiz( isset( $p['unite'] ) ? $p['unite'] : '', 80 ),
		'konu'     => sides_yr_temiz( isset( $p['konu'] ) ? $p['konu'] : '', 200 ),
		'sinif'    => sides_yr_temiz( isset( $p['sinif'] ) ? $p['sinif'] : '', 12 ),
		'ornek'    => ! empty( $p['ornek'] ),
		'sorular'  => $out,
	);
}
/* v7.9.20 Düzen: soru sırası, soru kâğıdında şıksız sorular, bölüm ekranları. Değişmesi kaydı yeniler ama onayı kaldırmaz. */
function sides_yr_deste_duzen( $d ) {
	$s = array();
	foreach ( (array) $d['sorular'] as $q ) {
		$s[] = array( $q['id'], ! empty( $q['kagitSiksiz'] ) );
	}
	return md5( wp_json_encode( array( $s, isset( $d['bolumler'] ) ? array_values( (array) $d['bolumler'] ) : array() ) ) );
}
function sides_yr_deste_icerik( $d ) {
	$s = array();
	foreach ( (array) $d['sorular'] as $q ) {
		$s[] = array( $q['id'], $q['v'] );
	}
	return md5( wp_json_encode( array( $d['ad'], $d['kategori'], $d['ders'], $d['unite'], $d['konu'], $d['sinif'], $s, isset( $d['atolye'] ) ? (string) $d['atolye'] : '' ) ) );
}
function sides_yr_deste_disari( $id, $d, $tam ) {
	$o = array(
		'id'        => $id,
		'ad'        => (string) $d['ad'],
		'kategori'  => isset( $d['kategori'] ) ? $d['kategori'] : 'ders',
		'ders'      => isset( $d['ders'] ) ? $d['ders'] : '',
		'unite'     => isset( $d['unite'] ) ? $d['unite'] : '',
		'konu'      => isset( $d['konu'] ) ? $d['konu'] : '',
		'sinif'     => isset( $d['sinif'] ) ? $d['sinif'] : '',
		'durum'     => isset( $d['durum'] ) ? $d['durum'] : 'taslak',
		'surum'     => (int) ( isset( $d['surum'] ) ? $d['surum'] : 1 ),
		'ornek'     => ! empty( $d['ornek'] ),
		'soruSay'   => count( (array) $d['sorular'] ),
		'atolye'    => isset( $d['atolye'] ) ? (string) $d['atolye'] : '',
		'kutuphane' => isset( $d['kutuphane'] ) ? (string) $d['kutuphane'] : '',
		'kaynak'    => isset( $d['kaynak'] ) ? (string) $d['kaynak'] : '',
		'zorlukSay' => sides_yr_zorluk_say( (array) $d['sorular'] ),
		'sureTop'   => array_sum( array_map( function ( $q ) { return (int) $q['sure']; }, (array) $d['sorular'] ) ),
		'olusturan' => isset( $d['olusturan']['ad'] ) ? $d['olusturan']['ad'] : '',
		'onaylayan' => isset( $d['onaylayan'] ) ? $d['onaylayan'] : null,
		'guncel'    => isset( $d['guncel'] ) ? (int) $d['guncel'] : 0,
	);
	if ( $tam ) {
		$o['bolumler'] = isset( $d['bolumler'] ) ? array_values( (array) $d['bolumler'] ) : array();
		$o['sorular']  = array_values( (array) $d['sorular'] );
		$o['gecmis']  = array_slice( array_reverse( (array) ( isset( $d['gecmis'] ) ? $d['gecmis'] : array() ) ), 0, 20 );
	}
	return $o;
}
function sides_yr_deste_oku( WP_REST_Request $req ) {
	$d = sides_get_doc( sides_org_id(), 'ydeste', (string) $req['id'] );
	if ( ! $d ) {
		return sides_yr_hata( 'sides_yok', 'Deste bulunamadı.', 404 );
	}
	return sides_yr_res( sides_yr_deste_disari( (string) $req['id'], $d, true ) );
}
function sides_yr_gecmis( &$d, $islem, $kim ) {
	$g   = isset( $d['gecmis'] ) && is_array( $d['gecmis'] ) ? $d['gecmis'] : array();
	$g[] = array( 't' => time(), 'u' => $kim['u'], 'ad' => $kim['ad'], 'islem' => $islem );
	$d['gecmis'] = array_slice( $g, -40 );
}
function sides_yr_deste_kaydet( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = (array) $req->get_json_params();
	$id  = isset( $p['id'] ) ? (string) $p['id'] : '';
	if ( ! preg_match( '/^yd[a-z0-9]{6,20}$/', $id ) ) {
		return sides_yr_hata( 'sides_gecersiz', 'Geçersiz deste kimliği.', 400 );
	}
	if ( ! sides_rl( 'yr_deste_' . get_current_user_id(), 200, 600 ) ) {
		return sides_yr_hata( 'sides_rl', 'Çok sık kayıt; biraz bekleyin.', 429 );
	}
	$l = sides_yr_kilit( $org, $id );
	if ( false === $l ) {
		return sides_yr_mesgul();
	}
	$eski = sides_get_doc( $org, 'ydeste', $id );
	$d    = sides_yr_deste_temizle( $p, $eski );
	if ( is_wp_error( $d ) ) {
		sides_yr_birak( $l );
		return $d;
	}
	$kim = sides_yr_kim();
	if ( $eski ) {
		if ( sides_yr_deste_icerik( $d ) === sides_yr_deste_icerik( $eski ) && sides_yr_deste_duzen( $d ) === sides_yr_deste_duzen( $eski ) && ! empty( $eski['ornek'] ) === $d['ornek'] ) {
			sides_yr_birak( $l );
			return sides_yr_res( sides_yr_deste_disari( $id, $eski, true ) );   // aynı içerik (tekrar gönderim): değişiklik yok
		}
		if ( isset( $p['taban'] ) && (int) $p['taban'] !== (int) $eski['surum'] ) {
			sides_yr_birak( $l );
			return sides_yr_hata( 'sides_cakisma', 'Bu deste siz düzenlerken başka biri tarafından değiştirildi. Desteyi yeniden açıp değişikliğinizi tekrar yapın.', 409 );
		}
		$cift   = function ( $L ) {   // v7.9.20 sıra değişikliği içerik sayılmaz (onay korunur)
			$x = array_map( function ( $q ) { return $q['id'] . ':' . ( isset( $q['v'] ) ? (int) $q['v'] : 1 ); }, (array) $L );
			sort( $x );
			return implode( ',', $x );
		};
		$icerik = $cift( $d['sorular'] ) !== $cift( $eski['sorular'] );
		$duzen  = sides_yr_deste_duzen( $d ) !== sides_yr_deste_duzen( $eski );
		$d['durum']     = isset( $eski['durum'] ) ? $eski['durum'] : 'taslak';
		$d['olusturan'] = isset( $eski['olusturan'] ) ? $eski['olusturan'] : $kim;
		$d['olustu']    = isset( $eski['olustu'] ) ? (int) $eski['olustu'] : time();
		$d['onaylayan'] = isset( $eski['onaylayan'] ) ? $eski['onaylayan'] : null;
		$d['gecmis']    = isset( $eski['gecmis'] ) ? $eski['gecmis'] : array();
		foreach ( array( 'kutuphane', 'kaynak' ) as $k ) {   // Hazır Soru Bankası kopyası: köken bilgisi korunur
			if ( ! empty( $eski[ $k ] ) ) {
				$d[ $k ] = $eski[ $k ];
			}
		}
		$d['surum']     = (int) $eski['surum'] + ( $icerik || $duzen ? 1 : 0 );
		$islem          = $icerik ? 'Sorular güncellendi' : ( $duzen ? 'Soru sırası / soru kâğıdı düzeni güncellendi' : 'Deste bilgisi güncellendi' );
		if ( $icerik && 'onayli' === $d['durum'] ) {
			$d['durum']     = 'kontrol';   // onaylı içerik değişti: yeniden öğretmen kontrolü
			$d['onaylayan'] = null;
			$islem         .= '; onay kaldırıldı (öğretmen kontrolüne döndü)';
		}
	} else {
		$d['durum']     = 'taslak';
		$d['olusturan'] = $kim;
		$d['olustu']    = time();
		$d['onaylayan'] = null;
		$d['surum']     = 1;
		$islem          = 'Deste oluşturuldu';
	}
	$d['guncel'] = time();
	sides_yr_gecmis( $d, $islem, $kim );
	$ok = sides_yr_kaydet( $org, 'ydeste', $id, $d );
	sides_yr_birak( $l );
	if ( ! $ok ) {
		return sides_yr_hata( 'sides_db', 'Deste kaydedilemedi.', 500 );
	}
	sides_log( $org, 'Bilgi yarışması destesi: ' . $d['ad'] . ' — ' . $islem );
	return sides_yr_res( sides_yr_deste_disari( $id, $d, true ) );
}
function sides_yr_deste_durum( WP_REST_Request $req ) {
	$org = sides_org_id();
	$id  = (string) $req['id'];
	$p   = (array) $req->get_json_params();
	$yd  = isset( $p['durum'] ) ? (string) $p['durum'] : '';
	if ( ! in_array( $yd, array( 'taslak', 'kontrol', 'onayli', 'arsiv' ), true ) ) {
		return sides_yr_hata( 'sides_gecersiz', 'Geçersiz durum.', 400 );
	}
	$l = sides_yr_kilit( $org, $id );
	if ( false === $l ) {
		return sides_yr_mesgul();
	}
	$d = sides_get_doc( $org, 'ydeste', $id );
	if ( ! $d ) {
		sides_yr_birak( $l );
		return sides_yr_hata( 'sides_yok', 'Deste bulunamadı.', 404 );
	}
	unset( $d['id'] );
	$kim = sides_yr_kim();
	if ( 'onayli' === $yd && ( 'kontrol' !== $d['durum'] || ! count( (array) $d['sorular'] ) ) ) {
		sides_yr_birak( $l );
		return sides_yr_hata( 'sides_gecersiz', count( (array) $d['sorular'] ) ? 'Önce desteyi öğretmen kontrolüne gönderin; kontrol edilen deste onaylanır.' : 'Soru olmayan deste onaylanamaz.', 409 );
	}
	if ( $yd === $d['durum'] ) {
		sides_yr_birak( $l );
		return sides_yr_res( sides_yr_deste_disari( $id, $d, true ) );
	}
	$ad              = array( 'taslak' => 'Taslak', 'kontrol' => 'Öğretmen kontrolü', 'onayli' => 'Onaylı', 'arsiv' => 'Arşiv' );
	$d['durum']      = $yd;
	$d['onaylayan']  = 'onayli' === $yd ? array( 'u' => $kim['u'], 'ad' => $kim['ad'], 't' => time(), 'surum' => (int) $d['surum'] ) : ( 'arsiv' === $yd && isset( $d['onaylayan'] ) ? $d['onaylayan'] : null );
	$d['guncel']     = time();
	sides_yr_gecmis( $d, 'Durum: ' . $ad[ $yd ], $kim );
	$ok = sides_yr_kaydet( $org, 'ydeste', $id, $d );
	sides_yr_birak( $l );
	if ( ! $ok ) {
		return sides_yr_hata( 'sides_db', 'Durum kaydedilemedi.', 500 );
	}
	sides_log( $org, 'Bilgi yarışması destesi: ' . $d['ad'] . ' — durum ' . $ad[ $yd ] );
	return sides_yr_res( sides_yr_deste_disari( $id, $d, true ) );
}
function sides_yr_deste_sil( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$id  = (string) $req['id'];
	$d   = sides_get_doc( $org, 'ydeste', $id );
	if ( ! $d ) {
		return sides_yr_res( array( 'silindi' => true ) );
	}
	// v7.9.20 her durumdaki deste (onaylı dahil) yazma yetkisiyle silinebilir; oynanmış oyunlar kendi soru kopyasını taşır.
	$wpdb->delete( sides_docs(), array( 'org' => $org, 'coll' => 'ydeste', 'id' => $id ) );
	sides_log( $org, 'Bilgi yarışması destesi silindi: ' . $d['ad'] . ' (oynanmış oyunlar kendi soru kopyasıyla kalır)' );
	return sides_yr_res( array( 'silindi' => true ) );
}

/* ---------------- oyun: oluşturma ---------------- */
function sides_yr_pin_uret() {
	global $wpdb;
	$t = sides_docs();
	for ( $i = 0; $i < 40; $i++ ) {
		$pin = (string) random_int( 100000, 999999 );
		if ( ! (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE token = %s", 'yp' . $pin ) ) ) { // phpcs:ignore
			return $pin;
		}
	}
	return '';
}
function sides_yr_pin_yaz( $org, $gid, $pin ) {
	global $wpdb;
	$wpdb->update( sides_docs(), array( 'token' => $pin ? 'yp' . $pin : null ), array( 'org' => (int) $org, 'coll' => 'yoyun', 'id' => $gid ) );
}
function sides_yr_pin_oku( $org, $gid ) {
	global $wpdb;
	$t   = sides_docs();
	$tok = (string) $wpdb->get_var( $wpdb->prepare( "SELECT token FROM $t WHERE org = %d AND coll = 'yoyun' AND id = %s", $org, $gid ) ); // phpcs:ignore
	return 0 === strpos( $tok, 'yp' ) ? substr( $tok, 2 ) : '';
}
/* v7.9.20 Takım üyeleri ve yoklama: takım başına en çok 40 kişi; ad, kurum öğrencisi kimliği (sid) ve sınıf ya da misafir; yok = gelmedi. */
function sides_yr_uyeler_temiz( $u, $n ) {
	$u   = is_array( $u ) ? array_values( $u ) : array();
	$out = array();
	for ( $ti = 0; $ti < $n; $ti++ ) {
		$L = isset( $u[ $ti ] ) && is_array( $u[ $ti ] ) ? array_values( $u[ $ti ] ) : array();
		$r = array();
		foreach ( array_slice( $L, 0, 40 ) as $x ) {
			if ( ! is_array( $x ) ) {
				continue;
			}
			$ad = sides_yr_temiz( isset( $x['ad'] ) ? $x['ad'] : '', 60 );
			if ( '' === $ad ) {
				continue;
			}
			$y = array( 'ad' => $ad );
			if ( ! empty( $x['misafir'] ) ) {
				$y['misafir'] = 1;
			} else {
				if ( isset( $x['sid'] ) && is_scalar( $x['sid'] ) && preg_match( '/^[A-Za-z0-9_.:-]{1,60}$/', (string) $x['sid'] ) ) {
					$y['sid'] = (string) $x['sid'];
				}
				$sn = sides_yr_temiz( isset( $x['sinif'] ) ? $x['sinif'] : '', 16 );
				if ( '' !== $sn ) {
					$y['sinif'] = $sn;
				}
			}
			if ( ! empty( $x['yok'] ) ) {
				$y['yok'] = 1;
			}
			$r[] = $y;
		}
		$out[] = $r;
	}
	return $out;
}
function sides_yr_uyeler_disari( $g ) {
	$U = isset( $g['uyeler'] ) ? (array) $g['uyeler'] : array();
	$o = sides_is_observer();
	$r = array();
	foreach ( (array) $g['takimlar'] as $ti => $ad ) {
		$r[] = array_map( function ( $x ) use ( $o ) {
			if ( $o ) {
				$x['ad'] = sides_mask_name( $x['ad'] );
				unset( $x['sid'] );
			}
			return $x;
		}, isset( $U[ $ti ] ) ? array_values( (array) $U[ $ti ] ) : array() );
	}
	return $r;
}
/* Desteden oyun kurar (soru sürümü dondurulur). $o: tip, puanTuru, sira, adet, sure, ekSure, takimlar, islemId. Dönüş: [id, oyun] | WP_Error */
function sides_yr_oyun_kur( $org, $did, $deste, $o, $kim ) {
	$tip = isset( $o['tip'] ) && 'sunum' === $o['tip'] ? 'sunum' : 'canli';
	$isl = isset( $o['islemId'] ) && is_string( $o['islemId'] ) && preg_match( '/^[A-Za-z0-9_-]{6,40}$/', $o['islemId'] ) ? $o['islemId'] : sides_yr_rastgele( 8 );
	$gid = 'yo' . substr( md5( $org . '|' . $kim['u'] . '|' . $isl ), 0, 12 );   // aynı işlem kimliği ikinci oyun açmaz
	$var = sides_get_doc( $org, 'yoyun', $gid );
	if ( $var ) {
		unset( $var['id'] );
		return array( $gid, $var );
	}
	$S = array_values( (array) $deste['sorular'] );
	if ( ! $S ) {
		return sides_yr_hata( 'sides_gecersiz', 'Destede soru yok.', 409 );
	}
	$zr = isset( $o['zorluk'] ) && in_array( $o['zorluk'], sides_yr_zorluklar(), true ) ? $o['zorluk'] : '';
	if ( $zr ) {   // v7.8: yalnız seçilen zorluktaki sorular
		$S = array_values( array_filter( $S, function ( $q ) use ( $zr ) { return isset( $q['zorluk'] ) && $q['zorluk'] === $zr; } ) );
		if ( ! $S ) {
			return sides_yr_hata( 'sides_gecersiz', 'Bu destede seçilen zorlukta soru yok.', 409 );
		}
	}
	$Y = array_values( array_filter( $S, function ( $q ) { return ! empty( $q['yedek'] ); } ) );   // v7.9.17 yedek (eşitlik bozma) sorular sonda kalır
	$S = array_values( array_filter( $S, function ( $q ) { return empty( $q['yedek'] ); } ) );
	if ( ! $S ) {
		return sides_yr_hata( 'sides_gecersiz', 'Destede yedek olmayan soru yok.', 409 );
	}
	if ( isset( $o['sira'] ) && 'karisik' === $o['sira'] ) {
		shuffle( $S );
	}
	$adet = isset( $o['adet'] ) ? (int) $o['adet'] : 0;
	if ( $adet > 0 && $adet < count( $S ) ) {
		$S = array_slice( $S, 0, $adet );
	}
	$S = array_merge( $S, $Y );
	$sure = isset( $o['sure'] ) ? (int) $o['sure'] : 0;
	$ek   = isset( $o['ekSure'] ) ? max( 0, min( 30, (int) $o['ekSure'] ) ) : 0;
	$Q    = array();
	foreach ( $S as $q ) {
		$Q[] = array(
			'id'         => $q['id'],
			'v'          => (int) ( isset( $q['v'] ) ? $q['v'] : 1 ),
			'soru'       => $q['soru'],
			'secenekler' => array_values( $q['secenekler'] ),
			'dogru'      => (int) $q['dogru'],
			'aciklama'   => isset( $q['aciklama'] ) ? $q['aciklama'] : '',
			'sure'       => max( 5, min( 240, ( $sure >= 5 ? $sure : (int) $q['sure'] ) + $ek ) ),
			'konu'       => '' !== ( isset( $q['konu'] ) ? $q['konu'] : '' ) ? $q['konu'] : ( '' !== $deste['konu'] ? $deste['konu'] : '' ),
			'zorluk'     => isset( $q['zorluk'] ) ? (string) $q['zorluk'] : '',
			'puan'       => sides_yr_soru_puan( $q ),
		) + sides_yr_medya_ozet( $q );
	}
	$g = array(
		'tip'        => $tip,
		'desteId'    => $did,
		'desteSurum' => (int) $deste['surum'],
		'ad'         => $deste['ad'],
		'kategori'   => isset( $deste['kategori'] ) ? $deste['kategori'] : '',
		'ders'       => isset( $deste['ders'] ) ? $deste['ders'] : '',
		'unite'      => isset( $deste['unite'] ) ? $deste['unite'] : '',
		'konu'       => isset( $deste['konu'] ) ? $deste['konu'] : '',
		'sinif'      => isset( $deste['sinif'] ) ? $deste['sinif'] : '',
		'sorular'    => $Q,
		'bolumler'   => isset( $deste['bolumler'] ) ? array_values( (array) $deste['bolumler'] ) : array(),
		'puanTuru'   => 'canli' === $tip && isset( $o['puanTuru'] ) && 'hiz' === $o['puanTuru'] ? 'hiz' : 'dogruluk',
		'faz'        => 'sunum' === $tip ? 'soru' : 'lobi',
		'no'         => 'sunum' === $tip ? 0 : -1,
		'bas'        => 0,
		'son'        => 0,
		'durak'      => null,
		'v'          => 1,
		'seq'        => 0,
		'oyuncular'  => new stdClass(),
		'sonuc'      => new stdClass(),
		'puanDisi'   => new stdClass(),
		'atlandi'    => new stdClass(),
		'olaylar'    => array(),
		'olusturan'  => $kim,
		'olustu'     => sides_yr_ms(),
		'bitti'      => 0,
		'kural'      => SIDES_YR_KURAL,
		'islemId'    => $isl,
		'zorluk'     => $zr,
	);
	if ( ! empty( $deste['kutuphane'] ) ) {
		$g['kutuphane'] = (string) $deste['kutuphane'];   // Hazır Soru Bankası destesi (doğrudan oynandı ya da kopyası)
	}
	if ( 'sunum' === $tip ) {
		$T = array();
		foreach ( ( isset( $o['takimlar'] ) && is_array( $o['takimlar'] ) ? array_values( $o['takimlar'] ) : array() ) as $i => $ad ) {
			$ad  = sides_yr_temiz( $ad, 30 );
			$T[] = '' !== $ad ? $ad : ( $i + 1 ) . '. takım';
		}
		if ( count( $T ) < 1 || count( $T ) > 10 ) {
			return sides_yr_hata( 'sides_gecersiz', '1–10 takım adı girin.', 400 );
		}
		$g['takimlar']  = $T;
		$g['uyeler']    = sides_yr_uyeler_temiz( isset( $o['uyeler'] ) ? $o['uyeler'] : array(), count( $T ) );
		$g['tpuan']     = new stdClass();
		$g['joker']     = new stdClass();
		$g['ceza']      = new stdClass();
		$g['prova']     = ! empty( $o['prova'] );
		$g['sunumAyar'] = sides_yr_sunum_ayar_temiz( isset( $o['ayar'] ) ? $o['ayar'] : null );
	}
	$g = json_decode( wp_json_encode( $g ), true );   // nesne/dizi biçimi kalıcı kayıttaki gibi
	sides_yr_olay( $g, 'olustur', array( 'kim' => $kim['ad'] ) );
	if ( ! sides_yr_kaydet( $org, 'yoyun', $gid, $g ) ) {
		return sides_yr_hata( 'sides_db', 'Yarışma kaydedilemedi.', 500 );
	}
	if ( 'canli' === $tip ) {
		$pin = sides_yr_pin_uret();
		if ( ! $pin ) {
			return sides_yr_hata( 'sides_db', 'Boş PIN bulunamadı; tekrar deneyin.', 503 );
		}
		sides_yr_pin_yaz( $org, $gid, $pin );
	}
	return array( $gid, $g );
}
function sides_yr_oyun_yeni( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = (array) $req->get_json_params();
	$tip = isset( $p['tip'] ) && 'sunum' === $p['tip'] ? 'sunum' : 'canli';
	if ( ! sides_yr_izin( 2, array( 'sunum' === $tip ? 'EK15' : 'EK16' ) ) ) {
		return sides_deny( 'sunum' === $tip ? 'Sunumlu bilgi yarışması (EK15) bu hesap için açık değil.' : 'Canlı yarışma (EK16) bu hesap için açık değil.' );
	}
	if ( ! sides_rl( 'yr_oyun_' . get_current_user_id(), 60, 600 ) ) {
		return sides_yr_hata( 'sides_rl', 'Çok sık yarışma oluşturuldu; biraz bekleyin.', 429 );
	}
	$did = isset( $p['desteId'] ) ? (string) $p['desteId'] : '';
	$hz  = preg_match( '/^hz:([a-z0-9][a-z0-9-]{2,40})$/', $did, $m ) ? $m[1] : '';
	$d   = $hz ? sides_yr_kut_deste( $hz ) : ( preg_match( '/^yd[a-z0-9]{6,20}$/', $did ) ? sides_get_doc( $org, 'ydeste', $did ) : null );
	if ( ! $d ) {
		return sides_yr_hata( 'sides_yok', $hz ? 'Hazır Soru Bankası’nda bu deste bulunamadı.' : 'Deste bulunamadı.', 404 );
	}
	if ( ! $hz && 'onayli' !== $d['durum'] ) {   // hazır deste doğrudan oynanabilir (ATLAS özgün; öğretmen kontrolü önerilir)
		return sides_yr_hata( 'sides_gecersiz', 'Yarışma yalnız onaylı desteyle başlatılır. Desteyi kontrol edip onaylayın.', 409 );
	}
	$kim = sides_yr_kim();
	$r   = sides_yr_oyun_kur( $org, $did, $d, $p, $kim );
	if ( is_wp_error( $r ) ) {
		return $r;
	}
	sides_log( $org, ( 'sunum' === $tip ? 'Sunumlu bilgi yarışması başlatıldı: ' : 'Canlı yarışma oluşturuldu: ' ) . $d['ad'] . ' (deste sürümü ' . (int) $d['surum'] . ')' );
	return sides_yr_res( sides_yr_sunucu_dto( $org, $r[0], $r[1] ) );
}

/* ---------------- oyun: durum makinesi ---------------- */
function sides_yr_olay( &$g, $tip, $ek = array() ) {
	$g['seq']       = (int) ( isset( $g['seq'] ) ? $g['seq'] : 0 ) + 1;
	$L              = isset( $g['olaylar'] ) && is_array( $g['olaylar'] ) ? $g['olaylar'] : array();
	$L[]            = array_merge( array( 's' => $g['seq'], 'tip' => $tip, 't' => sides_yr_ms() ), $ek );
	$g['olaylar']   = array_slice( $L, -300 );
}
function sides_yr_soru_ac( &$g, $no ) {
	$now        = sides_yr_ms();
	$g['faz']   = 'soru';
	$g['no']    = $no;
	$g['bas']   = $now;
	$g['son']   = $now + 1000 * (int) $g['sorular'][ $no ]['sure'];
	$g['durak'] = null;
	$g['v']     = (int) $g['v'] + 1;
	sides_yr_olay( $g, 'soru', array( 'no' => $no ) );
}
function sides_yr_cevaplar( $org, $gid, $no ) {
	global $wpdb;
	$t   = sides_docs();
	$out = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND exam_id = %s AND coll = 'ycevap'", $org, $gid . '_' . $no ) ) as $r ) { // phpcs:ignore
		$d   = json_decode( $r->data, true );
		$pid = substr( $r->id, strrpos( $r->id, '_' ) + 1 );
		if ( is_array( $d ) ) {
			$out[ $pid ] = $d;
		}
	}
	return $out;
}
function sides_yr_cevap_say( $org, $gid, $no ) {
	global $wpdb;
	$t = sides_docs();
	return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE org = %d AND exam_id = %s AND coll = 'ycevap'", $org, $gid . '_' . $no ) ); // phpcs:ignore
}
function sides_yr_hiz_puan( $ms, $sure ) {
	if ( $ms <= 500 ) {
		return 1000;
	}
	return max( 0, 1000 * ( 1 - ( $ms / 1000 ) / ( 2 * max( 1, (int) $sure ) ) ) );   // yuvarlama soru puanıyla çarpıldıktan sonra
}
/* Açık soruyu kapatır ve puanlar (yanıtlar ayrı kayıtlardan okunur) */
function sides_yr_soru_kapat( $org, $gid, &$g, $neden ) {
	$no  = (int) $g['no'];
	$q   = $g['sorular'][ $no ];
	$res = array();
	foreach ( sides_yr_cevaplar( $org, $gid, $no ) as $pid => $c ) {
		if ( ! isset( $g['oyuncular'][ $pid ] ) ) {
			continue;
		}
		$s  = (int) $c['s'];
		$ms = max( 0, (int) $c['ms'] );
		$d  = $s === (int) $q['dogru'] ? 1 : 0;
		$w  = sides_yr_soru_puan( $q );   // v2: 100 standart (v1 ile aynı sonuç), 200 çift, 0 puansız
		$pu = $d ? ( 'hiz' === $g['puanTuru'] ? (int) round( sides_yr_hiz_puan( $ms, $q['sure'] ) * $w / 100 ) : intdiv( $w, 100 ) ) : 0;
		$res[ $pid ] = array( $s, $ms, $pu, $d );
	}
	if ( ! isset( $g['sonuc'] ) || ! is_array( $g['sonuc'] ) ) {
		$g['sonuc'] = array();
	}
	$g['sonuc'][ $no ] = $res;
	$g['faz']          = 'cevap';
	$g['durak']        = null;
	$g['kapandi']      = sides_yr_ms();
	$g['v']            = (int) $g['v'] + 1;
	sides_yr_olay( $g, 'kapat', array( 'no' => $no, 'neden' => $neden, 'yanit' => count( $res ) ) );
}
function sides_yr_bitir( $org, $gid, &$g ) {
	$g['faz']   = 'bitti';
	$g['durak'] = null;
	$g['bitti'] = sides_yr_ms();
	$g['v']     = (int) $g['v'] + 1;
	sides_yr_olay( $g, 'bitir' );
	sides_yr_pin_yaz( $org, $gid, '' );   // PIN artık çalışmaz
}
function sides_yr_sistem_durak( &$g, $b ) {
	if ( 'bitti' === $g['faz'] || ! empty( $g['durak'] ) ) {
		return false;
	}
	$now = sides_yr_ms();
	$t   = $now;
	$kt  = isset( $b['kapatan']['t'] ) ? 1000 * (int) $b['kapatan']['t'] : 0;
	if ( 'soru' === $g['faz'] && $kt >= (int) $g['bas'] && $kt <= $now ) {
		$t = min( $kt, (int) $g['son'] );   // kapanma anından itibaren süre işlemez
	}
	$g['durak'] = array( 't' => $t, 'neden' => 'sistem' );
	$g['v']     = (int) $g['v'] + 1;
	sides_yr_olay( $g, 'sistem-durak', array( 'no' => (int) $g['no'] ) );
	return true;
}
/* Son zaman geçtiyse soruyu kapatır; kurum sistemi kapalıysa oyunu duraklatır. Kilit alınamazsa olduğu gibi döner. */
function sides_yr_tazele( $org, $gid, $g, $bekle = 0 ) {
	$b      = sides_yr_sistem( $org );
	$now    = sides_yr_ms();
	$sure   = 'soru' === $g['faz'] && empty( $g['durak'] ) && $now >= (int) $g['son'];
	$sistem = $b && 'bitti' !== $g['faz'] && empty( $g['durak'] );
	if ( ! $sure && ! $sistem ) {
		return $g;
	}
	$l = sides_yr_kilit( $org, $gid, $bekle );
	if ( false === $l ) {
		return $g;
	}
	$y = sides_get_doc( $org, 'yoyun', $gid );
	if ( ! $y ) {
		sides_yr_birak( $l );
		return $g;
	}
	unset( $y['id'] );
	$deg = false;
	if ( $b ) {
		$deg = sides_yr_sistem_durak( $y, $b );
	} elseif ( 'soru' === $y['faz'] && empty( $y['durak'] ) && sides_yr_ms() >= (int) $y['son'] ) {
		$kt = sides_yr_kesinti( $org, (int) $y['bas'], (int) $y['son'] );
		if ( $kt ) {   // soru açıkken sistem kapanıp açılmış ve kimse sormamış: kapanma anında duraklatılmış sayılır
			$y['durak'] = array( 't' => $kt, 'neden' => 'sistem' );
			$y['v']     = (int) $y['v'] + 1;
			sides_yr_olay( $y, 'sistem-durak', array( 'no' => (int) $y['no'], 'geriye' => 1 ) );
		} else {
			sides_yr_soru_kapat( $org, $gid, $y, 'sure' );
		}
		$deg = true;
	}
	if ( $deg ) {
		sides_yr_kaydet( $org, 'yoyun', $gid, $y );
	}
	sides_yr_birak( $l );
	return $y;
}
/* Soru penceresinde (bas, son) sistem kapatıldıysa ilk kapanma anı (ms) */
function sides_yr_kesinti( $org, $bas, $son ) {
	if ( ! function_exists( 'sides_bakim_oku' ) ) {
		return 0;
	}
	$b = sides_get_doc( (int) $org, 'sistem', 'bakim' );
	foreach ( ( $b && isset( $b['gecmis'] ) ? (array) $b['gecmis'] : array() ) as $x ) {
		$t = 1000 * (int) ( isset( $x['t'] ) ? $x['t'] : 0 );
		if ( isset( $x['islem'] ) && 'kapat' === $x['islem'] && $t >= $bas && $t < $son ) {
			return $t;
		}
	}
	return 0;
}
function sides_yr_kalan( $g ) {
	if ( 'soru' !== $g['faz'] ) {
		return 0;
	}
	$ref = ! empty( $g['durak'] ) ? (int) $g['durak']['t'] : sides_yr_ms();
	return max( 0, (int) $g['son'] - $ref );
}
/* Toplamlar ve sıralama (puan dışı ve atlanan sorular sayılmaz). Eşit puan eşit sıradır. */
function sides_yr_toplam( $g ) {
	$T = array();
	foreach ( (array) $g['oyuncular'] as $pid => $o ) {
		if ( empty( $o['cikti'] ) ) {
			$T[ $pid ] = array( 'id' => $pid, 'ad' => $o['ad'], 'puan' => 0, 'dogru' => 0, 'yanlis' => 0, 'bos' => 0, 'ms' => 0 );
		}
	}
	$S = isset( $g['sonuc'] ) && is_array( $g['sonuc'] ) ? $g['sonuc'] : array();
	foreach ( $S as $no => $res ) {
		if ( isset( $g['puanDisi'][ $no ] ) || isset( $g['atlandi'][ $no ] ) ) {
			continue;
		}
		foreach ( $T as $pid => $x ) {
			$r = is_array( $res ) && isset( $res[ $pid ] ) ? $res[ $pid ] : null;
			if ( ! $r ) {
				$T[ $pid ]['bos']++;
				continue;
			}
			$T[ $pid ][ $r[3] ? 'dogru' : 'yanlis' ]++;
			$T[ $pid ]['puan'] += (int) $r[2];
			$T[ $pid ]['ms']   += (int) $r[1];
		}
	}
	$L = array_values( $T );
	usort( $L, function ( $a, $b ) {
		return $b['puan'] - $a['puan'] ? $b['puan'] - $a['puan'] : ( $b['dogru'] - $a['dogru'] ? $b['dogru'] - $a['dogru'] : strcmp( mb_strtolower( $a['ad'] ), mb_strtolower( $b['ad'] ) ) );
	} );
	$say = array();
	foreach ( $L as $x ) {
		$say[ $x['puan'] ] = ( isset( $say[ $x['puan'] ] ) ? $say[ $x['puan'] ] : 0 ) + 1;
	}
	foreach ( $L as $i => $x ) {
		$ust = 0;
		foreach ( $L as $y ) {
			if ( $y['puan'] > $x['puan'] ) {
				$ust++;
			}
		}
		$L[ $i ]['sira'] = $ust + 1;
		$L[ $i ]['esit'] = $say[ $x['puan'] ] > 1;
	}
	return $L;
}
function sides_yr_aktif_say( $g ) {
	$n = 0;
	foreach ( (array) $g['oyuncular'] as $o ) {
		if ( empty( $o['cikti'] ) ) {
			$n++;
		}
	}
	return $n;
}
function sides_yr_sahip( $g ) {
	$c = sides_ctx();
	if ( sides_is_observer() || ! sides_can( 'sosyal', 2 ) ) {
		return false;
	}
	return 'yonetici' === $c['rol'] || (int) $g['olusturan']['u'] === (int) $c['uid'];
}

/* ---------------- sunucu (öğretmen) görünümü ---------------- */
function sides_yr_sunucu_dto( $org, $gid, $g ) {
	$b     = sides_yr_sistem( $org );
	$sahip = sides_yr_sahip( $g );
	$n     = count( $g['sorular'] );
	$d     = array(
		'id'         => $gid,
		'tip'        => $g['tip'],
		'ad'         => $g['ad'],
		'ders'       => $g['ders'],
		'unite'      => $g['unite'],
		'konu'       => $g['konu'],
		'sinif'      => $g['sinif'],
		'faz'        => $g['faz'],
		'no'         => (int) $g['no'],
		'toplam'     => $n,
		'puanTuru'   => $g['puanTuru'],
		'v'          => (int) $g['v'],
		'kalan'      => sides_yr_kalan( $g ),
		'durak'      => ! empty( $g['durak'] ) ? $g['durak']['neden'] : '',
		'sistem'     => (bool) $b,
		'sistemMesaj' => $b ? sides_yr_sistem_mesaj( $b ) : '',
		'sahip'      => $sahip,
		'olusturan'  => isset( $g['olusturan']['ad'] ) ? $g['olusturan']['ad'] : '',
		'olustu'     => (int) $g['olustu'],
		'bitti'      => (int) $g['bitti'],
		'desteSurum' => (int) $g['desteSurum'],
		'desteId'    => $g['desteId'],
		'puanDisi'   => array_map( 'intval', array_keys( (array) $g['puanDisi'] ) ),
		'atlandi'    => array_map( 'intval', array_keys( (array) $g['atlandi'] ) ),
	);
	if ( 'sunum' === $g['tip'] ) {
		$d['takimlar']  = $g['takimlar'];
		$d['uyeler']    = sides_yr_uyeler_disari( $g );
		$d['bolumler']  = isset( $g['bolumler'] ) ? array_values( (array) $g['bolumler'] ) : array();
		$d['girisLink'] = ! empty( $g['girisSon'] ) && (int) $g['girisSon'] > sides_yr_ms() && 0 === strpos( (string) sides_yr_token_oku( $org, $gid ), 'yk' ) ? (int) $g['girisSon'] : 0;
		$d['tpuan']     = (object) ( isset( $g['tpuan'] ) ? $g['tpuan'] : array() );
		$d['joker']     = (object) ( isset( $g['joker'] ) ? $g['joker'] : array() );
		$d['ceza']      = (object) ( isset( $g['ceza'] ) ? $g['ceza'] : array() );
		$d['sunumAyar'] = sides_yr_sunum_ayar_temiz( isset( $g['sunumAyar'] ) ? $g['sunumAyar'] : array( 'puanDurumu' => 'istek', 'tema' => 'klasik', 'sesler' => 0, 'geriSayim' => 0 ) );
		$d['prova']     = ! empty( $g['prova'] );
		if ( $sahip ) {
			$d['sorular'] = $g['sorular'];   // sunumu öğretmen yönetir: cevap anahtarı yalnız sahibine
		}
		return $d;
	}
	if ( $sahip && 'bitti' !== $g['faz'] ) {
		$d['pin'] = sides_yr_pin_oku( $org, $gid );
	}
	$d['oyuncuSay'] = sides_yr_aktif_say( $g );
	$T              = sides_yr_toplam( $g );
	$d['oyuncular'] = array_map( function ( $x ) {
		return array( 'id' => $x['id'], 'ad' => sides_is_observer() ? sides_mask_name( $x['ad'] ) : $x['ad'], 'puan' => $x['puan'], 'dogru' => $x['dogru'], 'sira' => $x['sira'], 'esit' => $x['esit'] );
	}, $T );
	if ( in_array( $g['faz'], array( 'soru', 'cevap' ), true ) && $g['no'] >= 0 ) {
		$q         = $g['sorular'][ $g['no'] ];
		$d['soru'] = array( 'metin' => $q['soru'], 'secenekler' => $q['secenekler'], 'sure' => (int) $q['sure'], 'konu' => $q['konu'], 'puan' => sides_yr_soru_puan( $q ) );
		if ( 'soru' === $g['faz'] ) {
			$d['cevapSay'] = sides_yr_cevap_say( $org, $gid, $g['no'] );
		} else {
			$res  = isset( $g['sonuc'][ $g['no'] ] ) ? (array) $g['sonuc'][ $g['no'] ] : array();
			$dag  = array_fill( 0, count( $q['secenekler'] ), 0 );
			foreach ( $res as $r ) {
				if ( isset( $dag[ (int) $r[0] ] ) ) {
					$dag[ (int) $r[0] ]++;
				}
			}
			$d['cevapSay']         = count( $res );
			$d['soru']['dogru']    = (int) $q['dogru'];
			$d['soru']['aciklama'] = $q['aciklama'];
			$d['soru']['dagilim']  = $dag;
		}
	}
	return $d;
}
function sides_yr_oyun_al( $org, $gid ) {
	$g = sides_get_doc( $org, 'yoyun', $gid );
	if ( $g ) {
		unset( $g['id'] );
	}
	return $g;
}
function sides_yr_oyun_oku( WP_REST_Request $req ) {
	$org = sides_org_id();
	$gid = (string) $req['id'];
	$g   = sides_yr_oyun_al( $org, $gid );
	if ( ! $g ) {
		return sides_yr_hata( 'sides_yok', 'Yarışma bulunamadı.', 404 );
	}
	if ( 'canli' === $g['tip'] ) {
		$g = sides_yr_tazele( $org, $gid, $g, 1 );
	}
	return sides_yr_res( sides_yr_sunucu_dto( $org, $gid, $g ) );
}
/* Öğretmen kontrolü. REST dışından (sınama) da çağrılabilir. */
function sides_yr_islem( $org, $gid, $is, $p ) {
	$l = sides_yr_kilit( $org, $gid, 5 );
	if ( false === $l ) {
		return sides_yr_mesgul();
	}
	$g = sides_yr_oyun_al( $org, $gid );
	if ( ! $g || 'canli' !== $g['tip'] ) {
		sides_yr_birak( $l );
		return sides_yr_hata( 'sides_yok', 'Canlı yarışma bulunamadı.', 404 );
	}
	$hata = null;
	$b    = sides_yr_sistem( $org );
	$deg  = $b ? sides_yr_sistem_durak( $g, $b ) : false;
	$n    = count( $g['sorular'] );
	$log  = '';
	if ( 'bitti' === $g['faz'] && 'bitir' !== $is ) {
		$hata = sides_yr_hata( 'sides_yr_bitti', 'Yarışma bitti.', 409 );
	} elseif ( $b && ! in_array( $is, array( 'bitir', 'cikar' ), true ) ) {
		$hata = sides_yr_hata( 'sides_yr_sistem', 'ATLAS şu anda kapalı; yarışma beklemede. Sistem açılınca kaldığı yerden devam ettirebilir ya da bitirebilirsiniz.', 503 );
	} elseif ( 'basla' === $is ) {
		if ( 'lobi' !== $g['faz'] ) {
			$hata = sides_yr_hata( 'sides_yr_faz', 'Yarışma zaten başladı.', 409 );
		} elseif ( ! sides_yr_aktif_say( $g ) ) {
			$hata = sides_yr_hata( 'sides_yr_faz', 'Henüz katılan oyuncu yok.', 409 );
		} else {
			$g['durak'] = null;
			sides_yr_soru_ac( $g, 0 );
			$deg = true;
			$log = 'Canlı yarışma başladı: ' . $g['ad'] . ' (' . sides_yr_aktif_say( $g ) . ' oyuncu)';
		}
	} elseif ( 'goster' === $is ) {
		if ( 'soru' !== $g['faz'] ) {
			$hata = sides_yr_hata( 'sides_yr_faz', 'Açık soru yok.', 409 );
		} else {
			sides_yr_soru_kapat( $org, $gid, $g, 'ogretmen' );
			$deg = true;
		}
	} elseif ( 'sonraki' === $is || 'atla' === $is ) {
		if ( 'atla' === $is && 'soru' === $g['faz'] ) {
			sides_yr_soru_kapat( $org, $gid, $g, 'atla' );
			$g['atlandi'][ (int) $g['no'] ] = 1;
		}
		if ( 'cevap' !== $g['faz'] ) {
			$hata = sides_yr_hata( 'sides_yr_faz', 'Önce cevabı gösterin.', 409 );
		} elseif ( ! empty( $g['durak'] ) ) {
			$hata = sides_yr_hata( 'sides_yr_faz', 'Yarışma duraklatılmış; önce devam ettirin.', 409 );
		} elseif ( (int) $g['no'] + 1 < $n ) {
			sides_yr_soru_ac( $g, (int) $g['no'] + 1 );
			$deg = true;
		} else {
			sides_yr_bitir( $org, $gid, $g );
			$deg = true;
			$log = 'Canlı yarışma bitti: ' . $g['ad'];
		}
	} elseif ( 'duraklat' === $is ) {
		if ( empty( $g['durak'] ) ) {
			$g['durak'] = array( 't' => sides_yr_ms(), 'neden' => 'ogretmen' );
			$g['v']     = (int) $g['v'] + 1;
			sides_yr_olay( $g, 'duraklat', array( 'no' => (int) $g['no'] ) );
			$deg = true;
		}
	} elseif ( 'devam' === $is ) {
		if ( ! empty( $g['durak'] ) ) {
			$fark = max( 0, sides_yr_ms() - (int) $g['durak']['t'] );
			if ( 'soru' === $g['faz'] ) {
				$g['bas'] = (int) $g['bas'] + $fark;   // kalan süre korunur
				$g['son'] = (int) $g['son'] + $fark;
			}
			$g['durak'] = null;
			$g['v']     = (int) $g['v'] + 1;
			sides_yr_olay( $g, 'devam', array( 'no' => (int) $g['no'], 'ms' => $fark ) );
			$deg = true;
		}
	} elseif ( 'bitir' === $is ) {
		if ( 'bitti' !== $g['faz'] ) {
			if ( 'soru' === $g['faz'] ) {
				sides_yr_soru_kapat( $org, $gid, $g, 'bitir' );
			}
			sides_yr_bitir( $org, $gid, $g );
			$deg = true;
			$log = 'Canlı yarışma bitirildi: ' . $g['ad'];
		}
	} elseif ( 'cikar' === $is ) {
		$pid = isset( $p['oyuncu'] ) ? (string) $p['oyuncu'] : '';
		if ( ! isset( $g['oyuncular'][ $pid ] ) ) {
			$hata = sides_yr_hata( 'sides_yok', 'Oyuncu bulunamadı.', 404 );
		} elseif ( empty( $g['oyuncular'][ $pid ]['cikti'] ) ) {
			$g['oyuncular'][ $pid ]['cikti'] = true;
			$g['v']                          = (int) $g['v'] + 1;
			sides_yr_olay( $g, 'cikar', array( 'p' => $pid ) );
			$deg = true;
		}
	} else {
		$hata = sides_yr_hata( 'sides_gecersiz', 'Geçersiz işlem.', 400 );
	}
	if ( $deg && ! sides_yr_kaydet( $org, 'yoyun', $gid, $g ) ) {
		$hata = sides_yr_hata( 'sides_db', 'Kaydedilemedi.', 500 );
	}
	sides_yr_birak( $l );
	if ( $log && ! $hata ) {
		sides_log( $org, $log );
	}
	return $hata ? $hata : $g;
}
function sides_yr_oyun_kontrol( WP_REST_Request $req ) {
	$org = sides_org_id();
	$gid = (string) $req['id'];
	$g   = sides_yr_oyun_al( $org, $gid );
	if ( ! $g ) {
		return sides_yr_hata( 'sides_yok', 'Yarışma bulunamadı.', 404 );
	}
	if ( ! sides_yr_sahip( $g ) ) {
		return sides_deny( 'Yarışmayı yalnız oluşturan öğretmen ya da kurum yöneticisi yönetir.' );
	}
	$p  = (array) $req->get_json_params();
	$is = isset( $p['islem'] ) ? (string) $p['islem'] : '';
	if ( ! in_array( $is, array( 'basla', 'goster', 'sonraki', 'atla', 'duraklat', 'devam', 'bitir', 'cikar' ), true ) ) {
		return sides_yr_hata( 'sides_gecersiz', 'Geçersiz işlem.', 400 );
	}
	$r = sides_yr_islem( $org, $gid, $is, $p );
	if ( is_wp_error( $r ) ) {
		return $r;
	}
	return sides_yr_res( sides_yr_sunucu_dto( $org, $gid, $r ) );
}
function sides_yr_sunum_kaydet( WP_REST_Request $req ) {
	$org = sides_org_id();
	$gid = (string) $req['id'];
	$p   = (array) $req->get_json_params();
	$l   = sides_yr_kilit( $org, $gid );
	if ( false === $l ) {
		return sides_yr_mesgul();
	}
	$g = sides_yr_oyun_al( $org, $gid );
	if ( ! $g || 'sunum' !== $g['tip'] ) {
		sides_yr_birak( $l );
		return sides_yr_hata( 'sides_yok', 'Sunumlu yarışma bulunamadı.', 404 );
	}
	if ( ! sides_yr_sahip( $g ) ) {
		sides_yr_birak( $l );
		return sides_deny( 'Sunumu yalnız başlatan öğretmen ya da kurum yöneticisi kaydeder.' );
	}
	$n  = count( $g['sorular'] );
	$tp = array();
	$in = isset( $p['tpuan'] ) && is_array( $p['tpuan'] ) ? $p['tpuan'] : null;   // v7.9.15: alan yoksa sunucudaki işaretler korunur (puan girişi ikinci kişiden gelebilir)
	foreach ( $g['takimlar'] as $ti => $ad ) {
		$a = null !== $in && isset( $in[ $ti ] ) && is_array( $in[ $ti ] ) ? array_values( $in[ $ti ] ) : array();
		$r = array();
		for ( $i = 0; $i < $n; $i++ ) {
			$r[] = isset( $a[ $i ] ) && 1 === (int) $a[ $i ] ? 1 : 0;
		}
		$tp[ $ti ] = $r;
	}
	if ( null !== $in ) {
		$g['tpuan'] = $tp;
	}
	$ay = sides_yr_sunum_ayar_temiz( isset( $g['sunumAyar'] ) ? $g['sunumAyar'] : array() );
	$jk = array();
	$ij = isset( $p['joker'] ) && is_array( $p['joker'] ) ? $p['joker'] : null;
	foreach ( null === $ij ? array() : $g['takimlar'] as $ti => $ad ) {
		$a  = isset( $ij[ $ti ] ) && is_array( $ij[ $ti ] ) ? array_values( $ij[ $ti ] ) : array();
		$r  = array();
		$kb = 0;
		$kv = 0;
		for ( $i = 0; $i < $n; $i++ ) {
			$v = isset( $a[ $i ] ) ? (int) $a[ $i ] : 0;
			if ( 2 === $v && $kb < $ay['banko'] ) {
				$kb++;
			} elseif ( 3 === $v && $kv < $ay['riziko'] ) {
				$kv++;
			} else {
				$v = 0;   // hak yok ya da geçersiz değer
			}
			$r[] = $v;
		}
		$jk[ $ti ] = $r;
	}
	if ( null !== $ij ) {
		$g['joker'] = $jk;
	}
	$cz = array();
	$ic = isset( $p['ceza'] ) && is_array( $p['ceza'] ) ? $p['ceza'] : null;
	foreach ( null === $ic ? array() : $g['takimlar'] as $ti => $ad ) {
		$cz[ $ti ] = isset( $ic[ $ti ] ) && is_numeric( $ic[ $ti ] ) ? max( -99999, min( 99999, (int) $ic[ $ti ] ) ) : 0;
	}
	if ( null !== $ic ) {
		$g['ceza'] = $cz;
	}
	if ( isset( $p['uyeler'] ) && is_array( $p['uyeler'] ) ) {
		$g['uyeler'] = sides_yr_uyeler_temiz( $p['uyeler'], count( $g['takimlar'] ) );   // v7.9.20 sahnede yoklama (geldi / gelmedi)
	}
	$g['no']    = isset( $p['no'] ) ? max( 0, min( $n - 1, (int) $p['no'] ) ) : (int) $g['no'];
	if ( isset( $p['asama'] ) && in_array( $p['asama'], array( 'acilis', 'prova', 'joker', 'soru', 'cevap', 'puan', 'tablo', 'bolum', 'bilgi', 'kapanis' ), true ) ) {
		$g['asama'] = $p['asama'];   // v7.9.17 puan girişi ekranı sahnenin nerede olduğunu gösterir
	}
	$bitti      = ! empty( $p['bitti'] ) && 'bitti' !== $g['faz'];
	if ( $bitti ) {
		$g['faz']   = 'bitti';
		$g['bitti'] = sides_yr_ms();
		sides_yr_olay( $g, 'bitir' );
	}
	$g['v'] = (int) $g['v'] + 1;
	$ok     = sides_yr_kaydet( $org, 'yoyun', $gid, $g );
	sides_yr_birak( $l );
	if ( ! $ok ) {
		return sides_yr_hata( 'sides_db', 'Sunum sonucu kaydedilemedi.', 500 );
	}
	if ( $bitti ) {
		sides_log( $org, 'Sunumlu bilgi yarışması tamamlandı: ' . $g['ad'] . ' (' . count( $g['takimlar'] ) . ' takım)' );
	}
	return sides_yr_res( array( 'v' => $g['v'], 'faz' => $g['faz'] ) );
}
/* v7.9.17 Puan girişi linki: hesapsız ikinci kişi ekranı. Anahtar yalnız oluşturulurken bir kez döner; sunucuda özeti (docs.token = 'yk' + sha256[0..37]) durur.
   Süre: 12 saat ya da yarışma bitene dek; yeniden oluşturmak eski linki kapatır. Uçlar: yarisma/oyun/<id>/giris-link (yetkili), yr/puan (herkese açık, anahtarla). */
function sides_yr_token_oku( $org, $gid ) {
	global $wpdb;
	$t = sides_docs();
	return (string) $wpdb->get_var( $wpdb->prepare( "SELECT token FROM $t WHERE org = %d AND coll = 'yoyun' AND id = %s", $org, $gid ) ); // phpcs:ignore
}
function sides_yr_giris_ozet( $k ) {
	return 'yk' . substr( hash( 'sha256', 'atlas-yr-puan|' . $k ), 0, 38 );
}
function sides_yr_giris_link( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$gid = (string) $req['id'];
	$p   = (array) $req->get_json_params();
	$l   = sides_yr_kilit( $org, $gid );
	if ( false === $l ) {
		return sides_yr_mesgul();
	}
	$g = sides_yr_oyun_al( $org, $gid );
	if ( ! $g || 'sunum' !== $g['tip'] ) {
		sides_yr_birak( $l );
		return sides_yr_hata( 'sides_yok', 'Sunumlu yarışma bulunamadı.', 404 );
	}
	if ( ! sides_yr_sahip( $g ) ) {
		sides_yr_birak( $l );
		return sides_deny( 'Puan girişi linkini yalnız sunumu başlatan öğretmen ya da kurum yöneticisi oluşturur.' );
	}
	if ( ! empty( $p['iptal'] ) ) {
		$wpdb->update( sides_docs(), array( 'token' => null ), array( 'org' => (int) $org, 'coll' => 'yoyun', 'id' => $gid ) );
		$g['girisSon'] = 0;
		sides_yr_kaydet( $org, 'yoyun', $gid, $g );
		sides_yr_birak( $l );
		return sides_yr_res( array( 'kapali' => 1 ) );
	}
	if ( 'bitti' === $g['faz'] ) {
		sides_yr_birak( $l );
		return sides_yr_hata( 'sides_gecersiz', 'Yarışma bitti; puan girişi linki oluşturulamaz.', 409 );
	}
	$k             = sides_yr_rastgele( 12 );   // 24 onaltılık karakter
	$g['girisSon'] = sides_yr_ms() + 12 * 3600 * 1000;
	sides_yr_kaydet( $org, 'yoyun', $gid, $g );
	$wpdb->update( sides_docs(), array( 'token' => sides_yr_giris_ozet( $k ) ), array( 'org' => (int) $org, 'coll' => 'yoyun', 'id' => $gid ) );
	sides_yr_birak( $l );
	sides_log( $org, 'Bilgi yarışması: puan girişi linki oluşturuldu (' . $g['ad'] . ')' );
	return sides_yr_res( array( 'anahtar' => $k, 'son' => (int) $g['girisSon'] ) );
}
function sides_yr_puan_link( WP_REST_Request $req ) {
	global $wpdb;
	$p = (array) $req->get_json_params();
	$k = isset( $p['k'] ) && is_string( $p['k'] ) && preg_match( '/^[a-f0-9]{24}$/', $p['k'] ) ? $p['k'] : '';
	if ( ! sides_rl_check( 'yr_pk_bad', 40 ) ) {
		return sides_yr_hata( 'sides_rl', 'Çok sayıda hatalı deneme; bir süre sonra yeniden deneyin.', 429 );
	}
	$t   = sides_docs();
	$row = '' !== $k ? $wpdb->get_row( $wpdb->prepare( "SELECT org, id FROM $t WHERE token = %s AND coll = 'yoyun' LIMIT 1", sides_yr_giris_ozet( $k ) ) ) : null; // phpcs:ignore
	$g   = $row ? sides_yr_oyun_al( (int) $row->org, $row->id ) : null;
	if ( ! $g || 'sunum' !== $g['tip'] || empty( $g['girisSon'] ) || (int) $g['girisSon'] < sides_yr_ms() ) {
		sides_rl_hit( 'yr_pk_bad', 600 );
		return sides_yr_hata( 'sides_yr_link', 'Puan girişi linki geçersiz ya da süresi dolmuş. Sunucudan yeni link isteyin.', 404 );
	}
	if ( ! sides_rl( 'yr_pk|' . substr( $k, 0, 8 ), 4000, 600 ) ) {
		return sides_yr_hata( 'sides_rl', 'Çok sık istek. Birkaç saniye sonra yeniden denenecek.', 429 );
	}
	$org = (int) $row->org;
	$gid = $row->id;
	if ( isset( $p['t'] ) ) {
		$r = sides_yr_isaret_yap( $org, $gid, $p, true );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		$d = $r->get_data();
		$d = isset( $d['data'] ) ? $d['data'] : $d;
	} else {
		$d = sides_yr_giris_dto( $gid, $g );
	}
	$d['sahip']  = false;
	$d['kurum']  = (string) get_option( 'blogname' );
	$d['link']   = 1;
	$d['son']    = (int) $g['girisSon'];
	return sides_yr_res( $d );
}
/* v7.9.15 Puan girişi (ikinci kişi): sunumu bir kişi yönetirken başka bir öğretmen telefondan doğru / yanlış, joker ve cezayı işaretler.
   Sunucu tek doğru kaynaktır: sahne de bu uçla tek hücre gönderir ve 2 sn'de bir sunucudan okur. Cevap anahtarı personel içindir (sosyal ≥ 2). */
function sides_yr_giris_dto( $gid, $g ) {
	$ay = sides_yr_sunum_ayar_temiz( isset( $g['sunumAyar'] ) ? $g['sunumAyar'] : array() );
	$Q  = array();
	foreach ( $g['sorular'] as $no => $q ) {
		$Q[] = array( 'no' => $no, 'soru' => $q['soru'], 'secenekler' => $q['secenekler'], 'dogru' => (int) $q['dogru'], 'puan' => sides_yr_soru_puan( $q ), 'konu' => isset( $q['konu'] ) ? $q['konu'] : '', 'bolum' => isset( $q['bolum'] ) ? $q['bolum'] : '', 'yedek' => ! empty( $q['yedek'] ) ? 1 : 0 );
	}
	$T = array();
	foreach ( $g['takimlar'] as $ti => $ad ) {
		$T[] = array( 'ad' => $ad, 'puan' => sides_yr_sunum_puan( $g, $ti ) );
	}
	return array(
		'id'        => $gid,
		'ad'        => $g['ad'],
		'faz'       => $g['faz'],
		'no'        => (int) $g['no'],
		'asama'     => isset( $g['asama'] ) ? (string) $g['asama'] : '',
		'v'         => (int) $g['v'],
		'takimlar'  => $g['takimlar'],
		'toplam'    => $T,
		'tpuan'     => (object) ( isset( $g['tpuan'] ) ? $g['tpuan'] : array() ),
		'joker'     => (object) ( isset( $g['joker'] ) ? $g['joker'] : array() ),
		'ceza'      => (object) ( isset( $g['ceza'] ) ? $g['ceza'] : array() ),
		'puanDisi'  => array_map( 'intval', array_keys( (array) $g['puanDisi'] ) ),
		'sunumAyar' => $ay,
		'jokerKip'  => sides_yr_sunum_joker_kip( $g ),
		'sorular'   => $Q,
		'sahip'     => sides_yr_sahip( $g ),
	);
}
function sides_yr_giris_oku( WP_REST_Request $req ) {
	$org = sides_org_id();
	$gid = (string) $req['id'];
	$g   = sides_yr_oyun_al( $org, $gid );
	if ( ! $g || 'sunum' !== $g['tip'] ) {
		return sides_yr_hata( 'sides_yok', 'Sunumlu yarışma bulunamadı.', 404 );
	}
	return sides_yr_res( sides_yr_giris_dto( $gid, $g ) );
}
function sides_yr_isaret( WP_REST_Request $req ) {
	return sides_yr_isaret_yap( sides_org_id(), (string) $req['id'], (array) $req->get_json_params(), false );
}
function sides_yr_isaret_yap( $org, $gid, $p, $link ) {
	$l   = sides_yr_kilit( $org, $gid );
	if ( false === $l ) {
		return sides_yr_mesgul();
	}
	$g = sides_yr_oyun_al( $org, $gid );
	if ( ! $g || 'sunum' !== $g['tip'] ) {
		sides_yr_birak( $l );
		return sides_yr_hata( 'sides_yok', 'Sunumlu yarışma bulunamadı.', 404 );
	}
	if ( 'bitti' === $g['faz'] && ( $link || ! sides_yr_sahip( $g ) ) ) {
		sides_yr_birak( $l );
		return sides_yr_hata( 'sides_gecersiz', 'Yarışma bitti; puanlar kapandı.', 409 );
	}
	$n  = count( $g['sorular'] );
	$ti = isset( $p['t'] ) ? (int) $p['t'] : -1;
	if ( $ti < 0 || $ti >= count( $g['takimlar'] ) ) {
		sides_yr_birak( $l );
		return sides_yr_hata( 'sides_gecersiz', 'Takım bulunamadı.', 400 );
	}
	$ay = sides_yr_sunum_ayar_temiz( isset( $g['sunumAyar'] ) ? $g['sunumAyar'] : array() );
	$tp = isset( $g['tpuan'] ) ? (array) $g['tpuan'] : array();
	$jk = isset( $g['joker'] ) ? (array) $g['joker'] : array();
	$cz = isset( $g['ceza'] ) ? (array) $g['ceza'] : array();
	foreach ( $g['takimlar'] as $k => $ad ) {
		$tp[ $k ] = array_pad( array_slice( isset( $tp[ $k ] ) ? array_values( (array) $tp[ $k ] ) : array(), 0, $n ), $n, 0 );
		$jk[ $k ] = array_pad( array_slice( isset( $jk[ $k ] ) ? array_values( (array) $jk[ $k ] ) : array(), 0, $n ), $n, 0 );
		$cz[ $k ] = isset( $cz[ $k ] ) ? (int) $cz[ $k ] : 0;
	}
	if ( isset( $p['ceza'] ) ) {
		$cz[ $ti ] = max( -99999, min( 99999, (int) $p['ceza'] ) );
	} else {
		$no = isset( $p['no'] ) ? (int) $p['no'] : -1;
		if ( $no < 0 || $no >= $n ) {
			sides_yr_birak( $l );
			return sides_yr_hata( 'sides_gecersiz', 'Soru numarası geçersiz.', 400 );
		}
		if ( isset( $p['dogru'] ) ) {
			$tp[ $ti ][ $no ] = 1 === (int) $p['dogru'] ? 1 : 0;
		}
		if ( isset( $p['joker'] ) ) {
			$v = (int) $p['joker'];
			if ( ! in_array( $v, array( 0, 2, 3 ), true ) ) {
				sides_yr_birak( $l );
				return sides_yr_hata( 'sides_gecersiz', 'Joker 0, 2 (Banko) ya da 3 (Riziko) olmalı.', 400 );
			}
			if ( $v ) {
				$hak  = 2 === $v ? $ay['banko'] : $ay['riziko'];
				$kull = 0;
				foreach ( $jk[ $ti ] as $qi => $x ) {
					if ( $qi !== $no && (int) $x === $v ) {
						$kull++;
					}
				}
				if ( $kull >= $hak ) {
					sides_yr_birak( $l );
					return sides_yr_hata( 'sides_gecersiz', $g['takimlar'][ $ti ] . ' takımının ' . ( 2 === $v ? 'Banko' : 'Riziko' ) . ' hakkı kalmadı.', 409 );
				}
			}
			$jk[ $ti ][ $no ] = $v;
		}
	}
	$g['tpuan'] = $tp;
	$g['joker'] = $jk;
	$g['ceza']  = $cz;
	$g['v']     = (int) $g['v'] + 1;
	$ok         = sides_yr_kaydet( $org, 'yoyun', $gid, $g );
	sides_yr_birak( $l );
	if ( ! $ok ) {
		return sides_yr_hata( 'sides_db', 'İşaret kaydedilemedi.', 500 );
	}
	return sides_yr_res( sides_yr_giris_dto( $gid, $g ) );
}
function sides_yr_puandisi( WP_REST_Request $req ) {
	$org = sides_org_id();
	$gid = (string) $req['id'];
	$p   = (array) $req->get_json_params();
	$no  = isset( $p['no'] ) ? (int) $p['no'] : -1;
	$geri = ! empty( $p['geri'] );
	$ger = sides_yr_temiz( isset( $p['gerekce'] ) ? $p['gerekce'] : '', 200 );
	if ( mb_strlen( $ger ) < 3 ) {
		return sides_yr_hata( 'sides_gecersiz', 'Gerekçe yazın (en az 3 karakter).', 400 );
	}
	$l = sides_yr_kilit( $org, $gid );
	if ( false === $l ) {
		return sides_yr_mesgul();
	}
	$g = sides_yr_oyun_al( $org, $gid );
	if ( ! $g ) {
		sides_yr_birak( $l );
		return sides_yr_hata( 'sides_yok', 'Yarışma bulunamadı.', 404 );
	}
	if ( ! sides_yr_sahip( $g ) ) {
		sides_yr_birak( $l );
		return sides_deny( 'Soruyu puan dışı bırakmayı yalnız yarışmayı oluşturan öğretmen ya da kurum yöneticisi yapar.' );
	}
	$kapali = 'sunum' === $g['tip'] ? ( $no >= 0 && $no < count( $g['sorular'] ) ) : isset( $g['sonuc'][ $no ] );
	if ( ! $kapali ) {
		sides_yr_birak( $l );
		return sides_yr_hata( 'sides_gecersiz', 'Yalnız kapanmış bir soru puan dışı bırakılabilir.', 409 );
	}
	$kim  = sides_yr_kim();
	$hs   = (int) ( isset( $g['hesap'] ) ? $g['hesap'] : 0 ) + 1;
	$PD   = is_array( $g['puanDisi'] ) ? $g['puanDisi'] : array();
	if ( $geri ) {
		unset( $PD[ $no ] );
	} else {
		$PD[ $no ] = array( 'gerekce' => $ger, 't' => time(), 'u' => $kim['u'], 'ad' => $kim['ad'], 'hesap' => $hs );
	}
	$g['puanDisi'] = $PD;
	$g['hesap']    = $hs;
	$g['v']        = (int) $g['v'] + 1;
	sides_yr_olay( $g, $geri ? 'puandisi-geri' : 'puandisi', array( 'no' => $no, 'gerekce' => $ger, 'kim' => $kim['ad'], 'hesap' => $hs ) );
	$ok = sides_yr_kaydet( $org, 'yoyun', $gid, $g );
	sides_yr_birak( $l );
	if ( ! $ok ) {
		return sides_yr_hata( 'sides_db', 'Kaydedilemedi.', 500 );
	}
	sides_log( $org, 'Bilgi yarışması ' . $g['ad'] . ': ' . ( $no + 1 ) . '. soru ' . ( $geri ? 'yeniden puana katıldı' : 'puan dışı bırakıldı' ) . ' (' . $ger . '); sonuçlar yeniden hesaplandı (hesap ' . $hs . ')' );
	return sides_yr_rapor_uret( $org, $gid, $g );
}
function sides_yr_oyun_sil( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$gid = (string) $req['id'];
	$g   = sides_yr_oyun_al( $org, $gid );
	if ( ! $g ) {
		return sides_yr_res( array( 'silindi' => true ) );
	}
	if ( ! sides_yr_sahip( $g ) ) {
		return sides_deny( 'Yarışmayı yalnız oluşturan öğretmen ya da kurum yöneticisi siler.' );
	}
	$t   = sides_docs();
	$ids = array();
	foreach ( array_keys( (array) $g['sorular'] ) as $no ) {
		$ids[] = $gid . '_' . $no;
	}
	if ( $ids ) {
		$ph = implode( ',', array_fill( 0, count( $ids ), '%s' ) );
		$wpdb->query( $wpdb->prepare( "DELETE FROM $t WHERE org = %d AND coll = 'ycevap' AND exam_id IN ($ph)", array_merge( array( $org ), $ids ) ) ); // phpcs:ignore
	}
	$wpdb->delete( $t, array( 'org' => $org, 'coll' => 'yoyun', 'id' => $gid ) );
	sides_log( $org, 'Bilgi yarışması kaydı silindi: ' . $g['ad'] );
	return sides_yr_res( array( 'silindi' => true ) );
}

/* ---------------- liste ve rapor ---------------- */
function sides_yr_ozet() {
	global $wpdb;
	$org = sides_org_id();
	$t   = sides_docs();
	$D   = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = 'ydeste'", $org ) ) as $r ) { // phpcs:ignore
		$d = json_decode( $r->data, true );
		if ( is_array( $d ) ) {
			$D[] = sides_yr_deste_disari( $r->id, $d, false );
		}
	}
	$O = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = 'yoyun' ORDER BY updated_at DESC LIMIT 80", $org ) ) as $r ) { // phpcs:ignore
		$g = json_decode( $r->data, true );
		if ( ! is_array( $g ) ) {
			continue;
		}
		$O[] = array(
			'id'        => $r->id,
			'tip'       => $g['tip'],
			'ad'        => $g['ad'],
			'desteId'   => $g['desteId'],
			'faz'       => $g['faz'],
			'puanTuru'  => $g['puanTuru'],
			'olustu'    => (int) $g['olustu'],
			'bitti'     => (int) $g['bitti'],
			'soruSay'   => count( (array) $g['sorular'] ),
			'oyuncuSay' => 'sunum' === $g['tip'] ? count( (array) $g['takimlar'] ) : sides_yr_aktif_say( $g ),
			'olusturan' => isset( $g['olusturan']['ad'] ) ? $g['olusturan']['ad'] : '',
			'sahip'     => sides_yr_sahip( $g ),
			'eski'      => 'bitti' !== $g['faz'] && sides_yr_ms() - (int) $g['olustu'] > SIDES_YR_PIN_OMUR * 1000,
		);
	}
	return sides_yr_res( array( 'desteler' => $D, 'oyunlar' => $O, 'kurulumlar' => sides_yr_kurulum_liste( $org ), 'yaz' => sides_yr_izin( 2 ) && ! sides_is_observer(), 'ek15' => sides_yr_izin( 1, array( 'EK15' ) ), 'ek16' => sides_yr_izin( 1, array( 'EK16' ) ) ) );
}
/* v7.9.21 Kayıtlı yarışma kurulumları (sunumlu): deste, takımlar, üyeler ve yoklama, Yarışma günü ayarları. Sayfa yenilense de kalır.
   Kullanıcı kendi kayıtlarını görür; kurum yöneticisi hepsini. Kişi başına en çok 50 kayıt. Belge: org/ykurulum/kr… */
function sides_yr_kurulum_temiz( $p ) {
	$T = array();
	foreach ( ( isset( $p['takimlar'] ) && is_array( $p['takimlar'] ) ? array_slice( array_values( $p['takimlar'] ), 0, 10 ) : array() ) as $i => $ad ) {
		$ad  = sides_yr_temiz( is_scalar( $ad ) ? (string) $ad : '', 30 );
		$T[] = '' !== $ad ? $ad : ( $i + 1 ) . '. takım';
	}
	if ( count( $T ) < 2 ) {
		$T = array_merge( $T, array_slice( array( '1. takım', '2. takım' ), count( $T ) ) );
	}
	$did = isset( $p['desteId'] ) && is_string( $p['desteId'] ) && preg_match( '/^(yd[a-z0-9]{6,20}|hz:[a-z0-9][a-z0-9-]{2,40})$/', $p['desteId'] ) ? $p['desteId'] : '';
	return array(
		'ad'       => sides_yr_temiz( isset( $p['ad'] ) ? $p['ad'] : '', 80 ),
		'desteId'  => $did,
		'takimlar' => $T,
		'uyeler'   => sides_yr_uyeler_temiz( isset( $p['uyeler'] ) ? $p['uyeler'] : array(), count( $T ) ),
		'sure'     => isset( $p['sure'] ) ? max( 0, min( 240, (int) $p['sure'] ) ) : 0,
		'sira'     => isset( $p['sira'] ) && 'karisik' === $p['sira'] ? 'karisik' : 'deste',
		'adet'     => isset( $p['adet'] ) ? max( 0, min( SIDES_YR_MAX_SORU, (int) $p['adet'] ) ) : 0,
		'prova'    => ! empty( $p['prova'] ),
		'zorluk'   => isset( $p['zorluk'] ) && in_array( $p['zorluk'], array( 'kolay', 'orta', 'zor' ), true ) ? $p['zorluk'] : '',
		'ay'       => sides_yr_sunum_ayar_temiz( isset( $p['ay'] ) && is_array( $p['ay'] ) ? $p['ay'] : array() ),
	);
}
function sides_yr_kurulum_liste( $org ) {
	global $wpdb;
	$t   = sides_docs();
	$uid = get_current_user_id();
	$yon = 'yonetici' === sides_ctx()['rol'];
	$L   = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = 'ykurulum' ORDER BY updated_at DESC LIMIT 200", $org ) ) as $r ) { // phpcs:ignore
		$d = json_decode( $r->data, true );
		if ( ! is_array( $d ) || ( ! $yon && (int) $d['sahip'] !== $uid ) ) {
			continue;
		}
		$d['id']    = $r->id;
		$d['benim'] = (int) $d['sahip'] === $uid;
		if ( sides_is_observer() ) {
			$d['uyeler'] = sides_yr_uyeler_disari( $d );
		}
		$L[] = $d;
	}
	usort( $L, function ( $a, $b ) { return (int) $b['guncel'] - (int) $a['guncel']; } );
	return $L;
}
function sides_yr_kurulum_kaydet( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = (array) $req->get_json_params();
	$uid = get_current_user_id();
	if ( ! sides_rl( 'yr_kurulum_' . $uid, 600, 600 ) ) {
		return sides_yr_hata( 'sides_rl', 'Çok sık kayıt; biraz bekleyin.', 429 );
	}
	$id   = isset( $p['id'] ) && is_string( $p['id'] ) && preg_match( '/^kr[a-f0-9]{12}$/', $p['id'] ) ? $p['id'] : '';
	$eski = $id ? sides_get_doc( $org, 'ykurulum', $id ) : null;
	if ( $eski && (int) $eski['sahip'] !== $uid && 'yonetici' !== sides_ctx()['rol'] ) {
		return sides_deny( 'Bu yarışma kaydını yalnız hazırlayan öğretmen ya da kurum yöneticisi değiştirir.' );
	}
	if ( ! $eski ) {
		global $wpdb;
		$t = sides_docs();
		$n = 0;
		foreach ( (array) $wpdb->get_col( $wpdb->prepare( "SELECT data FROM $t WHERE org = %d AND coll = 'ykurulum'", $org ) ) as $raw ) { // phpcs:ignore
			$x = json_decode( $raw, true );
			$n += is_array( $x ) && (int) $x['sahip'] === $uid ? 1 : 0;
		}
		if ( $n >= 50 ) {
			return sides_yr_hata( 'sides_gecersiz', 'En çok 50 kayıtlı yarışma tutulur; eskilerden birini silin.', 409 );
		}
		$id = $id ? $id : 'kr' . sides_yr_rastgele( 6 );
	}
	$d           = sides_yr_kurulum_temiz( $p );
	$kim         = sides_yr_kim();
	$d['sahip']  = $eski ? (int) $eski['sahip'] : $uid;
	$d['olusturan'] = $eski && isset( $eski['olusturan'] ) ? $eski['olusturan'] : $kim['ad'];
	$d['olustu'] = $eski && isset( $eski['olustu'] ) ? (int) $eski['olustu'] : time();
	$d['guncel'] = time();
	if ( '' === $d['ad'] ) {
		$d['ad'] = 'Yarışma ' . wp_date( 'd.m.Y H:i' );
	}
	if ( isset( $p['sonOyun'] ) && is_string( $p['sonOyun'] ) && preg_match( '/^yo[a-f0-9]{12}$/', $p['sonOyun'] ) ) {
		$d['sonOyun'] = $p['sonOyun'];
	} elseif ( $eski && isset( $eski['sonOyun'] ) ) {
		$d['sonOyun'] = $eski['sonOyun'];
	}
	if ( false === sides_put_doc( $org, 'ykurulum', $id, $d ) ) {
		return sides_yr_hata( 'sides_db', 'Yarışma kaydedilemedi.', 500 );
	}
	if ( ! $eski ) {
		sides_log( $org, 'Bilgi yarışması kaydedildi: ' . $d['ad'] . ' (' . count( $d['takimlar'] ) . ' takım)' );
	}
	$d['id']    = $id;
	$d['benim'] = (int) $d['sahip'] === $uid;
	return sides_yr_res( $d );
}
function sides_yr_kurulum_sil( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$id  = (string) $req['id'];
	$d   = sides_get_doc( $org, 'ykurulum', $id );
	if ( $d && (int) $d['sahip'] !== get_current_user_id() && 'yonetici' !== sides_ctx()['rol'] ) {
		return sides_deny( 'Bu yarışma kaydını yalnız hazırlayan öğretmen ya da kurum yöneticisi siler.' );
	}
	if ( $d ) {
		$wpdb->delete( sides_docs(), array( 'org' => $org, 'coll' => 'ykurulum', 'id' => $id ) );
		sides_log( $org, 'Kayıtlı bilgi yarışması silindi: ' . $d['ad'] );
	}
	return sides_yr_res( array( 'silindi' => true ) );
}
function sides_yr_rapor( WP_REST_Request $req ) {
	$org = sides_org_id();
	$gid = (string) $req['id'];
	$g   = sides_yr_oyun_al( $org, $gid );
	if ( ! $g ) {
		return sides_yr_hata( 'sides_yok', 'Yarışma bulunamadı.', 404 );
	}
	return sides_yr_rapor_uret( $org, $gid, $g );
}
function sides_yr_rapor_uret( $org, $gid, $g ) {
	$gz    = sides_is_observer();
	$adOf  = function ( $s ) use ( $gz ) {
		return $gz ? sides_mask_name( $s ) : $s;
	};
	$sun   = 'sunum' === $g['tip'];
	$PD    = (array) $g['puanDisi'];
	$AT    = (array) $g['atlandi'];
	$Q     = array();
	$K     = array();
	$yan   = array();
	$aktif = array();
	foreach ( (array) $g['oyuncular'] as $pid => $o ) {
		if ( empty( $o['cikti'] ) ) {
			$aktif[ $pid ] = $o['ad'];
		}
	}
	$tp = $sun && isset( $g['tpuan'] ) ? (array) $g['tpuan'] : array();
	foreach ( $g['sorular'] as $no => $q ) {
		$x = array( 'no' => $no, 'metin' => $q['soru'], 'secenekler' => $q['secenekler'], 'dogru' => (int) $q['dogru'], 'aciklama' => $q['aciklama'], 'konu' => '' !== $q['konu'] ? $q['konu'] : 'Konu belirtilmedi', 'sure' => (int) $q['sure'], 'v' => (int) $q['v'], 'zorluk' => isset( $q['zorluk'] ) ? $q['zorluk'] : '', 'puan' => sides_yr_soru_puan( $q ),
			'D' => 0, 'Y' => 0, 'B' => 0, 'ortMs' => null, 'dagilim' => array_fill( 0, count( $q['secenekler'] ), 0 ), 'kapandi' => false, 'puanDisi' => isset( $PD[ $no ] ) ? $PD[ $no ] : null, 'atlandi' => isset( $AT[ $no ] ) );
		if ( $sun ) {
			$x['kapandi'] = 'bitti' === $g['faz'] || $no <= (int) $g['no'];
			foreach ( $g['takimlar'] as $ti => $ad ) {
				$v = isset( $tp[ $ti ][ $no ] ) ? (int) $tp[ $ti ][ $no ] : 0;
				$x[ $v ? 'D' : 'Y' ]++;
			}
		} elseif ( isset( $g['sonuc'][ $no ] ) ) {
			$x['kapandi'] = true;
			$res          = (array) $g['sonuc'][ $no ];
			$top          = 0;
			foreach ( $aktif as $pid => $ad ) {
				$r = isset( $res[ $pid ] ) ? $res[ $pid ] : null;
				if ( ! $r ) {
					$x['B']++;
					$yan[] = array( $adOf( $ad ), $no + 1, '', 'boş', 0, null );
					continue;
				}
				$x[ $r[3] ? 'D' : 'Y' ]++;
				$top += (int) $r[1];
				if ( isset( $x['dagilim'][ (int) $r[0] ] ) ) {
					$x['dagilim'][ (int) $r[0] ]++;
				}
				$yan[] = array( $adOf( $ad ), $no + 1, chr( 65 + (int) $r[0] ), $r[3] ? 'doğru' : 'yanlış', isset( $PD[ $no ] ) || isset( $AT[ $no ] ) ? 0 : (int) $r[2], (int) $r[1] );
			}
			$x['ortMs'] = $x['D'] + $x['Y'] ? (int) round( $top / ( $x['D'] + $x['Y'] ) ) : null;
		}
		$Q[] = $x;
		if ( $x['kapandi'] && ! $x['puanDisi'] && ! $x['atlandi'] ) {
			$k = $x['konu'];
			if ( ! isset( $K[ $k ] ) ) {
				$K[ $k ] = array( 'konu' => $k, 'soru' => 0, 'D' => 0, 'Y' => 0, 'B' => 0 );
			}
			$K[ $k ]['soru']++;
			$K[ $k ]['D'] += $x['D'];
			$K[ $k ]['Y'] += $x['Y'];
			$K[ $k ]['B'] += $x['B'];
		}
	}
	foreach ( $K as $k => $v ) {
		$tum           = $v['D'] + $v['Y'] + $v['B'];
		$K[ $k ]['oran'] = $tum ? round( 100 * $v['D'] / $tum, 1 ) : null;
	}
	$out = array(
		'oyun'    => array( 'id' => $gid, 'tip' => $g['tip'], 'ad' => $g['ad'], 'kutuphane' => isset( $g['kutuphane'] ) ? $g['kutuphane'] : '', 'zorluk' => isset( $g['zorluk'] ) ? $g['zorluk'] : '', 'ders' => $g['ders'], 'unite' => $g['unite'], 'konu' => $g['konu'], 'sinif' => $g['sinif'], 'faz' => $g['faz'], 'puanTuru' => $g['puanTuru'], 'olustu' => (int) $g['olustu'], 'bitti' => (int) $g['bitti'],
			'olusturan' => isset( $g['olusturan']['ad'] ) ? $g['olusturan']['ad'] : '', 'desteId' => $g['desteId'], 'desteSurum' => (int) $g['desteSurum'], 'kural' => isset( $g['kural'] ) ? $g['kural'] : '', 'hesap' => (int) ( isset( $g['hesap'] ) ? $g['hesap'] : 0 ), 'sahip' => sides_yr_sahip( $g ) ),
		'sorular' => $Q,
		'konular' => array_values( $K ),
		'duzeltme' => array_values( array_filter( (array) $g['olaylar'], function ( $e ) { return in_array( $e['tip'], array( 'puandisi', 'puandisi-geri' ), true ); } ) ),
	);
	if ( $sun ) {
		$T = array();
		$jk  = isset( $g['joker'] ) ? (array) $g['joker'] : array();
		$cz  = isset( $g['ceza'] ) ? (array) $g['ceza'] : array();
		$kip = sides_yr_sunum_joker_kip( $g );
		$UY  = sides_yr_uyeler_disari( $g );
		foreach ( $g['takimlar'] as $ti => $ad ) {
			$T[] = array( 'ad' => $ad, 'ti' => (int) $ti, 'uyeler' => isset( $UY[ $ti ] ) ? $UY[ $ti ] : array(), 'puan' => sides_yr_sunum_puan( $g, $ti ), 'sorular' => isset( $tp[ $ti ] ) ? array_values( (array) $tp[ $ti ] ) : array(), 'joker' => $kip && isset( $jk[ $ti ] ) ? array_values( (array) $jk[ $ti ] ) : array(), 'ceza' => isset( $cz[ $ti ] ) ? (int) $cz[ $ti ] : 0 );
		}
		$out['oyun']['jokerKip'] = $kip;
		$out['oyun']['sunumAyar'] = sides_yr_sunum_ayar_temiz( isset( $g['sunumAyar'] ) ? $g['sunumAyar'] : array() );
		$P = array_map( function ( $x ) { return $x['puan']; }, $T );
		foreach ( $T as $i => $x ) {
			$T[ $i ]['sira'] = 1 + count( array_filter( $P, function ( $v ) use ( $x ) { return $v > $x['puan']; } ) );
			$T[ $i ]['esit'] = count( array_keys( $P, $x['puan'], true ) ) > 1;
		}
		usort( $T, function ( $a, $b ) { return $a['sira'] - $b['sira']; } );
		$out['takimlar'] = $T;
	} else {
		$out['siralama'] = array_map( function ( $x ) use ( $adOf ) {
			$x['ad'] = $adOf( $x['ad'] );
			unset( $x['id'] );
			return $x;
		}, sides_yr_toplam( $g ) );
		$out['yanitlar'] = $yan;
	}
	return sides_yr_res( $out );
}

/* ---------------- herkese açık oyuncu uçları ---------------- */
function sides_yr_takma_ad( $s ) {
	$s = sides_yr_temiz( $s, 40 );
	$n = mb_strlen( $s );
	if ( $n < 2 ) {
		return sides_yr_hata( 'sides_yr_ad', 'Takma ad en az 2 karakter olmalı.', 400 );
	}
	if ( $n > 20 ) {
		return sides_yr_hata( 'sides_yr_ad', 'Takma ad en çok 20 karakter olabilir.', 400 );
	}
	if ( ! preg_match( '/^[\p{L}\p{N} ._-]+$/u', $s ) ) {
		return sides_yr_hata( 'sides_yr_ad', 'Takma adda yalnız harf, rakam, boşluk, nokta, tire ve alt çizgi kullanın.', 400 );
	}
	if ( preg_match( '/\d{5,}/', $s ) ) {
		return sides_yr_hata( 'sides_yr_ad', 'Takma ada telefon numarası ya da uzun sayı yazmayın.', 400 );
	}
	$k = strtr( mb_strtolower( str_replace( array( 'I', 'İ' ), array( 'ı', 'i' ), $s ) ), array( '0' => 'o', '1' => 'i', '3' => 'e', '4' => 'a', '5' => 's', '7' => 't', '$' => 's', 'ı' => 'i', 'ş' => 's', 'ç' => 'c', 'ğ' => 'g', 'ö' => 'o', 'ü' => 'u', '.' => ' ', '_' => ' ', '-' => ' ' ) );
	$bitisik = str_replace( ' ', '', $k );
	foreach ( array( 'orospu', 'siktir', 'sikerim', 'sikeyim', 'yarrak', 'amcik', 'amina', 'pezevenk', 'kahpe', 'gavat', 'serefsiz', 'gerizekali', 'fuck', 'bitch', 'porno', 'kaltak', 'yavsak' ) as $kok ) {
		if ( false !== strpos( $bitisik, $kok ) ) {
			return sides_yr_hata( 'sides_yr_ad', 'Bu takma ad uygun değil. Başka bir ad seçin.', 400 );
		}
	}
	foreach ( preg_split( '/\s+/', $k ) as $w ) {
		if ( in_array( $w, array( 'amk', 'aq', 'mk', 'oc', 'pic', 'got', 'sik', 'salak', 'aptal', 'mal', 'ibne', 'shit', 'sex', 'seks', 'admin', 'ogretmen' ), true ) ) {
			return sides_yr_hata( 'sides_yr_ad', 'Bu takma ad uygun değil. Başka bir ad seçin.', 400 );
		}
	}
	return $s;
}
function sides_yr_ip_rl( $k, $max ) {
	return sides_rl( 'yr_' . $k, $max, 600 );
}
function sides_yr_katil( WP_REST_Request $req ) {
	global $wpdb;
	if ( ! sides_yr_ip_rl( 'katil', 600 ) ) {
		return sides_yr_hata( 'sides_rl', 'Çok fazla katılım denemesi. Birkaç dakika sonra tekrar deneyin.', 429 );
	}
	$p   = (array) $req->get_json_params();
	$pin = isset( $p['pin'] ) ? preg_replace( '/\D/', '', (string) $p['pin'] ) : '';
	if ( 6 !== strlen( $pin ) ) {
		return sides_yr_hata( 'sides_yr_pin', 'PIN 6 haneli olmalı.', 400 );
	}
	if ( ! sides_rl_check( 'yr_pin_bad', 60 ) ) {
		return sides_yr_hata( 'sides_rl', 'Çok fazla hatalı PIN denemesi. Birkaç dakika sonra tekrar deneyin.', 429 );
	}
	$t   = sides_docs();
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT org, id FROM $t WHERE token = %s AND coll = 'yoyun' LIMIT 1", 'yp' . $pin ) ); // phpcs:ignore
	$g   = $row ? sides_yr_oyun_al( (int) $row->org, $row->id ) : null;
	if ( $g && ( 'bitti' === $g['faz'] || sides_yr_ms() - (int) $g['olustu'] > SIDES_YR_PIN_OMUR * 1000 ) ) {
		sides_yr_pin_yaz( (int) $row->org, $row->id, '' );   // eski oyunun PIN'i kapanır
		$g = null;
	}
	if ( ! $g ) {
		sides_rl_hit( 'yr_pin_bad', 600 );
		return sides_yr_hata( 'sides_yr_pin', 'Bu PIN ile açık yarışma bulunamadı. Ekrandaki PIN’i kontrol edin.', 404 );
	}
	$org = (int) $row->org;
	$gid = $row->id;
	$ad  = sides_yr_takma_ad( isset( $p['ad'] ) ? $p['ad'] : '' );
	if ( is_wp_error( $ad ) ) {
		return $ad;
	}
	$isl = isset( $p['islemId'] ) && is_string( $p['islemId'] ) && preg_match( '/^[A-Za-z0-9_-]{16,64}$/', $p['islemId'] ) ? $p['islemId'] : '';
	$l   = sides_yr_kilit( $org, $gid, 5 );
	if ( false === $l ) {
		return sides_yr_mesgul();
	}
	$g = sides_yr_oyun_al( $org, $gid );
	$b = sides_yr_sistem( $org );
	if ( $b ) {
		if ( sides_yr_sistem_durak( $g, $b ) ) {
			sides_yr_kaydet( $org, 'yoyun', $gid, $g );
		}
		sides_yr_birak( $l );
		return sides_yr_hata( 'sides_yr_sistem', sides_yr_sistem_mesaj( $b ) . ' Şu an yeni katılım alınmıyor.', 503 );
	}
	$ih  = $isl ? sides_yr_hash( 'islem|' . $isl ) : '';
	$key = sides_yr_rastgele( 24 );
	$pid = '';
	foreach ( (array) $g['oyuncular'] as $id => $o ) {
		if ( $ih && isset( $o['ih'] ) && hash_equals( $o['ih'], $ih ) && empty( $o['cikti'] ) ) {
			$pid = $id;   // aynı katılım isteğinin tekrarı: aynı koltuk, yeni anahtar
			break;
		}
	}
	if ( ! $pid ) {
		$hata = null;
		if ( 'lobi' !== $g['faz'] ) {
			$hata = sides_yr_hata( 'sides_yr_faz', 'Yarışma başladı; yeni katılım alınmıyor.', 409 );
		} elseif ( sides_yr_aktif_say( $g ) >= SIDES_YR_MAX_OYUNCU ) {
			$hata = sides_yr_hata( 'sides_yr_dolu', 'Yarışma dolu (en çok ' . SIDES_YR_MAX_OYUNCU . ' oyuncu).', 409 );
		} else {
			foreach ( (array) $g['oyuncular'] as $o ) {
				if ( empty( $o['cikti'] ) && mb_strtolower( $o['ad'] ) === mb_strtolower( $ad ) ) {
					$hata = sides_yr_hata( 'sides_yr_ad', 'Bu takma ad alınmış. Başka bir ad yazın.', 409 );
				}
			}
		}
		if ( $hata ) {
			sides_yr_birak( $l );
			return $hata;
		}
		$pid = 'p' . sides_yr_rastgele( 5 );
		if ( ! is_array( $g['oyuncular'] ) ) {
			$g['oyuncular'] = array();
		}
		$g['oyuncular'][ $pid ] = array( 'ad' => $ad, 'kh' => '', 'ih' => $ih, 't' => sides_yr_ms() );
		sides_yr_olay( $g, 'katil', array( 'p' => $pid ) );
	}
	$g['oyuncular'][ $pid ]['kh'] = sides_yr_hash( $key );
	$g['v']                       = (int) $g['v'] + 1;
	$ok                           = sides_yr_kaydet( $org, 'yoyun', $gid, $g );
	sides_yr_birak( $l );
	if ( ! $ok ) {
		return sides_yr_hata( 'sides_db', 'Katılım kaydedilemedi; tekrar deneyin.', 500 );
	}
	return sides_yr_res( array( 'g' => $org, 'o' => $gid, 'p' => $pid, 'k' => $key, 'ad' => $g['oyuncular'][ $pid ]['ad'], 'baslik' => $g['ad'] ) );
}
/* Oyuncu doğrulama: [org, gid, pid, oyun] | WP_Error */
function sides_yr_oyuncu( $p ) {
	$org = isset( $p['g'] ) ? (int) $p['g'] : 0;
	$gid = isset( $p['o'] ) ? (string) $p['o'] : '';
	$pid = isset( $p['p'] ) ? (string) $p['p'] : '';
	$key = isset( $p['k'] ) ? (string) $p['k'] : '';
	if ( $org < 1 || ! preg_match( '/^yo[a-f0-9]{12}$/', $gid ) || ! preg_match( '/^p[a-f0-9]{10}$/', $pid ) || ! preg_match( '/^[a-f0-9]{48}$/', $key ) ) {
		return sides_yr_hata( 'sides_yr_oturum', 'Yarışma oturumu geçersiz. PIN ile yeniden katılın.', 400 );
	}
	if ( ! sides_rl_check( 'yr_key_bad', 120 ) ) {
		return sides_yr_hata( 'sides_rl', 'Çok fazla hatalı istek. Birkaç dakika sonra tekrar deneyin.', 429 );
	}
	$g = sides_yr_oyun_al( $org, $gid );
	$o = $g && isset( $g['oyuncular'][ $pid ] ) ? $g['oyuncular'][ $pid ] : null;
	if ( ! $o || ! hash_equals( (string) $o['kh'], sides_yr_hash( $key ) ) ) {
		sides_rl_hit( 'yr_key_bad', 600 );
		return sides_yr_hata( 'sides_yr_oturum', 'Bu cihazdaki yarışma oturumu artık geçerli değil. PIN ile yeniden katılın.', 410 );
	}
	if ( ! empty( $o['cikti'] ) ) {
		return sides_yr_hata( 'sides_yr_cikti', 'Öğretmen bu takma adı yarışmadan çıkardı. Uygun bir takma adla yeniden katılmak için öğretmeninize danışın.', 410 );
	}
	return array( $org, $gid, $pid, $g );
}
function sides_yr_etiket( $g, $b ) {
	return (int) $g['v'] . '.' . ( $b ? 1 : 0 );
}
function sides_yr_oyuncu_dto( $org, $gid, $g, $pid, $b ) {
	$n = count( $g['sorular'] );
	$d = array( 'e' => sides_yr_etiket( $g, $b ), 'faz' => $g['faz'], 'no' => (int) $g['no'], 'toplam' => $n, 'ad' => $g['oyuncular'][ $pid ]['ad'], 'baslik' => $g['ad'], 'puanTuru' => $g['puanTuru'],
		'oyuncuSay' => sides_yr_aktif_say( $g ), 'kalan' => sides_yr_kalan( $g ), 'durak' => $b ? 'sistem' : ( ! empty( $g['durak'] ) ? 'ogretmen' : '' ) );
	$T = sides_yr_toplam( $g );
	foreach ( $T as $x ) {
		if ( $x['id'] === $pid ) {
			$d['ben'] = array( 'puan' => $x['puan'], 'dogru' => $x['dogru'], 'sira' => $x['sira'], 'esit' => $x['esit'] );
		}
	}
	if ( $b ) {
		$d['mesaj'] = sides_yr_sistem_mesaj( $b );   // acil bekleme: soru alanı gönderilmez
		return $d;
	}
	if ( in_array( $g['faz'], array( 'soru', 'cevap' ), true ) && $g['no'] >= 0 ) {
		$q         = $g['sorular'][ $g['no'] ];
		$d['soru'] = array( 'metin' => $q['soru'], 'secenekler' => $q['secenekler'], 'sure' => (int) $q['sure'], 'puan' => sides_yr_soru_puan( $q ) );   // doğru seçenek ve açıklama yok
		if ( 'soru' === $g['faz'] ) {
			$c         = sides_get_doc( $org, 'ycevap', $gid . '_' . $g['no'] . '_' . $pid );
			$d['cevap'] = $c ? (int) $c['s'] : null;
		} else {
			$r          = isset( $g['sonuc'][ $g['no'] ][ $pid ] ) ? $g['sonuc'][ $g['no'] ][ $pid ] : null;
			$d['sonuc'] = array( 'dogru' => (int) $q['dogru'], 'aciklama' => $q['aciklama'], 'secim' => $r ? (int) $r[0] : null, 'dogruMu' => $r ? (bool) $r[3] : false, 'puan' => $r ? (int) $r[2] : 0,
				'puanDisi' => isset( $g['puanDisi'][ $g['no'] ] ) || isset( $g['atlandi'][ $g['no'] ] ) );
		}
	}
	if ( 'bitti' === $g['faz'] ) {
		$d['ilk'] = array_map( function ( $x ) { return array( 'ad' => $x['ad'], 'puan' => $x['puan'], 'sira' => $x['sira'] ); }, array_slice( $T, 0, 5 ) );
	}
	return $d;
}
function sides_yr_durum( WP_REST_Request $req ) {
	$p = (array) $req->get_json_params();
	$x = sides_yr_oyuncu( $p );
	if ( is_wp_error( $x ) ) {
		return $x;
	}
	list( $org, $gid, $pid, $g ) = $x;
	if ( ! sides_rl( 'yr_d|' . $pid, 1500, 600 ) ) {   // oyuncu başına (okulun ortak IP'si bütün sınıfı tek kişi saymaz)
		return sides_yr_hata( 'sides_rl', 'Çok sık istek. Birkaç saniye sonra yeniden denenecek.', 429 );
	}
	$g = sides_yr_tazele( $org, $gid, $g, 0 );
	$b = sides_yr_sistem( $org );
	$e = sides_yr_etiket( $g, $b );
	if ( isset( $p['e'] ) && (string) $p['e'] === $e ) {
		return sides_yr_res( array( 'e' => $e, 'ayni' => 1, 'kalan' => sides_yr_kalan( $g ) ) );
	}
	return sides_yr_res( sides_yr_oyuncu_dto( $org, $gid, $g, $pid, $b ) );
}
function sides_yr_cevap( WP_REST_Request $req ) {
	global $wpdb;
	$p = (array) $req->get_json_params();
	$x = sides_yr_oyuncu( $p );
	if ( is_wp_error( $x ) ) {
		return $x;
	}
	list( $org, $gid, $pid ) = $x;
	$no  = isset( $p['no'] ) && is_numeric( $p['no'] ) ? (int) $p['no'] : -1;
	$sec = isset( $p['secim'] ) && is_numeric( $p['secim'] ) ? (int) $p['secim'] : -1;
	$op  = isset( $p['islemId'] ) && is_string( $p['islemId'] ) && preg_match( '/^[A-Za-z0-9_-]{8,40}$/', $p['islemId'] ) ? $p['islemId'] : '';
	if ( $no < 0 || $no >= SIDES_YR_MAX_SORU || $sec < 0 || $sec > 3 || ! $op ) {
		return sides_yr_hata( 'sides_gecersiz', 'Geçersiz yanıt.', 400 );
	}
	if ( ! sides_rl( 'yr_c|' . $pid, 400, 600 ) ) {
		return sides_yr_hata( 'sides_rl', 'Çok sık istek.', 429 );
	}
	$l = sides_yr_kilit( $org, $gid, 3 );
	if ( false === $l ) {
		return sides_yr_mesgul();
	}
	$g   = sides_yr_oyun_al( $org, $gid );
	$now = sides_yr_ms();
	$cid = $gid . '_' . $no . '_' . $pid;
	$var = sides_get_doc( $org, 'ycevap', $cid );
	$son = null;
	$kay = false;
	if ( $var ) {
		$son = $var['op'] === $op ? array( 'kabul' => true, 'no' => $no, 'secim' => (int) $var['s'], 'tekrar' => true )
			: sides_yr_hata( 'sides_yr_tek', 'Bu soruya zaten yanıt verdiniz; ilk yanıt değiştirilemez.', 409, array( 'secim' => (int) $var['s'] ) );
	} else {
		$b = sides_yr_sistem( $org );
		if ( $b ) {
			$kay = sides_yr_sistem_durak( $g, $b );
			$son = sides_yr_hata( 'sides_yr_sistem', sides_yr_sistem_mesaj( $b ), 503 );
		} elseif ( 'soru' !== $g['faz'] || (int) $g['no'] !== $no ) {
			$son = sides_yr_hata( 'sides_yr_kapali', 'Bu soru kapandı; yanıt kabul edilmedi.', 409 );
		} elseif ( ! empty( $g['durak'] ) ) {
			$son = sides_yr_hata( 'sides_yr_durak', 'Yarışma duraklatıldı; şu an yanıt alınmıyor.', 409 );
		} elseif ( $now >= (int) $g['son'] ) {
			sides_yr_soru_kapat( $org, $gid, $g, 'sure' );
			$kay = true;
			$son = sides_yr_hata( 'sides_yr_sure', 'Süre doldu; yanıt kabul edilmedi.', 409 );
		} elseif ( $sec >= count( $g['sorular'][ $no ]['secenekler'] ) ) {
			$son = sides_yr_hata( 'sides_gecersiz', 'Geçersiz seçenek.', 400 );
		} else {
			$t = sides_docs();
			$d = array( 's' => $sec, 'ms' => max( 0, $now - (int) $g['bas'] ), 't' => $now, 'op' => $op );
			for ( $i = 0; $i < 4; $i++ ) {
				$n = $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO $t (org, coll, id, exam_id, data, updated_at, updated_by) VALUES (%d, 'ycevap', %s, %s, %s, %s, 0)", $org, $cid, $gid . '_' . $no, wp_json_encode( $d ), current_time( 'mysql', true ) ) ); // phpcs:ignore
				if ( false !== $n ) {
					break;
				}
				usleep( 30000 + 50000 * $i );
			}
			if ( 1 !== (int) $n ) {
				$son = sides_yr_hata( 'sides_db', 'Yanıt kaydedilemedi; tekrar deneyin.', 500 );
			} else {
				$son = array( 'kabul' => true, 'no' => $no, 'secim' => $sec );
				if ( count( array_filter( array_keys( sides_yr_cevaplar( $org, $gid, $no ) ), function ( $k ) use ( $g ) { return empty( $g['oyuncular'][ $k ]['cikti'] ); } ) ) >= sides_yr_aktif_say( $g ) ) {   // herkes yanıtladı: soru kapanır
					sides_yr_soru_kapat( $org, $gid, $g, 'herkes' );
					$kay = true;
				}
			}
		}
	}
	if ( $kay ) {
		sides_yr_kaydet( $org, 'yoyun', $gid, $g );
	}
	sides_yr_birak( $l );
	return is_wp_error( $son ) ? $son : sides_yr_res( $son );
}

/* ================================================================
 * v7.8 HAZIR SORU BANKASI (data/yarisma/*.json, ATLAS özgün) ve TOPLU EKLEME
 * Yükleyici her dosyayı, desteyi ve soruyu doğrular; hatalı kayıt atlanır, nedeni rapora yazılır (sayfa çökmez).
 * Önbellek: aynı istek içinde dosya adı + değişme zamanı + boyut imzasıyla (dosya değişince kendiliğinden yenilenir).
 * ================================================================ */
function sides_yr_kut_rapor( &$R, $dosya, $deste, $soru, $neden ) {
	if ( count( $R ) < 300 ) {
		$R[] = array( 'dosya' => (string) $dosya, 'deste' => (string) $deste, 'soru' => (int) $soru, 'neden' => (string) $neden );
	}
}
/* Düz metin: boş olamaz, sınırı aşamaz, HTML etiketi içeremez. Geçersizse null */
function sides_yr_kut_metin( $v, $max, $cok = false ) {
	if ( ! is_string( $v ) ) {
		return null;
	}
	$s = sides_yr_temiz( $v, $max + 1, $cok );
	if ( '' === $s || mb_strlen( $s ) > $max || preg_match( '/<\/?[a-z][a-z0-9]*(?:\s[^<>]*)?>|<!--/i', $s ) ) {
		return null;
	}
	return $s;
}
/* Tek soru: normalleştirilmiş dizi ya da hata metni */
function sides_yr_kut_soru( $q ) {
	if ( ! is_array( $q ) ) {
		return 'soru nesne değil';
	}
	$soru = sides_yr_kut_metin( isset( $q['soru'] ) ? $q['soru'] : null, 300, true );
	if ( null === $soru ) {
		return 'soru metni boş, 300 karakterden uzun ya da HTML içeriyor';
	}
	$S = isset( $q['secenekler'] ) && is_array( $q['secenekler'] ) ? array_values( $q['secenekler'] ) : array();
	if ( 4 !== count( $S ) ) {
		return 'tam 4 seçenek (A–D) olmalı';
	}
	$sec = array();
	$gor = array();
	foreach ( $S as $j => $s ) {
		$s = sides_yr_kut_metin( $s, 120 );
		if ( null === $s ) {
			return chr( 65 + $j ) . ' seçeneği boş, 120 karakterden uzun ya da HTML içeriyor';
		}
		$k = $s;   // büyük/küçük harf ayrımlı: genetikte UU ile uu farklı seçeneklerdir
		if ( isset( $gor[ $k ] ) ) {
			return 'aynı seçenek iki kez yazılmış (' . $s . ')';
		}
		$gor[ $k ] = 1;
		$sec[]     = $s;
	}
	$dg = isset( $q['dogru'] ) ? $q['dogru'] : null;
	if ( ! is_int( $dg ) || $dg < 0 || $dg > 3 ) {
		return 'dogru 0–3 arasında bir tam sayı olmalı (0 = A)';
	}
	$ack = isset( $q['aciklama'] ) && '' !== $q['aciklama'] ? sides_yr_kut_metin( $q['aciklama'], 400, true ) : '';
	if ( null === $ack ) {
		return 'açıklama 400 karakterden uzun ya da HTML içeriyor';
	}
	$zr = isset( $q['zorluk'] ) ? $q['zorluk'] : null;
	if ( ! is_string( $zr ) || ! in_array( $zr, sides_yr_zorluklar(), true ) ) {
		return 'zorluk kolay, orta ya da zor olmalı';
	}
	$su = isset( $q['sure'] ) ? $q['sure'] : 20;
	if ( ! is_int( $su ) || $su < 5 || $su > 240 ) {
		return 'süre 5–240 saniye arasında bir tam sayı olmalı';
	}
	$pu = isset( $q['puan'] ) ? $q['puan'] : 100;
	if ( ! is_int( $pu ) || ! in_array( $pu, sides_yr_puanlar(), true ) ) {
		return 'puan 0, 100 ya da 200 olmalı';
	}
	$kon = isset( $q['konu'] ) && '' !== $q['konu'] ? sides_yr_kut_metin( $q['konu'], 120 ) : '';
	if ( null === $kon ) {
		return 'konu 120 karakterden uzun';
	}
	$m = sides_yr_medya_temiz( $q );
	if ( is_string( $m ) ) {
		return $m;
	}
	return array( 'v' => 1, 'soru' => $soru, 'secenekler' => $sec, 'dogru' => $dg, 'aciklama' => $ack, 'sure' => $su, 'konu' => $kon, 'zorluk' => $zr, 'puan' => $pu ) + $m;
}
/* Kütüphane: { imza, desteler { id: deste }, rapor [], dosya (bulunan), gecerli (en az bir destesi alınan) } */
function sides_yr_kutuphane( $dir = '' ) {
	static $C = array();
	$dir = '' !== (string) $dir ? rtrim( (string) $dir, '/' ) : SIDES_YR_KUTUPHANE;
	$F   = is_dir( $dir ) ? glob( $dir . '/*.json' ) : array();
	$F   = is_array( $F ) ? $F : array();
	sort( $F, SORT_STRING );
	$imza = md5( wp_json_encode( array_map( function ( $f ) { return array( basename( $f ), (int) @filemtime( $f ), (int) @filesize( $f ) ); }, $F ) ) );
	if ( isset( $C[ $dir ] ) && $C[ $dir ]['imza'] === $imza ) {
		return $C[ $dir ];
	}
	$katlar = array( 'ders', 'kultur', 'dahili', 'atolye', 'yarisma' );
	$D      = array();
	$R      = array();
	$sahip  = array();
	$gec    = 0;
	foreach ( $F as $f ) {
		$ad = basename( $f );
		if ( ! preg_match( '/^[a-z0-9][a-z0-9._-]{0,80}\.json$/', $ad ) ) {
			sides_yr_kut_rapor( $R, $ad, '', 0, 'Dosya adı yalnız küçük harf, rakam, nokta, tire ve alt çizgi içermeli.' );
			continue;
		}
		$boy = (int) @filesize( $f );
		if ( $boy <= 0 || $boy > 2097152 ) {
			sides_yr_kut_rapor( $R, $ad, '', 0, 'Dosya boş ya da 2 MB’tan büyük.' );
			continue;
		}
		$raw = @file_get_contents( $f );
		if ( ! is_string( $raw ) ) {
			sides_yr_kut_rapor( $R, $ad, '', 0, 'Dosya okunamadı.' );
			continue;
		}
		if ( 0 === strncmp( $raw, "\xEF\xBB\xBF", 3 ) ) {
			$raw = substr( $raw, 3 );
		}
		if ( ! mb_check_encoding( $raw, 'UTF-8' ) ) {
			sides_yr_kut_rapor( $R, $ad, '', 0, 'Dosya UTF-8 kodlamalı değil.' );
			continue;
		}
		$j = json_decode( $raw, true );
		if ( ! is_array( $j ) || ( $j && array_values( $j ) === $j ) ) {
			sides_yr_kut_rapor( $R, $ad, '', 0, 'JSON okunamadı: ' . ( JSON_ERROR_NONE !== json_last_error() ? json_last_error_msg() : 'üst düzey nesne bekleniyor' ) . '.' );
			continue;
		}
		$kat = isset( $j['kategori'] ) && in_array( $j['kategori'], $katlar, true ) ? $j['kategori'] : '';
		$snf = isset( $j['sinif'] ) && is_scalar( $j['sinif'] ) ? trim( (string) $j['sinif'] ) : '';
		$ders = sides_yr_kut_metin( isset( $j['ders'] ) ? $j['ders'] : null, 40 );
		$atl = isset( $j['atolye'] ) && is_string( $j['atolye'] ) ? $j['atolye'] : '';
		$neden = '';
		if ( ! $kat ) {
			$neden = 'kategori ders, kultur, dahili, atolye ya da yarisma olmalı.';
		} elseif ( '' !== $snf && ! preg_match( '/^(?:[1-9]|1[0-2])$/', $snf ) ) {
			$neden = 'sinif boş ya da 1–12 arasında bir sayı olmalı.';
		} elseif ( 'ders' === $kat && '' === $snf ) {
			$neden = 'Akademik (ders) dosyasında sınıf gerekli.';
		} elseif ( null === $ders ) {
			$neden = 'ders adı boş ya da 40 karakterden uzun.';
		} elseif ( 'atolye' === $kat ? ! isset( sides_yr_atolyeler()[ $atl ] ) : '' !== $atl ) {
			$neden = 'atolye alanı yalnız atölye dosyasında ve origami, stem, munazara, spor ya da medya olabilir.';
		} elseif ( ! isset( $j['kaynak'] ) || 'ATLAS özgün' !== $j['kaynak'] ) {
			$neden = 'kaynak "ATLAS özgün" olmalı; yalnız özgün içerik yüklenir.';
		} elseif ( empty( $j['desteler'] ) || ! is_array( $j['desteler'] ) ) {
			$neden = 'desteler listesi boş.';
		}
		if ( $neden ) {
			sides_yr_kut_rapor( $R, $ad, '', 0, 'Dosya atlandı: ' . $neden );
			continue;
		}
		$alinan = 0;
		foreach ( array_values( $j['desteler'] ) as $di => $dx ) {
			$did = is_array( $dx ) && isset( $dx['id'] ) && is_string( $dx['id'] ) ? $dx['id'] : '';
			$et  = '' !== $did ? $did : '#' . ( $di + 1 );
			if ( ! preg_match( '/^[a-z0-9][a-z0-9-]{2,40}$/', $did ) ) {
				sides_yr_kut_rapor( $R, $ad, $et, 0, 'Deste atlandı: kimlik 3–41 karakter, küçük harf, rakam ve tire olmalı.' );
				continue;
			}
			if ( isset( $sahip[ $did ] ) ) {
				sides_yr_kut_rapor( $R, $ad, $et, 0, 'Deste atlandı: aynı kimlik ' . $sahip[ $did ] . ' dosyasında da var.' );
				continue;
			}
			$dad = sides_yr_kut_metin( isset( $dx['ad'] ) ? $dx['ad'] : null, 120 );
			$dde = isset( $dx['ders'] ) && '' !== $dx['ders'] ? sides_yr_kut_metin( $dx['ders'], 40 ) : $ders;   // v7.9.17 deste kendi dersini yazabilir (Yarışma soruları dosyasında ders ders desteler)
			if ( null === $dde ) {
				sides_yr_kut_rapor( $R, $ad, $et, 0, 'Deste atlandı: ders adı 40 karakterden uzun ya da geçersiz.' );
				continue;
			}
			$uni = isset( $dx['unite'] ) && '' !== $dx['unite'] ? sides_yr_kut_metin( $dx['unite'], 80 ) : '';
			$kon = isset( $dx['konu'] ) && '' !== $dx['konu'] ? sides_yr_kut_metin( $dx['konu'], 200 ) : '';
			if ( null === $dad || null === $uni || null === $kon ) {
				sides_yr_kut_rapor( $R, $ad, $et, 0, 'Deste atlandı: ad (en çok 120 karakter), ünite (80) ya da konu (200) boş değil ama geçersiz ya da çok uzun.' );
				continue;
			}
			$L = isset( $dx['sorular'] ) && is_array( $dx['sorular'] ) ? array_values( $dx['sorular'] ) : array();
			if ( count( $L ) > SIDES_YR_MAX_SORU ) {
				sides_yr_kut_rapor( $R, $ad, $et, 0, 'En çok ' . SIDES_YR_MAX_SORU . ' soru alınır; fazlası atlandı.' );
				$L = array_slice( $L, 0, SIDES_YR_MAX_SORU );
			}
			$Q   = array();
			$gor = array();
			foreach ( $L as $qi => $q ) {
				$n = sides_yr_kut_soru( $q );
				if ( is_string( $n ) ) {
					sides_yr_kut_rapor( $R, $ad, $et, $qi + 1, 'Soru atlandı: ' . $n . '.' );
					continue;
				}
				$k = mb_strtolower( $n['soru'] );
				if ( isset( $gor[ $k ] ) ) {
					sides_yr_kut_rapor( $R, $ad, $et, $qi + 1, 'Soru atlandı: aynı soru bu destede ' . $gor[ $k ] . '. sırada da var.' );
					continue;
				}
				$gor[ $k ] = $qi + 1;
				$n         = array( 'id' => 'q' . substr( md5( $did . '|' . $k ), 0, 14 ) ) + $n;
				$Q[]       = $n;
			}
			if ( ! $Q ) {
				sides_yr_kut_rapor( $R, $ad, $et, 0, 'Deste atlandı: geçerli soru yok.' );
				continue;
			}
			$sahip[ $did ] = $ad;
			$alinan++;
			$D[ $did ] = array( 'id' => $did, 'dosya' => $ad, 'kategori' => $kat, 'sinif' => $snf, 'ders' => $dde, 'atolye' => $atl, 'ad' => $dad, 'unite' => $uni, 'konu' => $kon, 'sorular' => $Q );
		}
		if ( $alinan ) {
			$gec++;
		}
	}
	$C[ $dir ] = array( 'imza' => $imza, 'desteler' => $D, 'rapor' => $R, 'dosya' => count( $F ), 'gecerli' => $gec );
	return $C[ $dir ];
}
function sides_yr_kut_ozet( $d, $sira ) {
	return array(
		'id'        => $d['id'],
		'ad'        => $d['ad'],
		'kategori'  => $d['kategori'],
		'sinif'     => $d['sinif'],
		'ders'      => $d['ders'],
		'atolye'    => $d['atolye'],
		'unite'     => $d['unite'],
		'konu'      => $d['konu'],
		'dosya'     => $d['dosya'],
		'sira'      => (int) $sira,
		'soruSay'   => count( $d['sorular'] ),
		'zorlukSay' => sides_yr_zorluk_say( $d['sorular'] ),
		'sureTop'   => array_sum( array_map( function ( $q ) { return (int) $q['sure']; }, $d['sorular'] ) ),
	);
}
/* Oyun kurmaya ve kopyalamaya uygun deste (iç biçim) ya da null */
function sides_yr_kut_deste( $kid ) {
	$K = sides_yr_kutuphane();
	if ( ! isset( $K['desteler'][ $kid ] ) ) {
		return null;
	}
	$d = $K['desteler'][ $kid ];
	return array( 'ad' => $d['ad'], 'kategori' => $d['kategori'], 'atolye' => $d['atolye'], 'ders' => $d['ders'], 'unite' => $d['unite'], 'konu' => $d['konu'], 'sinif' => $d['sinif'],
		'durum' => 'onayli', 'surum' => 1, 'sorular' => $d['sorular'], 'kutuphane' => $kid, 'kaynak' => 'ATLAS özgün' );
}
function sides_yr_kut_liste() {
	$K = sides_yr_kutuphane();
	$L = array();
	$n = 0;
	$i = 0;
	foreach ( $K['desteler'] as $d ) {
		$L[] = sides_yr_kut_ozet( $d, $i++ );
		$n  += count( $d['sorular'] );
	}
	$yon = 'yonetici' === sides_ctx()['rol'];
	return sides_yr_res( array(
		'desteler'  => $L,
		'soruSay'   => $n,
		'dosya'     => $K['dosya'],
		'gecerli'   => $K['gecerli'],
		'atlanan'   => count( $K['rapor'] ),
		'rapor'     => $yon ? $K['rapor'] : array(),   // ayrıntı yalnız kurum yöneticisine
		'atolyeler' => sides_yr_atolyeler(),
		'not'       => 'ATLAS özgün — öğretmen kontrolü önerilir',
	) );
}
function sides_yr_kut_oku( WP_REST_Request $req ) {
	$K   = sides_yr_kutuphane();
	$kid = (string) $req['kid'];
	if ( ! isset( $K['desteler'][ $kid ] ) ) {
		return sides_yr_hata( 'sides_yok', 'Hazır Soru Bankası’nda bu deste bulunamadı.', 404 );
	}
	$d = $K['desteler'][ $kid ];
	$o = sides_yr_kut_ozet( $d, array_search( $kid, array_keys( $K['desteler'] ), true ) );
	$o['sorular'] = array_map( function ( $q ) { unset( $q['v'] ); return $q; }, $d['sorular'] );
	$o['not']     = 'ATLAS özgün — öğretmen kontrolü önerilir';
	return sides_yr_res( $o );
}
/* "Kurumuma kopyala": düzenlenebilir kurum destesi (taslak ya da onaylı). Aynı işlem kimliği ikinci kopya açmaz. */
function sides_yr_kut_kopyala( WP_REST_Request $req ) {
	$org = sides_org_id();
	$kid = (string) $req['kid'];
	$p   = (array) $req->get_json_params();
	$d   = sides_yr_kut_deste( $kid );
	if ( ! $d ) {
		return sides_yr_hata( 'sides_yok', 'Hazır Soru Bankası’nda bu deste bulunamadı.', 404 );
	}
	if ( ! sides_rl( 'yr_kopya_' . get_current_user_id(), 120, 600 ) ) {
		return sides_yr_hata( 'sides_rl', 'Çok sık kopyalama; biraz bekleyin.', 429 );
	}
	$dur = isset( $p['durum'] ) && 'onayli' === $p['durum'] ? 'onayli' : 'taslak';
	$isl = isset( $p['islemId'] ) && is_string( $p['islemId'] ) && preg_match( '/^[A-Za-z0-9_-]{6,40}$/', $p['islemId'] ) ? $p['islemId'] : sides_yr_rastgele( 8 );
	$id  = 'yd' . substr( md5( $org . '|' . get_current_user_id() . '|kopya|' . $kid . '|' . $isl ), 0, 14 );
	$var = sides_get_doc( $org, 'ydeste', $id );
	if ( $var ) {
		unset( $var['id'] );
		return sides_yr_res( sides_yr_deste_disari( $id, $var, true ) + array( 'tekrar' => true ) );
	}
	$t = sides_yr_deste_temizle( $d, null );
	if ( is_wp_error( $t ) ) {
		return $t;
	}
	$kim  = sides_yr_kim();
	$t   += array( 'kutuphane' => $kid, 'kaynak' => 'ATLAS özgün', 'durum' => $dur, 'olusturan' => $kim, 'olustu' => time(), 'surum' => 1, 'guncel' => time(), 'gecmis' => array() );
	$t['onaylayan'] = 'onayli' === $dur ? array( 'u' => $kim['u'], 'ad' => $kim['ad'], 't' => time(), 'surum' => 1 ) : null;
	sides_yr_gecmis( $t, 'Hazır Soru Bankası’ndan kopyalandı (' . $kid . ')' . ( 'onayli' === $dur ? '; onaylı olarak eklendi' : '; taslak olarak eklendi' ), $kim );
	if ( ! sides_yr_kaydet( $org, 'ydeste', $id, $t ) ) {
		return sides_yr_hata( 'sides_db', 'Deste kopyalanamadı.', 500 );
	}
	sides_log( $org, 'Bilgi yarışması: Hazır Soru Bankası destesi kuruma kopyalandı: ' . $t['ad'] . ' (' . ( 'onayli' === $dur ? 'onaylı' : 'taslak' ) . ')' );
	return sides_yr_res( sides_yr_deste_disari( $id, $t, true ), 201 );
}
/* v7.9.15 "Seçerek deste kur": Hazır Soru Bankası'ndan ve kurumun onaylı destelerinden seçilen sorular tek kurum destesi olur (taslak ya da onaylı). Sorular sunucuda kaynak desteden kopyalanır. */
function sides_yr_kut_sec( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = (array) $req->get_json_params();
	if ( ! sides_rl( 'yr_kopya_' . get_current_user_id(), 120, 600 ) ) {
		return sides_yr_hata( 'sides_rl', 'Çok sık kopyalama; biraz bekleyin.', 429 );
	}
	$ad  = sides_yr_temiz( isset( $p['ad'] ) ? $p['ad'] : '', 120 );
	$sec = isset( $p['secim'] ) && is_array( $p['secim'] ) ? array_values( $p['secim'] ) : array();
	if ( ! $sec ) {
		return sides_yr_hata( 'sides_gecersiz', 'En az bir soru seçin.', 400 );
	}
	if ( count( $sec ) > SIDES_YR_MAX_SORU ) {
		return sides_yr_hata( 'sides_gecersiz', 'Bir destede en çok ' . SIDES_YR_MAX_SORU . ' soru olabilir.', 400 );
	}
	$K   = sides_yr_kutuphane();
	$Q   = array();
	$gor = array();
	$kay = array();
	$onb = array();
	foreach ( $sec as $i => $x ) {
		$did = is_array( $x ) && isset( $x['deste'] ) && is_string( $x['deste'] ) ? $x['deste'] : '';
		$qid = is_array( $x ) && isset( $x['id'] ) && is_string( $x['id'] ) ? $x['id'] : '';
		$q   = null;
		if ( isset( $K['desteler'][ $did ] ) ) {
			foreach ( $K['desteler'][ $did ]['sorular'] as $y ) {
				if ( $y['id'] === $qid ) {
					$q = $y;
					break;
				}
			}
		} elseif ( preg_match( '/^yd[a-f0-9]{8,24}$/', $did ) ) {
			if ( ! isset( $onb[ $did ] ) ) {
				$onb[ $did ] = sides_get_doc( $org, 'ydeste', $did );
			}
			$d = $onb[ $did ];
			if ( $d && isset( $d['sorular'] ) ) {
				foreach ( (array) $d['sorular'] as $y ) {
					if ( isset( $y['id'] ) && $y['id'] === $qid ) {
						$q = $y;
						break;
					}
				}
			}
		}
		if ( ! $q ) {
			return sides_yr_hata( 'sides_yok', ( $i + 1 ) . '. seçim bulunamadı (' . $did . ' / ' . $qid . '); listeyi yenileyin.', 404 );
		}
		$k = mb_strtolower( $q['soru'] );
		if ( isset( $gor[ $k ] ) ) {
			continue;   // aynı soru iki kez seçilmiş
		}
		$gor[ $k ] = 1;
		$kay[ $did ] = 1;
		if ( empty( $q['bolum'] ) ) {   // v7.9.17 sahnede bölüm (kategori) geçişi: kaynak destenin dersi
			$kd = isset( $K['desteler'][ $did ] ) ? $K['desteler'][ $did ]['ders'] : ( isset( $onb[ $did ]['ders'] ) ? $onb[ $did ]['ders'] : '' );
			if ( '' !== (string) $kd && 'Karma' !== $kd ) {
				$q['bolum'] = mb_substr( (string) $kd, 0, 60 );
			}
		}
		$q['id']   = 'q' . substr( md5( $did . '|' . $qid ), 0, 14 );
		unset( $q['v'] );
		$Q[] = $q;
	}
	$dur = isset( $p['durum'] ) && 'onayli' === $p['durum'] ? 'onayli' : 'taslak';
	$isl = isset( $p['islemId'] ) && is_string( $p['islemId'] ) && preg_match( '/^[A-Za-z0-9_-]{6,40}$/', $p['islemId'] ) ? $p['islemId'] : sides_yr_rastgele( 8 );
	$id  = 'yd' . substr( md5( $org . '|' . get_current_user_id() . '|sec|' . $isl ), 0, 14 );
	$var = sides_get_doc( $org, 'ydeste', $id );
	if ( $var ) {
		unset( $var['id'] );
		return sides_yr_res( sides_yr_deste_disari( $id, $var, true ) + array( 'tekrar' => true ) );
	}
	$t = sides_yr_deste_temizle( array( 'ad' => '' !== $ad ? $ad : 'Yarışma Günü · ' . count( $Q ) . ' soru', 'kategori' => 'karma', 'ders' => sides_yr_temiz( isset( $p['ders'] ) ? $p['ders'] : 'Karma', 40 ), 'unite' => '', 'konu' => 'Seçilen sorular', 'sinif' => sides_yr_temiz( isset( $p['sinif'] ) ? $p['sinif'] : '', 12 ), 'sorular' => $Q ), null );
	if ( is_wp_error( $t ) ) {
		return $t;
	}
	$kim  = sides_yr_kim();
	$t   += array( 'kaynak' => 'ATLAS özgün (seçerek)', 'durum' => $dur, 'olusturan' => $kim, 'olustu' => time(), 'surum' => 1, 'guncel' => time(), 'gecmis' => array() );
	$t['onaylayan'] = 'onayli' === $dur ? array( 'u' => $kim['u'], 'ad' => $kim['ad'], 't' => time(), 'surum' => 1 ) : null;
	sides_yr_gecmis( $t, 'Seçilen sorulardan oluşturuldu (' . count( $Q ) . ' soru, ' . count( $kay ) . ' deste)' . ( 'onayli' === $dur ? '; onaylı olarak eklendi' : '; taslak olarak eklendi' ), $kim );
	if ( ! sides_yr_kaydet( $org, 'ydeste', $id, $t ) ) {
		return sides_yr_hata( 'sides_db', 'Deste oluşturulamadı.', 500 );
	}
	sides_log( $org, 'Bilgi yarışması: seçilen sorulardan deste oluşturuldu: ' . $t['ad'] . ' (' . count( $Q ) . ' soru)' );
	return sides_yr_res( sides_yr_deste_disari( $id, $t, true ), 201 );
}
/* "Kurumuma toplu ekle": istemcide (tür, sınıf, ders, ünite) ile gruplanmış desteler; önce hepsi doğrulanır, sonra yazılır */
function sides_yr_iceaktar( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = (array) $req->get_json_params();
	$L   = isset( $p['desteler'] ) && is_array( $p['desteler'] ) ? array_values( $p['desteler'] ) : array();
	$isl = isset( $p['islemId'] ) && is_string( $p['islemId'] ) && preg_match( '/^[A-Za-z0-9_-]{6,40}$/', $p['islemId'] ) ? $p['islemId'] : '';
	if ( ! $L || count( $L ) > 60 || ! $isl ) {
		return sides_yr_hata( 'sides_gecersiz', ! $L ? 'Eklenecek deste yok.' : ( ! $isl ? 'İşlem kimliği eksik.' : 'Tek seferde en çok 60 deste eklenir; dosyayı bölün.' ), 400 );
	}
	if ( ! sides_rl( 'yr_ice_' . get_current_user_id(), 30, 600 ) ) {
		return sides_yr_hata( 'sides_rl', 'Çok sık toplu ekleme; biraz bekleyin.', 429 );
	}
	$dur = isset( $p['durum'] ) && 'onayli' === $p['durum'] ? 'onayli' : 'taslak';
	$T   = array();
	foreach ( $L as $i => $x ) {
		$t = sides_yr_deste_temizle( is_array( $x ) ? $x : array(), null );
		if ( is_wp_error( $t ) ) {
			return sides_yr_hata( 'sides_gecersiz', ( $i + 1 ) . '. deste' . ( is_array( $x ) && isset( $x['ad'] ) && is_string( $x['ad'] ) ? ' (' . mb_substr( $x['ad'], 0, 60 ) . ')' : '' ) . ': ' . $t->get_error_message(), 400 );
		}
		if ( ! $t['sorular'] ) {
			return sides_yr_hata( 'sides_gecersiz', ( $i + 1 ) . '. destede soru yok.', 400 );
		}
		$T[] = $t;
	}
	$kim = sides_yr_kim();
	$out = array();
	$top = 0;
	foreach ( $T as $i => $t ) {
		$id  = 'yd' . substr( md5( $org . '|' . get_current_user_id() . '|ice|' . $isl . '|' . $i ), 0, 14 );
		$var = sides_get_doc( $org, 'ydeste', $id );
		if ( $var ) {   // aynı gönderimin tekrarı
			unset( $var['id'] );
			$out[] = sides_yr_deste_disari( $id, $var, false );
			continue;
		}
		$t += array( 'durum' => $dur, 'olusturan' => $kim, 'olustu' => time(), 'surum' => 1, 'guncel' => time(), 'gecmis' => array() );
		$t['onaylayan'] = 'onayli' === $dur ? array( 'u' => $kim['u'], 'ad' => $kim['ad'], 't' => time(), 'surum' => 1 ) : null;
		sides_yr_gecmis( $t, 'Excel/CSV dosyasından toplu eklendi' . ( 'onayli' === $dur ? ' (onaylı)' : ' (taslak)' ), $kim );
		if ( ! sides_yr_kaydet( $org, 'ydeste', $id, $t ) ) {
			return sides_yr_hata( 'sides_db', ( $i + 1 ) . '. deste kaydedilemedi; önceki desteler eklendi. Aynı dosyayla yeniden denerseniz eklenenler tekrarlanmaz.', 500 );
		}
		$top  += count( $t['sorular'] );
		$out[] = sides_yr_deste_disari( $id, $t, false );
	}
	if ( $top ) {
		sides_log( $org, 'Bilgi yarışması: dosyadan ' . count( $out ) . ' deste toplu eklendi (' . $top . ' soru, ' . ( 'onayli' === $dur ? 'onaylı' : 'taslak' ) . ')' );
	}
	return sides_yr_res( array( 'desteler' => $out ), 201 );
}
