<?php
/**
 * Analiz Modülü v5.3: Tek Rapor / Veli Raporu görüntüleme bağlantıları (Denemeleri Birleştir kayıtları genel /doc ucuyla yazılır).
 *
 * Belgeler:
 *   birlesik/<id>            kaydedilmiş birleşik deneme seçimi { ad, sinif, sube, sid, sinavlar[], testler[], testDahil, esle{}, tarih, olusturan, ozet }
 *   velirapor/sablon         veli raporu bölüm şablonu { tur: 'sablon', bolumler: [], guncelleme }
 *   velirapor/vn_<ogr>       öğrenci notları { tur: 'not', studentId, veli, ic, tarih, u }   (ic: yalnızca kurum içi raporda)
 *   velirapor/vr_<islem>     görüntüleme bağlantısı { tur: 'link', studentId, ogrAd, bas, bit, bitis, gun, olusturma, olusturan, kapsam, iptal, yenileme }
 *                            belirteç (32 hex) token sütununda; donmuş rapor snapshot sütununda { sid, bitis, olusturma, rapor }.
 *                            Genel /doc ucuyla veri alanı değiştirilse bile yayın snapshot sütunundaki öğrenci ve bitiş tarihine göre yapılır.
 *
 * POST   analiz2/link                 { studentId, gun (1-180), rapor, islemId } → { id, token, bitis }  (analiz ≥ 2, gözlemci değil, sınıf kısıtı)
 * POST   analiz2/link/<id>/yenile     { rapor } → anlık görüntü yeniden üretilir, belirteç aynı kalır
 * DELETE analiz2/link/<id>            belirteç silinir (bağlantı hemen 404 döner), kayıt "iptal" olarak kalır
 * GET    analiz2/vr/<token>           herkese açık, hız sınırlı, Cache-Control: no-store. Yalnızca o öğrencinin donmuş raporu;
 *                                     başka öğrencilerin adları anlık görüntüde bulunursa sunucu bunları maskeler.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'rest_api_init', function () {
	$ns  = 'optik-karne/v1';
	$yaz = function () {
		if ( function_exists( 'sides_is_observer' ) && sides_is_observer() ) {
			return sides_deny( 'Gözlemci hesabının işlem yetkisi yok. Yöneticinizden izin isteyin.' );
		}
		return sides_can( 'analiz', 2 ) ? true : sides_deny( 'Veli bağlantısı için Analiz modülünde düzenleme yetkisi gerekir.' );
	};
	register_rest_route( $ns, '/analiz2/link', array( 'methods' => 'POST', 'callback' => 'sides_a2_link_olustur', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/analiz2/link/(?P<id>vr_[a-z0-9]{6,40})/yenile', array( 'methods' => 'POST', 'callback' => 'sides_a2_link_yenile', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/analiz2/link/(?P<id>vr_[a-z0-9]{6,40})', array( 'methods' => 'DELETE', 'callback' => 'sides_a2_link_sil', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/analiz2/vr/(?P<token>[a-f0-9]{32})', array( 'methods' => 'GET', 'callback' => 'sides_a2_vr_oku', 'permission_callback' => '__return_true' ) );
} );

/* ------------------------------------------------------------------ *
 * Anlık görüntü temizliği (yalnızca bilinen alanlar, uzunluk sınırları)
 * ------------------------------------------------------------------ */
function sides_a2_str( $v, $n = 300 ) {
	if ( ! is_scalar( $v ) ) {
		return '';
	}
	return mb_substr( trim( wp_strip_all_tags( (string) $v ) ), 0, $n );
}
function sides_a2_tarih( $v ) {
	return is_string( $v ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $v ) ? $v : '';
}
function sides_a2_hucre( $v ) {
	if ( is_array( $v ) ) {
		$c = isset( $v['c'] ) && in_array( $v['c'], array( 'yok', 'ok', 'bad', 'warn', 'muted', 'b' ), true ) ? $v['c'] : '';
		return array( 't' => sides_a2_str( isset( $v['t'] ) ? $v['t'] : '', 200 ), 'c' => $c );
	}
	if ( null === $v ) {
		return null;
	}
	if ( is_int( $v ) || is_float( $v ) ) {
		return is_finite( (float) $v ) ? $v : null;
	}
	return sides_a2_str( $v, 300 );
}
function sides_a2_temizle( $r ) {
	if ( ! is_array( $r ) ) {
		return null;
	}
	$out = array(
		'surum'  => 1,
		'baslik' => sides_a2_str( isset( $r['baslik'] ) ? $r['baslik'] : 'Öğrenci Gelişim Raporu', 120 ),
		'donem'  => array(
			'bas' => sides_a2_tarih( isset( $r['donem']['bas'] ) ? $r['donem']['bas'] : '' ),
			'bit' => sides_a2_tarih( isset( $r['donem']['bit'] ) ? $r['donem']['bit'] : '' ),
		),
		'kapsam' => sides_a2_str( isset( $r['kapsam'] ) ? $r['kapsam'] : '', 400 ),
		'ozet'   => array(),
		'bolumler' => array(),
	);
	foreach ( array_slice( isset( $r['ozet'] ) && is_array( $r['ozet'] ) ? $r['ozet'] : array(), 0, 12 ) as $o ) {
		if ( is_array( $o ) ) {
			$out['ozet'][] = array( 'ad' => sides_a2_str( isset( $o['ad'] ) ? $o['ad'] : '', 60 ), 'deger' => sides_a2_str( isset( $o['deger'] ) ? $o['deger'] : '', 40 ), 'alt' => sides_a2_str( isset( $o['alt'] ) ? $o['alt'] : '', 140 ) );
		}
	}
	foreach ( array_slice( isset( $r['bolumler'] ) && is_array( $r['bolumler'] ) ? $r['bolumler'] : array(), 0, 40 ) as $b ) {
		if ( ! is_array( $b ) ) {
			continue;
		}
		$x = array(
			'k'      => preg_replace( '/[^a-z0-9]/', '', strtolower( (string) ( isset( $b['k'] ) ? $b['k'] : '' ) ) ),
			'baslik' => sides_a2_str( isset( $b['baslik'] ) ? $b['baslik'] : '', 120 ),
		);
		foreach ( array( 'aciklama' => 500, 'yok' => 240, 'metin' => 3000 ) as $a => $n ) {
			if ( isset( $b[ $a ] ) && '' !== sides_a2_str( $b[ $a ], $n ) ) {
				$x[ $a ] = sides_a2_str( $b[ $a ], $n );
			}
		}
		if ( isset( $b['tablo'] ) && is_array( $b['tablo'] ) ) {
			$kol = array();
			foreach ( array_slice( isset( $b['tablo']['kolon'] ) && is_array( $b['tablo']['kolon'] ) ? $b['tablo']['kolon'] : array(), 0, 18 ) as $k ) {
				$kol[] = array( 'ad' => sides_a2_str( is_array( $k ) && isset( $k['ad'] ) ? $k['ad'] : '', 60 ), 'num' => is_array( $k ) && ! empty( $k['num'] ) );
			}
			$sat = array();
			foreach ( array_slice( isset( $b['tablo']['satir'] ) && is_array( $b['tablo']['satir'] ) ? $b['tablo']['satir'] : array(), 0, 500 ) as $s ) {
				if ( is_array( $s ) ) {
					$sat[] = array_map( 'sides_a2_hucre', array_slice( array_values( $s ), 0, 18 ) );
				}
			}
			$x['tablo'] = array( 'kolon' => $kol, 'satir' => $sat );
		}
		if ( isset( $b['tiles'] ) && is_array( $b['tiles'] ) ) {
			$x['tiles'] = array();
			foreach ( array_slice( $b['tiles'], 0, 16 ) as $o ) {
				if ( is_array( $o ) ) {
					$x['tiles'][] = array( 'ad' => sides_a2_str( isset( $o['ad'] ) ? $o['ad'] : '', 60 ), 'deger' => sides_a2_str( isset( $o['deger'] ) ? $o['deger'] : '', 40 ), 'alt' => sides_a2_str( isset( $o['alt'] ) ? $o['alt'] : '', 140 ) );
				}
			}
		}
		if ( isset( $b['liste'] ) && is_array( $b['liste'] ) ) {
			$x['liste'] = array();
			foreach ( array_slice( $b['liste'], 0, 40 ) as $o ) {
				if ( is_array( $o ) ) {
					$ton = isset( $o['ton'] ) && in_array( $o['ton'], array( 'ok', 'warn', 'bad', 'muted' ), true ) ? $o['ton'] : '';
					$x['liste'][] = array( 'baslik' => sides_a2_str( isset( $o['baslik'] ) ? $o['baslik'] : '', 140 ), 'metin' => sides_a2_str( isset( $o['metin'] ) ? $o['metin'] : '', 500 ), 'ton' => $ton );
				}
			}
		}
		if ( isset( $b['grafik'] ) && is_array( $b['grafik'] ) ) {
			$g   = $b['grafik'];
			$ser = array();
			foreach ( array_slice( isset( $g['seri'] ) && is_array( $g['seri'] ) ? $g['seri'] : array(), 0, 4 ) as $s ) {
				if ( is_array( $s ) ) {
					$ser[] = array( 'ad' => sides_a2_str( isset( $s['ad'] ) ? $s['ad'] : '', 60 ), 'v' => array_map( function ( $v ) {
						return is_numeric( $v ) && is_finite( (float) $v ) ? round( (float) $v, 2 ) : null;
					}, array_slice( isset( $s['v'] ) && is_array( $s['v'] ) ? array_values( $s['v'] ) : array(), 0, 60 ) ) );
				}
			}
			$x['grafik'] = array(
				'etiket' => array_map( function ( $e ) {
					return sides_a2_str( $e, 40 );
				}, array_slice( isset( $g['etiket'] ) && is_array( $g['etiket'] ) ? array_values( $g['etiket'] ) : array(), 0, 60 ) ),
				'seri'   => $ser,
				'min'    => isset( $g['min'] ) && is_numeric( $g['min'] ) ? (float) $g['min'] : 0,
				'max'    => isset( $g['max'] ) && is_numeric( $g['max'] ) ? (float) $g['max'] : 100,
				'birim'  => sides_a2_str( isset( $g['birim'] ) ? $g['birim'] : '', 12 ),
			);
		}
		$out['bolumler'][] = $x;
	}
	return $out;
}
/* Başka öğrencilerin adları (tam ad, en az iki sözcük) anlık görüntüde geçiyorsa maskelenir */
function sides_a2_maskele( $org, $sid, $rapor ) {
	global $wpdb;
	$t   = sides_docs();
	$kendi = '';
	$adlar = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = 'students'", $org ) ) as $r ) { // phpcs:ignore
		$d  = json_decode( $r->data, true );
		$ad = is_array( $d ) && isset( $d['ad'] ) ? trim( (string) $d['ad'] ) : '';
		if ( (string) $r->id === $sid ) {
			$kendi = $ad;
		} elseif ( mb_strlen( $ad ) >= 5 && false !== strpos( $ad, ' ' ) ) {
			$adlar[] = $ad;
		}
	}
	$adlar = array_values( array_filter( array_unique( $adlar ), function ( $a ) use ( $kendi ) {
		return '' === $kendi || false === mb_stripos( $kendi, $a );
	} ) );
	if ( ! $adlar ) {
		return $rapor;
	}
	$ara = array();
	foreach ( $adlar as $a ) {
		$ara[] = $a;
		$ara[] = mb_strtoupper( $a, 'UTF-8' );
	}
	$yurut = function ( $v ) use ( &$yurut, $ara ) {
		if ( is_array( $v ) ) {
			return array_map( $yurut, $v );
		}
		return is_string( $v ) ? str_replace( $ara, '•••', $v ) : $v;
	};
	return $yurut( $rapor );
}

/* ------------------------------------------------------------------ *
 * Bağlantılar
 * ------------------------------------------------------------------ */
function sides_a2_ogrenci_denetle( $org, $sid ) {
	$s = $sid ? sides_get_doc( $org, 'students', $sid ) : null;
	if ( ! $s ) {
		return new WP_Error( 'sides_yok', 'Öğrenci bulunamadı.', array( 'status' => 404 ) );
	}
	$kisit = sides_sinif_kisit();
	if ( null !== $kisit && ! sides_ogrenci_izinli( $s, $kisit ) ) {
		return sides_deny( 'Bu öğrenci, yetkili olduğunuz sınıfların dışında.' );
	}
	return $s;
}
function sides_a2_snapshot( $org, $sid, $s, $rapor, $bitis, $olusturma ) {
	$r = sides_a2_temizle( $rapor );
	if ( ! $r ) {
		return new WP_Error( 'sides_gecersiz', 'Rapor verisi okunamadı.', array( 'status' => 400 ) );
	}
	$r['ogrenci'] = array( 'ad' => isset( $s['ad'] ) ? (string) $s['ad'] : '', 'sinif' => isset( $s['sinif'] ) ? (string) $s['sinif'] : '', 'sube' => isset( $s['sube'] ) ? (string) $s['sube'] : '' );
	$r    = sides_a2_maskele( $org, $sid, $r );
	if ( function_exists( 'sides_r2_vr_suz' ) ) {   // v6 K06: ödev iç notu / kontrol eden adı veli görüntüsüne giremez (rapor2.php)
		$r = sides_r2_vr_suz( $org, $sid, $r );
	}
	$json = wp_json_encode( array( 'sid' => $sid, 'bitis' => $bitis, 'olusturma' => $olusturma, 'rapor' => $r ) );
	if ( strlen( $json ) > 600000 ) {
		return new WP_Error( 'sides_buyuk', 'Rapor bağlantı için çok büyük; bazı bölümleri kaldırıp tekrar deneyin.', array( 'status' => 413 ) );
	}
	return $json;
}
function sides_a2_link_olustur( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$p   = $req->get_json_params();
	$sid = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) ( isset( $p['studentId'] ) ? $p['studentId'] : '' ) );
	$s   = sides_a2_ogrenci_denetle( $org, $sid );
	if ( is_wp_error( $s ) ) {
		return $s;
	}
	$gun = isset( $p['gun'] ) ? (int) $p['gun'] : 30;
	if ( $gun < 1 || $gun > 180 ) {
		return new WP_Error( 'sides_gecersiz', 'Geçerlilik süresi 1 ile 180 gün arasında olmalı.', array( 'status' => 400 ) );
	}
	$islem = strtolower( preg_replace( '/[^a-z0-9]/i', '', (string) ( isset( $p['islemId'] ) ? $p['islemId'] : '' ) ) );
	$id    = 'vr_' . ( strlen( $islem ) >= 6 ? substr( $islem, 0, 40 ) : bin2hex( random_bytes( 8 ) ) );
	$t     = sides_docs();
	$var   = $wpdb->get_row( $wpdb->prepare( "SELECT token, data FROM $t WHERE org = %d AND coll = 'velirapor' AND id = %s", $org, $id ) ); // phpcs:ignore
	if ( $var ) {   // aynı işlem ikinci kez gönderildi: yeni kayıt açılmaz
		$d = json_decode( $var->data, true );
		if ( ! is_array( $d ) || ( isset( $d['studentId'] ) ? (string) $d['studentId'] : '' ) !== $sid ) {
			return new WP_Error( 'sides_cakisma', 'Bu işlem kimliği başka bir kayıtta kullanılmış.', array( 'status' => 409 ) );
		}
		if ( ! $var->token ) {
			return new WP_Error( 'sides_cakisma', 'Bu bağlantı daha önce iptal edildi.', array( 'status' => 409 ) );
		}
		return array( 'id' => $id, 'token' => $var->token, 'bitis' => isset( $d['bitis'] ) ? $d['bitis'] : '', 'tekrar' => true );
	}
	$now   = current_time( 'timestamp' );
	$bitis = gmdate( 'Y-m-d', $now + $gun * DAY_IN_SECONDS );
	$olus  = current_time( 'mysql' );
	$snap  = sides_a2_snapshot( $org, $sid, $s, isset( $p['rapor'] ) ? $p['rapor'] : null, $bitis, $olus );
	if ( is_wp_error( $snap ) ) {
		return $snap;
	}
	$r  = json_decode( $snap, true );
	$u  = wp_get_current_user();
	$d  = array(
		'tur'       => 'link',
		'studentId' => $sid,
		'ogrAd'     => isset( $s['ad'] ) ? (string) $s['ad'] : '',
		'bas'       => $r['rapor']['donem']['bas'],
		'bit'       => $r['rapor']['donem']['bit'],
		'kapsam'    => $r['rapor']['kapsam'],
		'gun'       => $gun,
		'bitis'     => $bitis,
		'olusturma' => $olus,
		'olusturan' => $u && $u->ID ? $u->display_name : '',
		'tarih'     => substr( $olus, 0, 10 ),
	);
	if ( false === sides_put_doc( $org, 'velirapor', $id, $d ) ) {
		return new WP_Error( 'sides_db', 'Kaydedilemedi.', array( 'status' => 500 ) );
	}
	$tok = bin2hex( random_bytes( 16 ) );
	$wpdb->update( $t, array( 'token' => $tok, 'snapshot' => $snap ), array( 'org' => $org, 'coll' => 'velirapor', 'id' => $id ) );
	sides_log( $org, 'Veli raporu bağlantısı oluşturuldu: ' . $d['ogrAd'] . ' (' . $gun . ' gün)' );
	return array( 'id' => $id, 'token' => $tok, 'bitis' => $bitis, 'doc' => array_merge( $d, array( 'id' => $id, 'token' => $tok ) ) );
}
function sides_a2_link_kayit( $org, $id ) {
	$d = sides_get_doc( $org, 'velirapor', $id );
	if ( ! $d || ( isset( $d['tur'] ) ? $d['tur'] : '' ) !== 'link' ) {
		return new WP_Error( 'sides_yok', 'Bağlantı bulunamadı.', array( 'status' => 404 ) );
	}
	$s = sides_a2_ogrenci_denetle( $org, isset( $d['studentId'] ) ? (string) $d['studentId'] : '' );
	return is_wp_error( $s ) ? $s : array( $d, $s );
}
function sides_a2_link_yenile( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$id  = (string) $req['id'];
	$k   = sides_a2_link_kayit( $org, $id );
	if ( is_wp_error( $k ) ) {
		return $k;
	}
	list( $d, $s ) = $k;
	$t   = sides_docs();
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT token, snapshot FROM $t WHERE org = %d AND coll = 'velirapor' AND id = %s", $org, $id ) ); // phpcs:ignore
	$eski = $row && $row->snapshot ? json_decode( $row->snapshot, true ) : null;
	if ( ! $row || ! $row->token || ! is_array( $eski ) ) {
		return new WP_Error( 'sides_yok', 'Bağlantı iptal edilmiş; yeni bir bağlantı oluşturun.', array( 'status' => 404 ) );
	}
	$p    = $req->get_json_params();
	$sid  = (string) $eski['sid'];
	$snap = sides_a2_snapshot( $org, $sid, $s, isset( $p['rapor'] ) ? $p['rapor'] : null, (string) $eski['bitis'], current_time( 'mysql' ) );
	if ( is_wp_error( $snap ) ) {
		return $snap;
	}
	$r = json_decode( $snap, true );
	$d = array_merge( $d, array( 'bas' => $r['rapor']['donem']['bas'], 'bit' => $r['rapor']['donem']['bit'], 'kapsam' => $r['rapor']['kapsam'], 'yenileme' => current_time( 'mysql' ) ) );
	sides_put_doc( $org, 'velirapor', $id, $d );
	$wpdb->update( $t, array( 'snapshot' => $snap ), array( 'org' => $org, 'coll' => 'velirapor', 'id' => $id ) );
	sides_log( $org, 'Veli raporu bağlantısı yeniden üretildi: ' . ( isset( $s['ad'] ) ? $s['ad'] : '' ) );
	return array( 'ok' => true, 'doc' => array_merge( $d, array( 'id' => $id, 'token' => $row->token ) ) );
}
function sides_a2_link_sil( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$id  = (string) $req['id'];
	$k   = sides_a2_link_kayit( $org, $id );
	if ( is_wp_error( $k ) ) {
		return $k;
	}
	list( $d, $s ) = $k;
	$d['iptal'] = current_time( 'mysql' );
	sides_put_doc( $org, 'velirapor', $id, $d );
	$wpdb->update( sides_docs(), array( 'token' => null, 'snapshot' => null ), array( 'org' => $org, 'coll' => 'velirapor', 'id' => $id ) );
	sides_log( $org, 'Veli raporu bağlantısı iptal edildi: ' . ( isset( $s['ad'] ) ? $s['ad'] : '' ) );
	return array( 'ok' => true, 'doc' => array_merge( $d, array( 'id' => $id, 'token' => null ) ) );
}

/* ------------------------------------------------------------------ *
 * Herkese açık okuma
 * ------------------------------------------------------------------ */
function sides_a2_vr_oku( WP_REST_Request $req ) {
	global $wpdb;
	if ( ! sides_rl( 'a2_vr', 120, 600 ) ) {
		return new WP_Error( 'sides_rl', 'Çok fazla istek. Biraz sonra tekrar deneyin.', array( 'status' => 429 ) );
	}
	$yok = new WP_Error( 'sides_yok', 'Bağlantı geçersiz, süresi dolmuş ya da iptal edilmiş.', array( 'status' => 404 ) );
	$t   = sides_docs();
	$r   = $wpdb->get_row( $wpdb->prepare( "SELECT org, id, snapshot FROM $t WHERE coll = 'velirapor' AND token = %s", (string) $req['token'] ) ); // phpcs:ignore
	$sn  = $r && $r->snapshot ? json_decode( $r->snapshot, true ) : null;
	if ( ! $r || ! is_array( $sn ) || empty( $sn['sid'] ) || empty( $sn['rapor'] ) ) {
		return $yok;
	}
	$org = (int) $r->org;
	if ( in_array( 'analiz', sides_kapali_moduller( $org ), true ) ) {
		return $yok;
	}
	$o = sides_org( $org );
	if ( ! $o || sides_org_blok( $o ) ) {
		return $yok;
	}
	if ( empty( $sn['bitis'] ) || current_time( 'Y-m-d' ) > (string) $sn['bitis'] ) {
		return $yok;
	}
	if ( ! sides_get_doc( $org, 'students', (string) $sn['sid'] ) ) {
		return $yok;
	}
	$set = sides_get_doc( $org, 'settings', 'main' );
	$res = rest_ensure_response( array(
		'rapor'     => $sn['rapor'],
		'kurum'     => $set && ! empty( $set['kurum'] ) ? (string) $set['kurum'] : '',
		'logo'      => $set && ! empty( $set['logo'] ) && is_string( $set['logo'] ) ? $set['logo'] : '',
		'olusturma' => isset( $sn['olusturma'] ) ? (string) $sn['olusturma'] : '',
		'bitis'     => (string) $sn['bitis'],
	) );
	$res->header( 'Cache-Control', 'no-store' );
	$res->header( 'X-Robots-Tag', 'noindex, nofollow' );
	return $res;
}
