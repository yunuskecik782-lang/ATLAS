<?php
/* ------------------------------------------------------------------ *
 * v6 K01 Ödev takibi + kurs takibi sunucu kancaları
 * odev/<id>   { tip, ders, baslik, kaynak, kapsam, aciklama, sinif, sube, grup?, verilis, sonTarih, tarih,
 *               ogrenciler[], durum{sid:T|E|Y|M} (yok = B), not{sid}, kontrol{sid:{u,ad,t}}, olusturan{u,ad}, kazanim?, tekrar? }
 * Öğrenci durumları POST odev/kontrol ile yazılır (kilit + değişiklik geçmişi). Genel PUT /doc yalnız ödevin kendisini
 * değiştirir: durum/not gönderilmezse eski hâli korunur; gönderilirse doğrulanır, kapsam dışı öğrenciler eski hâliyle kalır.
 * sides_v6_doc_denetim / sides_v6_suz: rest.php ve ortak.php bu iki işlevi tanımlıysa çağırır (odev, dplan, doturum).
 * ------------------------------------------------------------------ */
defined( 'ABSPATH' ) || exit;

/* ---------- ortak yardımcılar (oturum.php de kullanır) ---------- */
function sides_kt_metin( $v, $n ) {
	return is_scalar( $v ) ? mb_substr( trim( sanitize_text_field( (string) $v ) ), 0, $n ) : '';
}
function sides_kt_uzun( $v, $n ) {
	return is_scalar( $v ) ? mb_substr( trim( sanitize_textarea_field( (string) $v ) ), 0, $n ) : '';
}
function sides_kt_tarih( $v ) {
	$v = is_scalar( $v ) ? (string) $v : '';
	return preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $v, $m ) && checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ? $v : '';
}
function sides_kt_saat( $v ) {
	return is_scalar( $v ) && preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', (string) $v ) ? (string) $v : '';
}
function sides_kt_sid( $k ) {
	return is_scalar( $k ) && preg_match( '/^[A-Za-z0-9_\-]{1,64}$/', (string) $k );
}
function sides_kt_sinif( $s ) {
	return is_scalar( $s ) ? sides_sinif_norm( str_replace( '/', ' ', (string) $s ) ) : '';
}
function sides_kt_sube( $s ) {
	return is_scalar( $s ) ? mb_strtoupper( mb_substr( trim( sanitize_text_field( (string) $s ) ), 0, 20 ), 'UTF-8' ) : '';
}
function sides_kt_bugun() {
	return ( new DateTime( 'now', new DateTimeZone( 'Europe/Istanbul' ) ) )->format( 'Y-m-d' );
}
function sides_kt_hata( $m, $s = 400 ) {
	return new WP_Error( 'sides_gecersiz', $m, array( 'status' => $s ) );
}
function sides_kt_yazar() {
	return sides_can( 'takip', 2 ) && ! sides_is_observer() ? true : sides_deny( 'Takip modülünde değişiklik yapma yetkiniz yok.' );
}
function sides_kt_yonetici() {
	return 'yonetici' === sides_ctx()['rol'] || sides_is_super();
}
/* Sınıf kapsamı. Tam: sınıf (şubesiz kayıtta bütün sınıf, şubeli kayıtta sınıf ya da o şube) kullanıcının yetkisinde.
   Kısmi: şubesiz (bütün şubeler) kayıtta kullanıcının en az bir şubesi varsa da yeterli. Kısıt yoksa her zaman true. */
function sides_kt_kapsam( $sinif, $sube, $kismi = false ) {
	$kisit = sides_sinif_kisit();
	if ( null === $kisit ) {
		return true;
	}
	$g = sides_kt_sinif( $sinif );
	$b = sides_kt_sube( $sube );
	if ( '' === $g ) {
		return false;
	}
	if ( in_array( $g, $kisit, true ) ) {
		return true;
	}
	if ( '' !== $b ) {
		return in_array( $g . '/' . $b, $kisit, true );
	}
	if ( $kismi ) {
		foreach ( $kisit as $k ) {
			if ( 0 === strpos( (string) $k, $g . '/' ) ) {
				return true;
			}
		}
	}
	return false;
}
/* Öğrenci haritası birleştirme: yeni değerler doğrulanır ($dogrula: değer → temiz değer ya da null), kapsam dışı öğrenciler eski hâliyle kalır */
function sides_kt_harita_birlestir( $yeni, $eski, $izin, $dogrula, $liste = null ) {
	$m = array();
	foreach ( is_array( $eski ) ? $eski : array() as $k => $v ) {
		if ( null !== $izin && ! isset( $izin[ (string) $k ] ) ) {
			$m[ (string) $k ] = $v;
		}
	}
	if ( count( $yeni ) > 1200 ) {
		return sides_kt_hata( 'Liste çok uzun.' );
	}
	foreach ( $yeni as $k => $v ) {
		$k = (string) $k;
		if ( ! sides_kt_sid( $k ) ) {
			return sides_kt_hata( 'Geçersiz öğrenci.' );
		}
		if ( null !== $izin && ! isset( $izin[ $k ] ) ) {
			continue;   // kapsam dışı: eskisi korunur
		}
		if ( null !== $liste && ! in_array( $k, $liste, true ) ) {
			continue;
		}
		if ( null === $v || '' === $v ) {
			continue;
		}
		$t = call_user_func( $dogrula, $v );
		if ( null === $t ) {
			return sides_kt_hata( 'Geçersiz değer.' );
		}
		if ( '' !== $t ) {
			$m[ $k ] = $t;
		}
	}
	return $m;
}

/* ---------- kancalar ---------- */
function sides_v6_doc_denetim( $org, $coll, $id, $d ) {
	if ( ! in_array( $coll, array( 'odev', 'dplan', 'doturum' ), true ) ) {
		return $d;
	}
	if ( sides_is_observer() || ! sides_can( 'takip', 2 ) ) {
		return sides_deny( 'Takip modülünde değişiklik yapma yetkiniz yok.' );
	}
	if ( ! is_array( $d ) ) {
		return sides_kt_hata( 'Geçersiz veri.' );
	}
	if ( 'odev' === $coll ) {
		return sides_od_denetim( $org, $id, $d );
	}
	return 'dplan' === $coll ? sides_ot_plan_denetim( $org, $id, $d ) : sides_ot_denetim( $org, $id, $d );
}

function sides_v6_suz( $coll, $d, $izin ) {
	if ( ! in_array( $coll, array( 'odev', 'dplan', 'doturum' ), true ) || ! is_array( $d ) ) {
		return $d;
	}
	if ( null !== $izin ) {
		$sinif = isset( $d['sinif'] ) ? $d['sinif'] : '';
		$sube  = isset( $d['sube'] ) ? $d['sube'] : '';
		if ( 'odev' === $coll ) {
			$L = isset( $d['ogrenciler'] ) && is_array( $d['ogrenciler'] ) ? $d['ogrenciler'] : array();
			if ( $L ) {
				$L = array_values( array_filter( $L, function ( $s ) use ( $izin ) {
					return is_scalar( $s ) && isset( $izin[ (string) $s ] );
				} ) );
				if ( ! $L ) {
					return null;
				}
				$d['ogrenciler'] = $L;
			} elseif ( ! sides_kt_kapsam( $sinif, $sube, true ) ) {
				return null;
			}
			foreach ( array( 'durum', 'not', 'kontrol' ) as $a ) {
				if ( isset( $d[ $a ] ) ) {
					$d[ $a ] = (object) sides_takip_suz_harita( (array) $d[ $a ], $izin );
				}
			}
		} else {
			if ( ! sides_kt_kapsam( $sinif, $sube, true ) ) {
				return null;
			}
			if ( 'doturum' === $coll && isset( $d['yoklama'] ) ) {
				$d['yoklama'] = (object) sides_takip_suz_harita( (array) $d['yoklama'], $izin );
			}
		}
	}
	if ( sides_is_observer() ) {   // gözlemci: iç kullanıcı kimlikleri ve iç notlar gitmez
		if ( 'odev' === $coll ) {
			unset( $d['not'] );
			if ( isset( $d['olusturan'] ) && is_array( $d['olusturan'] ) ) {
				unset( $d['olusturan']['u'] );
			}
			if ( isset( $d['kontrol'] ) ) {
				$k = array();
				foreach ( (array) $d['kontrol'] as $s => $v ) {
					$k[ $s ] = is_array( $v ) ? array( 'ad' => isset( $v['ad'] ) ? $v['ad'] : '', 't' => isset( $v['t'] ) ? $v['t'] : 0 ) : $v;
				}
				$d['kontrol'] = (object) $k;
			}
		} else {
			if ( isset( $d['ogretmen'] ) && is_array( $d['ogretmen'] ) ) {
				unset( $d['ogretmen']['u'] );
			}
			if ( 'doturum' === $coll ) {
				unset( $d['not'] );
			}
		}
	}
	return $d;
}

/* ---------- ödev kaydı (PUT /doc/odev/<id>) ---------- */
function sides_od_kapsamda( $d, $izin ) {
	if ( null === $izin ) {
		return true;
	}
	if ( isset( $d['tip'] ) && 'kazanim' === $d['tip'] ) {   // tek öğrenciye kazanım görevi: öğrencileri yetkide olmalı
		$L = isset( $d['ogrenciler'] ) ? (array) $d['ogrenciler'] : array();
		foreach ( $L as $s ) {
			if ( ! isset( $izin[ (string) $s ] ) ) {
				return false;
			}
		}
		return (bool) $L;
	}
	return sides_kt_kapsam( isset( $d['sinif'] ) ? $d['sinif'] : '', isset( $d['sube'] ) ? $d['sube'] : '' );
}
function sides_od_denetim( $org, $id, $d ) {
	$eski  = sides_get_doc( $org, 'odev', $id );
	$eski  = is_array( $eski ) ? $eski : null;
	$izin  = sides_takip_izin( $org );
	$g     = function ( $k ) use ( $d ) {
		return isset( $d[ $k ] ) ? $d[ $k ] : '';
	};
	$o     = array(
		'tip'      => 'kazanim' === $g( 'tip' ) ? 'kazanim' : 'odev',
		'ders'     => sides_kt_metin( $g( 'ders' ), 60 ),
		'baslik'   => sides_kt_metin( $g( 'baslik' ), 120 ),
		'kaynak'   => sides_kt_metin( $g( 'kaynak' ), 120 ),
		'kapsam'   => sides_kt_metin( $g( 'kapsam' ), 120 ),
		'aciklama' => sides_kt_uzun( $g( 'aciklama' ), 1000 ),
		'sinif'    => sides_kt_sinif( $g( 'sinif' ) ),
		'sube'     => sides_kt_sube( $g( 'sube' ) ),
	);
	if ( '' !== sides_kt_metin( $g( 'grup' ), 60 ) ) {
		$o['grup'] = sides_kt_metin( $g( 'grup' ), 60 );
	}
	$o['verilis']  = sides_kt_tarih( $g( 'verilis' ) );
	$o['verilis']  = $o['verilis'] ? $o['verilis'] : ( sides_kt_tarih( $g( 'tarih' ) ) ? sides_kt_tarih( $g( 'tarih' ) ) : sides_kt_bugun() );
	$o['sonTarih'] = sides_kt_tarih( $g( 'sonTarih' ) );
	$o['tarih']    = $o['verilis'];
	if ( '' === $o['baslik'] && '' === $o['ders'] ) {
		return sides_kt_hata( 'Ödevin dersini ya da başlığını yazın.' );
	}
	if ( '' === $o['sonTarih'] ) {
		return sides_kt_hata( 'Son tarih geçersiz.' );
	}
	if ( $o['sonTarih'] < $o['verilis'] ) {
		return sides_kt_hata( 'Son tarih, veriliş tarihinden önce olamaz.' );
	}
	if ( '' === $o['sinif'] && 'odev' === $o['tip'] ) {
		return sides_kt_hata( 'Sınıf seçin.' );
	}
	$L = array();
	foreach ( is_array( $g( 'ogrenciler' ) ) ? $g( 'ogrenciler' ) : array() as $s ) {
		if ( sides_kt_sid( $s ) && ! in_array( (string) $s, $L, true ) ) {
			$L[] = (string) $s;
		}
	}
	if ( count( $L ) > 600 ) {
		return sides_kt_hata( 'Öğrenci listesi çok uzun.' );
	}
	if ( null !== $izin ) {   // sınıf kısıtlı: kapsam dışı öğrenciler eski listeden korunur, yenisine eklenemez
		$K = array();
		foreach ( $eski && isset( $eski['ogrenciler'] ) ? (array) $eski['ogrenciler'] : array() as $s ) {
			if ( ! isset( $izin[ (string) $s ] ) ) {
				$K[] = (string) $s;
			}
		}
		foreach ( $L as $s ) {
			if ( isset( $izin[ $s ] ) && ! in_array( $s, $K, true ) ) {
				$K[] = $s;
			}
		}
		$yeni_kendi = array_values( array_filter( $L, function ( $s ) use ( $izin ) {
			return isset( $izin[ $s ] );
		} ) );
		$L = $K;
		$red = sides_deny( 'Bu ödev, yetkili olduğunuz sınıfların dışında.' );
		if ( ! sides_od_kapsamda( array( 'tip' => $o['tip'], 'sinif' => $o['sinif'], 'sube' => $o['sube'], 'ogrenciler' => $yeni_kendi ), $izin ) ) {
			return $red;
		}
		if ( $eski && ! sides_od_kapsamda( $eski, $izin ) ) {
			return $red;
		}
	}
	$o['ogrenciler'] = $L;
	$u = wp_get_current_user();
	/* öğrenci durumları ve notları: gönderilmediyse eski hâli; gönderildiyse doğrulanır (kapsam dışı öğrenciler eski hâliyle) */
	$eD = $eski && isset( $eski['durum'] ) ? (array) $eski['durum'] : array();
	$eN = $eski && isset( $eski['not'] ) ? (array) $eski['not'] : array();
	$eK = $eski && isset( $eski['kontrol'] ) ? (array) $eski['kontrol'] : array();
	$D  = isset( $d['durum'] ) && is_array( $d['durum'] ) ? sides_kt_harita_birlestir( $d['durum'], $eD, $izin, function ( $v ) {
		return 'B' === $v ? '' : ( in_array( $v, array( 'T', 'E', 'Y', 'M' ), true ) ? $v : null );
	}, $L ? $L : null ) : $eD;
	if ( is_wp_error( $D ) ) {
		return $D;
	}
	$N = isset( $d['not'] ) && is_array( $d['not'] ) ? sides_kt_harita_birlestir( $d['not'], $eN, $izin, function ( $v ) {
		return is_scalar( $v ) ? sides_kt_metin( $v, 120 ) : null;
	}, $L ? $L : null ) : $eN;
	if ( is_wp_error( $N ) ) {
		return $N;
	}
	$K = array();   // kontrol kaydı istemciden alınmaz: değişen her durum için sunucu yazar
	foreach ( $D as $s => $v ) {
		$K[ $s ] = isset( $eD[ $s ] ) && $eD[ $s ] === $v && isset( $eK[ $s ] ) ? $eK[ $s ] : array( 'u' => (int) $u->ID, 'ad' => $u->display_name, 't' => time() );
	}
	$o['durum']     = (object) $D;
	$o['not']       = (object) $N;
	$o['kontrol']   = (object) $K;
	$o['olusturan'] = $eski && isset( $eski['olusturan'] ) && is_array( $eski['olusturan'] ) ? $eski['olusturan'] : array( 'u' => (int) $u->ID, 'ad' => $u->display_name );
	$kz = $g( 'kazanim' );
	if ( is_array( $kz ) ) {
		$o['kazanim'] = array( 'kod' => sides_kt_metin( isset( $kz['kod'] ) ? $kz['kod'] : '', 40 ), 'ad' => sides_kt_metin( isset( $kz['ad'] ) ? $kz['ad'] : '', 300 ) );
		foreach ( array( 'sinavId', 'testId' ) as $a ) {
			if ( isset( $kz[ $a ] ) && sides_kt_sid( $kz[ $a ] ) ) {
				$o['kazanim'][ $a ] = (string) $kz[ $a ];
			}
		}
		if ( isset( $kz['ders'] ) ) {
			$o['kazanim']['ders'] = sides_kt_metin( $kz['ders'], 60 );
		}
	}
	$tk = $g( 'tekrar' );
	if ( is_array( $tk ) ) {
		$o['tekrar'] = array();
		if ( isset( $tk['testId'] ) && sides_kt_sid( $tk['testId'] ) ) {
			$o['tekrar']['testId'] = (string) $tk['testId'];
		}
		if ( isset( $tk['sonuc'] ) && ( is_scalar( $tk['sonuc'] ) || strlen( (string) wp_json_encode( $tk['sonuc'] ) ) <= 2000 ) ) {
			$o['tekrar']['sonuc'] = is_string( $tk['sonuc'] ) ? sides_kt_metin( $tk['sonuc'], 200 ) : $tk['sonuc'];
		}
		if ( isset( $tk['tarih'] ) && sides_kt_tarih( $tk['tarih'] ) ) {
			$o['tekrar']['tarih'] = $tk['tarih'];
		}
	}
	return $o;
}

/* ---------- öğrenci durumu kontrolü ---------- */
add_action( 'rest_api_init', function () {
	register_rest_route( 'optik-karne/v1', '/odev/kontrol', array( 'methods' => 'POST', 'callback' => 'sides_od_kontrol', 'permission_callback' => 'sides_kt_yazar' ) );
} );
/* POST odev/kontrol { id, degerler: { sid: T|E|Y|M|B|null }, not?: { sid: metin|null } } → güncel ödev */
function sides_od_kontrol( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	$id  = isset( $p['id'] ) ? (string) $p['id'] : '';
	$deg = isset( $p['degerler'] ) && is_array( $p['degerler'] ) ? $p['degerler'] : array();
	$not = isset( $p['not'] ) && is_array( $p['not'] ) ? $p['not'] : array();
	if ( ! sides_kt_sid( $id ) || ( ! $deg && ! $not ) || count( $deg ) > 600 || count( $not ) > 600 ) {
		return sides_kt_hata( 'Geçersiz kayıt.' );
	}
	foreach ( $deg as $k => $v ) {
		if ( ! sides_kt_sid( $k ) || ! ( null === $v || '' === $v || in_array( $v, array( 'B', 'T', 'E', 'Y', 'M' ), true ) ) ) {
			return sides_kt_hata( 'Geçersiz ödev durumu.' );
		}
	}
	foreach ( $not as $k => $v ) {
		if ( ! sides_kt_sid( $k ) || ! ( null === $v || is_scalar( $v ) ) ) {
			return sides_kt_hata( 'Geçersiz not.' );
		}
	}
	$kilit = sides_takip_kilit( $org . '|odev|' . $id );
	if ( false === $kilit ) {
		return sides_kilit_mesgul();
	}
	$sonuc = sides_od_kontrol_uygula( $org, $id, $deg, $not );
	sides_takip_kilit_birak( $kilit );
	return $sonuc;
}
function sides_od_kontrol_uygula( $org, $id, $deg, $not ) {
	$d = sides_get_doc( $org, 'odev', $id );
	if ( ! is_array( $d ) ) {
		return sides_kt_hata( 'Ödev bulunamadı; silinmiş olabilir. Sayfayı yenileyin.', 404 );
	}
	unset( $d['id'], $d['token'] );
	$izin = sides_takip_izin( $org );
	$L    = array_map( 'strval', isset( $d['ogrenciler'] ) ? (array) $d['ogrenciler'] : array() );
	$red  = sides_deny( 'Bu öğrenci, yetkili olduğunuz sınıfların dışında.' );
	$D    = isset( $d['durum'] ) ? (array) $d['durum'] : array();
	$N    = isset( $d['not'] ) ? (array) $d['not'] : array();
	$K    = isset( $d['kontrol'] ) ? (array) $d['kontrol'] : array();
	$D0   = $D;
	$N0   = $N;
	$u    = wp_get_current_user();
	$denetle = function ( $sid ) use ( $izin, $L, $red ) {
		if ( null !== $izin && ! isset( $izin[ $sid ] ) ) {
			return $red;
		}
		return $L && ! in_array( $sid, $L, true ) ? sides_kt_hata( 'Bu öğrenci ödevin öğrenci listesinde yok.' ) : null;
	};
	foreach ( $deg as $sid => $v ) {
		$sid = (string) $sid;
		$h   = $denetle( $sid );
		if ( $h ) {
			return $h;
		}
		if ( null === $v || '' === $v || 'B' === $v ) {
			unset( $D[ $sid ], $K[ $sid ] );
			continue;
		}
		if ( isset( $D[ $sid ] ) && $D[ $sid ] === $v ) {
			continue;   // aynı değer yeniden gönderildi: kontrol kaydı değişmez
		}
		$D[ $sid ] = $v;
		$K[ $sid ] = array( 'u' => (int) $u->ID, 'ad' => $u->display_name, 't' => time() );
	}
	foreach ( $not as $sid => $v ) {
		$sid = (string) $sid;
		$h   = $denetle( $sid );
		if ( $h ) {
			return $h;
		}
		$v = null === $v ? '' : sides_kt_metin( $v, 120 );
		if ( '' === $v ) {
			unset( $N[ $sid ] );
		} else {
			$N[ $sid ] = $v;
		}
	}
	$d['durum']   = (object) $D;
	$d['not']     = (object) $N;
	$d['kontrol'] = (object) $K;
	if ( false === sides_put_doc( $org, 'odev', $id, $d ) ) {
		return new WP_Error( 'sides_db', 'Kaydedilemedi.', array( 'status' => 500 ) );
	}
	sides_tk_gecmis_yaz( $org, 'odev', $id, 'durum', $D0, $D );
	if ( $not ) {
		sides_tk_gecmis_yaz( $org, 'odev', $id, 'not', $N0, $N );
	}
	$out       = sides_v6_suz( 'odev', json_decode( wp_json_encode( $d ), true ), $izin );
	$out['id'] = $id;
	return $out;
}

/* ---------- silme: DELETE /doc/(odev|dplan|doturum)/<id> ---------- */
add_filter( 'rest_request_before_callbacks', function ( $res, $handler, $req ) {
	if ( is_wp_error( $res ) || 'DELETE' !== $req->get_method() || ! preg_match( '#^/optik-karne/v1/doc/(odev|dplan|doturum)/([A-Za-z0-9_\-]{1,64})$#', (string) $req->get_route(), $m ) ) {
		return $res;
	}
	$red = sides_kt_silme_denetimi( sides_org_id(), $m[1], $m[2] );
	return $red ? $red : $res;
}, 10, 3 );
function sides_kt_silme_denetimi( $org, $coll, $id ) {
	if ( sides_is_observer() || ! sides_can( 'takip', 2 ) ) {
		return sides_deny( 'Takip modülünde değişiklik yapma yetkiniz yok.' );
	}
	$d = sides_get_doc( $org, $coll, $id );
	if ( ! is_array( $d ) ) {
		return null;
	}
	$izin = sides_takip_izin( $org );
	if ( 'odev' === $coll ) {
		$sahip = isset( $d['olusturan']['u'] ) && (int) $d['olusturan']['u'] === get_current_user_id();
		if ( ! sides_kt_yonetici() && ! $sahip ) {
			return sides_deny( 'Ödevi yalnızca oluşturan öğretmen ya da yönetici silebilir.' );
		}
		return sides_od_kapsamda( $d, $izin ) ? null : sides_deny( 'Bu ödev, yetkili olduğunuz sınıfların dışında.' );
	}
	return sides_kt_kapsam( isset( $d['sinif'] ) ? $d['sinif'] : '', isset( $d['sube'] ) ? $d['sube'] : '', 'doturum' === $coll ) ? null : sides_deny( 'Bu kayıt, yetkili olduğunuz sınıfların dışında.' );
}
