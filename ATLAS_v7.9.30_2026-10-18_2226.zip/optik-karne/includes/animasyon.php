<?php
/**
 * v5.5 — Site Animasyonları ve Soru Havuzu kurumlar arası paylaşımı.
 *
 * Animasyon ayarları (v7: 36 şablon — SIDES_ANIM_36; kayıt { v:2, sablon, secim:{menu,bildirim,yukleme,tv}, kapali, g, tv })
 *   GET  /animasyon            → { kurum: ayar|null, kisisel: { hareket }, yazabilir, sema, sinir }
 *   TV panosu yanıtına (GET /tv/<token>) rest_post_dispatch ile anGecis { k, d, x, y, e, hz } eklenir.
 *   POST /animasyon/kurum      { ayar }      kurum varsayılanı (yalnız kurum yöneticisi) — belge: org/animasyon/kurum
 *   POST /animasyon/kisisel    { hareket }   kişisel tercih (kurum | az), kullanıcı meta: sides_animasyon
 *   Ana Sayfa Düzeni, Duyurular veya kurum ayarları (settings/main) kaydedilince bu belgeye dokunulmaz.
 *
 * Soru havuzu paylaşımı ("Tüm Kurumlar Kullansın")
 *   GET  /havuz/paylasim       → { acik, t, by, paylasilan, ortak, yazabilir }
 *   POST /havuz/paylasim       { acik: bool } (kurum yöneticisi + Soru Havuzu yazma yetkisi) — belge: org/havuzpay/main
 *   Paylaşan kurumun soruları kendi kurum alanında kalır (org değişmez); diğer kurumlar /havuz listesinde
 *   salt okunur "ortak" olarak görür, değiştiremez/silemez. Özel işaretli (ozel: true) sorular paylaşılmaz.
 *   Paylaşım kapatılınca liste erişimi kalkar; daha önce teste/denemeye alınmış soru kopyaları ve görselleri
 *   kullanım ilişkisi üzerinden (alan kurumun testler/exams belgelerinde görsel kimliği geçiyorsa) açılmaya devam eder.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* v5.5 hazır ayar kimlikleri: v7'de A01–A04 olarak aynen korunur (eski kayıtlar ve eski istemciler çalışmaya devam eder) */
const SIDES_ANIM_SABLON = array( 'sade', 'yumusak', 'akici', 'cicekli' );
const SIDES_HAYVANLAR   = array( 'tavsan', 'kus', 'ari', 'horoz', 'aslan', 'leopar', 'araba' );
/* v7.9 yarış arabası senaryoları (src/araba.js ARABA_SENARYO ile aynı) */
const SIDES_ARABA_SENARYO = array( 'karisik', 'tek', 'ikili', 'uclu', 'pit' );
/* v7 tavşan cinsleri ve sahneleri (src/tavsan.js TAV_CINS / TAV_SAHNE ile aynı); karisik = her seferinde farklı */
const SIDES_TAV_CINS    = array( 'karisik', 'beyaz', 'kahve', 'gri', 'benekli', 'sarkik', 'yavru' );
const SIDES_TAV_SAHNE   = array( 'karisik', 'bahce', 'klasik', 'yuva', 'aile', 'kelebek', 'uyku' );
const SIDES_ANIM_GRUP   = array( 'sayfa', 'menu', 'dugme', 'bildirim', 'yukleme', 'dekor' );
/* v7.9.21 açılış ekranı (logo animasyonu) şablonları; src/animasyon.js ACILIS_SABLON ile aynı. karisik = her açılışta farklı, yok = hareketsiz */
const SIDES_ACILIS = array( 'cizgi', 'belir', 'pusula', 'rota', 'dalga', 'parilti', 'harfler', 'aurora', 'karisik', 'yok' );
/*
 * v7 — 36 geçiş şablonu (dok. 18). anahtar => array( kod, grup, süre ms, sıra ms, x px, y px, ölçek, eğri ).
 * İstemcideki ANIM36 (src/animasyon.js) ile aynı tablodur; GET /animasyon bu şemayı da döndürür ve istemci sayısal
 * değerleri buradan alır. Grup → kayıt yeri: sayfa ve erisim → sablon; menu, bildirim, yukleme, tv → secim.<grup>.
 */
const SIDES_ANIM_36 = array(
	'sade'         => array( 'A01', 'sayfa', 180, 0, 0, 0, 1, 0 ),
	'yumusak'      => array( 'A02', 'sayfa', 260, 0, 0, 2, 1, 1 ),
	'akici'        => array( 'A03', 'sayfa', 200, 0, 0, 8, 1, 0 ),
	'cicekli'      => array( 'A04', 'sayfa', 260, 0, 0, 0, 0.995, 1 ),
	'belirmeHizli' => array( 'A05', 'sayfa', 110, 0, 0, 0, 1, 0 ),
	'belirmeYavas' => array( 'A06', 'sayfa', 420, 0, 0, 0, 1, 1 ),
	'yukari4'      => array( 'A07', 'sayfa', 180, 0, 0, 4, 1, 0 ),
	'yukari8'      => array( 'A08', 'sayfa', 180, 0, 0, 8, 1, 0 ),
	'yukari12'     => array( 'A09', 'sayfa', 180, 0, 0, 12, 1, 0 ),
	'asagi4'       => array( 'A10', 'sayfa', 180, 0, 0, -4, 1, 0 ),
	'asagi8'       => array( 'A11', 'sayfa', 180, 0, 0, -8, 1, 0 ),
	'soldan'       => array( 'A12', 'sayfa', 180, 0, -12, 0, 1, 0 ),
	'sagdan'       => array( 'A13', 'sayfa', 180, 0, 12, 0, 1, 0 ),
	'yakin98'      => array( 'A14', 'sayfa', 180, 0, 0, 0, 0.98, 0 ),
	'yakin96'      => array( 'A15', 'sayfa', 180, 0, 0, 0, 0.96, 0 ),
	'uzak102'      => array( 'A16', 'sayfa', 180, 0, 0, 0, 1.02, 0 ),
	'yayYumusak'   => array( 'A17', 'sayfa', 180, 0, 0, 6, 0.98, 2 ),
	'yayDengeli'   => array( 'A18', 'sayfa', 180, 0, 0, 6, 0.98, 3 ),
	'sakin'        => array( 'A19', 'sayfa', 300, 0, 0, 1, 1, 1 ),
	'siraKisa'     => array( 'A20', 'sayfa', 210, 40, 0, 0, 1, 0 ),
	'siraOrta'     => array( 'A21', 'sayfa', 230, 75, 0, 0, 1, 0 ),
	'menuAsagi'    => array( 'A22', 'menu', 180, 0, 0, -6, 1, 0 ),
	'menuYukari'   => array( 'A23', 'menu', 180, 0, 0, 6, 1, 0 ),
	'menuYakin'    => array( 'A24', 'menu', 180, 0, 0, 0, 0.97, 0 ),
	'bilSoldan'    => array( 'A25', 'bildirim', 180, 0, -20, 0, 1, 0 ),
	'bilSagdan'    => array( 'A26', 'bildirim', 180, 0, 20, 0, 1, 0 ),
	'basari'       => array( 'A27', 'bildirim', 220, 0, 0, 0, 1, 0 ),
	'hataSabit'    => array( 'A28', 'bildirim', 0, 0, 0, 0, 1, 0 ),
	'halka'        => array( 'A29', 'yukleme', 900, 0, 0, 0, 1, 0 ),
	'ucNokta'      => array( 'A30', 'yukleme', 1200, 0, 0, 0, 1, 0 ),
	'cizgi'        => array( 'A31', 'yukleme', 1300, 0, 0, 0, 1, 0 ),
	'iskelet'      => array( 'A32', 'yukleme', 1400, 0, 0, 0, 1, 0 ),
	'tvCapraz'     => array( 'A33', 'tv', 700, 0, 0, 0, 1, 1 ),
	'tvYatay'      => array( 'A34', 'tv', 600, 0, 24, 0, 1, 1 ),
	'tvDikey'      => array( 'A35', 'tv', 650, 0, 0, 16, 1, 1 ),
	'hareketsiz'   => array( 'A36', 'erisim', 0, 0, 0, 0, 1, 0 ),
);
const SIDES_ANIM_YER   = array( 'sayfa' => 'sablon', 'erisim' => 'sablon', 'menu' => 'menu', 'bildirim' => 'bildirim', 'yukleme' => 'yukleme', 'tv' => 'tv' );
/* Parametre sınırları (ms / px / ölçek): sunucu bu sınırların dışındaki şema değerini kullanmaz, istemci de aynı sınırlarla kırpar */
const SIDES_ANIM_SINIR = array(
	'sayfa'    => array( 0, 450, 80, 24 ),
	'erisim'   => array( 0, 0, 0, 0 ),
	'menu'     => array( 0, 300, 0, 12 ),
	'bildirim' => array( 0, 400, 0, 24 ),
	'yukleme'  => array( 600, 2400, 0, 0 ),
	'tv'       => array( 0, 1000, 0, 32 ),
);
const SIDES_ANIM_SECIM_VARS = array( 'menu' => 'menuYakin', 'bildirim' => 'basari', 'yukleme' => 'halka', 'tv' => 'tvDikey' );
/* Eski dört hazır ayarın menü ve bildirim karşılıkları (istemcide ANIM_ESKI) */
const SIDES_ANIM_ESKI = array(
	'sade'    => array( 'menuYakin', 'basari' ),
	'yumusak' => array( 'menuYakin', 'basari' ),
	'akici'   => array( 'menuAsagi', 'bilSagdan' ),
	'cicekli' => array( 'menuYakin', 'basari' ),
);

function sides_anim_hata( $m ) {
	return new WP_Error( 'sides_dogrulama', $m, array( 'status' => 400 ) );
}

/* $k, $yer (sablon | menu | bildirim | yukleme | tv) için izinli bir şablon anahtarı mı */
function sides_anim_yerde( $k, $yer ) {
	return is_string( $k ) && isset( SIDES_ANIM_36[ $k ] ) && SIDES_ANIM_YER[ SIDES_ANIM_36[ $k ][1] ] === $yer;
}

/* Seçim eksikse: eski hazır ayarın karşılıkları, yoksa varsayılanlar */
function sides_anim_secim_taban( $sablon ) {
	$t = SIDES_ANIM_SECIM_VARS;
	if ( isset( SIDES_ANIM_ESKI[ $sablon ] ) ) {
		$t['menu']     = SIDES_ANIM_ESKI[ $sablon ][0];
		$t['bildirim'] = SIDES_ANIM_ESKI[ $sablon ][1];
	}
	return $t;
}

/* Şema satırı sınırlar içinde mi (sunucu sınır dışı değeri yayımlamaz) */
function sides_anim_satir( $k ) {
	$r = SIDES_ANIM_36[ $k ];
	$s = SIDES_ANIM_SINIR[ $r[1] ];
	$r[2] = max( $s[0], min( $s[1], (int) $r[2] ) );
	$r[3] = max( 0, min( $s[2], (int) $r[3] ) );
	$r[4] = max( -$s[3], min( $s[3], (int) $r[4] ) );
	$r[5] = max( -$s[3], min( $s[3], (int) $r[5] ) );
	$r[6] = max( 0.9, min( 1.05, (float) $r[6] ) );
	$r[7] = max( 0, min( 3, (int) $r[7] ) );
	return $r;
}

/* Ayarı beyaz listeyle temizler; geçersiz şablon/hız/süre 400 döner (sunucu doğrulaması). Yalnız bilinen anahtarlar
   saklanır; CSS veya JavaScript metni ayar olarak kabul edilmez. v1 kaydı (secim yok) eski hazır ayarın karşılığıyla tamamlanır. */
function sides_anim_temizle( $a ) {
	if ( ! is_array( $a ) ) {
		return sides_anim_hata( 'Animasyon ayarı okunamadı.' );
	}
	$s = isset( $a['sablon'] ) ? $a['sablon'] : '';
	if ( ! sides_anim_yerde( $s, 'sablon' ) ) {
		return sides_anim_hata( 'Geçersiz geçiş şablonu seçildi.' );
	}
	$out   = array( 'v' => 2, 'sablon' => $s, 'secim' => array(), 'kapali' => ! empty( $a['kapali'] ), 'g' => array() );
	$out['acilis'] = isset( $a['acilis'] ) && is_string( $a['acilis'] ) && in_array( $a['acilis'], SIDES_ACILIS, true ) ? $a['acilis'] : 'cizgi';
	$taban = sides_anim_secim_taban( $s );
	$sx    = isset( $a['secim'] ) ? $a['secim'] : array();
	if ( ! is_array( $sx ) ) {
		return sides_anim_hata( 'Şablon seçimi okunamadı.' );
	}
	$adlar = array( 'menu' => 'menü', 'bildirim' => 'bildirim', 'yukleme' => 'yükleme göstergesi', 'tv' => 'TV geçişi' );
	foreach ( array_keys( $sx ) as $yer ) {
		if ( ! isset( $adlar[ $yer ] ) ) {
			return sides_anim_hata( 'Bilinmeyen şablon alanı.' );
		}
	}
	foreach ( $adlar as $yer => $ad ) {
		if ( ! array_key_exists( $yer, $sx ) ) {
			$out['secim'][ $yer ] = $taban[ $yer ];
		} elseif ( sides_anim_yerde( $sx[ $yer ], $yer ) ) {
			$out['secim'][ $yer ] = $sx[ $yer ];
		} else {
			return sides_anim_hata( 'Geçersiz ' . $ad . ' şablonu seçildi.' );
		}
	}
	$g   = isset( $a['g'] ) && is_array( $a['g'] ) ? $a['g'] : array();
	foreach ( SIDES_ANIM_GRUP as $k ) {
		$x = isset( $g[ $k ] ) && is_array( $g[ $k ] ) ? $g[ $k ] : array();
		$h = isset( $x['h'] ) ? (string) $x['h'] : 'normal';
		if ( ! in_array( $h, array( 'yavas', 'normal', 'hizli' ), true ) ) {
			return sides_anim_hata( 'Geçersiz hız değeri.' );
		}
		$o = array( 'a' => isset( $x['a'] ) ? (bool) $x['a'] : ( 'dekor' !== $k ), 'h' => $h );
		if ( 'bildirim' === $k ) {
			$sure = isset( $x['sure'] ) ? (int) $x['sure'] : 4;
			if ( $sure < 3 || $sure > 5 ) {
				return sides_anim_hata( 'Bildirim süresi 3 ile 5 saniye arasında olmalı.' );
			}
			$o['sure'] = $sure;
			$o['hata'] = ( isset( $x['hata'] ) && 'kapat' === $x['hata'] ) ? 'kapat' : 'uzun';
		}
		if ( 'dekor' === $k ) {
			$o['tur'] = ( isset( $x['tur'] ) && in_array( $x['tur'], array( 'yaprak', 'geometrik' ), true ) ) ? $x['tur'] : 'cicek';
		}
		$out['g'][ $k ] = $o;
	}
	$tv        = isset( $a['tv'] ) && is_array( $a['tv'] ) ? $a['tv'] : array();
	$out['tv'] = array();
	foreach ( SIDES_HAYVANLAR as $hk ) {
		$x = isset( $tv[ $hk ] ) && is_array( $tv[ $hk ] ) ? $tv[ $hk ] : array();
		if ( 'tavsan' === $hk && isset( $tv['tavsan'] ) && ! is_array( $tv['tavsan'] ) ) {   // 5.6.0 biçimi
			$x = array( 'a' => ! empty( $tv['tavsan'] ), 'h' => isset( $tv['h'] ) ? $tv['h'] : 'normal', 'sik' => isset( $tv['sik'] ) ? $tv['sik'] : 5 );
		}
		$h = isset( $x['h'] ) ? (string) $x['h'] : 'normal';
		$s = isset( $x['sik'] ) ? (int) $x['sik'] : 5;
		if ( ! in_array( $h, array( 'yavas', 'normal', 'hizli' ), true ) || ! in_array( $s, array( 1, 3, 5, 10, 15 ), true ) ) {
			return sides_anim_hata( 'Geçersiz hayvan ayarı.' );
		}
		$out['tv'][ $hk ] = array( 'a' => ! empty( $x['a'] ), 'h' => $h, 'sik' => $s );
		if ( 'tavsan' === $hk ) {   // eski kayıtlarda yoksa karışık
			$c  = isset( $x['cins'] ) ? $x['cins'] : 'karisik';
			$sh = isset( $x['sahne'] ) ? $x['sahne'] : 'karisik';
			if ( ! is_string( $c ) || ! is_string( $sh ) || ! in_array( $c, SIDES_TAV_CINS, true ) || ! in_array( $sh, SIDES_TAV_SAHNE, true ) ) {
				return sides_anim_hata( 'Geçersiz tavşan cinsi ya da sahnesi.' );
			}
			$out['tv'][ $hk ]['cins']  = $c;
			$out['tv'][ $hk ]['sahne'] = $sh;
		}
		if ( 'araba' === $hk ) {   /* v7.9 */
			$sn = isset( $x['senaryo'] ) ? $x['senaryo'] : 'karisik';
			if ( ! is_string( $sn ) || ! in_array( $sn, SIDES_ARABA_SENARYO, true ) ) {
				return sides_anim_hata( 'Geçersiz araba senaryosu.' );
			}
			$out['tv'][ $hk ]['senaryo'] = $sn;
		}
	}
	return $out;
}

/* v7.9.21 Açılış ekranı: kurumun seçtiği şablon; kişisel "hareketi azalt", kurumda animasyonlar kapalı ya da hareketsiz erişim → yok */
function sides_anim_acilis( $org, $uid ) {
	if ( $uid && 'az' === sides_anim_kisisel( $uid )['hareket'] ) {
		return 'yok';
	}
	$doc = $org ? sides_get_doc( (int) $org, 'animasyon', 'kurum' ) : null;
	if ( $doc && ( ! empty( $doc['kapali'] ) || ( isset( $doc['sablon'] ) && 'hareketsiz' === $doc['sablon'] ) ) ) {
		return 'yok';
	}
	$s = $doc && isset( $doc['acilis'] ) && in_array( $doc['acilis'], SIDES_ACILIS, true ) ? $doc['acilis'] : 'cizgi';
	if ( 'karisik' === $s ) {
		$L = array_slice( SIDES_ACILIS, 0, 8 );
		$s = $L[ array_rand( $L ) ];
	}
	return $s;
}
/* Perde işaretlemesi (src/animasyon.js acilisPerdeHTML ile aynı yapı) */
function sides_acilis_perde( $mark, $s ) {
	$h = '';
	foreach ( array( 'A', 'T', 'L', 'A', 'S' ) as $i => $c ) {
		$h .= '<span style="--i:' . $i . '">' . $c . '</span>';
	}
	return '<div id="acilisPerde" class="ap" data-s="' . esc_attr( $s ) . '" aria-hidden="true"><div class="ap-ic"><div class="ap-logo">'
		. '<svg class="ap-rota" viewBox="0 0 260 150" preserveAspectRatio="none"><path d="M4 146 C 48 150 64 104 104 108 S 160 70 186 56 S 236 18 258 4"/></svg>'
		. '<span class="ap-halka"></span><span class="ap-dalga"><i></i><i></i><i></i></span>'
		. '<img class="ap-mark" src="' . esc_url( $mark ) . '" alt="" width="112" height="112"></div>'
		. '<div class="ap-ad">' . $h . '</div><div class="ap-alt">Gelişiminin haritasını keşfet.</div><div class="ap-cizgi"></div></div></div>';
}

/* İstemciye giden şema (sınırlar uygulanmış) */
function sides_anim_sema() {
	$o = array();
	foreach ( array_keys( SIDES_ANIM_36 ) as $k ) {
		$o[ $k ] = sides_anim_satir( $k );
	}
	return $o;
}

/* TV panosunun geçiş profili: kurum kapatmışsa ya da A36 seçiliyse hareket yok (hz: hayvanlar da gizlenir) */
function sides_anim_tv_gecis( $org ) {
	$d  = sides_get_doc( (int) $org, 'animasyon', 'kurum' );
	$d  = is_array( $d ) ? $d : array();
	$s  = isset( $d['sablon'] ) && sides_anim_yerde( $d['sablon'], 'sablon' ) ? $d['sablon'] : 'yumusak';
	$sx = isset( $d['secim'] ) && is_array( $d['secim'] ) ? $d['secim'] : array();
	$k  = isset( $sx['tv'] ) && sides_anim_yerde( $sx['tv'], 'tv' ) ? $sx['tv'] : SIDES_ANIM_SECIM_VARS['tv'];
	$hz = 'hareketsiz' === $s;
	if ( $hz || ! empty( $d['kapali'] ) ) {
		return array( 'k' => 'yok', 'd' => 0, 'x' => 0, 'y' => 0, 'e' => 0, 'hz' => $hz );
	}
	$r = sides_anim_satir( $k );
	return array( 'k' => $k, 'd' => $r[2], 'x' => $r[4], 'y' => $r[5], 'e' => $r[7], 'hz' => false );
}

/* TV yanıtına (tv.php sides_tv_oku; "degismedi" yanıtı dahil) geçiş profili eklenir; tv.js tvCek bunu animTvGecis'e verir.
   Böylece yalnız geçiş değiştiğinde de pano yeni profili hemen alır (tv.php'nin sürüm denetimi animasyon belgesini zaten izler). */
add_filter( 'rest_post_dispatch', 'sides_anim_tv_yanit', 10, 3 );
function sides_anim_tv_yanit( $res, $server, $req ) {
	if ( ! ( $res instanceof WP_REST_Response ) || ! ( $req instanceof WP_REST_Request ) || 'GET' !== $req->get_method() || 200 !== $res->get_status() ) {
		return $res;
	}
	if ( ! preg_match( '#^/optik-karne/v1/tv/([a-f0-9]{32})$#', (string) $req->get_route(), $m ) || ! function_exists( 'sides_tv_bul' ) ) {
		return $res;
	}
	$data = $res->get_data();
	if ( ! is_array( $data ) || ! empty( $data['bekleme'] ) ) {
		return $res;
	}
	$org = sides_tv_bul( $m[1] );
	if ( $org ) {
		$data['anGecis'] = sides_anim_tv_gecis( $org );
		$res->set_data( $data );
	}
	return $res;
}

function sides_anim_kisisel( $uid ) {
	$h = (string) get_user_meta( $uid, 'sides_animasyon', true );
	return array( 'hareket' => 'az' === $h ? 'az' : 'kurum' );
}

function sides_rest_anim_get() {
	$c   = sides_ctx();
	$doc = sides_get_doc( (int) $c['org'], 'animasyon', 'kurum' );
	if ( $doc ) {
		unset( $doc['id'], $doc['token'] );
	}
	return array(
		'kurum'     => $doc ? $doc : null,
		'kisisel'   => sides_anim_kisisel( get_current_user_id() ),
		'yazabilir' => 'yonetici' === $c['rol'] && empty( $c['onizleme'] ),
		'sema'      => sides_anim_sema(),
		'sinir'     => SIDES_ANIM_SINIR,
	);
}

function sides_rest_anim_kurum( WP_REST_Request $req ) {
	$p = $req->get_json_params();
	$a = sides_anim_temizle( is_array( $p ) && isset( $p['ayar'] ) ? $p['ayar'] : null );
	if ( is_wp_error( $a ) ) {
		return $a;
	}
	$org      = sides_org_id();
	$a['t']   = time();
	$a['by']  = wp_get_current_user()->display_name;
	if ( false === sides_put_doc( $org, 'animasyon', 'kurum', $a ) ) {
		return new WP_Error( 'sides_db', 'Ayar veritabanına yazılamadı.', array( 'status' => 500 ) );
	}
	sides_log( $org, 'Site animasyonları güncellendi (' . SIDES_ANIM_36[ $a['sablon'] ][0] . ' ' . $a['sablon'] . '; menü ' . $a['secim']['menu'] . ', bildirim ' . $a['secim']['bildirim'] . ', yükleme ' . $a['secim']['yukleme'] . ', TV ' . $a['secim']['tv'] . ', açılış ekranı ' . $a['acilis'] . ')' );
	return array( 'kurum' => $a );
}

function sides_rest_anim_kisisel( WP_REST_Request $req ) {
	$p = $req->get_json_params();
	$h = is_array( $p ) && isset( $p['hareket'] ) ? (string) $p['hareket'] : '';
	if ( ! in_array( $h, array( 'kurum', 'az' ), true ) ) {
		return sides_anim_hata( 'Geçersiz hareket tercihi.' );
	}
	update_user_meta( get_current_user_id(), 'sides_animasyon', $h );
	return array( 'kisisel' => sides_anim_kisisel( get_current_user_id() ) );
}

/* ---------------- Soru havuzu paylaşımı ---------------- */

/* Paylaşımı açık ve etkin (askıda/süresi dolmuş olmayan) kurumlar; $haric hariç */
function sides_havuz_paylasan_orglar( $haric = 0 ) {
	global $wpdb;
	static $c = array();
	if ( isset( $c[ $haric ] ) ) {
		return $c[ $haric ];
	}
	$t    = sides_docs();
	$ids  = $wpdb->get_col( $wpdb->prepare( "SELECT org FROM $t WHERE coll = 'havuzpay' AND id = 'main' AND org > 0 AND org <> %d AND data LIKE %s", (int) $haric, '%"acik":true%' ) ); // phpcs:ignore
	$out  = array();
	foreach ( $ids as $id ) {
		$o = sides_org( (int) $id );
		if ( $o && '' === sides_org_blok( $o ) ) {
			$out[ (int) $id ] = (string) $o->ad;
		}
	}
	return $c[ $haric ] = $out;
}

function sides_havuz_pay_durum( $org ) {
	global $wpdb;
	$t   = sides_docs();
	$d   = sides_get_doc( $org, 'havuzpay', 'main' );
	$c   = sides_ctx();
	$n   = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE org = %d AND coll = 'havuz' AND data NOT LIKE %s", $org, '%"ozel":true%' ) ); // phpcs:ignore
	$po  = sides_havuz_paylasan_orglar( $org );
	$on  = 0;
	if ( $po ) {
		$in = implode( ',', array_map( 'intval', array_keys( $po ) ) );
		$on = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE coll = 'havuz' AND org IN ($in) AND data NOT LIKE %s", '%"ozel":true%' ) ); // phpcs:ignore
	}
	return array(
		'acik'       => $d ? ! empty( $d['acik'] ) : false,
		't'          => $d && isset( $d['t'] ) ? (int) $d['t'] : 0,
		'by'         => $d && isset( $d['by'] ) ? (string) $d['by'] : '',
		'paylasilan' => $n,
		'ortak'      => $on,
		'kurumlar'   => count( $po ),
		'yazabilir'  => sides_havuz_pay_yetkili(),
	);
}

function sides_havuz_pay_yetkili() {
	$c = sides_ctx();
	return ! empty( $c['org'] ) && empty( $c['onizleme'] ) && ( 'yonetici' === $c['rol'] || sides_is_super() ) && ! sides_is_observer() && sides_can( 'havuz', 2 );
}

function sides_rest_havuz_pay_get() {
	return sides_havuz_pay_durum( sides_org_id() );
}

function sides_rest_havuz_pay_post( WP_REST_Request $req ) {
	$p = $req->get_json_params();
	if ( ! is_array( $p ) || ! isset( $p['acik'] ) || ! is_bool( $p['acik'] ) ) {
		return sides_anim_hata( 'Paylaşım değeri açık veya kapalı olmalı.' );
	}
	$org = sides_org_id();
	$d   = array( 'acik' => $p['acik'], 't' => time(), 'by' => wp_get_current_user()->display_name );
	if ( false === sides_put_doc( $org, 'havuzpay', 'main', $d ) ) {
		return new WP_Error( 'sides_db', 'Paylaşım ayarı veritabanına yazılamadı.', array( 'status' => 500 ) );
	}
	sides_log( $org, $p['acik'] ? 'Soru havuzu tüm kurumlarla paylaşıldı' : 'Soru havuzu paylaşımı kapatıldı' );
	return sides_havuz_pay_durum( $org );
}

/* /havuz listesine eklenen ortak (başka kurumun paylaştığı) sorular: salt okunur, ekleyen bilgisi gizli */
function sides_havuz_ortak( $org ) {
	global $wpdb;
	$po = sides_havuz_paylasan_orglar( $org );
	if ( ! $po ) {
		return array();
	}
	$t   = sides_docs();
	$in  = implode( ',', array_map( 'intval', array_keys( $po ) ) );
	$out = array();
	foreach ( (array) $wpdb->get_results( "SELECT org, coll, id, token, data FROM $t WHERE coll = 'havuz' AND org IN ($in) ORDER BY org, id" ) as $r ) { // phpcs:ignore
		$o = sides_row_out( $r );
		if ( ! empty( $o['ozel'] ) ) {
			continue;
		}
		unset( $o['ekleyen'], $o['token'] );
		$o['genel']       = false;
		$o['ortak']       = true;
		$o['kaynakKurum'] = $po[ (int) $r->org ];
		$out[]            = $o;
	}
	return $out;
}

/* Soru kendi kurumda yok ama başka bir kurumun havuzunda varsa: değiştirme/silme yetkisi kendiliğinden oluşmaz */
function sides_havuz_yabanci( $org, $id ) {
	global $wpdb;
	if ( sides_get_doc( $org, 'havuz', $id ) ) {
		return false;
	}
	$t = sides_docs();
	return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE coll = 'havuz' AND id = %s AND org NOT IN (%d, 0)", $id, $org ) ) > 0; // phpcs:ignore
}

/* Kendi kurumunda/genelde olmayan bir görselin kaynak kurumu; erişim yoksa 0.
   Erişim: kaynak kurum paylaşıyor ve görsel paylaşılan bir soruda geçiyor, ya da görsel bu kurumun test/deneme/havuz
   belgelerinde (daha önce alınmış kopya) geçiyor. */
function sides_gorsel_ortak_org( $id, $org ) {
	global $wpdb;
	$t   = sides_docs();
	$src = (int) $wpdb->get_var( $wpdb->prepare( "SELECT org FROM $t WHERE coll = 'gorsel' AND id = %s LIMIT 1", $id ) ); // phpcs:ignore
	if ( ! $src || $src === (int) $org ) {
		return 0;
	}
	$like = '%' . $wpdb->esc_like( $id ) . '%';
	if ( (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE org = %d AND coll IN ('testler','exams','havuz') AND data LIKE %s", $org, $like ) ) ) { // phpcs:ignore
		return $src;
	}
	if ( isset( sides_havuz_paylasan_orglar( $org )[ $src ] ) && (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE org = %d AND coll = 'havuz' AND data LIKE %s AND data NOT LIKE %s", $src, $like, '%"ozel":true%' ) ) ) { // phpcs:ignore
		return $src;
	}
	return 0;
}

add_action( 'rest_api_init', function () {
	$ns    = 'optik-karne/v1';
	$panel = function () {
		return sides_is_panel() ? true : sides_deny( 'Oturum açmanız gerekiyor.' );
	};
	register_rest_route( $ns, '/animasyon', array( 'methods' => 'GET', 'callback' => 'sides_rest_anim_get', 'permission_callback' => $panel ) );
	register_rest_route( $ns, '/animasyon/kurum', array( 'methods' => 'POST', 'callback' => 'sides_rest_anim_kurum', 'permission_callback' => function () {
		$c = sides_ctx();
		if ( ! empty( $c['onizleme'] ) ) {
			return sides_deny( 'Önizleme modunda değişiklik yapılamaz.' );
		}
		return 'yonetici' === $c['rol'] ? true : sides_deny( 'Kurumun animasyon ayarını yalnızca kurum yöneticisi değiştirebilir.' );
	} ) );
	register_rest_route( $ns, '/animasyon/kisisel', array( 'methods' => 'POST', 'callback' => 'sides_rest_anim_kisisel', 'permission_callback' => function () {
		$c = sides_ctx();
		return ( sides_is_panel() && empty( $c['onizleme'] ) ) ? true : sides_deny( 'Oturum açmanız gerekiyor.' );
	} ) );
	register_rest_route( $ns, '/havuz/paylasim', array(
		array( 'methods' => 'GET', 'callback' => 'sides_rest_havuz_pay_get', 'permission_callback' => function () {
			return ( sides_is_panel() && ( sides_can( 'havuz', 1 ) || sides_can( 'test', 1 ) ) ) ? true : sides_deny();
		} ),
		array( 'methods' => 'POST', 'callback' => 'sides_rest_havuz_pay_post', 'permission_callback' => function () {
			return sides_havuz_pay_yetkili() ? true : sides_deny( 'Soru havuzu paylaşımını yalnızca Soru Havuzu yazma yetkisi olan kurum yöneticisi değiştirebilir.' );
		} ),
	) );
} );
