<?php
/**
 * ATLAS v5.3 — Sistem Yönetimi › Site Trafiği ve Kaynak Kullanımı.
 *
 * Ölçümler {prefix}sides_trafik tablosunda günlük toplu sayaç olarak tutulur: (org, gun, anahtar) → deger.
 * Kişisel veri olarak yalnızca kullanıcı kimliği ve rolü saklanır (tekil kullanıcı sayımı için). İstek gövdesi, IP,
 * tarayıcı parmak izi, öğrenci adı, token ve sorgu parametresi kaydedilmez.
 *   v|rol|rota      ekran (rota) görüntüleme             h|rol|SS        saate göre görüntüleme
 *   u|rol|uid       kullanıcının günlük görüntülemesi (ham veri; ayrı saklama süresi)
 *   o|rol|cihaz     başlayan oturum (30 dk etkileşimsizlik oturumu bitirir)   s|rol   oturum içi etkin süre (sn)
 *   q|sinif|grup    API isteği    e4|… / e5|…  4xx / 5xx yanıt    y|sinif  1 sn'den yavaş    d|sinif|kova  süre dağılımı
 *   qh|sinif|SS     saate göre istek     z|kategori  depolama anlık görüntüsü (bayt; toplanmaz, üzerine yazılır)   x|red  reddedilen olay
 * İstek sınıfları: panel (giriş yapmış kullanıcı işlemleri), senk (arka plan eşitleme: /all, /results, /oturum),
 * olcum (bu panelin ölçüm paketleri), tv (TV panosu yenilemeleri), acik (bağlantıyla açılan herkese açık sayfalar), bot, test (önizleme).
 *
 * REST (optik-karne/v1): POST trafik/iz · GET trafik/ozet · GET trafik/kaynak · GET|POST trafik/ayar
 *
 * @package SIDES
 */

defined( 'ABSPATH' ) || exit;

define( 'SIDES_TRF_DB', '1' );
define( 'SIDES_TRF_KOVA', array( 10, 20, 30, 50, 75, 100, 150, 200, 300, 500, 750, 1000, 1500, 2000, 3000, 5000, 10000 ) );
define( 'SIDES_TRF_ROLLER', array( 'yonetici', 'personel', 'gozlemci', 'ogretmen', 'ana' ) );
define( 'SIDES_TRF_SINIF', array( 'panel', 'senk', 'olcum', 'tv', 'acik', 'bot', 'test' ) );
define( 'SIDES_TRF_CIHAZ', array( 'mobil', 'tablet', 'masaustu' ) );
define( 'SIDES_TRF_ROTA', '/^[a-z][a-z0-9]{0,23}(\.[a-z0-9]{1,24}){0,2}$/' );

function sides_trafik_tablo() {
	global $wpdb;
	return $wpdb->prefix . 'sides_trafik';
}
/* Site saat dilimi UTC bırakılmışsa ATLAS varsayılanı (Europe/Istanbul) kullanılır */
function sides_trafik_tz() {
	$tz = wp_timezone();
	return in_array( $tz->getName(), array( 'UTC', '+00:00' ), true ) ? new DateTimeZone( 'Europe/Istanbul' ) : $tz;
}
function sides_trafik_an( $ts = null ) {
	$d = new DateTime( '@' . ( null === $ts ? time() : (int) $ts ) );
	$d->setTimezone( sides_trafik_tz() );
	return $d;
}
function sides_trafik_gun( $ts = null ) {
	return sides_trafik_an( $ts )->format( 'Y-m-d' );
}
function sides_trafik_gun_ekle( $gun, $n ) {
	$d = new DateTime( $gun . ' 12:00:00', sides_trafik_tz() );
	$d->modify( ( $n >= 0 ? '+' : '' ) . (int) $n . ' day' );
	return $d->format( 'Y-m-d' );
}

/* ------------------------------------------------------------------ *
 * Kurulum, ayarlar
 * ------------------------------------------------------------------ */
add_action( 'plugins_loaded', function () {
	if ( get_option( 'sides_trafik_db' ) !== SIDES_TRF_DB ) {
		sides_trafik_kur();
	}
}, 20 );
function sides_trafik_kur() {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$t = sides_trafik_tablo();
	dbDelta( "CREATE TABLE $t (
  org bigint(20) unsigned NOT NULL DEFAULT 0,
  gun date NOT NULL,
  anahtar varchar(64) NOT NULL,
  deger bigint(20) NOT NULL DEFAULT 0,
  PRIMARY KEY  (org,gun,anahtar),
  KEY gun (gun)
) " . $wpdb->get_charset_collate() . ';' );
	if ( ! get_option( 'sides_trafik_bas' ) ) {
		update_option( 'sides_trafik_bas', sides_trafik_gun(), false );
	}
	update_option( 'sides_trafik_db', SIDES_TRF_DB );
}

function sides_trafik_varsayilan() {
	return array(
		'acik'     => true,
		'saklaGun' => 180,
		'hamGun'   => 90,
		'pencere'  => 5,
		'anaDahil' => true,
		'bolumler' => array( 'trafik' => true, 'yogunluk' => true, 'istek' => true, 'depolama' => true, 'saglik' => true, 'uyari' => true ),
		'uyari'    => array(
			'depolama' => array( 'acik' => true, 'uyariYuzde' => 80, 'kritikYuzde' => 95, 'uyariMb' => 1024, 'kritikMb' => 2048 ),
			'hata'     => array( 'acik' => true, 'yuzde' => 5, 'gun' => 1, 'enAz' => 50 ),
			'yavas'    => array( 'acik' => true, 'yuzde' => 10, 'gun' => 1, 'enAz' => 50 ),
			'yedek'    => array( 'acik' => true, 'gun' => 2 ),
			'ai'       => array( 'acik' => true, 'yuzde' => 90 ),
		),
		'eposta'   => '',
		'kapali'   => array(),
	);
}
function sides_trafik_ayar( $org ) {
	$tum = get_option( 'sides_trafik_ayar' );
	$a   = is_array( $tum ) && isset( $tum[ (int) $org ] ) && is_array( $tum[ (int) $org ] ) ? $tum[ (int) $org ] : array();
	$v   = sides_trafik_varsayilan();
	foreach ( $v as $k => $d ) {
		if ( ! isset( $a[ $k ] ) ) {
			$a[ $k ] = $d;
		} elseif ( is_array( $d ) && 'kapali' !== $k ) {
			foreach ( $d as $k2 => $d2 ) {
				if ( ! isset( $a[ $k ][ $k2 ] ) ) {
					$a[ $k ][ $k2 ] = $d2;
				} elseif ( is_array( $d2 ) ) {
					$a[ $k ][ $k2 ] = array_merge( $d2, array_intersect_key( (array) $a[ $k ][ $k2 ], $d2 ) );
				}
			}
			$a[ $k ] = array_intersect_key( $a[ $k ], $d );
		}
	}
	return array_intersect_key( $a, $v );
}
function sides_trafik_olcuyor( $org ) {
	static $c = array();
	if ( ! isset( $c[ $org ] ) ) {
		$tum       = get_option( 'sides_trafik_ayar' );
		$c[ $org ] = ! ( is_array( $tum ) && isset( $tum[ $org ]['acik'] ) && ! $tum[ $org ]['acik'] );
	}
	return $c[ $org ] && get_option( 'sides_trafik_db' ) === SIDES_TRF_DB;
}
function sides_trafik_kota( $org ) {
	$k = get_option( 'sides_trafik_kota' );
	return is_array( $k ) && ! empty( $k[ (int) $org ] ) ? (int) $k[ (int) $org ] : 0;
}

/* Tabloya toplu yazım: tek sorguda çok satır; $yaz = true ise değer toplanmaz, üzerine yazılır (anlık görüntü) */
function sides_trafik_ekle( $org, $gun, $kv, $yaz = false ) {
	global $wpdb;
	if ( ! $kv || get_option( 'sides_trafik_db' ) !== SIDES_TRF_DB ) {
		return;
	}
	$t = sides_trafik_tablo();
	$v = array();
	$p = array();
	foreach ( $kv as $k => $n ) {
		$v[] = '(%d,%s,%s,%d)';
		array_push( $p, (int) $org, $gun, substr( (string) $k, 0, 64 ), (int) $n );
	}
	$eski = $wpdb->suppress_errors( true );
	$wpdb->query( $wpdb->prepare( "INSERT INTO $t (org,gun,anahtar,deger) VALUES " . implode( ',', $v ) . ' ON DUPLICATE KEY UPDATE deger = ' . ( $yaz ? 'VALUES(deger)' : 'deger + VALUES(deger)' ), $p ) ); // phpcs:ignore
	$wpdb->suppress_errors( $eski );
}
function sides_trafik_art( &$kv, $k, $n = 1 ) {
	$kv[ $k ] = ( isset( $kv[ $k ] ) ? $kv[ $k ] : 0 ) + $n;
}

/* ------------------------------------------------------------------ *
 * Sunucu tarafı istek sayımı (yalnızca optik-karne/v1; tek sorgu)
 * ------------------------------------------------------------------ */
add_filter( 'rest_post_dispatch', 'sides_trafik_istek_say', 999, 3 );
function sides_trafik_istek_say( $res, $server, $req ) {
	$route = $req->get_route();
	if ( 0 !== strpos( $route, '/optik-karne/v1/' ) ) {
		return $res;
	}
	try {
		$ms     = isset( $_SERVER['REQUEST_TIME_FLOAT'] ) ? ( microtime( true ) - (float) $_SERVER['REQUEST_TIME_FLOAT'] ) * 1000 : 0;
		$status = $res instanceof WP_HTTP_Response ? (int) $res->get_status() : 200;
		$rest   = substr( $route, 16 );
		$grup   = strtolower( (string) strtok( $rest, '/' ) );
		$grup   = preg_match( '/^[a-z0-9\-]{1,16}$/', $grup ) ? $grup : 'diger';
		$c      = sides_ctx();
		$org    = (int) $c['org'];
		if ( sides_onizleme_istek() ) {
			$sinif = 'test';
		} elseif ( 0 === strpos( $rest, 'trafik/iz' ) ) {
			$sinif = 'olcum';
		} elseif ( 'tv' === $grup && preg_match( '#^tv/[a-f0-9]{32}#', $rest ) ) {
			$sinif = 'tv';
		} elseif ( $org ) {
			$sinif = in_array( $grup, array( 'all', 'results', 'oturum' ), true ) && 'GET' === $req->get_method() ? 'senk' : 'panel';
		} else {
			$ua    = isset( $_SERVER['HTTP_USER_AGENT'] ) ? (string) $_SERVER['HTTP_USER_AGENT'] : '';
			$sinif = '' === $ua || preg_match( '/bot|crawl|spider|slurp|facebookexternalhit|preview|curl|wget|python-requests|monitor/i', $ua ) ? 'bot' : 'acik';
		}
		if ( ! $org ) {
			$org = sides_trafik_token_org( $req );
		}
		if ( ! sides_trafik_olcuyor( $org ) ) {
			return $res;
		}
		$an = sides_trafik_an();
		$kb = count( SIDES_TRF_KOVA );
		foreach ( SIDES_TRF_KOVA as $i => $s ) {
			if ( $ms <= $s ) {
				$kb = $i;
				break;
			}
		}
		$kv = array( "q|$sinif|$grup" => 1, "qh|$sinif|" . $an->format( 'H' ) => 1, "d|$sinif|$kb" => 1 );
		if ( $status >= 500 ) {
			$kv[ "e5|$sinif|$grup" ] = 1;
		} elseif ( $status >= 400 ) {
			$kv[ "e4|$sinif|$grup" ] = 1;
		}
		if ( $ms > 1000 ) {
			$kv[ "y|$sinif" ] = 1;
		}
		sides_trafik_ekle( $org, $an->format( 'Y-m-d' ), $kv );
	} catch ( Throwable $e ) { // ölçüm hatası isteği asla bozmaz
		unset( $e );
	}
	return $res;
}
/* Herkese açık bağlantılarda kurum, token sütunundan bulunur (dizinli tek sorgu); bulunamazsa site geneli (0) */
function sides_trafik_token_org( $req ) {
	global $wpdb;
	$tok = (string) $req->get_param( 'token' );
	if ( ! preg_match( '/^[a-f0-9]{32}$/', $tok ) ) {
		$tok = (string) $req->get_param( 't' );
	}
	if ( ! preg_match( '/^[a-f0-9]{32}$/', $tok ) ) {
		return 0;
	}
	$t = sides_docs();
	return (int) $wpdb->get_var( $wpdb->prepare( "SELECT org FROM $t WHERE token = %s LIMIT 1", $tok ) ); // phpcs:ignore
}

/* E-posta gönderiminin son durumu (yalnızca zaman ve başarı; alıcı ve içerik tutulmaz) */
add_action( 'wp_mail_succeeded', function () {
	update_option( 'sides_trafik_eposta', array( 't' => time(), 'ok' => 1 ), false );
} );
add_action( 'wp_mail_failed', function ( $e ) {
	update_option( 'sides_trafik_eposta', array( 't' => time(), 'ok' => 0, 'm' => is_wp_error( $e ) ? mb_substr( $e->get_error_message(), 0, 120 ) : '' ), false );
} );

/* ------------------------------------------------------------------ *
 * Zamanlanmış iş: saatlik; günde bir kez eski ölçümleri siler, uyarıları parça parça (20 kurum) denetler
 * ------------------------------------------------------------------ */
add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'sides_trafik_saatlik' ) ) {
		wp_schedule_event( time() + 300, 'hourly', 'sides_trafik_saatlik' );
	}
} );
register_deactivation_hook( OPTIK_KARNE_FILE, function () {
	wp_clear_scheduled_hook( 'sides_trafik_saatlik' );
} );
add_action( 'sides_trafik_saatlik', 'sides_trafik_zamanli' );
function sides_trafik_zamanli() {
	global $wpdb;
	$t = sides_trafik_tablo();
	if ( get_option( 'sides_trafik_db' ) !== SIDES_TRF_DB ) {
		return;
	}
	$bugun = sides_trafik_gun();
	if ( get_option( 'sides_trafik_temizlik' ) !== $bugun ) {
		sides_trafik_temizle();
		update_option( 'sides_trafik_temizlik', $bugun, false );
	}
	$orgs = $wpdb->get_col( 'SELECT id FROM ' . sides_orgs() . " WHERE durum = 'aktif' ORDER BY id" ); // phpcs:ignore
	$bas  = (int) get_option( 'sides_trafik_cron_sira', 0 );
	$parca = array_slice( $orgs, $bas, 20 );
	foreach ( $parca as $o ) {
		$k = sides_trafik_depolama( (int) $o, false );
		sides_trafik_uyari_denetle( (int) $o, $k );
	}
	update_option( 'sides_trafik_cron_sira', $bas + 20 >= count( $orgs ) ? 0 : $bas + 20, false );
	update_option( 'sides_trafik_cron', time(), false );
	unset( $t );
}
/* Saklama: yalnızca ölçüm tablosu silinir; öğrenci ve çalışma kayıtları etkilenmez */
function sides_trafik_temizle() {
	global $wpdb;
	$t     = sides_trafik_tablo();
	$bugun = sides_trafik_gun();
	$n     = 0;
	foreach ( $wpdb->get_col( "SELECT DISTINCT org FROM $t" ) as $org ) { // phpcs:ignore
		$a  = sides_trafik_ayar( (int) $org );
		$n += (int) $wpdb->query( $wpdb->prepare( "DELETE FROM $t WHERE org = %d AND gun < %s", $org, sides_trafik_gun_ekle( $bugun, -$a['saklaGun'] + 1 ) ) ); // phpcs:ignore
		$n += (int) $wpdb->query( $wpdb->prepare( "DELETE FROM $t WHERE org = %d AND gun < %s AND anahtar LIKE %s", $org, sides_trafik_gun_ekle( $bugun, -$a['hamGun'] + 1 ), 'u|%' ) ); // phpcs:ignore
	}
	return $n;
}

/* ------------------------------------------------------------------ *
 * Yetki
 * ------------------------------------------------------------------ */
function sides_trafik_super() {
	return sides_is_super() && ! sides_onizleme_istek();
}
function sides_trafik_yetkili() {
	if ( sides_trafik_super() ) {
		return true;
	}
	$c = sides_ctx();
	return $c['org'] && 'yonetici' === $c['rol'] && empty( $c['blok'] ) && isset( $c['yetki']['sistem'] ) && $c['yetki']['sistem'] >= 2;
}
/* İstenen kapsam: kurum yöneticisi daima kendi kurumu; ana hesap herhangi bir kurum ya da 0 (tüm site) */
function sides_trafik_kapsam( WP_REST_Request $req ) {
	$own = sides_org_id();
	if ( ! sides_trafik_super() ) {
		return $own;
	}
	$o = $req->get_param( 'org' );
	if ( null === $o || '' === $o ) {
		return $own;
	}
	return max( 0, (int) $o );
}

add_action( 'rest_api_init', function () {
	$ns   = 'optik-karne/v1';
	$yetk = function () {
		return sides_trafik_yetkili() ? true : sides_deny( 'Site trafiği ve kaynak kullanımı yalnızca kurum yöneticisine açıktır.' );
	};
	register_rest_route( $ns, '/trafik/iz', array( 'methods' => 'POST', 'callback' => 'sides_trafik_iz', 'permission_callback' => function () {
		if ( sides_onizleme_istek() ) {
			return sides_deny( 'Önizlemede ölçüm yapılmaz.' );
		}
		$c = sides_ctx();
		return $c['org'] && $c['rol'] ? true : new WP_Error( 'rest_not_logged_in', 'Giriş yapılmamış.', array( 'status' => 401 ) );
	} ) );
	register_rest_route( $ns, '/trafik/ozet', array( 'methods' => 'GET', 'callback' => 'sides_trafik_ozet', 'permission_callback' => $yetk ) );
	register_rest_route( $ns, '/trafik/kaynak', array( 'methods' => 'GET', 'callback' => 'sides_trafik_kaynak', 'permission_callback' => $yetk ) );
	register_rest_route( $ns, '/trafik/ayar', array(
		array( 'methods' => 'GET', 'callback' => 'sides_trafik_ayar_oku', 'permission_callback' => $yetk ),
		array( 'methods' => 'POST', 'callback' => 'sides_trafik_ayar_kaydet', 'permission_callback' => $yetk ),
	) );
} );

/* ------------------------------------------------------------------ *
 * POST trafik/iz — istemcinin ölçüm paketi: { islemId, simdi, cihaz, etk, olaylar: [ { r: rota, t: ms } ] }
 * ------------------------------------------------------------------ */
function sides_trafik_iz( WP_REST_Request $req ) {
	$c   = sides_ctx();
	$org = (int) $c['org'];
	$uid = (int) $c['uid'];
	if ( ! sides_rl( 'trafik_iz_' . $uid, 30, 60 ) ) {
		return new WP_Error( 'sides_trafik', 'Ölçüm paketleri çok sık gönderildi.', array( 'status' => 429 ) );
	}
	$p = json_decode( (string) $req->get_body(), true );
	if ( ! is_array( $p ) ) {
		return new WP_Error( 'sides_trafik', 'Ölçüm paketi okunamadı.', array( 'status' => 400 ) );
	}
	if ( ! sides_trafik_olcuyor( $org ) ) {
		return array( 'ok' => true, 'sayilan' => 0, 'kapali' => true );
	}
	$islem = isset( $p['islemId'] ) ? (string) $p['islemId'] : '';
	if ( $islem ) {
		if ( ! preg_match( '/^[a-z0-9]{4,40}$/', $islem ) ) {
			return new WP_Error( 'sides_trafik', 'Geçersiz paket kimliği.', array( 'status' => 400 ) );
		}
		$gorulen = get_transient( 'sides_trf_p_' . $uid );
		$gorulen = is_array( $gorulen ) ? $gorulen : array();
		if ( in_array( $islem, $gorulen, true ) ) {
			return array( 'ok' => true, 'sayilan' => 0, 'tekrar' => true );
		}
		$gorulen[] = $islem;
		set_transient( 'sides_trf_p_' . $uid, array_slice( $gorulen, -30 ), 900 );
	}
	$olaylar = isset( $p['olaylar'] ) && is_array( $p['olaylar'] ) ? array_values( $p['olaylar'] ) : array();
	$red     = max( 0, count( $olaylar ) - 60 );
	$olaylar = array_slice( $olaylar, 0, 60 );
	$simdi   = isset( $p['simdi'] ) && is_numeric( $p['simdi'] ) ? (float) $p['simdi'] : 0;
	$cihaz   = isset( $p['cihaz'] ) && in_array( $p['cihaz'], SIDES_TRF_CIHAZ, true ) ? $p['cihaz'] : 'masaustu';
	$rol     = user_can( $uid, 'manage_options' ) ? 'ana' : ( in_array( $c['rol'], SIDES_TRF_ROLLER, true ) ? $c['rol'] : 'personel' );
	$now     = time();
	$gunler  = array();
	$n       = 0;
	foreach ( $olaylar as $o ) {
		$r = is_array( $o ) && isset( $o['r'] ) ? (string) $o['r'] : '';
		if ( ! preg_match( SIDES_TRF_ROTA, $r ) ) {
			++$red;
			continue;
		}
		$yas = $simdi && isset( $o['t'] ) && is_numeric( $o['t'] ) ? max( 0, min( 900, ( $simdi - (float) $o['t'] ) / 1000 ) ) : 0;
		$an  = sides_trafik_an( $now - (int) $yas );
		$g   = $an->format( 'Y-m-d' );
		if ( ! isset( $gunler[ $g ] ) ) {
			$gunler[ $g ] = array();
		}
		sides_trafik_art( $gunler[ $g ], "v|$rol|$r" );
		sides_trafik_art( $gunler[ $g ], "h|$rol|" . $an->format( 'H' ) );
		sides_trafik_art( $gunler[ $g ], "u|$rol|$uid" );
		++$n;
	}
	$bugun = sides_trafik_gun( $now );
	if ( $n || ! empty( $p['etk'] ) ) {
		$ak  = get_option( 'sides_trf_aktif_' . $org );
		$ak  = is_array( $ak ) ? $ak : array();
		$son = isset( $ak[ $uid ] ) ? (int) $ak[ $uid ][0] : 0;
		if ( ! isset( $gunler[ $bugun ] ) ) {
			$gunler[ $bugun ] = array();
		}
		if ( ! $son || $now - $son > 1800 || sides_trafik_gun( $son ) !== $bugun ) {
			sides_trafik_art( $gunler[ $bugun ], "o|$rol|$cihaz" );
		} else {
			sides_trafik_art( $gunler[ $bugun ], "s|$rol", $now - $son );
		}
		$ak[ $uid ] = array( $now, $rol );
		foreach ( $ak as $k => $x ) {
			if ( '_son' !== $k && ( ! is_array( $x ) || $now - (int) $x[0] > 7200 ) ) {
				unset( $ak[ $k ] );
			}
		}
		$ak['_son'] = $now;
		update_option( 'sides_trf_aktif_' . $org, $ak, false );
	}
	if ( $red ) {
		if ( ! isset( $gunler[ $bugun ] ) ) {
			$gunler[ $bugun ] = array();
		}
		sides_trafik_art( $gunler[ $bugun ], 'x|red', $red );
	}
	foreach ( $gunler as $g => $kv ) {
		sides_trafik_ekle( $org, $g, $kv );
	}
	return array( 'ok' => true, 'sayilan' => $n, 'red' => $red );
}

/* ------------------------------------------------------------------ *
 * GET trafik/ozet — ?aralik=bugun|7|30|90|ozel&bas&bit&org&ana=0|1&pencere=dk
 * ------------------------------------------------------------------ */
function sides_trafik_aralik( WP_REST_Request $req ) {
	$bugun = sides_trafik_gun();
	$ar    = (string) $req->get_param( 'aralik' );
	$gun   = array( 'bugun' => 1, '7' => 7, '30' => 30, '90' => 90 );
	if ( 'ozel' === $ar ) {
		$bas = (string) $req->get_param( 'bas' );
		$bit = (string) $req->get_param( 'bit' );
		$re  = '/^\d{4}-\d{2}-\d{2}$/';
		if ( ! preg_match( $re, $bas ) || ! preg_match( $re, $bit ) || ! strtotime( $bas ) || ! strtotime( $bit ) ) {
			return new WP_Error( 'sides_trafik', 'Tarih aralığı YYYY-AA-GG biçiminde olmalı.', array( 'status' => 400 ) );
		}
		if ( $bit > $bugun ) {
			$bit = $bugun;
		}
		if ( $bas > $bit ) {
			return new WP_Error( 'sides_trafik', 'Başlangıç tarihi bitişten sonra olamaz.', array( 'status' => 400 ) );
		}
		if ( ( strtotime( $bit ) - strtotime( $bas ) ) / 86400 > 400 ) {
			return new WP_Error( 'sides_trafik', 'En fazla 400 günlük aralık seçilebilir.', array( 'status' => 400 ) );
		}
		return array( $bas, $bit );
	}
	$n = isset( $gun[ $ar ] ) ? $gun[ $ar ] : 7;
	return array( sides_trafik_gun_ekle( $bugun, -$n + 1 ), $bugun );
}
function sides_trafik_kurum_adi( $org ) {
	if ( ! $org ) {
		return 'Tüm site (bütün kurumlar ve herkese açık bağlantılar)';
	}
	$o = sides_org( $org );
	return $o ? $o->ad : 'Kurum ' . $org;
}
function sides_trafik_yuzdelik( $h, $oran ) {
	$top = array_sum( $h );
	if ( ! $top ) {
		return null;
	}
	$hedef = $top * $oran;
	$c     = 0;
	ksort( $h );
	foreach ( $h as $i => $n ) {
		$c += $n;
		if ( $c >= $hedef ) {
			return isset( SIDES_TRF_KOVA[ $i ] ) ? SIDES_TRF_KOVA[ $i ] : -1; // -1: 10 sn üstü
		}
	}
	return -1;
}
function sides_trafik_ozet( WP_REST_Request $req ) {
	global $wpdb;
	$ar = sides_trafik_aralik( $req );
	if ( is_wp_error( $ar ) ) {
		return $ar;
	}
	list( $bas, $bit ) = $ar;
	$org     = sides_trafik_kapsam( $req );
	$tum     = 0 === $org;
	$ayarOrg = $tum ? sides_org_id() : $org;
	$ayar    = sides_trafik_ayar( $ayarOrg );
	$anaP    = $req->get_param( 'ana' );
	$ana     = null === $anaP || '' === $anaP ? (bool) $ayar['anaDahil'] : '1' === (string) $anaP;
	$pencere = max( 1, min( 120, (int) ( $req->get_param( 'pencere' ) ? $req->get_param( 'pencere' ) : $ayar['pencere'] ) ) );
	$t       = sides_trafik_tablo();
	$wOrg    = $tum ? '' : $wpdb->prepare( ' AND org = %d', $org );
	$rows    = $wpdb->get_results( $wpdb->prepare( "SELECT gun, anahtar, SUM(deger) AS n FROM $t WHERE gun BETWEEN %s AND %s AND anahtar NOT LIKE %s$wOrg GROUP BY gun, anahtar", $bas, $bit, 'z|%' ) ); // phpcs:ignore
	$bugun   = sides_trafik_gun();
	$gunler  = array();
	for ( $g = $bas; $g <= $bit; $g = sides_trafik_gun_ekle( $g, 1 ) ) {
		$gunler[ $g ] = array( 'g' => $g, 'gv' => 0, 'tekil' => 0, 'oturum' => 0, 'insan' => 0, 'arka' => 0, 'hata' => 0, 'istek' => 0, '_u' => array() );
	}
	$top    = array( 'gv' => 0, 'oturum' => 0, 'sure' => 0, 'hata4' => 0, 'hata5' => 0, 'red' => 0 );
	$rota   = array();
	$saat   = array_fill( 0, 24, 0 );
	$isaat  = array();
	$cihaz  = array_fill_keys( SIDES_TRF_CIHAZ, 0 );
	$roller = array();
	$ist    = array();
	$dag    = array();
	$yavas  = array();
	$tekil  = array();
	foreach ( $rows as $r ) {
		if ( ! isset( $gunler[ $r->gun ] ) ) {
			continue;
		}
		$G = &$gunler[ $r->gun ];
		$p = explode( '|', $r->anahtar );
		$n = (int) $r->n;
		$k = $p[0];
		if ( in_array( $k, array( 'v', 'h', 'u', 'o', 's' ), true ) && isset( $p[1] ) && 'ana' === $p[1] && ! $ana ) {
			unset( $G );
			continue;
		}
		if ( 'v' === $k && isset( $p[2] ) ) {
			$G['gv']         += $n;
			$top['gv']       += $n;
			$rota[ $p[2] ]    = ( isset( $rota[ $p[2] ] ) ? $rota[ $p[2] ] : 0 ) + $n;
			$roller[ $p[1] ]  = ( isset( $roller[ $p[1] ] ) ? $roller[ $p[1] ] : 0 ) + $n;
		} elseif ( 'h' === $k && isset( $p[2] ) ) {
			$saat[ (int) $p[2] ] += $n;
		} elseif ( 'u' === $k && isset( $p[2] ) ) {
			$G['_u'][ $p[2] ] = 1;
			$tekil[ $p[2] ]   = 1;
		} elseif ( 'o' === $k && isset( $p[2] ) ) {
			$G['oturum']    += $n;
			$top['oturum']  += $n;
			if ( isset( $cihaz[ $p[2] ] ) ) {
				$cihaz[ $p[2] ] += $n;
			}
		} elseif ( 's' === $k ) {
			$top['sure'] += $n;
		} elseif ( 'q' === $k && isset( $p[2] ) ) {
			$key          = $p[1] . '|' . $p[2];
			$ist[ $key ]  = isset( $ist[ $key ] ) ? $ist[ $key ] : array( 'sinif' => $p[1], 'grup' => $p[2], 'n' => 0, 'e4' => 0, 'e5' => 0 );
			$ist[ $key ]['n'] += $n;
			$G['istek']  += $n;
			if ( 'panel' === $p[1] ) {
				$G['insan'] += $n;
			} else {
				$G['arka'] += $n;
			}
		} elseif ( ( 'e4' === $k || 'e5' === $k ) && isset( $p[2] ) ) {
			$key          = $p[1] . '|' . $p[2];
			$ist[ $key ]  = isset( $ist[ $key ] ) ? $ist[ $key ] : array( 'sinif' => $p[1], 'grup' => $p[2], 'n' => 0, 'e4' => 0, 'e5' => 0 );
			$ist[ $key ][ $k ] += $n;
			$top[ 'e4' === $k ? 'hata4' : 'hata5' ] += $n;
			$G['hata'] += $n;
		} elseif ( 'd' === $k && isset( $p[2] ) ) {
			$dag[ $p[1] ][ (int) $p[2] ] = ( isset( $dag[ $p[1] ][ (int) $p[2] ] ) ? $dag[ $p[1] ][ (int) $p[2] ] : 0 ) + $n;
		} elseif ( 'y' === $k && isset( $p[1] ) ) {
			$yavas[ $p[1] ] = ( isset( $yavas[ $p[1] ] ) ? $yavas[ $p[1] ] : 0 ) + $n;
		} elseif ( 'qh' === $k && isset( $p[2] ) ) {
			if ( ! isset( $isaat[ $p[1] ] ) ) {
				$isaat[ $p[1] ] = array_fill( 0, 24, 0 );
			}
			$isaat[ $p[1] ][ (int) $p[2] ] += $n;
		} elseif ( 'x' === $k ) {
			$top['red'] += $n;
		}
		unset( $G );
	}
	// Ölçüm kapsamı: kurulum öncesi, saklama süresini aşan ve ölçümün kapalı olduğu günler "kayıt yok" sayılır
	$olcBas   = (string) get_option( 'sides_trafik_bas', $bugun );
	$saklaBas = sides_trafik_gun_ekle( $bugun, -$ayar['saklaGun'] + 1 );
	$hamBas   = sides_trafik_gun_ekle( $bugun, -$ayar['hamGun'] + 1 );
	$kapali   = $tum ? array() : (array) $ayar['kapali'];
	$out_g    = array();
	foreach ( $gunler as $g => $G ) {
		$neden = '';
		if ( $g < $olcBas ) {
			$neden = 'kurulum';
		} elseif ( $g < $saklaBas ) {
			$neden = 'saklama';
		} else {
			foreach ( $kapali as $ka ) {
				if ( $g >= $ka[0] && ( '' === $ka[1] || $g <= $ka[1] ) && ! $G['gv'] ) {
					$neden = 'kapali';
				}
			}
		}
		$G['tekil'] = $g < $hamBas ? null : count( $G['_u'] );
		unset( $G['_u'] );
		$G['olculdu'] = '' === $neden;
		$G['neden']   = $neden;
		$out_g[]      = $G;
	}
	$sure = array();
	$tumH = array();
	foreach ( $dag as $s => $h ) {
		$sure[ $s ] = array( 'n' => array_sum( $h ), 'p50' => sides_trafik_yuzdelik( $h, 0.5 ), 'p95' => sides_trafik_yuzdelik( $h, 0.95 ), 'yavas' => isset( $yavas[ $s ] ) ? $yavas[ $s ] : 0 );
		if ( in_array( $s, array( 'panel', 'senk' ), true ) ) {
			foreach ( $h as $i => $n ) {
				$tumH[ $i ] = ( isset( $tumH[ $i ] ) ? $tumH[ $i ] : 0 ) + $n;
			}
		}
	}
	arsort( $rota );
	$rotalar = array();
	foreach ( $rota as $r => $n ) {
		$rotalar[] = array( 'r' => $r, 'n' => $n );
	}
	// Şu an aktif: pencere içinde etkileşim gösteren giriş yapmış kullanıcılar (açık sekme ya da istek sayısı değil)
	$simdi = time();
	$aktif = 0;
	$sonT  = 0;
	$akOrg = $tum ? array_map( 'intval', (array) $wpdb->get_col( 'SELECT id FROM ' . sides_orgs() ) ) : array( $org ); // phpcs:ignore
	foreach ( $akOrg as $o ) {
		$ak = get_option( 'sides_trf_aktif_' . $o );
		if ( ! is_array( $ak ) ) {
			continue;
		}
		$sonT = max( $sonT, isset( $ak['_son'] ) ? (int) $ak['_son'] : 0 );
		foreach ( $ak as $u => $x ) {
			if ( '_son' !== $u && is_array( $x ) && $simdi - (int) $x[0] <= $pencere * 60 && ( $ana || 'ana' !== $x[1] ) ) {
				++$aktif;
			}
		}
	}
	$out = array(
		'kapsam'   => array( 'org' => $org, 'tum' => $tum, 'ad' => sides_trafik_kurum_adi( $org ) ),
		'bas'      => $bas,
		'bit'      => $bit,
		'bugun'    => $bugun,
		'olcumBas' => $olcBas,
		'saklaBas' => $saklaBas,
		'hamBas'   => $hamBas,
		'acik'     => $tum ? true : (bool) $ayar['acik'],
		'ana'      => $ana,
		'gunler'   => $out_g,
		'toplam'   => $top + array( 'tekil' => count( $tekil ) ),
		'rotalar'  => array_slice( $rotalar, 0, 40 ),
		'saatler'  => $saat,
		'istekSaat'=> $isaat,
		'cihaz'    => $cihaz,
		'roller'   => $roller,
		'istekler' => array_values( $ist ),
		'sure'     => $sure,
		'sureUygulama' => array( 'n' => array_sum( $tumH ), 'p50' => sides_trafik_yuzdelik( $tumH, 0.5 ), 'p95' => sides_trafik_yuzdelik( $tumH, 0.95 ) ),
		'aktif'    => array( 'n' => $aktif, 'pencere' => $pencere, 'sonVeri' => $sonT ),
		'olcum'    => $simdi,
		'super'    => sides_trafik_super(),
	);
	if ( $tum && sides_trafik_super() ) {
		$out['kurumlar'] = sides_trafik_kurum_dokum( $bas, $bit, $ana );
	}
	return $out;
}
/* Ana hesap için kurum kırılımı (trafik + mantıksal kayıt boyutu) */
function sides_trafik_kurum_dokum( $bas, $bit, $ana ) {
	global $wpdb;
	$t    = sides_trafik_tablo();
	$rows = $wpdb->get_results( $wpdb->prepare( "SELECT org, anahtar, SUM(deger) AS n FROM $t WHERE gun BETWEEN %s AND %s AND ( anahtar LIKE %s OR anahtar LIKE %s OR anahtar LIKE %s OR anahtar LIKE %s OR anahtar LIKE %s ) GROUP BY org, anahtar", $bas, $bit, 'v|%', 'u|%', 'q|%', 'e4|%', 'e5|%' ) ); // phpcs:ignore
	$k    = array();
	foreach ( $rows as $r ) {
		$o = (int) $r->org;
		if ( ! isset( $k[ $o ] ) ) {
			$k[ $o ] = array( 'id' => $o, 'gv' => 0, 'tekil' => array(), 'istek' => 0, 'hata' => 0 );
		}
		$p = explode( '|', $r->anahtar );
		if ( ( 'v' === $p[0] || 'u' === $p[0] ) && 'ana' === $p[1] && ! $ana ) {
			continue;
		}
		if ( 'v' === $p[0] ) {
			$k[ $o ]['gv'] += (int) $r->n;
		} elseif ( 'u' === $p[0] ) {
			$k[ $o ]['tekil'][ $p[2] ] = 1;
		} elseif ( 'q' === $p[0] ) {
			$k[ $o ]['istek'] += (int) $r->n;
		} else {
			$k[ $o ]['hata'] += (int) $r->n;
		}
	}
	$boy = get_transient( 'sides_trf_orgboy' );
	if ( ! is_array( $boy ) ) {
		$boy = array();
		foreach ( $wpdb->get_results( 'SELECT org, COUNT(*) AS n, SUM(LENGTH(data)) + SUM(COALESCE(LENGTH(snapshot),0)) AS b FROM ' . sides_docs() . ' GROUP BY org' ) as $r ) { // phpcs:ignore
			$boy[ (int) $r->org ] = array( (int) $r->n, (int) $r->b );
		}
		set_transient( 'sides_trf_orgboy', $boy, 600 );
	}
	$ad = array();
	foreach ( $wpdb->get_results( 'SELECT id, ad, durum FROM ' . sides_orgs() ) as $o ) { // phpcs:ignore
		$ad[ (int) $o->id ] = $o;
		if ( ! isset( $k[ (int) $o->id ] ) ) {
			$k[ (int) $o->id ] = array( 'id' => (int) $o->id, 'gv' => 0, 'tekil' => array(), 'istek' => 0, 'hata' => 0 );
		}
	}
	$out = array();
	foreach ( $k as $o => $x ) {
		$x['tekil'] = count( $x['tekil'] );
		$x['ad']    = $o ? ( isset( $ad[ $o ] ) ? $ad[ $o ]->ad : 'Silinmiş kurum ' . $o ) : 'Kurumsuz (herkese açık bağlantılar, kayıt sayfası)';
		$x['durum'] = isset( $ad[ $o ] ) ? $ad[ $o ]->durum : '';
		$x['kayit'] = isset( $boy[ $o ] ) ? $boy[ $o ][0] : 0;
		$x['bayt']  = isset( $boy[ $o ] ) ? $boy[ $o ][1] : 0;
		$out[]      = $x;
	}
	usort( $out, function ( $a, $b ) {
		return $b['gv'] - $a['gv'] ?: $b['istek'] - $a['istek'];
	} );
	return $out;
}

/* ------------------------------------------------------------------ *
 * Depolama (önbellekli: 10 dk; ağır tarama her sayfa açılışında çalışmaz)
 * ------------------------------------------------------------------ */
function sides_trafik_koll_kategori( $c ) {
	$m = array(
		'ogrenci' => array( 'students', 'lgs', 'adaylar', 'kayit' ),
		'sinav'   => array( 'exams', 'results', 'testler', 'tsonuc', 'birlesik' ),
		'havuz'   => array( 'havuz' ),
		'takip'   => array( 'etut', 'izin', 'kitap', 'takviye', 'seviye', 'dgrup', 'hedef', 'hsablon', 'workwin', 'sgunluk', 'tklink' ),
		'puan'    => array( 'pkriter', 'phareket', 'pgun', 'podul', 'tv' ),
		'rapor'   => array( 'rsablon', 'rapor', 'velirapor' ),
		'log'     => array( 'log' ),
	);
	foreach ( $m as $k => $l ) {
		if ( in_array( $c, $l, true ) ) {
			return $k;
		}
	}
	return 'diger';
}
function sides_trafik_depolama( $org, $yenile ) {
	global $wpdb;
	$ck = 'sides_trf_depo_' . (int) $org;
	if ( ! $yenile ) {
		$c = get_transient( $ck );
		if ( is_array( $c ) ) {
			$c['onbellek'] = true;
			return $c;
		}
	}
	$t   = sides_docs();
	$wo  = $org ? $wpdb->prepare( 'WHERE org = %d', $org ) : '';
	$kol = array();
	$top = array( 'n' => 0, 'b' => 0 );
	foreach ( $wpdb->get_results( "SELECT coll, COUNT(*) AS n, SUM(LENGTH(data)) + SUM(COALESCE(LENGTH(snapshot),0)) AS b FROM $t $wo GROUP BY coll ORDER BY coll" ) as $r ) { // phpcs:ignore
		$kol[]     = array( 'coll' => $r->coll, 'n' => (int) $r->n, 'b' => (int) $r->b, 'kat' => 'gorsel' === $r->coll ? 'gorsel' : sides_trafik_koll_kategori( $r->coll ) );
		$top['n'] += (int) $r->n;
		$top['b'] += (int) $r->b;
	}
	// Görseller: hangi kayıt türünün kullandığına göre ayrılır; her görsel yalnızca bir kategoride sayılır
	$ref  = array();
	$sira = array( 'soru' => "'havuz','testler','exams'", 'ogrenci' => "'students'", 'hedef' => "'hedef','hsablon'", 'pano' => "'tv','duyurular'" );
	foreach ( $sira as $kat => $in ) {
		foreach ( $wpdb->get_col( "SELECT data FROM $t $wo" . ( $wo ? ' AND' : ' WHERE' ) . " coll IN ($in) AND data LIKE '%\"g%'" ) as $d ) { // phpcs:ignore
			if ( preg_match_all( '/g[a-f0-9]{16,40}/', $d, $m ) ) {
				foreach ( $m[0] as $gid ) {
					if ( ! isset( $ref[ $gid ] ) ) {
						$ref[ $gid ] = $kat;
					}
				}
			}
		}
	}
	$gk   = array_fill_keys( array( 'soru', 'ogrenci', 'hedef', 'pano', 'diger' ), array( 'n' => 0, 'b' => 0 ) );
	$buyk = array();
	foreach ( $wpdb->get_results( "SELECT org, id, LENGTH(data) AS b, updated_at FROM $t $wo" . ( $wo ? ' AND' : ' WHERE' ) . " coll = 'gorsel'" ) as $r ) { // phpcs:ignore
		$kat              = isset( $ref[ $r->id ] ) ? $ref[ $r->id ] : 'diger';
		$gk[ $kat ]['n'] += 1;
		$gk[ $kat ]['b'] += (int) $r->b;
		$buyk[]           = array( 'tur' => 'gorsel', 'id' => $r->id, 'b' => (int) $r->b, 't' => strtotime( $r->updated_at . ' UTC' ), 'kat' => $kat, 'org' => (int) $r->org );
	}
	// Yedekler: kurum yedekleri kesin; site geneli yedekler paylaşılır, kuruma pay edilmez (aynı dosya iki kez sayılmaz)
	$yd   = array( 'kurum' => array( 'n' => 0, 'b' => 0, 'son' => 0 ), 'site' => array( 'n' => 0, 'b' => 0, 'son' => 0 ) );
	$ydir = function_exists( 'sides_yedek_dir' ) ? sides_yedek_dir() : '';
	foreach ( function_exists( 'sides_yedek_liste' ) ? sides_yedek_liste() : array() as $dosya => $x ) {
		$kap = 'site' === $x['kapsam'] ? 'site' : 'kurum';
		if ( 'kurum' === $kap && $org && (int) $x['org'] !== $org ) {
			continue;
		}
		$b                   = (int) $x['boyut'];
		$yd[ $kap ]['n']    += 1;
		$yd[ $kap ]['b']    += $b;
		$yd[ $kap ]['son']   = max( $yd[ $kap ]['son'], (int) $x['t'] );
		if ( 'kurum' === $kap || ! $org ) {
			$buyk[] = array( 'tur' => 'yedek', 'id' => ( 'site' === $kap ? 'Site geneli yedek' : 'Kurum yedeği' ) . ' · ' . ( isset( $x['tur'] ) ? $x['tur'] : '' ), 'b' => $b, 't' => (int) $x['t'], 'kat' => 'yedek', 'org' => 'kurum' === $kap ? (int) $x['org'] : 0 );
		}
		unset( $dosya );
	}
	usort( $buyk, function ( $a, $b ) {
		return $b['b'] - $a['b'];
	} );
	$kat = array();
	foreach ( $kol as $k ) {
		if ( 'gorsel' === $k['kat'] ) {
			continue;
		}
		$kat[ $k['kat'] ]      = isset( $kat[ $k['kat'] ] ) ? $kat[ $k['kat'] ] : array( 'n' => 0, 'b' => 0 );
		$kat[ $k['kat'] ]['n'] += $k['n'];
		$kat[ $k['kat'] ]['b'] += $k['b'];
	}
	$out = array(
		'olcum'      => time(),
		'onbellek'   => false,
		'koleksiyon' => $kol,
		'kayit'      => $top,
		'kategori'   => $kat,
		'gorsel'     => $gk,
		'yedek'      => $yd,
		'enBuyuk'    => array_slice( $buyk, 0, 10 ),
		'kapsam'     => array(
			'tablo'  => $t . ( $org ? ' (org = ' . $org . ' satırları; data + snapshot sütunları)' : ' (tüm satırlar)' ),
			'klasor' => $ydir ? str_replace( ABSPATH, '', $ydir ) . ' (yedek dizini: ' . ( $org ? 'bu kurumun yedekleri; site geneli yedekler ayrı' : 'tüm yedekler' ) . ')' : '',
		),
	);
	// Günlük anlık görüntü (büyüme için): toplanmaz, gün içinde üzerine yazılır
	sides_trafik_ekle( $org, sides_trafik_gun(), array( 'z|kayit' => $top['b'], 'z|gorsel' => array_sum( array_column( $gk, 'b' ) ), 'z|yedek' => $yd['kurum']['b'] + ( $org ? 0 : $yd['site']['b'] ), 'z|toplam' => $top['b'] + $yd['kurum']['b'] + ( $org ? 0 : $yd['site']['b'] ) ), true );
	set_transient( $ck, $out, 600 );
	return $out;
}
/* Fiziksel veritabanı boyutu: MySQL'de information_schema, SQLite'ta veritabanı dosyası; ölçülemezse açıkça söylenir */
function sides_trafik_fiziksel() {
	global $wpdb;
	if ( defined( 'DB_ENGINE' ) && 'sqlite' === DB_ENGINE ) {
		$f = defined( 'FQDB' ) ? FQDB : '';
		if ( $f && @is_readable( $f ) ) { // phpcs:ignore
			return array( 'durum' => 'olculdu', 'kaynak' => 'SQLite veritabanı dosyasının boyutu (tüm site tabloları tek dosyada)', 'toplam' => (int) filesize( $f ), 'tablolar' => array(), 'motor' => 'sqlite' );
		}
		return array( 'durum' => 'olculemedi', 'kaynak' => 'SQLite dosyası okunamadı' );
	}
	$eski = $wpdb->suppress_errors( true );
	$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT table_name AS ad, data_length AS d, index_length AS i FROM information_schema.TABLES WHERE table_schema = DATABASE() AND table_name LIKE %s', $wpdb->esc_like( $wpdb->prefix . 'sides_' ) . '%' ) );
	$wpdb->suppress_errors( $eski );
	$tb  = array();
	$top = 0;
	foreach ( (array) $rows as $r ) {
		$b    = (int) $r->d + (int) $r->i;
		$tb[] = array( 'ad' => $r->ad, 'b' => $b );
		$top += $b;
	}
	if ( ! $tb || ! $top ) {
		return array( 'durum' => 'olculemedi', 'kaynak' => 'information_schema erişilemedi' );
	}
	return array( 'durum' => 'olculdu', 'kaynak' => 'information_schema.TABLES (veri + dizin; ATLAS tabloları)', 'toplam' => $top, 'tablolar' => $tb, 'motor' => 'mysql' );
}

/* ------------------------------------------------------------------ *
 * GET trafik/kaynak — depolama, sayılar, sistem sağlığı, uyarılar. ?org&yenile=1
 * ------------------------------------------------------------------ */
function sides_trafik_ini_bayt( $v ) {
	$v = trim( (string) $v );
	if ( '' === $v || '-1' === $v ) {
		return -1;
	}
	$n = (float) $v;
	$s = strtolower( substr( $v, -1 ) );
	return (int) ( 'g' === $s ? $n * 1073741824 : ( 'm' === $s ? $n * 1048576 : ( 'k' === $s ? $n * 1024 : $n ) ) );
}
function sides_trafik_islev( $f ) {
	$kapali = array_map( 'trim', explode( ',', (string) ini_get( 'disable_functions' ) ) );
	return function_exists( $f ) && ! in_array( $f, $kapali, true );
}
function sides_trafik_kaynak( WP_REST_Request $req ) {
	global $wpdb;
	$org    = sides_trafik_kapsam( $req );
	$super  = sides_trafik_super();
	$yenile = '1' === (string) $req->get_param( 'yenile' );
	if ( $yenile && ! sides_rl( 'trafik_yenile_' . get_current_user_id(), 6, 60 ) ) {
		$yenile = false;
	}
	$d     = sides_trafik_depolama( $org, $yenile );
	$simdi = time();
	$t     = sides_docs();
	$wo    = $org ? $wpdb->prepare( 'org = %d AND ', $org ) : '';
	$say   = array();
	foreach ( $wpdb->get_results( "SELECT coll, COUNT(*) AS n FROM $t WHERE $wo coll IN ('students','exams','testler','havuz','gorsel','results','tsonuc') GROUP BY coll" ) as $r ) { // phpcs:ignore
		$say[ $r->coll ] = (int) $r->n;
	}
	$fiz = $super ? sides_trafik_fiziksel() : null;
	if ( ! $super ) {
		// kuruma yalnızca kendi payının yaklaşığı gösterilir: fiziksel boyut × (kurum kayıtları / tüm kayıtlar)
		$f = sides_trafik_fiziksel();
		$h = get_transient( 'sides_trf_orgboy' );
		if ( ! is_array( $h ) ) {
			$h = array();
			foreach ( $wpdb->get_results( "SELECT org, COUNT(*) AS n, SUM(LENGTH(data)) + SUM(COALESCE(LENGTH(snapshot),0)) AS b FROM $t GROUP BY org" ) as $r ) { // phpcs:ignore
				$h[ (int) $r->org ] = array( (int) $r->n, (int) $r->b );
			}
			set_transient( 'sides_trf_orgboy', $h, 600 );
		}
		$tumB = array_sum( array_map( function ( $x ) {
			return $x[1];
		}, $h ) );
		$fiz  = 'olculdu' === $f['durum'] && $tumB && 'sqlite' !== $f['motor']
			? array( 'durum' => 'yaklasik', 'toplam' => (int) round( $f['toplam'] * $d['kayit']['b'] / $tumB ), 'kaynak' => 'Yaklaşık: ATLAS tablolarının fiziksel boyutu × (kurumunuzun kayıt boyutu ÷ tüm kurumların kayıt boyutu)' )
			: array( 'durum' => 'olculemedi', 'kaynak' => 'Paylaşılan veritabanında kurum payı bu ortamda ölçülemiyor' );
	}
	$kota  = $org ? sides_trafik_kota( $org ) : 0;
	$kull  = $d['kayit']['b'] + $d['yedek']['kurum']['b'];
	$buy   = null;
	$tt    = sides_trafik_tablo();
	$eski  = $wpdb->get_row( $wpdb->prepare( "SELECT gun, deger FROM $tt WHERE org = %d AND anahtar = 'z|toplam' AND gun >= %s ORDER BY gun ASC LIMIT 1", $org, sides_trafik_gun_ekle( sides_trafik_gun(), -30 ) ) ); // phpcs:ignore
	if ( $eski && $eski->gun < sides_trafik_gun() ) {
		$simdiB = $d['kayit']['b'] + $d['yedek']['kurum']['b'] + ( $org ? 0 : $d['yedek']['site']['b'] );
		$buy    = array( 'bas' => $eski->gun, 'onceki' => (int) $eski->deger, 'simdi' => $simdiB, 'fark' => $simdiB - (int) $eski->deger );
	}
	$out = array(
		'kapsam'   => array( 'org' => $org, 'tum' => 0 === $org, 'ad' => sides_trafik_kurum_adi( $org ) ),
		'olcum'    => $simdi,
		'depolama' => $d,
		'fiziksel' => $fiz,
		'kota'     => array( 'mb' => $kota ?: null, 'kullanilan' => $kull, 'kalan' => $kota ? max( 0, $kota * 1048576 - $kull ) : null, 'yuzde' => $kota ? round( 100 * $kull / ( $kota * 1048576 ), 1 ) : null ),
		'buyume'   => $buy,
		'sayilar'  => $say,
		'ai'       => function_exists( 'sides_ai_durum' ) && $org ? sides_ai_durum( $org ) : null,
		'saglik'   => sides_trafik_saglik( $org, $super, $d ),
		'super'    => $super,
	);
	if ( $super ) {
		$gec = array( 'n' => 0, 'b' => 0 );
		$ydir = function_exists( 'sides_yedek_dir' ) ? sides_yedek_dir() : '';
		foreach ( $ydir ? (array) glob( "$ydir/parca-*.tmp" ) : array() as $f ) {
			if ( $f ) {
				++$gec['n'];
				$gec['b'] += (int) @filesize( $f ); // phpcs:ignore
			}
		}
		$tr = $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) AS n, SUM(LENGTH(option_value)) AS b FROM $wpdb->options WHERE option_name LIKE %s", $wpdb->esc_like( '_transient_sides_' ) . '%' ) );
		$out['gecici'] = array(
			'dosya'   => $gec + array( 'kapsam' => $ydir ? str_replace( ABSPATH, '', $ydir ) . '/parca-*.tmp (yarım kalmış yedek yüklemeleri)' : '' ),
			'onbellek' => array( 'n' => (int) $tr->n, 'b' => (int) $tr->b, 'kapsam' => $wpdb->options . ' içindeki _transient_sides_* kayıtları (hız sınırı, önbellek)' ),
		);
		$bos  = sides_trafik_islev( 'disk_free_space' ) ? @disk_free_space( WP_CONTENT_DIR ) : false; // phpcs:ignore
		$top  = sides_trafik_islev( 'disk_total_space' ) ? @disk_total_space( WP_CONTENT_DIR ) : false; // phpcs:ignore
		$out['disk'] = false !== $bos ? array( 'bos' => (float) $bos, 'toplam' => false !== $top ? (float) $top : null, 'kapsam' => 'wp-content klasörünün bulunduğu disk bölümü (sunucu diski; kurum kotası değildir)' ) : null;
		$kotalar = get_option( 'sides_trafik_kota' );
		$out['kotalar'] = is_array( $kotalar ) ? $kotalar : array();
	}
	$out['uyarilar'] = $org ? sides_trafik_uyari_denetle( $org, $d ) : null;
	return $out;
}
function sides_trafik_satir( $k, $ad, $deger, $kaynak, $durum = 'ok', $zaman = null ) {
	return array( 'k' => $k, 'ad' => $ad, 'deger' => $deger, 'kaynak' => $kaynak, 'durum' => $durum, 'zaman' => null === $zaman ? time() : $zaman );
}
function sides_trafik_son_yedek( $org ) {
	$son = 0;
	foreach ( function_exists( 'sides_yedek_liste' ) ? sides_yedek_liste() : array() as $x ) {
		if ( ! $org || ( 'kurum' === $x['kapsam'] && (int) $x['org'] === $org ) || ( 'site' === $x['kapsam'] && in_array( $x['tur'], array( 'gunluk', 'guncelleme' ), true ) ) ) {
			$son = max( $son, (int) $x['t'] );
		}
	}
	return $son;
}
function sides_trafik_saglik( $org, $super, $d ) {
	global $wpdb, $wp_version;
	$s     = array();
	$simdi = time();
	$ayar  = sides_trafik_ayar( $org ? $org : sides_org_id() );
	$s[]   = sides_trafik_satir( 'surum', 'ATLAS sürümü', OPTIK_KARNE_VER, 'Eklenti sabiti' );
	$ak    = $org ? get_option( 'sides_trf_aktif_' . $org ) : null;
	$sonT  = is_array( $ak ) && isset( $ak['_son'] ) ? (int) $ak['_son'] : 0;
	$s[]   = sides_trafik_satir( 'olcum', 'Son başarılı veri toplama', $org ? ( $ayar['acik'] ? ( $sonT ? array( 't' => $sonT ) : 'Henüz ölçüm paketi gelmedi' ) : 'Ölçüm kapalı' ) : 'Kurum seçin', 'trafik/iz ölçüm paketleri', $org && $ayar['acik'] && $sonT ? 'ok' : 'yok', $sonT ?: null );
	$son   = sides_trafik_son_yedek( $org );
	$hata  = get_option( 'sides_yedek_hata' );
	$ydDur = ! $son ? 'bad' : ( $simdi - $son > 2 * 86400 ? 'warn' : 'ok' );
	if ( is_array( $hata ) && ! empty( $hata['t'] ) && (int) $hata['t'] > $son ) {
		$ydDur = 'bad';
	}
	$s[] = sides_trafik_satir( 'yedek', 'Son başarılı yedek', $son ? array( 't' => $son ) : 'Hiç yedek yok', 'Yedek dizini (sides_yedekler)', $ydDur, $son ?: null );
	if ( is_array( $hata ) && ! empty( $hata['t'] ) && (int) $hata['t'] > $son ) {
		$s[] = sides_trafik_satir( 'yedekHata', 'Son yedek hatası', $super ? (string) $hata['m'] : 'Son yedekleme denemesi başarısız oldu', 'sides_yedek_hata', 'bad', (int) $hata['t'] );
	}
	$cronKapali = defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON;
	$yd         = function_exists( 'sides_yedek_ayar' ) ? sides_yedek_ayar() : array( 'gunluk' => true );
	$nx         = wp_next_scheduled( 'sides_gunluk_yedek' );
	$s[]        = sides_trafik_satir( 'cronYedek', 'Zamanlanmış görev: gece yedeği', $yd['gunluk'] ? ( $nx ? array( 't' => $nx, 'sonraki' => 1 ) : 'Zamanlanmamış' ) : 'Kapalı (ana hesap ayarı)', 'WP-Cron' . ( $cronKapali ? ' (DISABLE_WP_CRON: sunucu cron’u gerekir)' : '' ), $yd['gunluk'] ? ( $nx && $nx > $simdi - 3600 ? 'ok' : 'warn' ) : 'yok' );
	$nt  = wp_next_scheduled( 'sides_trafik_saatlik' );
	$lt  = (int) get_option( 'sides_trafik_cron', 0 );
	$s[] = sides_trafik_satir( 'cronTrafik', 'Zamanlanmış görev: ölçüm temizliği ve uyarı denetimi', $lt ? array( 't' => $lt ) : 'Henüz çalışmadı', 'WP-Cron (saatlik) · sonraki: ' . ( $nt ? wp_date( 'd.m.Y H:i', $nt, sides_trafik_tz() ) : 'zamanlanmamış' ), $lt && $simdi - $lt < 3 * 3600 ? 'ok' : 'warn', $lt ?: null );
	$ai  = function_exists( 'sides_ai_durum' ) && $org ? sides_ai_durum( $org ) : null;
	$s[] = sides_trafik_satir( 'ai', 'Yapay zekâ hizmeti', $ai ? ( $ai['acik'] ? 'Yapılandırılmış' . ( $ai['sinir'] ? ' · bu ay ' . $ai['kullanilan'] . ' / ' . $ai['sinir'] : ' · bu ay ' . $ai['kullanilan'] . ' istek' ) : 'Yapılandırılmamış' ) : '—', 'Ana hesap ayarı ve aylık kullanım sayacı; bağlantı sınaması yapılmaz (ücretli çağrı başlatmamak için)', $ai && $ai['acik'] ? 'ok' : 'yok' );
	$ep  = get_option( 'sides_trafik_eposta' );
	$s[] = sides_trafik_satir( 'eposta', 'Son e-posta gönderimi', is_array( $ep ) ? ( $ep['ok'] ? 'Başarılı' : 'Başarısız' . ( $super && ! empty( $ep['m'] ) ? ': ' . $ep['m'] : '' ) ) : 'v5.3’ten beri kayıt yok', 'wp_mail sonuç kancası', is_array( $ep ) ? ( $ep['ok'] ? 'ok' : 'bad' ) : 'yok', is_array( $ep ) ? (int) $ep['t'] : null );
	if ( $org ) {
		$ay  = sides_trafik_an()->format( 'Y-m' );
		$vk  = sides_get_doc( $org, 'tv', 'vakit_' . $ay );
		$s[] = sides_trafik_satir( 'vakit', 'Namaz vakti çizelgesi (TV)', $vk ? 'Bu ay için yüklü' . ( ! empty( $vk['kaynak'] ) ? ' · ' . mb_substr( (string) $vk['kaynak'], 0, 40 ) : '' ) : 'Bu ay için çizelge yok', 'TV ayarında kayıtlı aylık çizelge; dış kaynak sorgulanmaz', $vk ? 'ok' : 'yok' );
	}
	if ( ! $super ) {
		$s[] = sides_trafik_satir( 'sunucu', 'Sunucu kaynakları (CPU, RAM, disk, PHP)', 'Yalnızca ana hesap (site yöneticisi) görebilir', 'Yetki', 'yok' );
		return $s;
	}
	$s[]  = sides_trafik_satir( 'php', 'PHP sürümü', PHP_VERSION, 'PHP_VERSION' );
	$s[]  = sides_trafik_satir( 'wp', 'WordPress sürümü', $wp_version, '$wp_version' );
	$dbs  = defined( 'DB_ENGINE' ) && 'sqlite' === DB_ENGINE ? 'SQLite ' . $wpdb->db_server_info() : 'MySQL/MariaDB ' . $wpdb->db_version();
	$s[]  = sides_trafik_satir( 'db', 'Veritabanı sunucusu', $dbs, '$wpdb' );
	$ml   = ini_get( 'memory_limit' );
	$s[]  = sides_trafik_satir( 'memory', 'PHP bellek sınırı (istek başına)', $ml, 'ini_get(memory_limit)', -1 === sides_trafik_ini_bayt( $ml ) || sides_trafik_ini_bayt( $ml ) >= 128 * 1048576 ? 'ok' : 'warn' );
	$s[]  = sides_trafik_satir( 'bellekIstek', 'Bu isteğin PHP belleği (zirve)', array( 'b' => memory_get_peak_usage( true ) ), 'memory_get_peak_usage — sunucu RAM’i değildir' );
	$s[]  = sides_trafik_satir( 'sure', 'En uzun çalışma süresi', ini_get( 'max_execution_time' ) . ' sn', 'ini_get(max_execution_time)' );
	$s[]  = sides_trafik_satir( 'yukleme', 'En büyük yükleme / gönderi', ini_get( 'upload_max_filesize' ) . ' / ' . ini_get( 'post_max_size' ), 'ini_get(upload_max_filesize, post_max_size)' );
	$bos  = sides_trafik_islev( 'disk_free_space' ) ? @disk_free_space( WP_CONTENT_DIR ) : false; // phpcs:ignore
	$s[]  = sides_trafik_satir( 'disk', 'Sunucu diski boş alan (wp-content bölümü)', false !== $bos ? array( 'b' => (float) $bos ) : 'Bu ortamda ölçülemiyor', 'disk_free_space() — kurumun kalan kotası değildir', false !== $bos ? ( $bos < 1073741824 ? 'warn' : 'ok' ) : 'yok' );
	$yuk  = sides_trafik_islev( 'sys_getloadavg' ) ? @sys_getloadavg() : false; // phpcs:ignore
	$s[]  = sides_trafik_satir( 'yuk', 'İşletim sistemi yük ortalaması (1 / 5 / 15 dk)', is_array( $yuk ) ? implode( ' / ', array_map( function ( $x ) {
		return number_format( (float) $x, 2, ',', '' );
	}, $yuk ) ) : 'Sunucu bu bilgiyi paylaşmıyor', 'sys_getloadavg() — CPU yüzdesi değildir; paylaşımlı sunucuda tüm makineyi yansıtır', is_array( $yuk ) ? 'ok' : 'yok' );
	$s[]  = sides_trafik_satir( 'ram', 'Sunucu RAM kullanımı', 'Sunucu bu bilgiyi paylaşmıyor', 'Barındırma sağlayıcısının izleme paneli gerekir', 'yok' );
	$s[]  = sides_trafik_satir( 'bant', 'Bant genişliği ve eşzamanlı istek', 'Bu ortamda ölçülemiyor', 'Web sunucusu/CDN günlükleri gerekir', 'yok' );
	$s[]  = sides_trafik_satir( 'uptime', 'Kesintisiz çalışma (uptime)', 'Bağımsız izleme bağlı değil; hesaplanmaz', 'Sitenin kendi yanıtından kesintisizlik varsayılmaz', 'yok' );
	$s[]  = sides_trafik_satir( 'cron', 'WP-Cron', $cronKapali ? 'DISABLE_WP_CRON açık (sunucu cron’u ile çalışmalı)' : 'Ziyaretlerle tetiklenir', 'wp-config.php', $cronKapali ? 'warn' : 'ok' );
	return $s;
}

/* ------------------------------------------------------------------ *
 * Uyarılar: her kural tek olay olarak açılır / kapanır; açılış ve normale dönüş İşlem Geçmişi'ne bir kez yazılır
 * ------------------------------------------------------------------ */
function sides_trafik_uyari_olc( $org, $gun ) {
	global $wpdb;
	$t    = sides_trafik_tablo();
	$bas  = sides_trafik_gun_ekle( sides_trafik_gun(), -max( 1, (int) $gun ) + 1 );
	$rows = $wpdb->get_results( $wpdb->prepare( "SELECT anahtar, SUM(deger) AS n FROM $t WHERE org = %d AND gun >= %s AND ( anahtar LIKE %s OR anahtar LIKE %s OR anahtar LIKE %s OR anahtar LIKE %s ) GROUP BY anahtar", $org, $bas, 'q|%', 'e4|%', 'e5|%', 'y|%' ) ); // phpcs:ignore
	$m    = array( 'n' => 0, 'hata' => 0, 'yavas' => 0 );
	foreach ( $rows as $r ) {
		$p = explode( '|', $r->anahtar );
		if ( ! in_array( $p[1], array( 'panel', 'senk' ), true ) ) {
			continue;
		}
		if ( 'q' === $p[0] ) {
			$m['n'] += (int) $r->n;
		} elseif ( 'y' === $p[0] ) {
			$m['yavas'] += (int) $r->n;
		} else {
			$m['hata'] += (int) $r->n;
		}
	}
	return $m;
}
function sides_trafik_mb( $b ) {
	return number_format( $b / 1048576, 1, ',', '.' ) . ' MB';
}
function sides_trafik_uyari_denetle( $org, $d ) {
	if ( ! $org ) {
		return null;
	}
	$a     = sides_trafik_ayar( $org );
	$U     = $a['uyari'];
	$simdi = time();
	$kosul = array();
	// depolama
	$kull = $d['kayit']['b'] + $d['yedek']['kurum']['b'];
	$kota = sides_trafik_kota( $org );
	if ( $U['depolama']['acik'] ) {
		if ( $kota ) {
			$y   = 100 * $kull / ( $kota * 1048576 );
			$sev = $y >= $U['depolama']['kritikYuzde'] ? 'kritik' : ( $y >= $U['depolama']['uyariYuzde'] ? 'uyari' : '' );
			$kosul['depolama'] = array( $sev, 'Depolama kotanın %' . number_format( $y, 1, ',', '' ) . ' kadarı dolu (' . sides_trafik_mb( $kull ) . ' / ' . $kota . ' MB).', round( $y, 1 ) );
		} else {
			$mb  = $kull / 1048576;
			$sev = $mb >= $U['depolama']['kritikMb'] ? 'kritik' : ( $mb >= $U['depolama']['uyariMb'] ? 'uyari' : '' );
			$kosul['depolama'] = array( $sev, 'Kurum depolaması ' . sides_trafik_mb( $kull ) . ' (eşik ' . ( 'kritik' === $sev ? $U['depolama']['kritikMb'] : $U['depolama']['uyariMb'] ) . ' MB).', round( $mb, 1 ) );
		}
	}
	foreach ( array( 'hata', 'yavas' ) as $kk ) {
		if ( ! $U[ $kk ]['acik'] ) {
			continue;
		}
		$m = sides_trafik_uyari_olc( $org, $U[ $kk ]['gun'] );
		if ( $m['n'] < $U[ $kk ]['enAz'] ) {
			$kosul[ $kk ] = array( '', '', null );
			continue;
		}
		$y   = 100 * $m[ $kk ] / $m['n'];
		$sev = $y >= $U[ $kk ]['yuzde'] ? ( $y >= 2 * $U[ $kk ]['yuzde'] ? 'kritik' : 'uyari' ) : '';
		$kosul[ $kk ] = array( $sev, ( 'hata' === $kk ? 'API hata oranı' : 'Yavaş yanıt (1 sn üstü) oranı' ) . ' son ' . $U[ $kk ]['gun'] . ' günde %' . number_format( $y, 1, ',', '' ) . ' (' . $m[ $kk ] . ' / ' . $m['n'] . ' istek; eşik %' . $U[ $kk ]['yuzde'] . ').', round( $y, 2 ) );
	}
	if ( $U['yedek']['acik'] ) {
		$son  = sides_trafik_son_yedek( $org );
		$hata = get_option( 'sides_yedek_hata' );
		if ( is_array( $hata ) && ! empty( $hata['t'] ) && (int) $hata['t'] > $son ) {
			$kosul['yedek'] = array( 'kritik', 'Son yedekleme denemesi başarısız oldu.', 0 );
		} else {
			$gun            = $son ? ( $simdi - $son ) / 86400 : null;
			$kosul['yedek'] = array( null === $gun || $gun > $U['yedek']['gun'] ? 'uyari' : '', $son ? 'Son başarılı yedek ' . number_format( $gun, 1, ',', '' ) . ' gün önce alındı (eşik ' . $U['yedek']['gun'] . ' gün).' : 'Bu kurum için hiç yedek yok.', null === $gun ? null : round( $gun, 1 ) );
		}
	}
	$ai = function_exists( 'sides_ai_durum' ) ? sides_ai_durum( $org ) : null;
	if ( $U['ai']['acik'] && $ai && $ai['acik'] && $ai['sinir'] ) {
		$y           = 100 * $ai['kullanilan'] / $ai['sinir'];
		$kosul['ai'] = array( $y >= 100 ? 'kritik' : ( $y >= $U['ai']['yuzde'] ? 'uyari' : '' ), 'Yapay zekâ aylık kotasının %' . number_format( $y, 0, ',', '' ) . ' kadarı kullanıldı (' . $ai['kullanilan'] . ' / ' . $ai['sinir'] . ').', round( $y, 1 ) );
	}
	$ad    = array( 'depolama' => 'Depolama', 'hata' => 'Hata oranı', 'yavas' => 'Yavaş yanıt', 'yedek' => 'Yedek', 'ai' => 'Yapay zekâ kotası' );
	$tum   = get_option( 'sides_trafik_uyari' );
	$tum   = is_array( $tum ) ? $tum : array();
	$st    = isset( $tum[ $org ] ) && is_array( $tum[ $org ] ) ? $tum[ $org ] : array( 'aktif' => array(), 'gecmis' => array() );
	$degis = false;
	foreach ( $ad as $k => $baslik ) {
		$acik = isset( $st['aktif'][ $k ] ) ? $st['aktif'][ $k ] : null;
		$c    = isset( $kosul[ $k ] ) ? $kosul[ $k ] : array( '', '', null );
		if ( $c[0] ) {
			if ( ! $acik ) {
				$st['aktif'][ $k ] = array( 'kural' => $k, 'ad' => $baslik, 'seviye' => $c[0], 'mesaj' => $c[1], 'deger' => $c[2], 'bas' => $simdi, 'son' => $simdi );
				sides_log( $org, 'Sistem uyarısı açıldı (' . $baslik . '): ' . $c[1], 'Sistem' );
				sides_trafik_uyari_eposta( $org, $a, $baslik, $c );
			} else {
				if ( 'kritik' === $c[0] && 'uyari' === $acik['seviye'] ) {
					sides_log( $org, 'Sistem uyarısı kritik seviyeye çıktı (' . $baslik . '): ' . $c[1], 'Sistem' );
					sides_trafik_uyari_eposta( $org, $a, $baslik, $c );
				}
				$st['aktif'][ $k ] = array_merge( $acik, array( 'seviye' => $c[0], 'mesaj' => $c[1], 'deger' => $c[2], 'son' => $simdi ) );
			}
			$degis = true;
		} elseif ( $acik ) {
			$acik['bitis'] = $simdi;
			array_unshift( $st['gecmis'], $acik );
			$st['gecmis'] = array_slice( $st['gecmis'], 0, 20 );
			unset( $st['aktif'][ $k ] );
			sides_log( $org, 'Sistem uyarısı normale döndü (' . $baslik . ').', 'Sistem' );
			$degis = true;
		}
	}
	if ( $degis ) {
		$tum[ $org ] = $st;
		update_option( 'sides_trafik_uyari', $tum, false );
	}
	return array( 'aktif' => array_values( $st['aktif'] ), 'gecmis' => $st['gecmis'], 'denetim' => $simdi );
}
/* E-posta yalnızca ayarlarda adres girildiyse ve olay yeni açıldığında gönderilir */
function sides_trafik_uyari_eposta( $org, $a, $baslik, $c ) {
	if ( empty( $a['eposta'] ) || ! is_email( $a['eposta'] ) || ! sides_rl( 'trafik_uyari_mail_' . $org, 10, 86400 ) ) {
		return;
	}
	wp_mail( $a['eposta'], 'ATLAS sistem uyarısı: ' . $baslik, sides_trafik_kurum_adi( $org ) . "\n\n" . $c[1] . "\n\nAyrıntılar: " . optik_karne_url() . "\nATLAS · Akademik Takip ve Analiz Sistemi" );
}

/* ------------------------------------------------------------------ *
 * GET|POST trafik/ayar
 * ------------------------------------------------------------------ */
function sides_trafik_ayar_oku( WP_REST_Request $req ) {
	$org = sides_trafik_kapsam( $req );
	$org = $org ? $org : sides_org_id();
	$a   = sides_trafik_ayar( $org );
	return array( 'org' => $org, 'ayar' => $a, 'kota' => sides_trafik_kota( $org ) ?: null, 'super' => sides_trafik_super(), 'olcumBas' => get_option( 'sides_trafik_bas' ) );
}
function sides_trafik_ayar_kaydet( WP_REST_Request $req ) {
	$org = sides_trafik_kapsam( $req );
	$org = $org ? $org : sides_org_id();
	if ( ! $org ) {
		return new WP_Error( 'sides_trafik', 'Kurum seçilmedi.', array( 'status' => 400 ) );
	}
	$p   = $req->get_json_params();
	$p   = is_array( $p ) ? $p : array();
	if ( isset( $p['kota'] ) && ! sides_trafik_super() ) {
		return sides_deny( 'Kurum kotasını yalnızca ana hesap belirleyebilir.' );
	}
	$eski = sides_trafik_ayar( $org );
	$a    = $eski;
	$sin  = function ( $v, $min, $max, $def ) {
		return is_numeric( $v ) ? max( $min, min( $max, (int) $v ) ) : $def;
	};
	if ( isset( $p['acik'] ) ) {
		$a['acik'] = (bool) $p['acik'];
	}
	if ( isset( $p['saklaGun'] ) ) {
		$a['saklaGun'] = $sin( $p['saklaGun'], 30, 730, $eski['saklaGun'] );
	}
	if ( isset( $p['hamGun'] ) ) {
		$a['hamGun'] = $sin( $p['hamGun'], 7, 365, $eski['hamGun'] );
	}
	$a['hamGun'] = min( $a['hamGun'], $a['saklaGun'] );
	if ( isset( $p['pencere'] ) ) {
		$a['pencere'] = $sin( $p['pencere'], 1, 120, $eski['pencere'] );
	}
	if ( isset( $p['anaDahil'] ) ) {
		$a['anaDahil'] = (bool) $p['anaDahil'];
	}
	if ( isset( $p['bolumler'] ) && is_array( $p['bolumler'] ) ) {
		foreach ( $a['bolumler'] as $k => $v ) {
			if ( isset( $p['bolumler'][ $k ] ) ) {
				$a['bolumler'][ $k ] = (bool) $p['bolumler'][ $k ];
			}
		}
	}
	if ( isset( $p['uyari'] ) && is_array( $p['uyari'] ) ) {
		$sinir = array( 'uyariYuzde' => array( 1, 100 ), 'kritikYuzde' => array( 1, 100 ), 'uyariMb' => array( 1, 1048576 ), 'kritikMb' => array( 1, 1048576 ), 'yuzde' => array( 1, 100 ), 'gun' => array( 1, 90 ), 'enAz' => array( 1, 1000000 ) );
		foreach ( $a['uyari'] as $k => $kural ) {
			if ( ! isset( $p['uyari'][ $k ] ) || ! is_array( $p['uyari'][ $k ] ) ) {
				continue;
			}
			foreach ( $kural as $f => $v ) {
				if ( ! isset( $p['uyari'][ $k ][ $f ] ) ) {
					continue;
				}
				$a['uyari'][ $k ][ $f ] = 'acik' === $f ? (bool) $p['uyari'][ $k ][ $f ] : $sin( $p['uyari'][ $k ][ $f ], $sinir[ $f ][0], $sinir[ $f ][1], $v );
			}
		}
		$dp = &$a['uyari']['depolama'];
		if ( $dp['kritikYuzde'] < $dp['uyariYuzde'] || $dp['kritikMb'] < $dp['uyariMb'] ) {
			return new WP_Error( 'sides_trafik', 'Kritik eşik, uyarı eşiğinden küçük olamaz.', array( 'status' => 400 ) );
		}
		unset( $dp );
	}
	if ( isset( $p['eposta'] ) ) {
		$e = trim( (string) $p['eposta'] );
		if ( '' !== $e && ! is_email( $e ) ) {
			return new WP_Error( 'sides_trafik', 'Uyarı e-posta adresi geçersiz.', array( 'status' => 400 ) );
		}
		$a['eposta'] = $e;
	}
	// Ölçümün kapalı olduğu aralıklar: o günler "sıfır trafik" değil "kayıt yok" sayılır
	$bugun = sides_trafik_gun();
	if ( $eski['acik'] && ! $a['acik'] ) {
		$a['kapali'][] = array( $bugun, '' );
	} elseif ( ! $eski['acik'] && $a['acik'] && $a['kapali'] ) {
		$i                    = count( $a['kapali'] ) - 1;
		$a['kapali'][ $i ][1] = $bugun;
	}
	$a['kapali'] = array_slice( $a['kapali'], -20 );
	$tum         = get_option( 'sides_trafik_ayar' );
	$tum         = is_array( $tum ) ? $tum : array();
	$tum[ $org ] = $a;
	update_option( 'sides_trafik_ayar', $tum, true );
	if ( isset( $p['kota'] ) ) {
		$k         = get_option( 'sides_trafik_kota' );
		$k         = is_array( $k ) ? $k : array();
		$mb        = $sin( $p['kota'], 0, 10485760, 0 );
		if ( $mb ) {
			$k[ $org ] = $mb;
		} else {
			unset( $k[ $org ] );
		}
		update_option( 'sides_trafik_kota', $k, false );
	}
	delete_transient( 'sides_trf_depo_' . $org );
	if ( $eski['acik'] !== $a['acik'] ) {
		sides_log( $org, 'Site trafiği ölçümü ' . ( $a['acik'] ? 'açıldı' : 'kapatıldı' ) . '.' );
	} else {
		sides_log( $org, 'Site trafiği ve uyarı ayarları güncellendi.' );
	}
	return sides_trafik_ayar_oku( $req );
}
