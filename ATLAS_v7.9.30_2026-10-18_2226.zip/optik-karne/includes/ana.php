<?php
/**
 * Ana Hesap (platform sahibi): kurumlar, lisans kodları, kayıt yöntemi.
 * Platform sahibi = WordPress site yöneticisi (manage_options).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function sides_kodlar() {
	global $wpdb;
	return $wpdb->prefix . 'sides_kodlar';
}
function sides_is_super() {
	return current_user_can( 'manage_options' );
}

/* Kayıt yöntemi: kapali | kod (yalnız kodla) | kod_onay (kodla anında, kodsuz onaya) | sonra_kod (kayıttan sonra etkinleştirme kodu sorulur) | acik */
function sides_kayit_yontemi() {
	$y = get_option( 'sides_kayit_yontemi', '' );
	if ( ! $y ) {
		$y = '0' === (string) get_option( 'sides_kayit_acik', '1' ) ? 'kapali' : 'kod_onay';
		update_option( 'sides_kayit_yontemi', $y );
	}
	return in_array( $y, SIDES_YONTEMLER, true ) ? $y : 'kod_onay';
}

/* '' = etkin; aksi halde bekliyor | askida | suresi */
function sides_org_blok( $o ) {
	if ( ! $o || 1 === (int) $o->id ) {
		return '';
	}
	$d = isset( $o->durum ) ? (string) $o->durum : 'aktif';
	if ( 'bekliyor' === $d || 'askida' === $d ) {
		return $d;
	}
	if ( ! empty( $o->bitis ) && strtotime( $o->bitis . ' UTC' ) < time() ) {
		return 'suresi';
	}
	return '';
}

function sides_kod_norm( $k ) {
	$k = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) $k ) );
	if ( 13 === strlen( $k ) && in_array( substr( $k, 0, 5 ), array( 'ATLAS', 'SIDES' ), true ) ) {
		$k = substr( $k, 5 );
	}
	return strlen( $k ) === 8 ? substr( $k, 0, 4 ) . '-' . substr( $k, 4, 4 ) : '';
}
function sides_kod_bul( $k ) {
	global $wpdb;
	$k = sides_kod_norm( $k );
	if ( ! $k ) {
		return null;
	}
	$t = sides_kodlar();
	// Yeni kodlar ATLAS-, marka değişikliğinden önce üretilenler SIDES- ile başlar; ikisi de geçerlidir.
	$r = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE kod IN (%s, %s)", 'ATLAS-' . $k, 'SIDES-' . $k ) ); // phpcs:ignore
	return ( $r && 'bos' === $r->durum ) ? $r : null;
}
function sides_kod_uret() {
	$a = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
	$s = '';
	for ( $i = 0; $i < 8; $i++ ) {
		$s .= $a[ random_int( 0, strlen( $a ) - 1 ) ];
	}
	return 'ATLAS-' . substr( $s, 0, 4 ) . '-' . substr( $s, 4, 4 );
}

/* Süreyi uzatır: bitiş = max(şimdi, eski bitiş) + gün. gün = 0 ise süresiz. */
function sides_org_uzat( $org, $gun, $plan = null ) {
	global $wpdb;
	$o = sides_org( $org );
	if ( ! $o ) {
		return;
	}
	$data = array( 'durum' => 'aktif' );
	if ( (int) $gun > 0 ) {
		$bas           = ( ! empty( $o->bitis ) && strtotime( $o->bitis . ' UTC' ) > time() ) ? strtotime( $o->bitis . ' UTC' ) : time();
		$data['bitis'] = gmdate( 'Y-m-d H:i:s', $bas + (int) $gun * DAY_IN_SECONDS );
	} else {
		$data['bitis'] = null;
	}
	if ( null !== $plan ) {
		$data['plan'] = mb_substr( (string) $plan, 0, 60 );
	}
	$wpdb->update( sides_orgs(), $data, array( 'id' => $org ) );
}

/* Kodu kurum için kullanır (aynı kod iki kez kullanılamaz). */
function sides_kod_kullan( $kod, $org ) {
	global $wpdb;
	$r = sides_kod_bul( $kod );
	if ( ! $r ) {
		return false;
	}
	$t = sides_kodlar();
	$n = $wpdb->query( $wpdb->prepare( "UPDATE $t SET durum = 'kullanildi', kullanan = %d, kullanma = %s WHERE kod = %s AND durum = 'bos'", $org, current_time( 'mysql', true ), $r->kod ) ); // phpcs:ignore
	if ( 1 !== (int) $n ) {
		return false;
	}
	sides_org_uzat( $org, (int) $r->gun, $r->plan );
	sides_log( $org, 'Etkinleştirme kodu kullanıldı: ' . $r->kod . ' (' . ( (int) $r->gun ? (int) $r->gun . ' gün' : 'süresiz' ) . ')' );
	return true;
}

function sides_mail_sahip( $subj, $body ) {
	wp_mail( get_option( 'admin_email' ), $subj, $body . "\n\nAna Hesap: " . optik_karne_url() . "\nATLAS · Akademik Takip ve Analiz Sistemi" );
}

/* ------------------------------------------------------------------ *
 * REST: /ana/...
 * ------------------------------------------------------------------ */
add_action( 'rest_api_init', function () {
	$ns    = 'optik-karne/v1';
	$super = function () {
		return sides_is_super() ? true : new WP_Error( 'sides_yetki', 'Bu bölüm yalnızca ana hesaba açıktır.', array( 'status' => 403 ) );
	};
	register_rest_route( $ns, '/ana/kurumlar', array( 'methods' => 'GET', 'callback' => 'sides_ana_kurumlar', 'permission_callback' => $super ) );
	register_rest_route( $ns, '/ana/kurum', array( 'methods' => 'POST', 'callback' => 'sides_ana_kurum_ekle', 'permission_callback' => $super ) );
	register_rest_route( $ns, '/ana/kurum/(?P<id>\d+)', array(
		array( 'methods' => 'PUT, POST', 'callback' => 'sides_ana_kurum_duzenle', 'permission_callback' => $super ),
		array( 'methods' => 'DELETE', 'callback' => 'sides_ana_kurum_sil', 'permission_callback' => $super ),
	) );
	register_rest_route( $ns, '/ana/kodlar', array(
		array( 'methods' => 'GET', 'callback' => 'sides_ana_kodlar', 'permission_callback' => $super ),
		array( 'methods' => 'POST', 'callback' => 'sides_ana_kod_uret', 'permission_callback' => $super ),
	) );
	register_rest_route( $ns, '/ana/kod/(?P<kod>[A-Z0-9\-]{8,20})', array( 'methods' => 'DELETE', 'callback' => 'sides_ana_kod_iptal', 'permission_callback' => $super ) );
	register_rest_route( $ns, '/ana/ozet', array( 'methods' => 'GET', 'callback' => 'sides_ana_ozet', 'permission_callback' => $super ) );
	register_rest_route( $ns, '/ana/islemler', array( 'methods' => 'GET', 'callback' => 'sides_ana_islemler', 'permission_callback' => $super ) );
	register_rest_route( $ns, '/ana/kurum/(?P<id>\d+)/kullanicilar', array( 'methods' => 'GET', 'callback' => 'sides_ana_kurum_kullanicilar', 'permission_callback' => $super ) );
	register_rest_route( $ns, '/ana/mufredat', array( 'methods' => 'POST', 'callback' => 'sides_ana_mufredat', 'permission_callback' => $super ) );
	register_rest_route( $ns, '/ana/ayar', array(
		array( 'methods' => 'GET', 'callback' => 'sides_ana_ayar', 'permission_callback' => $super ),
		array( 'methods' => 'PUT, POST', 'callback' => 'sides_ana_ayar_kaydet', 'permission_callback' => $super ),
	) );
} );

function sides_ana_kurum_row( $o, $cnt, $users, $etkinlik = array() ) {
	$sahip = $o->sahip ? get_userdata( (int) $o->sahip ) : null;
	$id    = (int) $o->id;
	$c     = isset( $cnt[ $id ] ) ? $cnt[ $id ] : array();
	return array(
		'kapali'    => sides_kapali_moduller( $id ),
		'sonIslem'  => isset( $etkinlik['islem'][ $id ] ) ? $etkinlik['islem'][ $id ] : null,
		'sonGiris'  => isset( $etkinlik['giris'][ $id ] ) ? $etkinlik['giris'][ $id ] : null,
		'cihaz'     => isset( $etkinlik['cihaz'][ $id ] ) ? $etkinlik['cihaz'][ $id ] : 0,
		'id'        => $id,
		'ad'        => $o->ad,
		'anahtar'   => $o->anahtar,
		'durum'     => isset( $o->durum ) && $o->durum ? $o->durum : 'aktif',
		'blok'      => sides_org_blok( $o ),
		'bitis'     => ! empty( $o->bitis ) ? gmdate( 'Y-m-d', strtotime( $o->bitis . ' UTC' ) ) : '',
		'plan'      => isset( $o->plan ) ? $o->plan : '',
		'not'       => isset( $o->notlar ) ? (string) $o->notlar : '',
		'olusturma' => $o->olusturma,
		'sahip'     => $sahip ? array( 'id' => $sahip->ID, 'ad' => $sahip->display_name, 'email' => $sahip->user_email, 'sonGiris' => (int) get_user_meta( $sahip->ID, 'sides_son_giris', true ) ) : null,
		'kullanici' => isset( $users[ $id ] ) ? $users[ $id ] : ( 1 === $id ? 1 : 0 ),
		'ogrenci'   => isset( $c['students'] ) ? $c['students'] : 0,
		'deneme'    => isset( $c['exams'] ) ? $c['exams'] : 0,
		'okutma'    => isset( $c['results'] ) ? $c['results'] : 0,
		'ana'       => 1 === $id,
	);
}

function sides_ana_kurumlar() {
	global $wpdb;
	$d   = sides_docs();
	$cnt = array();
	foreach ( $wpdb->get_results( "SELECT org, coll, COUNT(*) AS n FROM $d WHERE coll IN ('students','exams','results') GROUP BY org, coll" ) as $r ) { // phpcs:ignore
		$cnt[ (int) $r->org ][ $r->coll ] = (int) $r->n;
	}
	$users = array();
	foreach ( $wpdb->get_results( "SELECT meta_value AS org, COUNT(*) AS n FROM {$wpdb->usermeta} WHERE meta_key = 'sides_org' GROUP BY meta_value" ) as $r ) { // phpcs:ignore
		$users[ (int) $r->org ] = (int) $r->n;
	}
	$etkinlik = sides_ana_etkinlik();
	$out      = array();
	foreach ( $wpdb->get_results( 'SELECT * FROM ' . sides_orgs() . ' ORDER BY id DESC' ) as $o ) { // phpcs:ignore
		$out[] = sides_ana_kurum_row( $o, $cnt, $users, $etkinlik );
	}
	return $out;
}

/* Kurumların son işlemi, son girişi (kim, ne zaman, hangi cihaz ve IP) ve tanınan cihaz sayısı */
function sides_ana_etkinlik() {
	global $wpdb;
	$d   = sides_docs();
	$out = array( 'islem' => array(), 'giris' => array(), 'cihaz' => array() );
	foreach ( $wpdb->get_results( "SELECT l.org, l.data FROM $d l JOIN (SELECT org, MAX(id) AS id FROM $d WHERE coll = 'log' GROUP BY org) s ON s.org = l.org AND s.id = l.id WHERE l.coll = 'log'" ) as $r ) { // phpcs:ignore
		$x = json_decode( $r->data, true );
		if ( is_array( $x ) ) {
			$out['islem'][ (int) $r->org ] = array( 't' => isset( $x['t'] ) ? (int) $x['t'] : 0, 'u' => isset( $x['u'] ) ? (string) $x['u'] : '', 'm' => isset( $x['m'] ) ? (string) $x['m'] : '' );
		}
	}
	$org = array();
	foreach ( $wpdb->get_results( "SELECT user_id, meta_value FROM {$wpdb->usermeta} WHERE meta_key = 'sides_org'" ) as $r ) { // phpcs:ignore
		$org[ (int) $r->user_id ] = (int) $r->meta_value;
	}
	foreach ( $wpdb->get_results( "SELECT user_id, meta_key, meta_value FROM {$wpdb->usermeta} WHERE meta_key IN ('sides_girisler', 'sides_cihazlar')" ) as $r ) { // phpcs:ignore
		$uid = (int) $r->user_id;
		if ( empty( $org[ $uid ] ) ) {
			continue;
		}
		$o = $org[ $uid ];
		$l = maybe_unserialize( $r->meta_value );
		if ( ! is_array( $l ) || ! $l ) {
			continue;
		}
		if ( 'sides_cihazlar' === $r->meta_key ) {
			$out['cihaz'][ $o ] = ( isset( $out['cihaz'][ $o ] ) ? $out['cihaz'][ $o ] : 0 ) + count( $l );
			continue;
		}
		$g = end( $l );
		if ( is_array( $g ) && ( empty( $out['giris'][ $o ] ) || (int) $g['t'] > $out['giris'][ $o ]['t'] ) ) {
			$u                  = get_userdata( $uid );
			$out['giris'][ $o ] = array( 't' => (int) $g['t'], 'ad' => $u ? $u->display_name : '', 'ua' => isset( $g['ua'] ) ? (string) $g['ua'] : '', 'ip' => isset( $g['ip'] ) ? (string) $g['ip'] : '' );
		}
	}
	return $out;
}

/* Tüm kurumların son işlemleri (en yeni önce). ?org= ile tek kurum; ?son=<ms> verilirse o andan sonraki başkalarının işlem sayısı da döner. */
function sides_ana_islemler( WP_REST_Request $req ) {
	global $wpdb;
	$d     = sides_docs();
	$limit = max( 1, min( 300, (int) ( $req['limit'] ? $req['limit'] : 100 ) ) );
	$org   = (int) $req['org'];
	$ben   = get_current_user_id();
	$yeni  = null;
	if ( null !== $req['son'] && '' !== (string) $req['son'] ) {
		$esik = str_pad( (string) max( 0, (int) $req['son'] ), 14, '0', STR_PAD_LEFT ) . '-9999';
		$yeni = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $d WHERE coll = 'log' AND id > %s AND updated_by <> %d", $esik, $ben ) ); // phpcs:ignore
	}
	if ( $req['say'] ) {
		return array( 'yeni' => (int) $yeni );
	}
	$ad = array();
	foreach ( $wpdb->get_results( 'SELECT id, ad FROM ' . sides_orgs() ) as $o ) { // phpcs:ignore
		$ad[ (int) $o->id ] = $o->ad;
	}
	$sql  = $org ? $wpdb->prepare( "SELECT org, data, updated_by FROM $d WHERE coll = 'log' AND org = %d ORDER BY id DESC LIMIT %d", $org, $limit ) // phpcs:ignore
		: $wpdb->prepare( "SELECT org, data, updated_by FROM $d WHERE coll = 'log' ORDER BY id DESC LIMIT %d", $limit ); // phpcs:ignore
	$list = array();
	foreach ( $wpdb->get_results( $sql ) as $r ) { // phpcs:ignore
		$x = json_decode( $r->data, true );
		if ( ! is_array( $x ) ) {
			continue;
		}
		$o      = (int) $r->org;
		$list[] = array( 't' => isset( $x['t'] ) ? (int) $x['t'] : 0, 'u' => isset( $x['u'] ) ? (string) $x['u'] : '', 'm' => isset( $x['m'] ) ? (string) $x['m'] : '',
			'org' => $o, 'kurum' => isset( $ad[ $o ] ) ? $ad[ $o ] : '#' . $o, 'ben' => (int) $r->updated_by === $ben );
	}
	return array( 'liste' => $list, 'yeni' => $yeni );
}

/* Bir kurumun kullanıcıları: son girişler (cihaz, IP), tanınan cihazlar; önizleme için kimlik */
function sides_ana_kurum_kullanicilar( WP_REST_Request $req ) {
	$id = (int) $req['id'];
	if ( ! sides_org( $id ) ) {
		return new WP_Error( 'sides_yok', 'Kurum bulunamadı.', array( 'status' => 404 ) );
	}
	$out = array();
	foreach ( get_users( array( 'meta_key' => 'sides_org', 'meta_value' => (string) $id ) ) as $u ) {
		$g = get_user_meta( $u->ID, 'sides_girisler', true );
		$g = is_array( $g ) ? array_slice( array_reverse( $g ), 0, 5 ) : array();
		$c = array();
		foreach ( array_reverse( sides_cihaz_listesi( $u->ID ) ) as $x ) {
			$c[] = array( 'ad' => isset( $x['ad'] ) ? $x['ad'] : '', 'ilk' => isset( $x['ilk'] ) ? (int) $x['ilk'] : 0, 'son' => isset( $x['son'] ) ? (int) $x['son'] : 0, 'ip' => isset( $x['ip'] ) ? $x['ip'] : '' );
		}
		$rol   = (string) get_user_meta( $u->ID, 'sides_rol', true );
		$out[] = array( 'id' => $u->ID, 'ad' => $u->display_name, 'email' => $u->user_email, 'rol' => $rol,
			'sonGiris' => (int) get_user_meta( $u->ID, 'sides_son_giris', true ), 'girisler' => $g, 'cihazlar' => $c,
			'onizle' => ! user_can( $u, 'manage_options' ) && in_array( $rol, SIDES_ROLLER, true ) );
	}
	return $out;
}

function sides_ana_kurum_ekle( WP_REST_Request $req ) {
	global $wpdb;
	$p     = $req->get_json_params();
	$kurum = isset( $p['kurum'] ) ? mb_substr( sanitize_text_field( (string) $p['kurum'] ), 0, 120 ) : '';
	$ad    = isset( $p['ad'] ) ? mb_substr( sanitize_text_field( (string) $p['ad'] ), 0, 80 ) : '';
	$email = isset( $p['email'] ) ? sanitize_email( (string) $p['email'] ) : '';
	$pass  = isset( $p['sifre'] ) ? (string) $p['sifre'] : '';
	$gun   = isset( $p['gun'] ) ? max( 0, (int) $p['gun'] ) : 365;
	if ( ! $kurum || ! $ad || ! is_email( $email ) ) {
		return new WP_Error( 'sides_eksik', 'Kurum adı, yönetici adı ve geçerli bir e-posta yazın.', array( 'status' => 400 ) );
	}
	/* Bu e-postayla açılmış ama hiçbir kuruma bağlı olmayan hesap (ör. kurumdan kaldırılmış kullanıcı) yeni kurumun yöneticisi yapılır */
	$mevcut = get_user_by( 'email', $email );
	if ( $mevcut ) {
		if ( user_can( $mevcut, 'manage_options' ) ) {
			return new WP_Error( 'sides_var', 'Bu e-posta site yöneticisinin hesabına ait. Kurum yöneticisi için başka bir e-posta yazın.', array( 'status' => 409 ) );
		}
		$c = sides_ctx( $mevcut->ID );
		if ( $c['org'] ) {
			$diger = sides_org( (int) $c['org'] );
			return new WP_Error( 'sides_var', 'Bu e-posta «' . ( $diger ? $diger->ad : '#' . $c['org'] ) . '» kurumunda kayıtlı. Önce kişiyi o kurumun Kullanıcılar sayfasından silin ya da başka bir e-posta yazın.', array( 'status' => 409 ) );
		}
	}
	if ( strlen( $pass ) < 8 ) {
		return new WP_Error( 'sides_sifre', 'Şifre en az 8 karakter olmalı.', array( 'status' => 400 ) );
	}
	if ( $mevcut ) {
		$uid = $mevcut->ID;
		wp_set_password( $pass, $uid );
		wp_update_user( array( 'ID' => $uid, 'display_name' => $ad ) );
	} else {
		$uid = sides_new_wp_user( $email, $ad, $pass );
		if ( is_wp_error( $uid ) ) {
			return $uid;
		}
	}
	$org = sides_org_olustur( $kurum, $uid, 'aktif' );
	sides_org_uzat( $org, $gun, isset( $p['plan'] ) ? (string) $p['plan'] : '' );
	if ( ! empty( $p['bildir'] ) ) {
		wp_mail( $email, 'ATLAS hesabınız hazır', "Merhaba $ad,\n\n$kurum için ATLAS hesabınız açıldı.\n\nGiriş adresi: " . optik_karne_url() . "\nE-posta: $email\nŞifre: size ayrıca iletilen şifre\n\nATLAS · Akademik Takip ve Analiz Sistemi" );
	}
	return array( 'ok' => true, 'id' => $org, 'mevcut' => (bool) $mevcut );
}

function sides_org_olustur( $kurum, $uid, $durum ) {
	global $wpdb;
	$wpdb->insert( sides_orgs(), array( 'ad' => $kurum, 'anahtar' => bin2hex( random_bytes( 6 ) ), 'sahip' => $uid, 'olusturma' => current_time( 'mysql', true ), 'durum' => $durum ) );
	$org = (int) $wpdb->insert_id;
	update_user_meta( $uid, 'sides_org', $org );
	update_user_meta( $uid, 'sides_rol', 'yonetici' );
	sides_put_doc( $org, 'settings', 'main', array( 'kurum' => $kurum ) );
	return $org;
}

function sides_ana_kurum_duzenle( WP_REST_Request $req ) {
	global $wpdb;
	$id = (int) $req['id'];
	$o  = sides_org( $id );
	if ( ! $o ) {
		return new WP_Error( 'sides_yok', 'Kurum bulunamadı.', array( 'status' => 404 ) );
	}
	$p      = $req->get_json_params();
	$data   = array();
	$onceki = isset( $o->durum ) ? $o->durum : 'aktif';
	if ( isset( $p['durum'] ) && in_array( $p['durum'], array( 'aktif', 'askida', 'bekliyor' ), true ) && 1 !== $id ) {
		$data['durum'] = $p['durum'];
	}
	if ( array_key_exists( 'bitis', $p ) && 1 !== $id ) {
		$b             = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $p['bitis'] ) ? $p['bitis'] . ' 23:59:59' : null;
		$data['bitis'] = $b;
	}
	if ( isset( $p['plan'] ) ) {
		$data['plan'] = mb_substr( sanitize_text_field( (string) $p['plan'] ), 0, 60 );
	}
	if ( isset( $p['not'] ) ) {
		$data['notlar'] = mb_substr( sanitize_textarea_field( (string) $p['not'] ), 0, 2000 );
	}
	if ( $data ) {
		$wpdb->update( sides_orgs(), $data, array( 'id' => $id ) );
	}
	if ( isset( $p['kapali'] ) && is_array( $p['kapali'] ) ) {   // kurumda kapatılan modüller
		$eski = sides_kapali_moduller( $id );
		$yeni = sides_kapali_kaydet( $id, array_map( 'strval', $p['kapali'] ) );
		if ( $eski !== $yeni ) {
			sides_log( $id, $yeni ? 'Kurumda kapalı modüller: ' . implode( ', ', $yeni ) : 'Kurumda tüm modüller açıldı', 'Ana hesap' );
		}
	}
	if ( isset( $p['gun'] ) && 1 !== $id ) { // onay sırasında süre verme
		sides_org_uzat( $id, (int) $p['gun'], isset( $p['plan'] ) ? (string) $p['plan'] : null );
	}
	$yeni = sides_org( $id );
	if ( 'bekliyor' === $onceki && 'aktif' === $yeni->durum && $o->sahip && ( $u = get_userdata( (int) $o->sahip ) ) ) {
		wp_mail( $u->user_email, 'ATLAS hesabınız onaylandı', "Merhaba {$u->display_name},\n\n{$o->ad} için ATLAS başvurunuz onaylandı. Artık giriş yapabilirsiniz:\n" . optik_karne_url() . "\n\nATLAS · Akademik Takip ve Analiz Sistemi" );
		sides_log( $id, 'Hesap ana hesap tarafından onaylandı' );
	}
	return array( 'ok' => true );
}

function sides_ana_kurum_sil( WP_REST_Request $req ) {
	global $wpdb;
	$id = (int) $req['id'];
	$o  = sides_org( $id );
	if ( ! $o || 1 === $id ) {
		return new WP_Error( 'sides_yok', 'Bu kurum silinemez.', array( 'status' => 400 ) );
	}
	$p = $req->get_json_params();
	if ( ! isset( $p['onay'] ) || trim( (string) $p['onay'] ) !== trim( (string) $o->ad ) ) {
		return new WP_Error( 'sides_onay', 'Silmek için kurum adını aynen yazın.', array( 'status' => 400 ) );
	}
	require_once ABSPATH . 'wp-admin/includes/user.php';
	foreach ( get_users( array( 'meta_key' => 'sides_org', 'meta_value' => (string) $id ) ) as $u ) {
		delete_user_meta( $u->ID, 'sides_org' );
		delete_user_meta( $u->ID, 'sides_rol' );
		delete_user_meta( $u->ID, 'sides_yetki' );
		if ( array_values( (array) $u->roles ) === array( 'sides_uye' ) ) {
			wp_delete_user( $u->ID );
		}
	}
	$wpdb->delete( sides_docs(), array( 'org' => $id ) );
	$wpdb->delete( sides_orgs(), array( 'id' => $id ) );
	return array( 'ok' => true );
}

function sides_ana_kodlar() {
	global $wpdb;
	$out = array();
	foreach ( $wpdb->get_results( 'SELECT * FROM ' . sides_kodlar() . ' ORDER BY olusturma DESC LIMIT 500' ) as $r ) { // phpcs:ignore
		$o     = $r->kullanan ? sides_org( (int) $r->kullanan ) : null;
		$out[] = array( 'kod' => $r->kod, 'plan' => $r->plan, 'gun' => (int) $r->gun, 'durum' => $r->durum, 'not' => $r->notlar, 'olusturma' => $r->olusturma, 'kurum' => $o ? $o->ad : '', 'kullanma' => $r->kullanma );
	}
	return $out;
}

function sides_ana_kod_uret( WP_REST_Request $req ) {
	global $wpdb;
	$p    = $req->get_json_params();
	$adet = max( 1, min( 50, isset( $p['adet'] ) ? (int) $p['adet'] : 1 ) );
	$gun  = max( 0, min( 3650, isset( $p['gun'] ) ? (int) $p['gun'] : 365 ) );
	$plan = isset( $p['plan'] ) ? mb_substr( sanitize_text_field( (string) $p['plan'] ), 0, 60 ) : '';
	$not  = isset( $p['not'] ) ? mb_substr( sanitize_text_field( (string) $p['not'] ), 0, 250 ) : '';
	$yeni = array();
	for ( $i = 0; $i < $adet; $i++ ) {
		do {
			$k = sides_kod_uret();
		} while ( $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . sides_kodlar() . ' WHERE kod = %s', $k ) ) ); // phpcs:ignore
		$wpdb->insert( sides_kodlar(), array( 'kod' => $k, 'plan' => $plan, 'gun' => $gun, 'durum' => 'bos', 'notlar' => $not, 'olusturma' => current_time( 'mysql', true ) ) );
		$yeni[] = $k;
	}
	return array( 'kodlar' => $yeni );
}

function sides_ana_kod_iptal( WP_REST_Request $req ) {
	global $wpdb;
	$wpdb->update( sides_kodlar(), array( 'durum' => 'iptal' ), array( 'kod' => $req['kod'], 'durum' => 'bos' ) );
	return array( 'ok' => true );
}

function sides_ana_ayar() {
	$engel = get_option( 'sides_kayit_engel' );
	if ( ! is_array( $engel ) || empty( $engel['t'] ) || time() - (int) $engel['t'] > 30 * DAY_IN_SECONDS ) {
		$engel = null;
	}
	return array( 'yontem' => sides_kayit_yontemi(), 'dogrulama' => sides_opt_dogrulama(), 'kayitUrl' => optik_karne_url( array( 'sayfa' => 'kaydol' ) ), 'engel' => $engel );
}

function sides_ana_ayar_kaydet( WP_REST_Request $req ) {
	$p = $req->get_json_params();
	if ( isset( $p['yontem'] ) && in_array( $p['yontem'], SIDES_YONTEMLER, true ) ) {
		update_option( 'sides_kayit_yontemi', $p['yontem'] );
	}
	if ( isset( $p['dogrulama'] ) ) {
		update_option( 'sides_eposta_dogrulama', $p['dogrulama'] ? '1' : '0' );
	}
	if ( ! empty( $p['engelSil'] ) ) {
		delete_option( 'sides_kayit_engel' );
	}
	return sides_ana_ayar();
}

/* Ana hesap kontrol paneli: tüm kurumların toplamları */
function sides_ana_ozet() {
	global $wpdb;
	$t   = sides_docs();
	$o   = sides_orgs();
	$say = array();
	foreach ( (array) $wpdb->get_results( "SELECT coll, COUNT(*) AS n FROM $t WHERE org > 0 GROUP BY coll" ) as $r ) { // phpcs:ignore
		$say[ $r->coll ] = (int) $r->n;
	}
	$kurum = array( 'toplam' => 0, 'aktif' => 0, 'bekliyor' => 0, 'askida' => 0, 'suresi' => 0 );
	$simdi = current_time( 'mysql', true );
	foreach ( (array) $wpdb->get_results( "SELECT durum, bitis FROM $o" ) as $r ) { // phpcs:ignore
		$kurum['toplam']++;
		if ( 'aktif' === $r->durum && $r->bitis && $r->bitis < $simdi ) {
			$kurum['suresi']++;
		} elseif ( isset( $kurum[ $r->durum ] ) ) {
			$kurum[ $r->durum ]++;
		}
	}
	$en = array();
	foreach ( (array) $wpdb->get_results( "SELECT d.org, COUNT(*) AS n, o.ad FROM $t d JOIN $o o ON o.id = d.org WHERE d.coll = 'students' GROUP BY d.org, o.ad ORDER BY n DESC LIMIT 8" ) as $r ) { // phpcs:ignore
		$en[] = array( 'ad' => $r->ad, 'n' => (int) $r->n );
	}
	return array( 'say' => $say, 'genelHavuz' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM $t WHERE org = 0 AND coll = 'havuz'" ), 'kurum' => $kurum, 'enCok' => $en ); // phpcs:ignore
}

/* Konu ve kazanım listeleri: ana hesabın tüm kurumlar için belirlediği liste (ders|sınıf → metin) */
function sides_ana_mufredat( WP_REST_Request $req ) {
	$p   = $req->get_json_params();
	$k   = isset( $p['anahtar'] ) ? mb_substr( sanitize_text_field( (string) $p['anahtar'] ), 0, 80 ) : '';
	$m   = get_option( 'sides_mufredat' );
	$m   = is_array( $m ) ? $m : array();
	if ( ! $k || false === strpos( $k, '|' ) ) {
		return new WP_Error( 'sides_eksik', 'Ders ve sınıf seçin.', array( 'status' => 400 ) );
	}
	$metin = isset( $p['metin'] ) ? (string) $p['metin'] : '';
	if ( '' === trim( $metin ) ) {
		unset( $m[ $k ] );
	} else {
		$m[ $k ] = mb_substr( sanitize_textarea_field( $metin ), 0, 20000 );
	}
	update_option( 'sides_mufredat', $m, false );
	return array( 'mufredat' => $m ? $m : new stdClass() );
}
