<?php
/* Optik tasarımı (v7.4): hazır tasarımlar ve kuruma özel (düzenlenebilir) optik şablonları.
   - Özel şablonlar sides_docs 'osablon' koleksiyonunda: { ad, p: { sablon, …, duzen }, kontrol: { imza, ok, t }, guncelleme }.
     Kurum başına en çok 10 özel şablon. Parametreler sunucuda beyaz listeyle doğrulanır (yerleşim geometrisi istemcide hesaplanır).
   - Kurum varsayılanı settings.main.optikVarsayilan = hazır tasarım anahtarı ya da özel şablon kimliği (özel şablon ancak okuma
     güvenliği testinden geçtiyse varsayılan yapılabilir).
   - Sınava özel seçim, sınav kaydında optikSablon = { id, ad, p } anlık görüntüsü olarak durur (PUT /doc/exams ile); okutma
     bağlantısı (GET scan/exams) sınavlara bu anlık görüntüyü ekler ki formlar basıldığı yerleşimle okunsun.
   Rotalar: GET optik/sablonlar · PUT/DELETE optik/sablon/<id> · POST optik/varsayilan { id, tur: 'deneme'|'test' }
   v7.8: testler de tasarım alır (test kaydında optikSablon; kurum varsayılanı settings.main.optikVarsayilanTest). Serbest düzen yarım A4
   ve A6 kâğıtta da olabilir (duzen.kagit); A6 yalnız testlerde. Görünüm alanları: alanlar (öğrenci bilgileri), adlar (basılı ders adları), altBilgi. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function sides_os_hazir() {
	return array( 'klasik', 'modern', 'sade', 'kurumsal', 'dostu', 'yatay', 'solpanel', 'minimal', 'a6serit', 'a6sade', 'ozel' );
}
/* Hazır tasarımların kullanım alanı (engine.js OPT_PRESET.tur ile aynı) */
function sides_os_hazir_tur( $k ) {
	if ( in_array( $k, array( 'yatay', 'solpanel', 'minimal' ), true ) ) {
		return 'deneme';
	}
	if ( in_array( $k, array( 'a6serit', 'a6sade' ), true ) ) {
		return 'test';
	}
	return 'hepsi';
}
function sides_os_enum() {
	return array(
		'kagit'    => array( 'oto', 'buyuk', 'tam', 'yarim', 'a6' ),
		'sutunAra' => array( 'dar', 'normal', 'genis' ),
		'qr'       => array( 'oto', 'sol', 'sag' ),
		'logo'     => array( 'yok', 'sol', 'sag' ),
		'palet'    => array( 'gri', 'yok', 'mavi', 'yesil', 'mor', 'turuncu', 'turkuaz', 'renkli' ),
		'yazi'     => array( 'rubik', 'sistem', 'serif' ),
	);
}
function sides_os_okuyabilir() {
	return sides_can( 'sinav', 1 ) || sides_can( 'nehari', 1 ) || sides_can( 'karne', 1 ) || sides_can( 'test', 1 );
}
/* Test varsayılanını kim değiştirir: Test ya da Nehari modülünde tam yetkili (gözlemci değil) */
function sides_os_test_yazabilir() {
	return ! sides_is_observer() && ( sides_can( 'test', 2 ) || sides_can( 'nehari', 2 ) );
}
function sides_os_yazabilir() {
	return ! sides_is_observer() && ( sides_can( 'sinav', 2 ) || sides_can( 'nehari', 2 ) );
}
function sides_os_sayi( $v, $a, $b ) {
	if ( ! is_numeric( $v ) ) {
		return null;
	}
	$n = (float) $v;
	return ( $n < $a - 1e-9 || $n > $b + 1e-9 ) ? null : round( $n * 100 ) / 100;
}
/* Dikdörtgen: x, y, w, h sayı; sayfa içinde (0–210 × 0–297) */
function sides_os_rect( $r, $minw, $minh ) {
	if ( ! is_array( $r ) ) {
		return null;
	}
	$x = sides_os_sayi( isset( $r['x'] ) ? $r['x'] : null, 0, 210 );
	$y = sides_os_sayi( isset( $r['y'] ) ? $r['y'] : null, 0, 297 );
	$w = sides_os_sayi( isset( $r['w'] ) ? $r['w'] : null, $minw, 210 );
	$h = sides_os_sayi( isset( $r['h'] ) ? $r['h'] : null, $minh, 297 );
	if ( null === $x || null === $y || null === $w || null === $h ) {
		return null;
	}
	return array( 'x' => $x, 'y' => $y, 'w' => $w, 'h' => $h );
}
/* Parametre kümesini doğrular ve temizler; hata metni ya da temiz dizi döner */
function sides_os_temizle( $p ) {
	if ( ! is_array( $p ) ) {
		return 'Tasarım parametreleri eksik.';
	}
	$izin = array( 'sablon', 'kagit', 'yuvarlak', 'satir', 'sutunAra', 'yogun', 'kitapcik', 'adSatir', 'qr', 'logo', 'kose', 'palet', 'renk', 'yazi', 'baslik', 'yonerge', 'ipucu', 'kurum', 'tarih', 'sinif', 'duzen', 'alanlar', 'adlar', 'altBilgi' );
	foreach ( array_keys( $p ) as $k ) {
		if ( ! in_array( $k, $izin, true ) ) {
			return 'Bilinmeyen parametre: ' . sanitize_key( (string) $k );
		}
	}
	$out = array();
	$out['sablon'] = isset( $p['sablon'] ) && in_array( $p['sablon'], sides_os_hazir(), true ) ? $p['sablon'] : 'klasik';
	foreach ( sides_os_enum() as $k => $vals ) {
		if ( isset( $p[ $k ] ) ) {
			if ( ! in_array( $p[ $k ], $vals, true ) ) {
				return 'Geçersiz seçenek: ' . $k;
			}
			$out[ $k ] = $p[ $k ];
		}
	}
	foreach ( array( 'yuvarlak' => array( 0.85, 1.25 ), 'satir' => array( 0.9, 1.3 ), 'kose' => array( 0, 2.5 ) ) as $k => $ab ) {
		if ( isset( $p[ $k ] ) ) {
			$v = sides_os_sayi( $p[ $k ], $ab[0], $ab[1] );
			if ( null === $v ) {
				return 'Aralık dışı değer: ' . $k;
			}
			$out[ $k ] = $v;
		}
	}
	foreach ( array( 'yogun', 'kitapcik', 'adSatir', 'ipucu', 'kurum', 'tarih', 'sinif' ) as $k ) {
		if ( isset( $p[ $k ] ) ) {
			$out[ $k ] = (bool) $p[ $k ];
		}
	}
	foreach ( array( 'baslik' => 60, 'yonerge' => 160, 'altBilgi' => 120 ) as $k => $max ) {
		if ( isset( $p[ $k ] ) ) {
			if ( ! is_string( $p[ $k ] ) || mb_strlen( $p[ $k ] ) > $max ) {
				return 'Metin çok uzun: ' . $k;
			}
			$out[ $k ] = sanitize_text_field( $p[ $k ] );
		}
	}
	if ( isset( $p['renk'] ) ) {
		if ( ! is_string( $p['renk'] ) || ! preg_match( '/^#[0-9a-f]{6}$/i', $p['renk'] ) ) {
			return 'Renk #rrggbb biçiminde olmalı.';
		}
		$out['renk'] = strtolower( $p['renk'] );
	}
	// v7.8: öğrenci bilgi alanları (sıralı, tekrarsız) ve basılı ders adları (yalnızca görünüm)
	if ( array_key_exists( 'alanlar', $p ) && null !== $p['alanlar'] ) {
		if ( ! is_array( $p['alanlar'] ) || count( $p['alanlar'] ) > 5 ) {
			return 'Öğrenci bilgi alanları geçersiz.';
		}
		$al = array();
		foreach ( $p['alanlar'] as $a ) {
			if ( ! is_string( $a ) || ! in_array( $a, array( 'ad', 'no', 'sinif', 'okul', 'kod' ), true ) ) {
				return 'Bilinmeyen öğrenci bilgi alanı.';
			}
			if ( ! in_array( $a, $al, true ) ) {
				$al[] = $a;
			}
		}
		$out['alanlar'] = $al;
	}
	if ( array_key_exists( 'adlar', $p ) && null !== $p['adlar'] ) {
		if ( ! is_array( $p['adlar'] ) || count( $p['adlar'] ) > 16 ) {
			return 'Ders adları geçersiz (en çok 16).';
		}
		$ad = array();
		foreach ( $p['adlar'] as $k => $v ) {
			$k = mb_substr( trim( mb_strtolower( (string) $k ) ), 0, 40 );
			if ( '' === $k || ! is_string( $v ) || mb_strlen( $v ) > 24 ) {
				return 'Basılı ders adı en çok 24 karakter olabilir.';
			}
			$v = trim( sanitize_text_field( $v ) );
			if ( '' !== $v ) {
				$ad[ sanitize_text_field( $k ) ] = $v;
			}
		}
		if ( $ad ) {
			$out['adlar'] = $ad;
		}
	}
	if ( array_key_exists( 'duzen', $p ) && null !== $p['duzen'] ) {
		$d = $p['duzen'];
		if ( ! is_array( $d ) || ! isset( $d['ogeler'] ) || ! is_array( $d['ogeler'] ) ) {
			return 'Düzen bilgisi geçersiz.';
		}
		$o     = $d['ogeler'];
		$kagit = isset( $d['kagit'] ) ? $d['kagit'] : 'tam';
		if ( ! in_array( $kagit, array( 'tam', 'yarim', 'a6' ), true ) ) {
			return 'Düzen kâğıdı geçersiz.';
		}
		$qrs = array( 'tam' => array( 22, 34 ), 'yarim' => array( 20, 30 ), 'a6' => array( 18, 26 ) );
		$min = array( 'baslik' => array( 40, 8 ), 'bilgi' => array( 30, 10 ), 'kitapcik' => array( 34, 8 ), 'yonerge' => array( 30, 8 ), 'alan' => array( 28, 18 ) );
		$og  = array();
		foreach ( array( 'baslik', 'bilgi', 'alan' ) as $k ) {
			$r = sides_os_rect( isset( $o[ $k ] ) ? $o[ $k ] : null, $min[ $k ][0], $min[ $k ][1] );
			if ( ! $r ) {
				return 'Düzen öğesi geçersiz: ' . $k;
			}
			$og[ $k ] = $r;
		}
		foreach ( array( 'kitapcik', 'yonerge' ) as $k ) {
			if ( ! isset( $o[ $k ] ) || null === $o[ $k ] ) {
				$og[ $k ] = null;
				continue;
			}
			$r = sides_os_rect( $o[ $k ], $min[ $k ][0], $min[ $k ][1] );
			if ( ! $r ) {
				return 'Düzen öğesi geçersiz: ' . $k;
			}
			$og[ $k ] = $r;
		}
		$q = isset( $o['qr'] ) && is_array( $o['qr'] ) ? $o['qr'] : null;
		$qx = $q ? sides_os_sayi( isset( $q['x'] ) ? $q['x'] : null, 0, 210 ) : null;
		$qy = $q ? sides_os_sayi( isset( $q['y'] ) ? $q['y'] : null, 0, 297 ) : null;
		$qs = $q ? sides_os_sayi( isset( $q['s'] ) ? $q['s'] : null, $qrs[ $kagit ][0], $qrs[ $kagit ][1] ) : null;
		if ( null === $qx || null === $qy || null === $qs ) {
			return 'QR kod konumu veya boyutu geçersiz (' . $qrs[ $kagit ][0] . '–' . $qrs[ $kagit ][1] . ' mm).';
		}
		$og['qr'] = array( 'x' => $qx, 'y' => $qy, 's' => $qs );
		$bl = array();
		if ( isset( $d['bloklar'] ) ) {
			if ( ! is_array( $d['bloklar'] ) || count( $d['bloklar'] ) > 12 ) {
				return 'Blok listesi geçersiz (en çok 12).';
			}
			foreach ( $d['bloklar'] as $b ) {
				if ( null === $b ) {
					$bl[] = null;
					continue;
				}
				if ( ! is_array( $b ) ) {
					return 'Blok bilgisi geçersiz.';
				}
				$x = sides_os_sayi( isset( $b['x'] ) ? $b['x'] : null, 0, 210 );
				$y = sides_os_sayi( isset( $b['y'] ) ? $b['y'] : null, 0, 297 );
				$s = isset( $b['sutun'] ) && is_numeric( $b['sutun'] ) ? (int) $b['sutun'] : 0;
				if ( null === $x || null === $y || $s < 1 || $s > 8 ) {
					return 'Blok konumu veya sütun sayısı geçersiz (1–8).';
				}
				$bl[] = array( 'x' => $x, 'y' => $y, 'sutun' => $s );
			}
		}
		$ss = isset( $d['sutunSatir'] ) && is_numeric( $d['sutunSatir'] ) ? (int) $d['sutunSatir'] : 0;
		if ( $ss && ( $ss < 4 || $ss > 30 ) ) {
			return 'Sütun başına satır 4–30 arasında olmalı.';
		}
		$out['duzen'] = array(
			'ogeler'     => $og,
			'bloklar'    => $bl,
			'akis'       => isset( $d['akis'] ) && 'raf' === $d['akis'] ? 'raf' : 'sutun',
			'sutunSatir' => $ss,
			'bant'       => ! empty( $d['bant'] ),
			'cerceve'    => ! isset( $d['cerceve'] ) || (bool) $d['cerceve'],
		);
		// v7.8 ek alanları (varsayılandan farklıysa): kâğıt, ders sırası, ders başına sütun, en çok sütun
		if ( 'tam' !== $kagit ) {
			$out['duzen']['kagit'] = $kagit;
		}
		foreach ( array( 'sira' => array( 0, 11 ), 'bsutun' => array( 0, 8 ) ) as $k => $ab ) {
			if ( ! isset( $d[ $k ] ) ) {
				continue;
			}
			if ( ! is_array( $d[ $k ] ) || count( $d[ $k ] ) > 12 ) {
				return 'Düzen listesi geçersiz: ' . $k;
			}
			$li = array();
			foreach ( $d[ $k ] as $v ) {
				if ( ! is_numeric( $v ) || (int) $v < $ab[0] || (int) $v > $ab[1] ) {
					return 'Düzen listesi geçersiz: ' . $k;
				}
				$li[] = (int) $v;
			}
			if ( 'sira' === $k && count( array_unique( $li ) ) !== count( $li ) ) {
				return 'Ders sırası geçersiz.';
			}
			if ( $li ) {
				$out['duzen'][ $k ] = $li;
			}
		}
		if ( isset( $d['sutunMax'] ) && is_numeric( $d['sutunMax'] ) && (int) $d['sutunMax'] ) {
			$sm = (int) $d['sutunMax'];
			if ( $sm < 1 || $sm > 8 ) {
				return 'En çok sütun 1–8 arasında olmalı.';
			}
			$out['duzen']['sutunMax'] = $sm;
		}
	}
	return $out;
}
function sides_os_liste( $org ) {
	global $wpdb;
	$t    = sides_docs();
	$rows = $wpdb->get_results( $wpdb->prepare( "SELECT coll, id, token, data FROM $t WHERE org = %d AND coll = 'osablon' ORDER BY id", $org ) ); // phpcs:ignore
	$out  = array();
	foreach ( (array) $rows as $r ) {
		$d = sides_row_out( $r );
		$out[] = array(
			'id'         => $d['id'],
			'ad'         => isset( $d['ad'] ) ? (string) $d['ad'] : '',
			'p'          => isset( $d['p'] ) && is_array( $d['p'] ) ? $d['p'] : array(),
			'kontrol'    => isset( $d['kontrol'] ) && is_array( $d['kontrol'] ) ? $d['kontrol'] : null,
			'guncelleme' => isset( $d['guncelleme'] ) ? (int) $d['guncelleme'] : 0,
		);
	}
	return $out;
}
function sides_os_varsayilan( $org, $tur = 'deneme' ) {
	$s   = sides_get_doc( (int) $org, 'settings', 'main' );
	$key = 'test' === $tur ? 'optikVarsayilanTest' : 'optikVarsayilan';
	$v   = is_array( $s ) && isset( $s[ $key ] ) && is_string( $s[ $key ] ) ? $s[ $key ] : 'klasik';
	if ( in_array( $v, sides_os_hazir(), true ) && 'ozel' !== $v ) {
		return $v;
	}
	if ( preg_match( '/^os[a-z0-9]{4,24}$/', $v ) && sides_get_doc( (int) $org, 'osablon', $v ) ) {
		return $v;
	}
	return 'klasik';
}
function sides_os_varsayilan_yaz( $org, $id, $tur = 'deneme' ) {
	$s = sides_get_doc( $org, 'settings', 'main' );
	if ( ! is_array( $s ) ) {
		$s = array();
	}
	unset( $s['id'] );
	$s[ 'test' === $tur ? 'optikVarsayilanTest' : 'optikVarsayilan' ] = $id;
	return false !== sides_put_doc( $org, 'settings', 'main', $s );
}

function sides_os_rest_liste( WP_REST_Request $req ) {
	$org = sides_org_id();
	$res = rest_ensure_response( array( 'sablonlar' => sides_os_liste( $org ), 'varsayilan' => sides_os_varsayilan( $org ), 'varsayilanTest' => sides_os_varsayilan( $org, 'test' ), 'limit' => 10 ) );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}
function sides_os_rest_put( WP_REST_Request $req ) {
	$org = sides_org_id();
	$id  = (string) $req['id'];
	$p   = $req->get_json_params();
	if ( ! is_array( $p ) ) {
		return new WP_Error( 'sides_os', 'Geçersiz veri.', array( 'status' => 400 ) );
	}
	foreach ( array_keys( $p ) as $k ) {
		if ( ! in_array( $k, array( 'ad', 'p', 'kontrol' ), true ) ) {
			return new WP_Error( 'sides_os', 'Bilinmeyen alan: ' . sanitize_key( (string) $k ), array( 'status' => 400 ) );
		}
	}
	$ad = isset( $p['ad'] ) && is_string( $p['ad'] ) ? trim( sanitize_text_field( $p['ad'] ) ) : '';
	if ( '' === $ad || mb_strlen( $ad ) > 60 ) {
		return new WP_Error( 'sides_os', 'Şablon adı 1–60 karakter olmalı.', array( 'status' => 400 ) );
	}
	$temiz = sides_os_temizle( isset( $p['p'] ) ? $p['p'] : null );
	if ( is_string( $temiz ) ) {
		return new WP_Error( 'sides_os', $temiz, array( 'status' => 400 ) );
	}
	if ( empty( $temiz['duzen'] ) ) {
		return new WP_Error( 'sides_os', 'Özel şablonda düzen bilgisi bulunmalı.', array( 'status' => 400 ) );
	}
	$kontrol = null;
	if ( isset( $p['kontrol'] ) && is_array( $p['kontrol'] ) ) {
		$kontrol = array(
			'imza'  => isset( $p['kontrol']['imza'] ) ? substr( preg_replace( '/[^A-Za-z0-9_:|,.\-]/', '', (string) $p['kontrol']['imza'] ), 0, 120 ) : '',
			'ok'    => ! empty( $p['kontrol']['ok'] ),
			't'     => isset( $p['kontrol']['t'] ) && is_numeric( $p['kontrol']['t'] ) ? (int) $p['kontrol']['t'] : time() * 1000,
			'mesaj' => isset( $p['kontrol']['mesaj'] ) ? mb_substr( sanitize_text_field( (string) $p['kontrol']['mesaj'] ), 0, 200 ) : '',
		);
	}
	$eski = sides_get_doc( $org, 'osablon', $id );
	if ( ! $eski ) {
		global $wpdb;
		$t = sides_docs();
		$n = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE org = %d AND coll = 'osablon'", $org ) ); // phpcs:ignore
		if ( $n >= 10 ) {
			return new WP_Error( 'sides_os', 'En çok 10 özel şablon kaydedilebilir. Önce birini silin.', array( 'status' => 400 ) );
		}
	}
	$doc = array( 'ad' => $ad, 'p' => $temiz, 'kontrol' => $kontrol, 'guncelleme' => (int) round( microtime( true ) * 1000 ), 'olusturma' => $eski && isset( $eski['olusturma'] ) ? (int) $eski['olusturma'] : (int) round( microtime( true ) * 1000 ) );
	if ( false === sides_put_doc( $org, 'osablon', $id, $doc ) ) {
		return new WP_Error( 'sides_db', 'Şablon kaydedilemedi.', array( 'status' => 500 ) );
	}
	// Varsayılan bu şablonsa ve test artık geçerli değilse varsayılan klasiğe döner
	foreach ( array( 'deneme', 'test' ) as $tur ) {
		if ( sides_os_varsayilan( $org, $tur ) === $id && ! ( $kontrol && $kontrol['ok'] ) ) {
			sides_os_varsayilan_yaz( $org, 'klasik', $tur );
		}
	}
	sides_log( $org, 'Optik şablonu kaydedildi: ' . $ad );
	$res = rest_ensure_response( array( 'id' => $id ) + $doc + array( 'varsayilan' => sides_os_varsayilan( $org ), 'varsayilanTest' => sides_os_varsayilan( $org, 'test' ) ) );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}
function sides_os_rest_sil( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$id  = (string) $req['id'];
	$d   = sides_get_doc( $org, 'osablon', $id );
	if ( ! $d ) {
		return new WP_Error( 'sides_os', 'Şablon bulunamadı.', array( 'status' => 404 ) );
	}
	if ( false === $wpdb->delete( sides_docs(), array( 'org' => $org, 'coll' => 'osablon', 'id' => $id ) ) ) {
		return new WP_Error( 'sides_db', 'Silinemedi.', array( 'status' => 500 ) );
	}
	foreach ( array( 'deneme', 'test' ) as $tur ) {
		if ( sides_os_varsayilan( $org, $tur ) === $id ) {
			sides_os_varsayilan_yaz( $org, 'klasik', $tur );
		}
	}
	sides_log( $org, 'Optik şablonu silindi: ' . ( isset( $d['ad'] ) ? $d['ad'] : $id ) );
	$res = rest_ensure_response( array( 'ok' => true, 'varsayilan' => sides_os_varsayilan( $org ), 'varsayilanTest' => sides_os_varsayilan( $org, 'test' ) ) );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}
function sides_os_rest_varsayilan( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	$id  = is_array( $p ) && isset( $p['id'] ) && is_string( $p['id'] ) ? $p['id'] : '';
	$tur = is_array( $p ) && isset( $p['tur'] ) && 'test' === $p['tur'] ? 'test' : 'deneme';
	// v7.8: deneme varsayılanı Deneme/Nehari, test varsayılanı Test/Nehari yetkisiyle
	if ( 'test' === $tur ? ! sides_os_test_yazabilir() : ! sides_os_yazabilir() ) {
		return sides_deny( 'Varsayılan optik tasarımını değiştirme yetkiniz yok.' );
	}
	if ( in_array( $id, sides_os_hazir(), true ) && 'ozel' !== $id ) {
		$ht = sides_os_hazir_tur( $id );
		if ( 'hepsi' !== $ht && $ht !== $tur ) {
			return new WP_Error( 'sides_os', 'test' === $tur ? 'Bu tasarım testler için kullanılamaz.' : 'Bu tasarım denemeler için kullanılamaz.', array( 'status' => 400 ) );
		}
	} elseif ( preg_match( '/^os[a-z0-9]{4,24}$/', $id ) ) {
		$d = sides_get_doc( $org, 'osablon', $id );
		if ( ! $d ) {
			return new WP_Error( 'sides_os', 'Şablon bulunamadı.', array( 'status' => 400 ) );
		}
		if ( empty( $d['kontrol'] ) || empty( $d['kontrol']['ok'] ) ) {
			return new WP_Error( 'sides_os', 'Bu şablon okuma güvenliği testinden geçmedi; önce düzenleyicide testi çalıştırın.', array( 'status' => 400 ) );
		}
		if ( 'deneme' === $tur && isset( $d['p']['duzen']['kagit'] ) && 'a6' === $d['p']['duzen']['kagit'] ) {
			return new WP_Error( 'sides_os', 'A6 şablonlar yalnızca testlerde kullanılabilir.', array( 'status' => 400 ) );
		}
	} else {
		return new WP_Error( 'sides_os', 'Bilinmeyen optik tasarımı.', array( 'status' => 400 ) );
	}
	if ( ! sides_os_varsayilan_yaz( $org, $id, $tur ) ) {
		return new WP_Error( 'sides_db', 'Ayar kaydedilemedi.', array( 'status' => 500 ) );
	}
	sides_log( $org, ( 'test' === $tur ? 'Testler için varsayılan optik tasarımı: ' : 'Varsayılan optik tasarımı: ' ) . $id );
	$res = rest_ensure_response( array( 'varsayilan' => $id, 'tur' => $tur ) );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}

add_action( 'rest_api_init', function () {
	$ns   = 'optik-karne/v1';
	$oku  = function () { return sides_os_okuyabilir() ? true : sides_deny( 'Optik tasarımlarını görme yetkiniz yok.' ); };
	$yaz  = function () {
		if ( sides_is_observer() ) {
			return sides_deny( 'Gözlemci hesabının işlem yetkisi yok. Yöneticinizden izin isteyin.' );
		}
		return sides_os_yazabilir() ? true : sides_deny( 'Optik tasarımını değiştirme yetkiniz yok.' );
	};
	register_rest_route( $ns, '/optik/sablonlar', array( 'methods' => 'GET', 'callback' => 'sides_os_rest_liste', 'permission_callback' => $oku ) );
	register_rest_route( $ns, '/optik/sablon/(?P<id>os[a-z0-9]{4,24})', array(
		array( 'methods' => 'PUT', 'callback' => 'sides_os_rest_put', 'permission_callback' => $yaz ),
		array( 'methods' => 'DELETE', 'callback' => 'sides_os_rest_sil', 'permission_callback' => $yaz ),
	) );
	// varsayılan: modül yetkisi geri çağrıda (deneme → Deneme/Nehari, test → Test/Nehari)
	$vyaz = function () {
		if ( sides_is_observer() ) {
			return sides_deny( 'Gözlemci hesabının işlem yetkisi yok. Yöneticinizden izin isteyin.' );
		}
		return sides_os_yazabilir() || sides_os_test_yazabilir() ? true : sides_deny( 'Optik tasarımını değiştirme yetkiniz yok.' );
	};
	register_rest_route( $ns, '/optik/varsayilan', array( 'methods' => 'POST', 'callback' => 'sides_os_rest_varsayilan', 'permission_callback' => $vyaz ) );
} );

/* Okutma bağlantısı: scan/exams yanıtındaki sınavlara basımda alınan optikSablon anlık görüntüsü eklenir (rest.php değişmeden).
   Yalnızca temizlenmiş parametreler gönderilir; form basılırken kaydedilen yerleşim okumada aynen kullanılır. */
add_filter( 'rest_post_dispatch', function ( $res, $server, $req ) {
	if ( ! ( $res instanceof WP_REST_Response ) || $res->is_error() ) {
		return $res;
	}
	if ( '/optik-karne/v1/scan/exams' !== (string) $req->get_route() ) {
		return $res;
	}
	$d = $res->get_data();
	if ( ! is_array( $d ) || empty( $d['exams'] ) || ! is_array( $d['exams'] ) || ! function_exists( 'sides_scan_ctx' ) ) {
		return $res;
	}
	$sc = sides_scan_ctx( $req );
	if ( ! $sc || empty( $sc['org'] ) ) {
		return $res;
	}
	foreach ( $d['exams'] as $i => $e ) {
		if ( ! is_array( $e ) || empty( $e['id'] ) ) {
			continue;
		}
		// v7.8: testlerin anlık görüntüsü test kaydında
		$full = sides_get_doc( (int) $sc['org'], ! empty( $e['tip'] ) && 'test' === $e['tip'] ? 'testler' : 'exams', (string) $e['id'] );
		// v7.9.26: dış optik (yayınevi formu) şablonu: okutma bağlantısında da aynı okuyucu kullanılır (görsel kimliği gönderilmez)
		if ( $full && empty( $e['tip'] ) && ! empty( $full['disOptik'] ) && is_array( $full['disOptik'] ) ) {
			$dop = sides_dop_temizle( $full['disOptik'] );
			if ( $dop ) {
				$d['exams'][ $i ]['disOptik'] = $dop;
			}
		}
		if ( ! $full || empty( $full['optikSablon'] ) || ! is_array( $full['optikSablon'] ) || empty( $full['optikSablon']['p'] ) ) {
			continue;
		}
		$temiz = sides_os_temizle( $full['optikSablon']['p'] );
		if ( is_array( $temiz ) ) {
			$d['exams'][ $i ]['optikSablon'] = array( 'id' => isset( $full['optikSablon']['id'] ) ? (string) $full['optikSablon']['id'] : '', 'ad' => isset( $full['optikSablon']['ad'] ) ? (string) $full['optikSablon']['ad'] : '', 'p' => $temiz );
		}
	}
	$res->set_data( $d );
	return $res;
}, 10, 3 );

/* v7.9.26 Dış optik şablonunun okutma bağlantısına giden temiz kopyası: yalnızca okumada gereken sayısal alanlar,
   değer dizisi, taban koyulukları ve base64 yama / profil metinleri (biçim ve uzunluk denetimiyle). */
function sides_dop_temizle( $s ) {
	if ( ! is_array( $s ) || 1 !== (int) ( isset( $s['v'] ) ? $s['v'] : 0 ) || empty( $s['capa'] ) || ! is_array( $s['capa'] ) || 4 !== count( $s['capa'] ) || empty( $s['alanlar'] ) || ! is_array( $s['alanlar'] ) ) {
		return null;
	}
	$b64 = function ( $v, $max ) {
		$v = is_string( $v ) ? $v : '';
		return ( strlen( $v ) <= $max && preg_match( '/^[A-Za-z0-9+\/=]*$/', $v ) ) ? $v : '';
	};
	$sayi = function ( $v, $min, $max ) {
		$v = is_numeric( $v ) ? (float) $v : 0;
		return max( $min, min( $max, $v ) );
	};
	$ref  = isset( $s['ref'] ) && is_array( $s['ref'] ) ? $s['ref'] : array();
	$out  = array(
		'v'       => 1,
		'ad'      => mb_substr( sanitize_text_field( isset( $s['ad'] ) ? (string) $s['ad'] : '' ), 0, 60 ),
		'bos'     => ! isset( $s['bos'] ) || false !== $s['bos'],
		'ref'     => array( 'w' => (int) $sayi( isset( $ref['w'] ) ? $ref['w'] : 0, 1, 4000 ), 'h' => (int) $sayi( isset( $ref['h'] ) ? $ref['h'] : 0, 1, 8000 ) ),
		'capa'    => array(),
		'alanlar' => array(),
	);
	foreach ( $s['capa'] as $c ) {
		if ( ! is_array( $c ) ) {
			return null;
		}
		$out['capa'][] = array( 'x' => $sayi( isset( $c['x'] ) ? $c['x'] : 0, -500, 8000 ), 'y' => $sayi( isset( $c['y'] ) ? $c['y'] : 0, -500, 8000 ), 'p' => $b64( isset( $c['p'] ) ? $c['p'] : '', 8000 ) );
	}
	foreach ( array_slice( $s['alanlar'], 0, 40 ) as $a ) {
		if ( ! is_array( $a ) || empty( $a['tur'] ) || ! in_array( $a['tur'], array( 'ders', 'no', 'ad', 'kitapcik' ), true ) ) {
			continue;
		}
		$o = array( 'id' => preg_replace( '/[^a-z0-9]/i', '', (string) ( isset( $a['id'] ) ? $a['id'] : '' ) ), 'tur' => $a['tur'], 'ad' => mb_substr( sanitize_text_field( isset( $a['ad'] ) ? (string) $a['ad'] : '' ), 0, 40 ) );
		foreach ( array( 'di' => array( 0, 50 ), 'bas' => array( 1, 300 ), 'satir' => array( 1, 200 ), 'sutun' => array( 1, 200 ) ) as $k => $r ) {
			$o[ $k ] = (int) $sayi( isset( $a[ $k ] ) ? $a[ $k ] : $r[0], $r[0], $r[1] );
		}
		foreach ( array( 'x1', 'y1', 'x2', 'y2' ) as $k ) {
			$o[ $k ] = $sayi( isset( $a[ $k ] ) ? $a[ $k ] : 0, -500, 8000 );
		}
		$o['r']     = $sayi( isset( $a['r'] ) ? $a['r'] : 0.34, 0.1, 0.6 );
		$o['yon']   = isset( $a['yon'] ) && 'sutun' === $a['yon'] ? 'sutun' : 'satir';
		$o['deger'] = mb_substr( preg_replace( '/[^\p{L}\p{N}]/u', '', (string) ( isset( $a['deger'] ) ? $a['deger'] : '' ) ), 0, 40 );
		if ( isset( $a['taban'] ) && is_array( $a['taban'] ) && count( $a['taban'] ) <= 40000 ) {
			$o['taban'] = array_map( function ( $v ) {
				return max( 0, min( 100, (int) $v ) );
			}, array_values( $a['taban'] ) );
		}
		if ( isset( $a['prof'] ) && is_array( $a['prof'] ) ) {
			$o['prof'] = array( 'x' => $b64( isset( $a['prof']['x'] ) ? $a['prof']['x'] : '', 20000 ), 'y' => $b64( isset( $a['prof']['y'] ) ? $a['prof']['y'] : '', 20000 ) );
		}
		$out['alanlar'][] = $o;
	}
	return $out['alanlar'] ? $out : null;
}
