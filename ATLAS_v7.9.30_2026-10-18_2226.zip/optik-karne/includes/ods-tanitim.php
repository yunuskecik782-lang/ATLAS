<?php
/**
 * ATLAS — eski ÖDS tanıtım sitesi (v7.2–v7.7). v7.8'de devre dışı: /ods/ ve ?ods= adresleri artık kayıt formunu gösterir
 * (includes/odsform.php → sides_ods_sayfa). Bu dosya eklenti tarafından YÜKLENMEZ; kod ve ayarları (sides_docs ods/ayar)
 * geri dönüş gerekirse diye saklanır. Yeniden açmak için optik-karne.php içe aktarma listesine 'ods-tanitim' eklenip
 * sides_render_app('ods') çağrısı sides_ods_tanitim_sayfa'ya yönlendirilmelidir.
 *
 * @package SIDES
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/* Form için sınıf seçenekleri: "Sınıflar" yazısındaki 3–8 rakamları; yoksa 5–8 */
function sides_ods_siniflar( $yazi ) {
	preg_match_all( '/[3-8]/', (string) $yazi, $m );
	$s = array_values( array_unique( $m[0] ) );
	sort( $s );
	return $s ? $s : array( '5', '6', '7', '8' );
}

function sides_ods_tanitim_sayfa( $key ) {
	$o = sides_ods_org( $key );
	if ( ! $o ) {
		status_header( 404 );
		header( 'X-Robots-Tag: noindex' );
		echo '<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>Sayfa bulunamadı</title></head><body style="font-family:system-ui;padding:40px 16px;text-align:center"><h1>Sayfa bulunamadı</h1><p>Bu bağlantı geçerli bir kuruma ait değil.</p></body></html>';
		return;
	}
	$org  = (int) $o->id;
	$a    = sides_ods_ayar( $org );
	$set  = sides_get_doc( $org, 'settings', 'main' );
	$kur  = isset( $set['kurum'] ) && $set['kurum'] ? (string) $set['kurum'] : (string) $o->ad;
	$R    = SIDES_ODS_RENKLER[ isset( SIDES_ODS_RENKLER[ $a['renk'] ] ) ? $a['renk'] : 'lacivert' ];
	$logo = sides_ods_logo_url( $o, $a );
	$aktif = ! empty( $a['aktif'] ) && ! sides_org_blok( $o );
	$kapandi = '' !== $a['sonBasvuru'] && sides_ods_bugun() > $a['sonBasvuru'];
	$kayitAcik = ! empty( $set['kayitAcik'] );
	$gomulu = 'gomulu' === $a['form'];
	$acik  = $aktif && ! $kapandi && ( ! $gomulu || $kayitAcik );   // başvuru alınabilir mi?
	$kisa  = sides_ods_url_kisa();
	$kayitUrl = optik_karne_url( array( 'kayit' => $o->anahtar ) );
	$basvurHref = $gomulu ? '#basvuru' : $kayitUrl;
	$basTitle = $a['baslik'] . ' · ' . $kur;
	$rest = esc_url_raw( rest_url( 'optik-karne/v1/' ) );
	$sinavIso = $a['sinavTarih'] ? $a['sinavTarih'] . 'T' . $a['sinavSaat'] . ':00+03:00' : '';
	$dugme = function ( $sinif, $metin = 'Hemen Başvur' ) use ( $acik, $basvurHref, $gomulu ) {
		if ( ! $acik ) {
			return '<span class="btn btn-lac kapali" aria-disabled="true">Başvurular kapandı</span>';
		}
		return '<a class="btn btn-altin ' . esc_attr( $sinif ) . '" href="' . esc_url( $basvurHref ) . '"' . ( $gomulu ? '' : ' target="_blank" rel="noopener"' ) . '>' . esc_html( $metin ) . '</a>';
	};
	$h = function ( $s ) {
		return esc_html( $s );
	};
	$kurumBaslik = '<span class="marka">' . ( $logo ? '<img src="' . esc_url( $logo ) . '" alt="" width="40" height="40">' : '<span class="logo" aria-hidden="true">ÖDS</span>' ) . '<span>' . $h( $kur ) . '</span></span>';
	$kokCss = ':root{--lac:' . $R['a'] . ';--lac2:' . $R['b'] . ';--lac3:' . $R['c'] . ';--altin:' . $R['v'] . ';--altin2:' . $R['v2'] . ';--zemin:#f6f8fc;--kart:#fff;--yazi:#13213a;--mut:#56657f;--cizgi:#e3e9f3}';
	?><!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<title><?php echo $h( $basTitle ); ?></title>
<?php if ( $aktif ) : ?>
<meta name="description" content="<?php echo esc_attr( mb_substr( $a['altYazi'], 0, 160 ) ); ?>">
<link rel="canonical" href="<?php echo esc_url( $kisa ); ?>">
<meta property="og:type" content="website">
<meta property="og:locale" content="tr_TR">
<meta property="og:site_name" content="<?php echo esc_attr( $kur ); ?>">
<meta property="og:title" content="<?php echo esc_attr( $basTitle ); ?>">
<meta property="og:description" content="<?php echo esc_attr( mb_substr( $a['altYazi'], 0, 200 ) ); ?>">
<meta property="og:url" content="<?php echo esc_url( $kisa ); ?>">
<?php if ( $logo ) : ?>
<meta property="og:image" content="<?php echo esc_url( $logo ); ?>">
<?php endif; ?>
<meta name="twitter:card" content="summary">
<?php else : ?>
<meta name="robots" content="noindex,nofollow">
<?php endif; ?>
<style>
<?php echo $kokCss; // phpcs:ignore ?>
*{box-sizing:border-box}html,body{margin:0;padding:0}html{scroll-behavior:smooth}
body{font-family:system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;color:var(--yazi);background:var(--zemin);line-height:1.5;-webkit-text-size-adjust:100%;overflow-x:hidden}
a{color:var(--lac)}img{max-width:100%}
.ic{max-width:1040px;margin:0 auto;padding:0 16px}
.ust{position:sticky;top:0;z-index:5;background:rgba(255,255,255,.94);backdrop-filter:blur(8px);border-bottom:1px solid var(--cizgi)}
.ust .ic{display:flex;align-items:center;justify-content:space-between;gap:12px;min-height:60px}
.marka{display:flex;align-items:center;gap:10px;font-weight:800;color:var(--lac);text-decoration:none;min-width:0}
.marka>span:last-child{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.marka .logo{flex:none;width:36px;height:36px;border-radius:50%;background:var(--lac);color:#fff;display:grid;place-items:center;font-size:13px;font-weight:900;letter-spacing:.5px}
.marka img{flex:none;width:40px;height:40px;object-fit:contain;border-radius:8px;background:#fff}
.btn{display:inline-flex;align-items:center;justify-content:center;gap:8px;min-height:48px;padding:0 22px;border-radius:12px;border:0;font-weight:800;font-size:16px;text-decoration:none;cursor:pointer;transition:transform .15s,box-shadow .15s;font-family:inherit}
.btn:active{transform:scale(.98)}
.btn-altin{background:linear-gradient(135deg,var(--altin2),var(--altin));color:var(--lac);box-shadow:0 8px 24px rgba(0,0,0,.18)}
.btn-altin:hover{box-shadow:0 10px 28px rgba(0,0,0,.28)}
.btn-lac{background:var(--lac);color:#fff}
.btn.kapali{cursor:default;opacity:.85}
.btn-cizgi{background:transparent;border:2px solid rgba(255,255,255,.75);color:#fff}
.ust .btn{min-height:44px;padding:0 16px;font-size:15px;flex:none}
.hero{position:relative;overflow:hidden;color:#fff;background:radial-gradient(1200px 600px at 80% -10%,var(--lac3) 0%,var(--lac2) 40%,var(--lac) 100%)}
.hero::after{content:"";position:absolute;inset:0;background:repeating-linear-gradient(135deg,rgba(255,255,255,.035) 0 2px,transparent 2px 22px);pointer-events:none}
.hero .ic{position:relative;padding:44px 16px 40px;display:grid;gap:28px;grid-template-columns:1fr}
.etiket{display:inline-flex;align-items:center;gap:8px;padding:6px 12px;border-radius:999px;background:rgba(255,255,255,.14);border:1px solid rgba(255,255,255,.3);font-size:13px;font-weight:700;letter-spacing:.4px;text-transform:uppercase}
.etiket i{width:8px;height:8px;border-radius:50%;background:var(--altin2);display:inline-block}
.etiket.kapali i{background:#ff9f9f}
h1{margin:14px 0 8px;font-size:clamp(30px,6vw,52px);line-height:1.08;letter-spacing:-.5px;overflow-wrap:anywhere}
h1 span{color:var(--altin2)}
.alt{font-size:clamp(16px,2.4vw,20px);opacity:.94;max-width:560px;margin:0 0 22px}
.hero .dugmeler{display:flex;flex-wrap:wrap;gap:12px}
.sayac{display:grid;grid-template-columns:repeat(4,1fr);gap:10px;max-width:520px}
.sayac div{background:rgba(255,255,255,.1);border:1px solid rgba(255,255,255,.22);border-radius:14px;padding:12px 4px;text-align:center;min-width:0}
.sayac b{display:block;font-size:clamp(24px,5vw,36px);font-variant-numeric:tabular-nums;line-height:1}
.sayac span{font-size:12px;opacity:.9;text-transform:uppercase;letter-spacing:.5px}
.sayac-not{font-size:14px;opacity:.9;margin-top:8px}
.bilgi{margin-top:-26px;position:relative}
.bilgi .ic{display:grid;grid-template-columns:repeat(2,1fr);gap:12px}
.kart{background:var(--kart);border:1px solid var(--cizgi);border-radius:16px;padding:16px;box-shadow:0 6px 20px rgba(15,45,92,.06);min-width:0}
.kart .k{font-size:12px;font-weight:800;letter-spacing:.6px;text-transform:uppercase;color:var(--mut)}
.kart .v{font-size:18px;font-weight:800;color:var(--lac);margin-top:4px;overflow-wrap:anywhere}
.kart .a{font-size:13px;color:var(--mut);margin-top:2px;overflow-wrap:anywhere}
section{padding:40px 0 8px}
h2{font-size:clamp(22px,3.6vw,30px);margin:0 0 6px;color:var(--lac);letter-spacing:-.3px}
.h2alt{color:var(--mut);margin:0 0 20px}
.oduller{display:grid;grid-template-columns:1fr;gap:12px}
.odul{display:flex;gap:14px;align-items:center;background:var(--kart);border:1px solid var(--cizgi);border-radius:16px;padding:14px 16px;min-width:0}
.odul .no{flex:none;min-width:52px;height:52px;padding:0 8px;border-radius:14px;display:grid;place-items:center;font-weight:900;font-size:17px;color:#fff;background:var(--lac)}
.odul.s1 .no{background:linear-gradient(135deg,#f2c14e,#c8900d);color:#3a2a00}
.odul.s2 .no{background:linear-gradient(135deg,#dfe6ef,#9aa8bb);color:#1e2a3a}
.odul.s3 .no{background:linear-gradient(135deg,#e2a06a,#b8692f);color:#3a1c05}
.odul div{min-width:0}.odul b{display:block;font-size:17px;overflow-wrap:anywhere}.odul span{color:var(--mut);font-size:14px}
.adimlar{display:grid;grid-template-columns:1fr;gap:12px;counter-reset:adim}
.adim{background:var(--kart);border:1px solid var(--cizgi);border-radius:16px;padding:16px 16px 16px 64px;position:relative}
.adim::before{counter-increment:adim;content:counter(adim);position:absolute;left:16px;top:16px;width:34px;height:34px;border-radius:50%;background:var(--altin2);color:var(--lac);font-weight:900;display:grid;place-items:center}
.adim b{display:block;margin-bottom:2px}.adim span{color:var(--mut);font-size:14px}
.dersler{display:flex;flex-wrap:wrap;gap:8px}
.dersler span{background:#eef3fb;color:var(--lac);border:1px solid #d6e0f0;border-radius:999px;padding:6px 12px;font-weight:700;font-size:14px}
.sinav-not{color:var(--mut);margin-top:14px;white-space:pre-line}
.sss details{background:var(--kart);border:1px solid var(--cizgi);border-radius:14px;padding:0 16px;margin-bottom:10px}
.sss summary{cursor:pointer;padding:14px 0;font-weight:700;list-style:none;display:flex;justify-content:space-between;align-items:center;gap:10px;min-height:48px}
.sss summary::-webkit-details-marker{display:none}
.sss summary::after{content:"+";font-size:22px;color:var(--mut);flex:none}
.sss details[open] summary::after{content:"–"}
.sss p{margin:0 0 14px;color:var(--mut);white-space:pre-line}
.form-k{background:var(--kart);border:1px solid var(--cizgi);border-radius:20px;padding:22px 16px;box-shadow:0 10px 30px rgba(15,45,92,.08);max-width:720px}
.form-k h2{margin-bottom:4px}
.form-g{display:grid;grid-template-columns:1fr;gap:12px;margin-top:16px}
.f{display:flex;flex-direction:column;gap:5px;font-weight:700;font-size:14px;min-width:0}
.f input,.f select,.f textarea{font:inherit;font-weight:500;min-height:46px;padding:10px 12px;border:1px solid #c5d0e0;border-radius:10px;background:#fff;color:var(--yazi);width:100%}
.f textarea{min-height:84px;resize:vertical}
.f input:focus,.f select:focus,.f textarea:focus{outline:2px solid var(--lac3);outline-offset:1px}
.chk{display:flex;gap:10px;align-items:flex-start;font-size:14px;color:var(--yazi);min-height:44px;cursor:pointer}
.chk input{width:22px;height:22px;flex:none;margin:1px 0 0}
.not{border-radius:12px;padding:12px 14px;font-size:15px;margin-top:12px}
.not.ok{background:#e6f6ec;color:#124d2a;border:1px solid #bfe4cc}
.not.bad{background:#fdecec;color:#7a1a1a;border:1px solid #f3c3c3}
.not.warn{background:#fff6e0;color:#5c4300;border:1px solid #f0dca0}
.form-k .btn{width:100%;margin-top:16px}
.cta{margin:36px 0 0;background:var(--lac);color:#fff;border-radius:20px;padding:28px 20px;text-align:center}
.cta h2{color:#fff;margin-bottom:8px}.cta p{margin:0 0 18px;opacity:.92}
.iletisim{display:flex;flex-wrap:wrap;gap:10px;justify-content:center}
.iletisim a{color:#fff;text-decoration:none;background:rgba(255,255,255,.12);border:1px solid rgba(255,255,255,.3);padding:10px 14px;border-radius:12px;font-weight:700;min-height:44px;display:inline-flex;align-items:center;gap:8px;max-width:100%;overflow-wrap:anywhere}
.iletisim svg{flex:none;width:18px;height:18px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
footer{padding:28px 0 96px;color:var(--mut);font-size:13px;text-align:center}
.alt-cubuk{position:fixed;left:0;right:0;bottom:0;z-index:6;background:rgba(255,255,255,.97);border-top:1px solid var(--cizgi);padding:10px 16px calc(10px + env(safe-area-inset-bottom));display:flex;align-items:center;justify-content:space-between;gap:12px}
.alt-cubuk .t{font-size:14px;font-weight:700;color:var(--lac);min-width:0;overflow:hidden}
.alt-cubuk .t span{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.alt-cubuk .t small{display:block;color:var(--mut);font-weight:500;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.alt-cubuk .btn{flex:none}
.hidden{display:none!important}
.kapali-s{max-width:560px;margin:40px auto;padding:0 16px;text-align:center}
.kapali-s .kart{padding:32px 20px}.kapali-s h1{color:var(--lac);font-size:28px;margin:10px 0}
@media (min-width:760px){
  .hero .ic{grid-template-columns:1.2fr .8fr;align-items:center;padding:72px 16px 64px}
  .bilgi .ic{grid-template-columns:repeat(4,1fr)}
  .oduller{grid-template-columns:repeat(3,1fr)}
  .adimlar{grid-template-columns:repeat(3,1fr)}
  .form-g{grid-template-columns:1fr 1fr}.form-g .tam{grid-column:1/-1}
  .form-k{padding:28px}.form-k .btn{width:auto}
  .alt-cubuk{display:none}footer{padding-bottom:40px}
}
@media (prefers-reduced-motion:reduce){.btn{transition:none}html{scroll-behavior:auto}}
</style>
</head>
<body>
<?php if ( ! $aktif ) : ?>
<header class="ust"><div class="ic"><?php echo $kurumBaslik; // phpcs:ignore ?></div></header>
<main class="kapali-s"><div class="kart"><span class="etiket" style="background:#eef3fb;color:var(--lac);border-color:#d6e0f0"><i style="background:#c9d3e3"></i>Yayında değil</span><h1><?php echo $h( $a['baslik'] ); ?></h1><p style="color:var(--mut);margin:0">Başvurular şu an kapalı. Sınav duyurusu yayınlandığında bu sayfadan başvurabilirsiniz.</p></div></main>
<?php else : ?>
<header class="ust"><div class="ic">
  <?php echo $kurumBaslik; // phpcs:ignore ?>
  <?php echo $dugme( 'd-ust' ); // phpcs:ignore ?>
</div></header>
<main>
<div class="hero"><div class="ic">
  <div>
    <span class="etiket<?php echo $acik ? '' : ' kapali'; ?>"><i></i><?php echo $acik ? 'Başvurular açık' : 'Başvurular kapandı'; ?></span>
    <h1><?php
		$b = $a['baslik'];
		$p = mb_strrpos( $b, ' ' );   // son iki kelime vurgulu (ör. Ödüllü <Deneme Sınavı>)
		$p2 = false !== $p ? mb_strrpos( mb_substr( $b, 0, $p ), ' ' ) : false;
		$kes = false !== $p2 ? $p2 : $p;
		echo false !== $kes ? $h( mb_substr( $b, 0, $kes ) ) . ' <span>' . $h( mb_substr( $b, $kes + 1 ) ) . '</span>' : $h( $b );
	?></h1>
    <?php if ( $a['altYazi'] ) : ?><p class="alt"><?php echo $h( $a['altYazi'] ); ?></p><?php endif; ?>
    <div class="dugmeler"><?php echo $dugme( 'd-hero' ); // phpcs:ignore ?><?php if ( $a['oduller'] ) : ?><a class="btn btn-cizgi" href="#oduller">Ödülleri Gör</a><?php endif; ?></div>
  </div>
  <div>
    <?php if ( $sinavIso ) : ?>
    <div class="sayac" id="sayac" data-t="<?php echo esc_attr( $sinavIso ); ?>" aria-live="polite">
      <div><b id="sGun">--</b><span>gün</span></div><div><b id="sSaat">--</b><span>saat</span></div><div><b id="sDk">--</b><span>dakika</span></div><div><b id="sSn">--</b><span>saniye</span></div>
    </div>
    <div class="sayac-not" id="sayacNot">Sınava kalan süre</div>
    <?php endif; ?>
  </div>
</div></div>

<div class="bilgi"><div class="ic">
  <div class="kart"><div class="k">Sınav tarihi</div><div class="v"><?php echo $a['sinavTarih'] ? $h( sides_ods_tarih_yaz( $a['sinavTarih'] ) ) : 'Yakında açıklanacak'; ?></div><div class="a"><?php echo $h( $a['saatYazi'] ? $a['saatYazi'] : ( $a['sinavTarih'] ? 'Saat ' . str_replace( ':', '.', $a['sinavSaat'] ) : '' ) ); ?></div></div>
  <div class="kart"><div class="k">Yer</div><div class="v"><?php echo $h( $a['yer'] ? $a['yer'] : $kur ); ?></div><div class="a"><?php echo $h( $a['adres'] ); ?></div></div>
  <div class="kart"><div class="k">Sınıflar</div><div class="v"><?php echo $h( $a['siniflar'] ); ?></div><div class="a">Ortaokul öğrencileri</div></div>
  <div class="kart"><div class="k">Katılım</div><div class="v"><?php echo $h( $a['ucret'] ? $a['ucret'] : 'Ücretsiz' ); ?></div><div class="a"><?php echo $a['sonBasvuru'] ? 'Son başvuru: ' . $h( sides_ods_tarih_yaz( $a['sonBasvuru'] ) ) : ''; ?></div></div>
</div></div>

<?php if ( $a['oduller'] ) : ?>
<section id="oduller"><div class="ic">
  <h2>Ödüller</h2>
  <?php if ( $a['odulAlt'] ) : ?><p class="h2alt"><?php echo $h( $a['odulAlt'] ); ?></p><?php endif; ?>
  <div class="oduller"><?php foreach ( $a['oduller'] as $i => $od ) : ?><div class="odul<?php echo $i < 3 ? ' s' . ( $i + 1 ) : ''; ?>"><div class="no"><?php echo $h( $od['sira'] ? $od['sira'] : ( $i + 1 ) . '.' ); ?></div><div><b><?php echo $h( $od['ad'] ); ?></b><?php if ( $od['aciklama'] ) : ?><span><?php echo $h( $od['aciklama'] ); ?></span><?php endif; ?></div></div><?php endforeach; ?></div>
</div></section>
<?php endif; ?>

<section id="nasil"><div class="ic">
  <h2>Nasıl başvurulur?</h2>
  <p class="h2alt">Üç adımda iki dakika sürer.</p>
  <div class="adimlar">
    <div class="adim"><b>Formu doldurun</b><span>"Hemen Başvur" düğmesine basın; öğrencinin adı, sınıfı, okulu ve veli telefonu yeterli.</span></div>
    <div class="adim"><b>Onay mesajını bekleyin</b><span>Kaydınız alındığında sınav yeri ve saati için size ulaşılır.</span></div>
    <div class="adim"><b>Sınav günü gelin</b><span>Yanınızda kurşun kalem ve silgi olsun. Sonuçlar ve karne size iletilir.</span></div>
  </div>
</div></section>

<section id="sinav"><div class="ic">
  <h2>Sınav hakkında</h2>
  <?php if ( $a['sinavAlt'] ) : ?><p class="h2alt"><?php echo $h( $a['sinavAlt'] ); ?></p><?php endif; ?>
  <?php if ( $a['dersler'] ) : ?><div class="dersler"><?php foreach ( $a['dersler'] as $d ) : ?><span><?php echo $h( $d ); ?></span><?php endforeach; ?></div><?php endif; ?>
  <?php if ( $a['sinavNot'] ) : ?><p class="sinav-not"><?php echo $h( $a['sinavNot'] ); ?></p><?php endif; ?>
</div></section>

<?php if ( $a['sss'] ) : ?>
<section class="sss" id="sss"><div class="ic">
  <h2>Sık sorulan sorular</h2>
  <div style="margin-top:16px"><?php foreach ( $a['sss'] as $x ) : ?><details><summary><?php echo $h( $x['s'] ); ?></summary><p><?php echo $h( $x['c'] ); ?></p></details><?php endforeach; ?></div>
</div></section>
<?php endif; ?>

<?php if ( $gomulu ) : ?>
<section id="basvuru"><div class="ic"><div class="form-k">
  <h2>Başvuru formu</h2>
  <?php if ( ! $acik ) : ?>
  <p class="h2alt" style="margin:0"><?php echo $kapandi ? 'Başvurular kapandı. İlginiz için teşekkür ederiz.' : 'Başvuru formu şu an kapalı.'; ?></p>
  <?php else : ?>
  <p class="h2alt" style="margin:0">Bilgileriniz yalnızca sınav kaydı için kullanılır. Kaydınız alındığında veli telefonundan size ulaşılır.</p>
  <form id="odsForm" novalidate>
    <div class="form-g">
      <label class="f">Öğrencinin adı soyadı<input type="text" name="ad" required autocomplete="name" maxlength="80"></label>
      <label class="f">Sınıfı<select name="sinif"><?php foreach ( sides_ods_siniflar( $a['siniflar'] ) as $s ) : ?><option value="<?php echo esc_attr( $s ); ?>"><?php echo $h( $s ); ?>. sınıf</option><?php endforeach; ?></select></label>
      <label class="f">Okulu<input type="text" name="okul" maxlength="120" autocomplete="organization"></label>
      <label class="f">Veli adı soyadı<input type="text" name="veliAd" maxlength="80"></label>
      <label class="f">Veli telefonu<input type="tel" name="telefon" required inputmode="tel" autocomplete="tel" placeholder="05xx xxx xx xx" maxlength="30"></label>
      <label class="f tam">Notunuz (isteğe bağlı)<textarea name="not" maxlength="500"></textarea></label>
      <input type="text" name="web" tabindex="-1" autocomplete="off" style="position:absolute;left:-9999px" aria-hidden="true">
      <label class="chk tam"><input type="checkbox" name="kvkk" required> <span>Başvurumun değerlendirilmesi için bilgilerimin kurumla paylaşılacağını okudum ve anladım.</span></label>
    </div>
    <div id="odsMsg" aria-live="polite"></div>
    <button class="btn btn-altin" type="submit" id="odsGonder">Başvuruyu gönder</button>
  </form>
  <?php endif; ?>
</div></div></section>
<?php endif; ?>

<div class="ic"><div class="cta" id="iletisim">
  <h2>Sorunuz mu var?</h2>
  <p>Bize ulaşın, yardımcı olalım.</p>
  <div class="iletisim">
    <?php if ( $a['telefon'] ) : ?><a href="tel:<?php echo esc_attr( preg_replace( '/[^\d+]/', '', $a['telefon'] ) ); ?>"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M22 16.9v3a2 2 0 0 1-2.2 2 19.8 19.8 0 0 1-8.6-3.1 19.5 19.5 0 0 1-6-6A19.8 19.8 0 0 1 2.1 4.2 2 2 0 0 1 4.1 2h3a2 2 0 0 1 2 1.7c.1.9.4 1.9.7 2.8a2 2 0 0 1-.5 2.1L8 9.9a16 16 0 0 0 6 6l1.3-1.3a2 2 0 0 1 2.1-.4c.9.3 1.8.6 2.8.7a2 2 0 0 1 1.8 2z"/></svg><?php echo $h( $a['telefon'] ); ?></a><?php endif; ?>
    <?php if ( $a['whatsapp'] ) : ?><a href="<?php echo esc_url( 'https://wa.me/' . $a['whatsapp'] . '?text=' . rawurlencode( 'Merhaba, ' . $a['baslik'] . ' hakkında bilgi almak istiyorum.' ) ); ?>" target="_blank" rel="noopener"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21 11.5a8.4 8.4 0 0 1-9 8.4 8.6 8.6 0 0 1-3.8-.9L3 21l2-5a8.4 8.4 0 0 1-1-4.5 8.4 8.4 0 0 1 8.5-8.5 8.4 8.4 0 0 1 8.5 8.5z"/></svg>WhatsApp</a><?php endif; ?>
    <?php if ( $a['eposta'] ) : ?><a href="mailto:<?php echo esc_attr( $a['eposta'] ); ?>"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4h16a2 2 0 0 1 2 2v12a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/><path d="m22 6-10 7L2 6"/></svg><?php echo $h( $a['eposta'] ); ?></a><?php endif; ?>
    <?php if ( ! $a['telefon'] && ! $a['whatsapp'] && ! $a['eposta'] ) : ?><span style="opacity:.9"><?php echo $h( $kur ); ?></span><?php endif; ?>
  </div>
</div></div>
</main>

<footer><div class="ic"><?php echo $h( $kur . ( $a['footer'] ? ' · ' . $a['footer'] : '' ) ); ?></div></footer>

<div class="alt-cubuk" id="altCubuk">
  <div class="t"><span><?php echo $h( $a['baslik'] ); ?></span><small><?php echo $acik ? ( $a['sonBasvuru'] ? 'Son başvuru: ' . $h( sides_ods_tarih_yaz( $a['sonBasvuru'] ) ) : 'Başvurular açık' ) : 'Başvurular kapandı'; ?></small></div>
  <?php echo $dugme( 'd-alt', 'Başvur' ); // phpcs:ignore ?>
</div>

<script>
(function(){
  var $=function(s){return document.querySelector(s)};
  var S=$('#sayac');
  if(S){
    var T=new Date(S.getAttribute('data-t')).getTime();
    var pad=function(n){return String(n).padStart(2,'0')};
    var tik=function(){
      var k=T-Date.now();
      if(isNaN(k)){S.classList.add('hidden');$('#sayacNot').textContent='';return}
      if(k<=0){S.classList.add('hidden');$('#sayacNot').textContent='Sınav günü geldi. Başarılar!';return}
      $('#sGun').textContent=Math.floor(k/864e5);$('#sSaat').textContent=pad(Math.floor(k/36e5)%24);$('#sDk').textContent=pad(Math.floor(k/6e4)%60);$('#sSn').textContent=pad(Math.floor(k/1e3)%60);
      setTimeout(tik,1000);
    };
    tik();
  }
  var F=$('#odsForm');
  if(F){
    F.addEventListener('submit',function(ev){
      ev.preventDefault();
      var M=$('#odsMsg'),B=$('#odsGonder'),v=function(n){return (F.elements[n].value||'').trim()};
      var body={o:<?php echo wp_json_encode( $o->anahtar ); ?>,ad:v('ad'),sinif:v('sinif'),okul:v('okul'),veliAd:v('veliAd'),telefon:v('telefon'),not:v('not'),web:v('web'),kanal:'ods'};
      if(!body.ad||body.telefon.replace(/\D/g,'').length<10){M.innerHTML='<div class="not bad">Öğrencinin adını ve geçerli bir telefon numarası yazın.</div>';return}
      if(!F.elements.kvkk.checked){M.innerHTML='<div class="not bad">Devam etmek için onay kutusunu işaretleyin.</div>';return}
      B.disabled=true;B.textContent='Gönderiliyor…';M.innerHTML='';
      fetch(<?php echo wp_json_encode( $rest . 'kayit' ); ?>,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)})
        .then(function(r){return r.text().then(function(t){var j={};try{j=JSON.parse(t)}catch(e){}if(!r.ok)throw new Error(j.message||('Sunucu hatası ('+r.status+')'));return j})})
        .then(function(){F.innerHTML='<div class="not ok" id="odsOk"><b>Başvurunuz alındı.</b> Teşekkürler; kurumumuz en kısa sürede '+body.telefon.replace(/[<>&"]/g,'')+' numarasından sizinle iletişime geçecek.</div>'})
        .catch(function(e){M.innerHTML='<div class="not bad"></div>';M.firstChild.textContent=e.message||'Gönderilemedi. Lütfen tekrar deneyin.';B.disabled=false;B.textContent='Başvuruyu gönder'});
    });
  }
})();
</script>
<?php endif; ?>
</body>
</html>
	<?php
}
