<?php
/* ATLAS asistanı (v7.9.28, eğitim önerisi 3 — 1. aşama: yardım ve sayfaya yönlendirme, salt okunur).
   POST asistan/sor { soru, aktif, sayfalar: [ { r, t, d } ] } → { cevap, sayfalar: [r], durum }
   - Modele yalnız kullanıcının sorusu ve kullanıcının menüsünde görebildiği sayfaların adı/açıklaması gider; öğrenci, sonuç
     ya da kurum verisi gönderilmez. Önerilen sayfalar istemcinin gönderdiği (kullanıcının görebildiği) listeyle sınırlıdır.
   - Mevcut yapay zekâ hizmeti kullanılır (includes/ai.php: anahtar, model, aylık hak); her soru aylık haktan 1 düşer.
   - Kullanıcı ve kurum başına saatlik sınır; işlem günlüğüne soru metni yazılmaz (kişisel veri içerebilir), yalnız kullanım kaydı. */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'optik-karne/v1', '/asistan/sor', array(
		'methods'             => 'POST',
		'callback'            => 'sides_asistan_sor',
		'permission_callback' => function () {
			return sides_is_panel() ? true : sides_deny( 'Oturum açmanız gerekiyor.' );
		},
	) );
} );

function sides_asistan_sema() {
	return array(
		'type'                 => 'object',
		'properties'           => array(
			'cevap'    => array( 'type' => 'string' ),
			'sayfalar' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
		),
		'required'             => array( 'cevap', 'sayfalar' ),
		'additionalProperties' => false,
	);
}

function sides_asistan_sor( WP_REST_Request $req ) {
	$a   = sides_ai_ayar();
	$org = sides_org_id();
	if ( ! $a['acik'] || '' === $a['anahtar'] ) {
		return new WP_Error( 'sides_ai', 'Yapay zekâ kapalı; asistan yalnız sayfa önerileriyle çalışıyor.', array( 'status' => 400 ) );
	}
	if ( ! sides_rl( 'asistan|' . get_current_user_id(), 30, HOUR_IN_SECONDS ) || ! sides_rl( 'asistan_kurum|' . $org, 120, HOUR_IN_SECONDS ) ) {
		return new WP_Error( 'sides_rl', 'Bir saat içinde çok fazla soru soruldu. Biraz sonra tekrar deneyin.', array( 'status' => 429 ) );
	}
	if ( $a['sinir'] && sides_ai_kullanim( $org ) + 1 > $a['sinir'] ) {
		return new WP_Error( 'sides_ai', 'Bu ayki yapay zekâ hakkınız doldu. Yeni ayda yenilenir; asistan sayfa önerileriyle çalışmaya devam eder.', array( 'status' => 429 ) );
	}
	$p    = $req->get_json_params();
	$p    = is_array( $p ) ? $p : array();
	$soru = mb_substr( trim( sanitize_textarea_field( isset( $p['soru'] ) ? (string) $p['soru'] : '' ) ), 0, 500 );
	if ( mb_strlen( $soru ) < 3 ) {
		return new WP_Error( 'sides_eksik', 'Sorunuzu yazın.', array( 'status' => 400 ) );
	}
	$liste = array();
	foreach ( array_slice( (array) ( isset( $p['sayfalar'] ) ? $p['sayfalar'] : array() ), 0, 250 ) as $s ) {
		if ( ! is_array( $s ) || ! isset( $s['r'] ) || ! is_string( $s['r'] ) || ! preg_match( '/^[a-z0-9_.]{1,40}$/i', $s['r'] ) ) {
			continue;
		}
		$liste[ $s['r'] ] = array(
			't' => mb_substr( sanitize_text_field( isset( $s['t'] ) ? (string) $s['t'] : '' ), 0, 80 ),
			'd' => mb_substr( sanitize_text_field( isset( $s['d'] ) ? (string) $s['d'] : '' ), 0, 160 ),
		);
	}
	$aktif = isset( $p['aktif'] ) && is_string( $p['aktif'] ) && isset( $liste[ $p['aktif'] ] ) ? $p['aktif'] : '';
	$satir = array();
	foreach ( $liste as $r => $s ) {
		$satir[] = $r . ' | ' . $s['t'] . ( $s['d'] ? ' — ' . $s['d'] : '' );
	}
	$system = 'Sen ATLAS — Akademik Takip ve Analiz Sistemi\'nin (dershane ve okullar için WordPress tabanlı deneme, karne, analiz ve takip sistemi) yardım asistanısın. '
		. 'Yalnız ATLAS\'ın nasıl kullanılacağı hakkında yardım edersin. Öğrenci, sonuç ya da kurum verisine erişimin yoktur; sayı, isim, sonuç uydurma. '
		. 'Kullanıcı veri sorarsa (ör. "8-B\'nin ortalaması"), veriyi hangi sayfada görebileceğini söyle. Bilmediğin bir özelliği varmış gibi anlatma; emin değilsen bunu söyle. '
		. 'Cevabın kısa (en çok 5 cümle), sade Türkçe ve adım adım olsun. "sayfalar" alanına aşağıdaki listeden en ilgili en çok 3 sayfanın kodunu yaz; listede olmayan kod yazma.';
	$prompt = "Kullanıcının görebildiği ATLAS sayfaları (kod | ad — açıklama):\n" . implode( "\n", $satir )
		. ( $aktif ? "\n\nKullanıcı şu an bu sayfada: {$aktif}" : '' )
		. "\n\nSoru: {$soru}";
	$txt = sides_ai_istek( $a, $system, $prompt, sides_asistan_sema(), 900 );
	if ( is_wp_error( $txt ) ) {
		return $txt;
	}
	$j = json_decode( $txt, true );
	if ( ! is_array( $j ) || ! isset( $j['cevap'] ) || ! is_string( $j['cevap'] ) ) {
		return new WP_Error( 'sides_ai', 'Asistanın yanıtı okunamadı. Tekrar deneyin.', array( 'status' => 502 ) );
	}
	$oner = array();
	foreach ( (array) ( isset( $j['sayfalar'] ) ? $j['sayfalar'] : array() ) as $r ) {
		if ( is_string( $r ) && isset( $liste[ $r ] ) && ! in_array( $r, $oner, true ) ) {
			$oner[] = $r;
		}
	}
	sides_ai_say( $org, 1 );
	sides_log( $org, 'ATLAS asistanı: bir soru yanıtlandı (yapay zekâ, model ' . (string) $a['model'] . ')' );
	return array( 'cevap' => mb_substr( trim( $j['cevap'] ), 0, 1500 ), 'sayfalar' => array_slice( $oner, 0, 3 ), 'durum' => sides_ai_durum( $org ) );
}
