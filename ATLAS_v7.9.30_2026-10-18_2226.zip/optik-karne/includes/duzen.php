<?php
/**
 * Ana Sayfa Düzeni ve Duyurular (v5.5).
 *
 * Düzen belgeleri (coll: duzen):
 *   org = kurum, id = 'kurum'      kurumun panel ve menü düzeni (yalnız kurum yöneticisi yazar)
 *   org = 0,     id = 'varsayilan' ana hesabın tüm kurumlar için genel varsayılanı (yalnız ana hesap yazar)
 * Belge: { menu: {gruplar, sira, altlar, ogeler, ogeSira, kisayol}, panel: {kartlar:[{id, boyut, gizli}]} }.
 * Menü düzeni yalnızca sunumdur: istemci düzeni uyguladıktan sonra öğeleri yine yetkiye göre süzer; sunucudaki
 * sayfa/veri yetkileri değişmez.
 *
 * Kurum duyuruları genel /doc/duyurular ucundan yazılır (sistem yazma yetkisi). Ana hesabın genel duyuruları
 * org = 0 'duyurular' belgelerinde durur; kapsam { tum: true } ya da { kurumlar: [id…] }.
 *
 * GET    /duzen                       { kurum, varsayilan, genelDuyurular, sinir }
 * PUT    /duzen/kurum | /duzen/varsayilan    { menu, panel }   DELETE ile varsayılana dönülür
 * PUT    /duzen/genel-duyuru/<id>      DELETE /duzen/genel-duyuru/<id>   (ana hesap)
 * POST   /duzen/gorsel  { data: data-url, genel? }        → { id, w, h }   (görsel 1,5 MB'a kadar)
 * POST   /duzen/video?genel=1  ham gövde (video/mp4 | video/webm) → { id, boyut, mime }
 * GET    /duzen/video/<id>             (Range desteği)
 * DELETE /duzen/medya/<id>             başka bir duyuruda kullanılmıyorsa görsel/video kaydını siler
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SIDES_DUZEN_VIDEO_MAX', 6 * 1048576 );

function sides_duzen_video_sinir() {
	$p = ini_get( 'post_max_size' );
	$n = (int) $p;
	$u = strtoupper( substr( trim( (string) $p ), -1 ) );
	$b = 'G' === $u ? $n * 1073741824 : ( 'M' === $u ? $n * 1048576 : ( 'K' === $u ? $n * 1024 : $n ) );
	return $b > 0 ? min( SIDES_DUZEN_VIDEO_MAX, $b - 65536 ) : SIDES_DUZEN_VIDEO_MAX;
}

function sides_duzen_yazar_mi() {   // kurum yöneticisi, sistem yazma yetkisiyle
	$c = sides_ctx();
	if ( ! empty( $c['onizleme'] ) ) {
		return sides_deny( 'Önizleme modunda değişiklik yapılamaz.' );
	}
	return ( 'yonetici' === $c['rol'] && sides_can( 'sistem', 2 ) ) ? true : sides_deny( 'Ana sayfa düzenini yalnızca kurum yöneticisi değiştirebilir.' );
}
function sides_duzen_duyuru_yazar() {
	$c = sides_ctx();
	if ( ! empty( $c['onizleme'] ) ) {
		return sides_deny( 'Önizleme modunda değişiklik yapılamaz.' );
	}
	if ( sides_is_observer() ) {
		return sides_deny( 'Gözlemci hesabının işlem yetkisi yok. Yöneticinizden izin isteyin.' );
	}
	return sides_can( 'sistem', 2 ) ? true : sides_deny( 'Duyuru yayınlama yetkiniz yok.' );
}
function sides_duzen_super() {
	$c = sides_ctx();
	if ( ! empty( $c['onizleme'] ) ) {
		return sides_deny( 'Önizleme modunda değişiklik yapılamaz.' );
	}
	return sides_is_super() ? true : sides_deny( 'Bu işlemi yalnızca ana hesap yapabilir.' );
}

add_action( 'rest_api_init', function () {
	$ns    = 'optik-karne/v1';
	$panel = function () {
		return sides_is_panel() ? true : sides_deny( 'Oturum açmanız gerekiyor.' );
	};
	register_rest_route( $ns, '/duzen', array( 'methods' => 'GET', 'callback' => 'sides_duzen_get', 'permission_callback' => $panel ) );
	register_rest_route( $ns, '/duzen/(?P<hedef>kurum|varsayilan)', array(
		array( 'methods' => 'PUT, POST', 'callback' => 'sides_duzen_put', 'permission_callback' => 'sides_duzen_hedef_izin' ),
		array( 'methods' => 'DELETE', 'callback' => 'sides_duzen_del', 'permission_callback' => 'sides_duzen_hedef_izin' ),
	) );
	register_rest_route( $ns, '/duzen/genel-duyuru/(?P<id>[A-Za-z0-9_\-]{1,64})', array(
		array( 'methods' => 'PUT, POST', 'callback' => 'sides_duzen_genel_duyuru_put', 'permission_callback' => 'sides_duzen_super' ),
		array( 'methods' => 'DELETE', 'callback' => 'sides_duzen_genel_duyuru_del', 'permission_callback' => 'sides_duzen_super' ),
	) );
	register_rest_route( $ns, '/duzen/gorsel', array( 'methods' => 'POST', 'callback' => 'sides_duzen_gorsel', 'permission_callback' => 'sides_duzen_duyuru_yazar' ) );
	register_rest_route( $ns, '/duzen/video', array( 'methods' => 'POST', 'callback' => 'sides_duzen_video_add', 'permission_callback' => 'sides_duzen_duyuru_yazar' ) );
	register_rest_route( $ns, '/duzen/video/(?P<id>v[a-f0-9]{20})', array( 'methods' => 'GET', 'callback' => 'sides_duzen_video_get', 'permission_callback' => $panel ) );
	register_rest_route( $ns, '/duzen/medya/(?P<id>(g[a-f0-9]{16,40}|v[a-f0-9]{20}))', array( 'methods' => 'DELETE', 'callback' => 'sides_duzen_medya_del', 'permission_callback' => 'sides_duzen_duyuru_yazar' ) );
} );

function sides_duzen_hedef_izin( WP_REST_Request $req ) {
	return 'varsayilan' === $req['hedef'] ? sides_duzen_super() : sides_duzen_yazar_mi();
}

/* ---------- temizleme ---------- */
function sides_duzen_metin( $s, $n ) {
	$s = trim( wp_strip_all_tags( (string) $s ) );
	return function_exists( 'mb_substr' ) ? mb_substr( $s, 0, $n ) : substr( $s, 0, $n );
}
function sides_duzen_anahtar( $k ) {
	return is_string( $k ) && preg_match( '/^[a-z0-9._\-]{1,48}$/i', $k ) ? $k : '';
}
function sides_duzen_temizle( $d ) {
	$out = array( 'menu' => array(), 'panel' => array() );
	$m   = isset( $d['menu'] ) && is_array( $d['menu'] ) ? $d['menu'] : array();
	foreach ( array( 'gruplar', 'altlar', 'ogeler' ) as $alan ) {
		$o = array();
		if ( isset( $m[ $alan ] ) && is_array( $m[ $alan ] ) ) {
			foreach ( array_slice( $m[ $alan ], 0, 200, true ) as $k => $v ) {
				$k = sides_duzen_anahtar( $k );
				if ( ! $k || ! is_array( $v ) ) {
					continue;
				}
				$x = array();
				if ( isset( $v['t'] ) && '' !== sides_duzen_metin( $v['t'], 60 ) ) {
					$x['t'] = sides_duzen_metin( $v['t'], 60 );
				}
				if ( ! empty( $v['gizli'] ) ) {
					$x['gizli'] = true;
				}
				if ( 'ogeler' === $alan && isset( $v['grp'] ) && sides_duzen_anahtar( $v['grp'] ) ) {
					$x['grp'] = sides_duzen_anahtar( $v['grp'] );
				}
				if ( $x ) {
					$o[ $k ] = $x;
				}
			}
		}
		$out['menu'][ $alan ] = (object) $o;
	}
	$sira = array();
	foreach ( isset( $m['sira'] ) && is_array( $m['sira'] ) ? array_slice( $m['sira'], 0, 60 ) : array() as $k ) {
		if ( sides_duzen_anahtar( $k ) ) {
			$sira[] = $k;
		}
	}
	$out['menu']['sira'] = $sira;
	$os = array();
	if ( isset( $m['ogeSira'] ) && is_array( $m['ogeSira'] ) ) {
		foreach ( array_slice( $m['ogeSira'], 0, 60, true ) as $g => $l ) {
			if ( ! sides_duzen_anahtar( $g ) || ! is_array( $l ) ) {
				continue;
			}
			$os[ $g ] = array_values( array_filter( array_slice( $l, 0, 80 ), 'sides_duzen_anahtar' ) );
		}
	}
	$out['menu']['ogeSira'] = (object) $os;
	$ks = array();
	foreach ( isset( $m['kisayol'] ) && is_array( $m['kisayol'] ) ? array_slice( $m['kisayol'], 0, 40 ) : array() as $x ) {
		if ( is_array( $x ) && sides_duzen_anahtar( isset( $x['k'] ) ? $x['k'] : '' ) && sides_duzen_anahtar( isset( $x['grp'] ) ? $x['grp'] : '' ) ) {
			$ks[] = array( 'k' => $x['k'], 'grp' => $x['grp'], 't' => isset( $x['t'] ) ? sides_duzen_metin( $x['t'], 60 ) : '' );
		}
	}
	$out['menu']['kisayol'] = $ks;
	$p  = isset( $d['panel'] ) && is_array( $d['panel'] ) ? $d['panel'] : array();
	$kl = array();
	foreach ( isset( $p['kartlar'] ) && is_array( $p['kartlar'] ) ? array_slice( $p['kartlar'], 0, 40 ) : array() as $x ) {
		if ( is_array( $x ) && sides_duzen_anahtar( isset( $x['id'] ) ? $x['id'] : '' ) ) {
			$kl[] = array( 'id' => $x['id'], 'boyut' => in_array( isset( $x['boyut'] ) ? $x['boyut'] : '', array( 'tam', 'yarim', 'ucte' ), true ) ? $x['boyut'] : 'yarim', 'gizli' => ! empty( $x['gizli'] ) );
		}
	}
	$out['panel']['kartlar'] = $kl;
	return $out;
}

/* ---------- düzen ---------- */
function sides_duzen_genel_duyurular( $org ) {
	global $wpdb;
	$t   = sides_docs();
	$out = array();
	foreach ( $wpdb->get_results( "SELECT coll, id, token, data FROM $t WHERE org = 0 AND coll = 'duyurular' ORDER BY id" ) as $r ) { // phpcs:ignore
		$d = sides_row_out( $r );
		$k = isset( $d['kapsam'] ) && is_array( $d['kapsam'] ) ? $d['kapsam'] : array( 'tum' => true );
		if ( sides_is_super() || ! empty( $k['tum'] ) || ( isset( $k['kurumlar'] ) && is_array( $k['kurumlar'] ) && in_array( (int) $org, array_map( 'intval', $k['kurumlar'] ), true ) ) ) {
			if ( ! sides_is_super() ) {
				unset( $d['kapsam'] );
			}
			$d['genel'] = true;
			$out[]      = $d;
		}
	}
	return $out;
}
function sides_duzen_get() {
	$org = sides_org_id();
	return array(
		'kurum'          => sides_get_doc( $org, 'duzen', 'kurum' ),
		'varsayilan'     => sides_get_doc( 0, 'duzen', 'varsayilan' ),
		'genelDuyurular' => sides_duzen_genel_duyurular( $org ),
		'sinir'          => array( 'video' => sides_duzen_video_sinir(), 'gorsel' => 1600000 ),
	);
}
function sides_duzen_put( WP_REST_Request $req ) {
	$body = $req->get_body();
	if ( strlen( $body ) > 65536 ) {
		return new WP_Error( 'sides_buyuk', 'Düzen kaydı çok büyük.', array( 'status' => 413 ) );
	}
	$d = json_decode( $body, true );
	if ( ! is_array( $d ) ) {
		return new WP_Error( 'sides_gecersiz', 'Geçersiz düzen.', array( 'status' => 400 ) );
	}
	$genel = 'varsayilan' === $req['hedef'];
	$org   = $genel ? 0 : sides_org_id();
	$x     = sides_duzen_temizle( $d );
	$x['t'] = time();
	$x['u'] = wp_get_current_user()->display_name;
	if ( false === sides_put_doc( $org, 'duzen', $genel ? 'varsayilan' : 'kurum', $x ) ) {
		return new WP_Error( 'sides_db', 'Düzen kaydedilemedi.', array( 'status' => 500 ) );
	}
	sides_log( sides_org_id(), $genel ? 'Genel ana sayfa düzeni (tüm kurumlar için varsayılan) kaydedildi' : 'Ana sayfa ve menü düzeni kaydedildi' );
	return sides_get_doc( $org, 'duzen', $genel ? 'varsayilan' : 'kurum' );
}
function sides_duzen_del( WP_REST_Request $req ) {
	global $wpdb;
	$genel = 'varsayilan' === $req['hedef'];
	$wpdb->delete( sides_docs(), array( 'org' => $genel ? 0 : sides_org_id(), 'coll' => 'duzen', 'id' => $genel ? 'varsayilan' : 'kurum' ) );
	sides_log( sides_org_id(), $genel ? 'Genel ana sayfa düzeni sıfırlandı' : 'Ana sayfa ve menü düzeni varsayılana döndürüldü' );
	return array( 'ok' => true );
}

/* ---------- genel duyurular (ana hesap) ---------- */
function sides_duzen_genel_duyuru_put( WP_REST_Request $req ) {
	$body = $req->get_body();
	if ( strlen( $body ) > 65536 ) {
		return new WP_Error( 'sides_buyuk', 'Duyuru çok büyük.', array( 'status' => 413 ) );
	}
	$d = json_decode( $body, true );
	if ( ! is_array( $d ) || '' === sides_duzen_metin( isset( $d['baslik'] ) ? $d['baslik'] : '', 160 ) ) {
		return new WP_Error( 'sides_gecersiz', 'Duyuru başlığı gerekli.', array( 'status' => 400 ) );
	}
	$k = isset( $d['kapsam'] ) && is_array( $d['kapsam'] ) ? $d['kapsam'] : array();
	$d['kapsam'] = ! empty( $k['tum'] ) || empty( $k['kurumlar'] ) ? array( 'tum' => true ) : array( 'kurumlar' => array_slice( array_values( array_unique( array_map( 'intval', (array) $k['kurumlar'] ) ) ), 0, 500 ) );
	if ( false === sides_put_doc( 0, 'duyurular', $req['id'], $d ) ) {
		return new WP_Error( 'sides_db', 'Duyuru kaydedilemedi.', array( 'status' => 500 ) );
	}
	sides_log( sides_org_id(), 'Genel duyuru kaydedildi: ' . sides_duzen_metin( $d['baslik'], 80 ) );
	$x          = sides_get_doc( 0, 'duyurular', $req['id'] );
	$x['genel'] = true;
	return $x;
}
function sides_duzen_genel_duyuru_del( WP_REST_Request $req ) {
	global $wpdb;
	$wpdb->delete( sides_docs(), array( 'org' => 0, 'coll' => 'duyurular', 'id' => $req['id'] ) );
	sides_log( sides_org_id(), 'Genel duyuru silindi' );
	return array( 'ok' => true );
}

/* ---------- medya ---------- */
function sides_duzen_medya_org( $genel ) {
	if ( $genel ) {
		return sides_is_super() ? 0 : sides_deny( 'Genel duyuru dosyasını yalnızca ana hesap yükleyebilir.' );
	}
	return sides_org_id();
}
function sides_duzen_gorsel( WP_REST_Request $req ) {
	$p   = $req->get_json_params();
	$org = sides_duzen_medya_org( ! empty( $p['genel'] ) );
	if ( is_wp_error( $org ) ) {
		return $org;
	}
	return sides_gorsel_kaydet( isset( $p['data'] ) ? (string) $p['data'] : '', $org );
}
function sides_duzen_video_add( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_duzen_medya_org( ! empty( $req['genel'] ) );
	if ( is_wp_error( $org ) ) {
		return $org;
	}
	if ( ! sides_rl_check( 'duzen_vid_' . get_current_user_id(), 30 ) ) {
		return new WP_Error( 'sides_cok', 'Çok fazla video yüklendi; biraz sonra yeniden deneyin.', array( 'status' => 429 ) );
	}
	$sinir = sides_duzen_video_sinir();
	$mb    = number_format( $sinir / 1048576, 1, ',', '' );
	$bin   = $req->get_body();
	$len   = (int) $req->get_header( 'content_length' );
	if ( '' === $bin ) {
		return new WP_Error( 'sides_video', $len > 0 ? 'Video sunucunun kabul ettiği boyutu aşıyor (en fazla ' . $mb . ' MB).' : 'Video dosyası boş.', array( 'status' => $len > 0 ? 413 : 400 ) );
	}
	if ( strlen( $bin ) > $sinir ) {
		return new WP_Error( 'sides_video', 'Video çok büyük (en fazla ' . $mb . ' MB). Daha uzun videolar için video bağlantısı ekleyin.', array( 'status' => 413 ) );
	}
	$mime = strtolower( trim( explode( ';', (string) $req->get_header( 'content_type' ) )[0] ) );
	$ok   = ( 'video/mp4' === $mime && 'ftyp' === substr( $bin, 4, 4 ) ) || ( 'video/webm' === $mime && "\x1A\x45\xDF\xA3" === substr( $bin, 0, 4 ) );
	if ( ! $ok ) {
		return new WP_Error( 'sides_video', 'Yalnızca MP4 ya da WebM video yüklenebilir.', array( 'status' => 400 ) );
	}
	$id = 'v' . bin2hex( random_bytes( 10 ) );
	$r  = $wpdb->insert( sides_docs(), array( 'org' => (int) $org, 'coll' => 'medya', 'id' => $id, 'exam_id' => '', 'data' => wp_json_encode( array( 'm' => $mime, 'b' => base64_encode( $bin ), 'n' => strlen( $bin ) ) ), 'updated_at' => current_time( 'mysql', true ), 'updated_by' => get_current_user_id() ) );
	if ( ! $r ) {
		return new WP_Error( 'sides_db', 'Video kaydedilemedi (veritabanı sınırı). Daha küçük bir dosya ya da video bağlantısı deneyin.', array( 'status' => 500 ) );
	}
	sides_rl_hit( 'duzen_vid_' . get_current_user_id(), 3600 );   // yalnızca başarılı yüklemeler sayılır (saatte 30)
	return array( 'id' => $id, 'boyut' => strlen( $bin ), 'mime' => $mime );
}
function sides_duzen_video_get( WP_REST_Request $req ) {
	global $wpdb;
	$t   = sides_docs();
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT data FROM $t WHERE coll = 'medya' AND id = %s AND org IN (%d, 0)", $req['id'], sides_org_id() ) ); // phpcs:ignore
	$d   = $row ? json_decode( $row->data, true ) : null;
	if ( ! $d || empty( $d['b'] ) ) {
		return new WP_Error( 'sides_yok', 'Video bulunamadı.', array( 'status' => 404 ) );
	}
	$bin = base64_decode( $d['b'] );
	$n   = strlen( $bin );
	$a   = 0;
	$z   = $n - 1;
	$rng = isset( $_SERVER['HTTP_RANGE'] ) ? (string) $_SERVER['HTTP_RANGE'] : ''; // phpcs:ignore
	if ( preg_match( '/^bytes=(\d*)-(\d*)$/', $rng, $m ) ) {
		if ( '' === $m[1] ) {
			$a = max( 0, $n - (int) $m[2] );
		} else {
			$a = (int) $m[1];
			$z = '' === $m[2] ? $n - 1 : min( $n - 1, (int) $m[2] );
		}
		if ( $a > $z ) {
			status_header( 416 );
			header( 'Content-Range: bytes */' . $n );
			exit;
		}
		status_header( 206 );
		header( 'Content-Range: bytes ' . $a . '-' . $z . '/' . $n );
	}
	header( 'Content-Type: ' . ( in_array( $d['m'], array( 'video/mp4', 'video/webm' ), true ) ? $d['m'] : 'video/mp4' ) );
	header( 'Accept-Ranges: bytes' );
	header( 'Content-Length: ' . ( $z - $a + 1 ) );
	header( 'X-Content-Type-Options: nosniff' );
	header( 'Cache-Control: private, max-age=86400' );
	echo substr( $bin, $a, $z - $a + 1 ); // phpcs:ignore
	exit;
}
function sides_duzen_medya_del( WP_REST_Request $req ) {
	global $wpdb;
	$t    = sides_docs();
	$id   = (string) $req['id'];
	$coll = 'v' === $id[0] ? 'medya' : 'gorsel';
	$orgs = sides_is_super() ? array( sides_org_id(), 0 ) : array( sides_org_id() );
	$like = '%' . $wpdb->esc_like( $id ) . '%';
	foreach ( $orgs as $o ) {
		$kul = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE org = %d AND coll IN ('duyurular','testler','havuz','tv','students','exams','ods','kelime','settings','hedef','ydeste','osablon') AND data LIKE %s", $o, $like ) ); // phpcs:ignore
		if ( ! $kul ) {
			$wpdb->delete( $t, array( 'org' => $o, 'coll' => $coll, 'id' => $id ) );
		}
	}
	return array( 'ok' => true );
}
