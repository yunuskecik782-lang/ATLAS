<?php
/**
 * v6 R09 Sistemi aç / kapat ve TV bekleme.
 *
 * Belge (coll: sistem, id: bakim; genel /doc ve /all uçlarından okunmaz, yedeğe girer):
 *   { kapali, mesaj, acilis ('' | 'YYYY-MM-DDTHH:MM', Europe/Istanbul), acilisTs, tvBekleme (kapalıyken TV bekleme ekranı gösterir),
 *     tvDurdur (sistemi kapatmadan yalnız TV bekleme), tvMesaj, surum, kapatan { uid, ad, t }, gecmis: [ { t, uid, ad, islem, mesaj?, acilis? } ] (son 100) }
 * Hızlı denetim: 'sides_bakim_orgs' seçeneği (autoload) = [ org => 1 ] yalnızca kapalı ya da TV'si beklemede olan kurumlar;
 * bu listede olmayan kurumun isteği hiçbir ek sorgu yapmadan geçer.
 *
 * Kapı (rest_pre_dispatch): kurum kapalıyken o kurumun yönetici olmayan kullanıcılarının (personel, gözlemci, öğretmen/okutma) ve
 * kurumun herkese açık bağlantılarının (veli, takviye öğretmen, veli raporu, okutma…) her ATLAS REST isteği 503 'sides_bakim' alır.
 * Yönetici ve ana hesap hiçbir zaman engellenmez (kurtarma yolu: Sistem Yönetimi › Sistemi Aç / Kapat). Giriş/çıkış sayfaları REST dışıdır.
 * Muaf uçlar: bakim/durum, oturum, kayit-bilgi, kayit ve TV uçları (TV kapanmaz; yanıtta bekleme bayrağı taşır).
 *
 * Uçlar (optik-karne/v1):
 *   GET  bakim          (yönetici) durum + geçmiş
 *   POST bakim          (yönetici) { islem: kapat|ac|guncelle|tv-beklet|tv-devam, mesaj, acilis, tvBekleme, tvMesaj }
 *   GET  bakim/durum    (herkes, ?t=<belirteç>) { kapali, mesaj, acilis } — engellenen ekranın açılışı beklerken sorduğu küçük uç
 */
defined( 'ABSPATH' ) || exit;

define( 'SIDES_BAKIM_MESAJ', 'ATLAS kısa bir süre için kapalı. Lütfen daha sonra tekrar deneyin.' );

add_action( 'rest_api_init', function () {
	$ns  = 'optik-karne/v1';
	$yon = function () {
		$c = sides_ctx();
		return ( $c['org'] && 'yonetici' === $c['rol'] && empty( $c['onizleme'] ) ) ? true : sides_deny( 'Sistemi açıp kapatma yalnızca kurum yöneticisine açıktır.' );
	};
	register_rest_route( $ns, '/bakim', array(
		array( 'methods' => 'GET', 'callback' => 'sides_rest_bakim_oku', 'permission_callback' => $yon ),
		array( 'methods' => 'POST', 'callback' => 'sides_rest_bakim_yaz', 'permission_callback' => $yon ),
	) );
	register_rest_route( $ns, '/bakim/durum', array( 'methods' => 'GET', 'callback' => 'sides_rest_bakim_durum', 'permission_callback' => '__return_true' ) );
} );

/* ---------- belge ---------- */
function sides_bakim_bos() {
	return array( 'kapali' => false, 'mesaj' => '', 'acilis' => '', 'acilisTs' => 0, 'tvBekleme' => true, 'tvDurdur' => false, 'tvSiyah' => false, 'tvMesaj' => '', 'surum' => 0, 'kapatan' => null, 'gecmis' => array() );
}
function sides_bakim_tz() {
	return new DateTimeZone( 'Europe/Istanbul' );
}
/* Durumu okur; planlı açılış zamanı geçtiyse sistemi açar (bir kez yazar, geçmişe "planlı açılış" düşer) */
function sides_bakim_oku( $org ) {
	$d = sides_get_doc( (int) $org, 'sistem', 'bakim' );
	$b = array_merge( sides_bakim_bos(), is_array( $d ) ? $d : array() );
	unset( $b['id'], $b['token'] );
	if ( ! is_array( $b['gecmis'] ) ) {
		$b['gecmis'] = array();
	}
	if ( ! empty( $b['kapali'] ) && (int) $b['acilisTs'] > 0 && time() >= (int) $b['acilisTs'] ) {
		$b['kapali']   = false;
		$b['surum']    = (int) $b['surum'] + 1;
		$b['gecmis'][] = array( 't' => time(), 'uid' => 0, 'ad' => 'Planlı açılış', 'islem' => 'otomatik-ac', 'acilis' => $b['acilis'] );
		$b['acilis']   = '';
		$b['acilisTs'] = 0;
		sides_bakim_kaydet( (int) $org, $b );
		sides_log( (int) $org, 'Sistem planlanan zamanda kendiliğinden açıldı', 'Sistem' );
	}
	return $b;
}
function sides_bakim_kaydet( $org, $b ) {
	$b['gecmis'] = array_values( array_slice( (array) $b['gecmis'], -100 ) );
	$ok          = sides_put_doc( (int) $org, 'sistem', 'bakim', $b );
	$l           = get_option( 'sides_bakim_orgs' );
	$l           = is_array( $l ) ? $l : array();
	if ( ! empty( $b['kapali'] ) || ! empty( $b['tvDurdur'] ) ) {
		$l[ (int) $org ] = 1;
	} else {
		unset( $l[ (int) $org ] );
	}
	update_option( 'sides_bakim_orgs', $l, true );
	return false !== $ok;
}
function sides_bakim_listede( $org ) {
	$l = get_option( 'sides_bakim_orgs' );
	return is_array( $l ) && isset( $l[ (int) $org ] );
}
/* Kurum kapalı mı (hızlı yol: listede yoksa sorgu yapılmaz) */
function sides_bakim_kapali( $org ) {
	if ( ! $org || ! sides_bakim_listede( $org ) ) {
		return null;
	}
	$b = sides_bakim_oku( $org );
	return ! empty( $b['kapali'] ) ? $b : null;
}

/* ---------- kapı ---------- */
function sides_bakim_istek_token( WP_REST_Request $req ) {
	foreach ( array( 't', 'token', 'tok' ) as $k ) {
		$v = $req->get_param( $k );
		if ( is_string( $v ) && preg_match( '/^[a-f0-9]{32}$/', $v ) ) {
			return $v;
		}
	}
	if ( preg_match( '#/([a-f0-9]{32})(?:/|$)#', $req->get_route(), $m ) ) {
		return $m[1];
	}
	return '';
}
function sides_bakim_token_org( $tok ) {
	global $wpdb;
	if ( ! preg_match( '/^[a-f0-9]{32}$/', (string) $tok ) ) {
		return 0;
	}
	$t = sides_docs();
	return (int) $wpdb->get_var( $wpdb->prepare( "SELECT org FROM $t WHERE token = %s LIMIT 1", $tok ) ); // phpcs:ignore
}
function sides_bakim_yanit( $b ) {
	$r = new WP_REST_Response( array(
		'code'    => 'sides_bakim',
		'message' => '' !== trim( (string) $b['mesaj'] ) ? (string) $b['mesaj'] : SIDES_BAKIM_MESAJ,
		'data'    => array( 'status' => 503, 'acilis' => (string) $b['acilis'], 'surum' => (int) $b['surum'] ),
	), 503 );
	$r->header( 'Retry-After', (string) ( (int) $b['acilisTs'] > time() ? min( 3600, max( 30, (int) $b['acilisTs'] - time() ) ) : 120 ) );
	$r->header( 'Cache-Control', 'no-store' );
	return $r;
}
add_filter( 'rest_pre_dispatch', 'sides_bakim_kapi', 5, 3 );
function sides_bakim_kapi( $res, $server, $req ) {
	if ( null !== $res ) {
		return $res;
	}
	$route = (string) $req->get_route();
	if ( 0 !== strpos( $route, '/optik-karne/v1/' ) ) {
		return $res;
	}
	$l = get_option( 'sides_bakim_orgs' );
	if ( ! is_array( $l ) || ! $l ) {
		return $res;   // hiçbir kurum kapalı değil
	}
	$r = substr( $route, strlen( '/optik-karne/v1' ) );
	if ( preg_match( '#^/(bakim/durum|oturum|kayit-bilgi|kayit|tv/[a-f0-9]{32}(/.*)?)$#', $r ) ) {
		return $res;
	}
	if ( sides_is_super() ) {
		return $res;   // ana hesap hiçbir zaman engellenmez
	}
	$uid  = get_current_user_id();
	$yon  = 0;
	$orgs = array();
	if ( $uid ) {
		$c = sides_ctx( $uid );   // gerçek kullanıcı (önizleme hedefi değil)
		if ( $c['org'] ) {
			if ( 'yonetici' === $c['rol'] ) {
				$yon = (int) $c['org'];
			} else {
				$orgs[] = (int) $c['org'];
			}
		}
	}
	$tok = sides_bakim_istek_token( $req );
	if ( $tok ) {
		$to = sides_bakim_token_org( $tok );
		if ( $to && $to !== $yon ) {
			$orgs[] = $to;
		}
	}
	foreach ( array_unique( $orgs ) as $o ) {
		if ( ! isset( $l[ $o ] ) ) {
			continue;
		}
		$b = sides_bakim_kapali( $o );
		if ( $b ) {
			return sides_bakim_yanit( $b );
		}
	}
	return $res;
}

/* ---------- TV ---------- */
/* TV bekleme etkinse küçük yanıt (öğrenci sıralaması, program, duyuru gönderilmez); değilse null */
function sides_bakim_tv_yanit( $org ) {
	if ( ! sides_bakim_listede( $org ) ) {
		return null;
	}
	$b   = sides_bakim_oku( $org );
	$tur = ! empty( $b['tvDurdur'] ) ? 'tv' : ( ! empty( $b['kapali'] ) && ! empty( $b['tvBekleme'] ) ? 'kapali' : '' );
	if ( ! $tur ) {
		return null;
	}
	$set  = sides_get_doc( $org, 'settings', 'main' );
	$ayrH = sides_get_doc( $org, 'tv', 'ayar' );
	$ayar = function_exists( 'sides_tv_ayar_disari' ) ? sides_tv_ayar_disari( $ayrH ) : array( 'tema' => 'acik', 'renkProfil' => 'lacivert', 'vakit' => array( 'tz' => 'Europe/Istanbul' ) );
	$tz   = isset( $ayar['vakit']['tz'] ) ? (string) $ayar['vakit']['tz'] : 'Europe/Istanbul';
	try {
		$zone = new DateTimeZone( $tz );
	} catch ( Exception $e ) {
		$zone = sides_bakim_tz();
		$tz   = 'Europe/Istanbul';
	}
	$mesaj = 'tv' === $tur && '' !== trim( (string) $b['tvMesaj'] ) ? (string) $b['tvMesaj'] : ( '' !== trim( (string) $b['mesaj'] ) ? (string) $b['mesaj'] : '' );
	$out   = array(
		'bekleme' => array( 'tur' => $tur, 'siyah' => 'tv' === $tur && ! empty( $b['tvSiyah'] ), 'mesaj' => $mesaj, 'acilis' => 'kapali' === $tur ? (string) $b['acilis'] : '', 'surum' => (int) $b['surum'] ),
		'kurum'   => array( 'ad' => $set && isset( $set['kurum'] ) ? (string) $set['kurum'] : '', 'logo' => $set && isset( $set['logo'] ) ? (string) $set['logo'] : '' ),
		'ayar'    => array( 'tema' => 'koyu' === $ayar['tema'] ? 'koyu' : 'acik', 'renkProfil' => isset( $ayar['renkProfil'] ) ? $ayar['renkProfil'] : 'lacivert', 'vakit' => array( 'tz' => $tz ), 'yenile' => 5 ),
		'simdi'   => ( new DateTime( 'now', $zone ) )->format( 'Y-m-d\TH:i:s' ),
	);
	$res = rest_ensure_response( $out );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}

/* v7.8 Yönetim önizlemesi için bekleme özeti (yalnız tür, mesaj, planlı açılış); bekleme yoksa null */
function sides_bakim_tv_durum( $org ) {
	if ( ! sides_bakim_listede( $org ) ) {
		return null;
	}
	$b   = sides_bakim_oku( $org );
	$tur = ! empty( $b['tvDurdur'] ) ? 'tv' : ( ! empty( $b['kapali'] ) && ! empty( $b['tvBekleme'] ) ? 'kapali' : '' );
	if ( ! $tur ) {
		return null;
	}
	$mesaj = 'tv' === $tur && '' !== trim( (string) $b['tvMesaj'] ) ? (string) $b['tvMesaj'] : (string) $b['mesaj'];
	return array( 'tur' => $tur, 'siyah' => 'tv' === $tur && ! empty( $b['tvSiyah'] ), 'mesaj' => $mesaj, 'acilis' => 'kapali' === $tur ? (string) $b['acilis'] : '' );
}

/* ---------- uçlar ---------- */
function sides_bakim_disari( $b, $tam ) {
	$o = array(
		'kapali'    => ! empty( $b['kapali'] ),
		'mesaj'     => (string) $b['mesaj'],
		'acilis'    => (string) $b['acilis'],
		'tvBekleme' => ! empty( $b['tvBekleme'] ),
		'tvDurdur'  => ! empty( $b['tvDurdur'] ),
		'tvSiyah'   => ! empty( $b['tvDurdur'] ) && ! empty( $b['tvSiyah'] ),
		'tvMesaj'   => (string) $b['tvMesaj'],
		'surum'     => (int) $b['surum'],
	);
	if ( $tam ) {
		$o['kapatan'] = $b['kapatan'];
		$o['gecmis']  = array_reverse( (array) $b['gecmis'] );
		$o['simdi']   = ( new DateTime( 'now', sides_bakim_tz() ) )->format( 'Y-m-d\TH:i' );
	}
	return $o;
}
function sides_rest_bakim_oku() {
	return sides_bakim_disari( sides_bakim_oku( sides_org_id() ), true );
}
/* 'YYYY-MM-DDTHH:MM' (İstanbul) → unix; geçersizse WP_Error, boşsa 0 */
function sides_bakim_acilis_ts( $v ) {
	$v = trim( (string) $v );
	if ( '' === $v ) {
		return 0;
	}
	if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}$/', $v ) ) {
		return new WP_Error( 'sides_gecersiz', 'Açılış zamanı geçersiz.', array( 'status' => 400 ) );
	}
	$d = DateTime::createFromFormat( 'Y-m-d\TH:i', $v, sides_bakim_tz() );
	if ( ! $d || $d->format( 'Y-m-d\TH:i' ) !== $v ) {
		return new WP_Error( 'sides_gecersiz', 'Açılış zamanı geçersiz.', array( 'status' => 400 ) );
	}
	$ts = $d->getTimestamp();
	if ( $ts <= time() + 30 ) {
		return new WP_Error( 'sides_gecersiz', 'Planlanan açılış zamanı ileri bir saat olmalı.', array( 'status' => 400 ) );
	}
	if ( $ts > time() + 60 * 86400 ) {
		return new WP_Error( 'sides_gecersiz', 'Planlanan açılış en çok 60 gün sonrası olabilir.', array( 'status' => 400 ) );
	}
	return $ts;
}
function sides_rest_bakim_yaz( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = (array) $req->get_json_params();
	$is  = isset( $p['islem'] ) ? (string) $p['islem'] : '';
	if ( ! in_array( $is, array( 'kapat', 'ac', 'guncelle', 'tv-beklet', 'tv-siyah', 'tv-devam' ), true ) ) {   /* v7.9.5 tv-siyah: TV tamamen siyah (kapalı gibi) */
		return new WP_Error( 'sides_gecersiz', 'Geçersiz işlem.', array( 'status' => 400 ) );
	}
	if ( ! sides_rl( 'bakim_' . get_current_user_id(), 60, 600 ) ) {
		return new WP_Error( 'sides_hiz', 'Çok sık değişiklik; biraz bekleyin.', array( 'status' => 429 ) );
	}
	$mesaj = isset( $p['mesaj'] ) ? mb_substr( trim( sanitize_textarea_field( (string) $p['mesaj'] ) ), 0, 300 ) : '';
	$tvm   = isset( $p['tvMesaj'] ) ? mb_substr( trim( sanitize_textarea_field( (string) $p['tvMesaj'] ) ), 0, 200 ) : '';
	$u     = wp_get_current_user();
	$kim   = array( 'uid' => (int) $u->ID, 'ad' => $u->display_name ? $u->display_name : $u->user_login, 't' => time() );
	$kilit = function_exists( 'sides_takip_kilit' ) ? sides_takip_kilit( $org . '|sistem|bakim' ) : '';
	if ( false === $kilit ) {
		return sides_kilit_mesgul();
	}
	$b = sides_bakim_oku( $org );
	$g = array( 't' => $kim['t'], 'uid' => $kim['uid'], 'ad' => $kim['ad'], 'islem' => $is );
	if ( 'kapat' === $is || 'guncelle' === $is ) {
		$ts = sides_bakim_acilis_ts( isset( $p['acilis'] ) ? $p['acilis'] : '' );
		if ( is_wp_error( $ts ) ) {
			sides_takip_kilit_birak( $kilit );
			return $ts;
		}
		if ( 'guncelle' === $is && empty( $b['kapali'] ) ) {
			sides_takip_kilit_birak( $kilit );
			return new WP_Error( 'sides_gecersiz', 'Sistem zaten açık; güncellenecek kapalı durum yok.', array( 'status' => 409 ) );
		}
		if ( 'kapat' === $is && ! empty( $b['kapali'] ) ) {
			$g['islem'] = 'guncelle';   // zaten kapalı: yeniden kapatma, yalnızca ayrıntı güncellenir
		}
		$b['mesaj']     = $mesaj;
		$b['acilisTs']  = (int) $ts;
		$b['acilis']    = $ts ? ( new DateTime( '@' . $ts ) )->setTimezone( sides_bakim_tz() )->format( 'Y-m-d\TH:i' ) : '';
		$b['tvBekleme'] = ! empty( $p['tvBekleme'] );
		if ( empty( $b['kapali'] ) ) {
			$b['kapatan'] = $kim;
		}
		$b['kapali'] = true;
		$g['mesaj']  = $mesaj;
		$g['acilis'] = $b['acilis'];
		$g['tv']     = $b['tvBekleme'];
		$log         = 'kapat' === $g['islem'] ? 'Sistem kapatıldı' . ( $b['acilis'] ? ' (planlı açılış: ' . str_replace( 'T', ' ', $b['acilis'] ) . ')' : '' ) : 'Sistem kapalılık bilgisi güncellendi';
	} elseif ( 'ac' === $is ) {
		if ( empty( $b['kapali'] ) ) {
			sides_takip_kilit_birak( $kilit );
			return array_merge( sides_bakim_disari( $b, true ), array( 'degismedi' => true ) );
		}
		$b['kapali']   = false;
		$b['acilis']   = '';
		$b['acilisTs'] = 0;
		$b['kapatan']  = null;
		$log           = 'Sistem açıldı';
	} elseif ( 'tv-beklet' === $is ) {
		$b['tvDurdur'] = true;
		$b['tvSiyah']  = false;
		$b['tvMesaj']  = $tvm;
		$g['mesaj']    = $tvm;
		$log           = 'TV panoları beklemeye alındı';
	} elseif ( 'tv-siyah' === $is ) {   /* v7.9.5 */
		if ( ! empty( $b['tvDurdur'] ) && ! empty( $b['tvSiyah'] ) ) {
			sides_takip_kilit_birak( $kilit );
			return array_merge( sides_bakim_disari( $b, true ), array( 'degismedi' => true ) );
		}
		$b['tvDurdur'] = true;
		$b['tvSiyah']  = true;
		$log           = 'TV panoları siyah ekrana alındı';
	} else {
		if ( empty( $b['tvDurdur'] ) ) {
			sides_takip_kilit_birak( $kilit );
			return array_merge( sides_bakim_disari( $b, true ), array( 'degismedi' => true ) );
		}
		$b['tvDurdur'] = false;
		$b['tvSiyah']  = false;
		$log           = 'TV panoları yeniden yayına alındı';
	}
	$b['surum']    = (int) $b['surum'] + 1;
	$b['gecmis'][] = $g;
	$ok            = sides_bakim_kaydet( $org, $b );
	sides_takip_kilit_birak( $kilit );
	if ( ! $ok ) {
		return new WP_Error( 'sides_db', 'Kaydedilemedi; durum değişmedi.', array( 'status' => 500 ) );
	}
	sides_log( $org, $log );
	return sides_bakim_disari( $b, true );
}
/* Engellenen ekranın açılışı beklerken sorduğu uç: giriş yapan kullanıcının ya da belirtecin kurumu; ayrıntı yok */
function sides_rest_bakim_durum( WP_REST_Request $req ) {
	if ( ! sides_rl( 'bakim_durum', 600, 600 ) ) {
		return new WP_Error( 'sides_rl', 'Çok fazla istek.', array( 'status' => 429 ) );
	}
	$org = 0;
	$uid = get_current_user_id();
	if ( $uid ) {
		$c   = sides_ctx( $uid );
		$org = (int) $c['org'];
	}
	if ( ! $org ) {
		$org = sides_bakim_token_org( (string) $req->get_param( 't' ) );
	}
	$b   = $org ? sides_bakim_kapali( $org ) : null;
	$res = rest_ensure_response( $b ? array( 'kapali' => true, 'mesaj' => '' !== trim( (string) $b['mesaj'] ) ? (string) $b['mesaj'] : SIDES_BAKIM_MESAJ, 'acilis' => (string) $b['acilis'] ) : array( 'kapali' => false ) );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}
/* /all yanıtı için (yalnız yöneticiye): kapalıysa kısa özet; yönetici uygulamada "sistem kapalı" bandını görür */
function sides_bakim_ozet( $org ) {
	if ( 'yonetici' !== sides_ctx()['rol'] || ! sides_bakim_listede( $org ) ) {
		return null;
	}
	$b = sides_bakim_oku( $org );
	if ( empty( $b['kapali'] ) && empty( $b['tvDurdur'] ) ) {
		return null;
	}
	return array( 'kapali' => ! empty( $b['kapali'] ), 'tvDurdur' => ! empty( $b['tvDurdur'] ), 'acilis' => (string) $b['acilis'] );
}
