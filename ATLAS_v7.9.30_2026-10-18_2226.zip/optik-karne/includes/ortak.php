<?php
/**
 * v5.3 ortak altyapı: koleksiyon okuma ucu (tarih aralığı ve sınıf yetkisi süzgeçli), eğitim yılı yardımcıları,
 * hareket kimliği ile yinelenen istek koruması ve kurum ayarları içindeki modül ayarlarına erişim.
 *
 * GET /koleksiyon/<coll>?bas=YYYY-MM-DD&bit=YYYY-MM-DD&ogr=<studentId>&alan=<tarih alanı>
 *   Kurumun o koleksiyondaki belgelerini döndürür. Sınıf yetkili kullanıcı yalnızca izinli öğrencilerin (studentId) belgelerini alır.
 *   bas/bit verilirse belgenin tarih alanına (varsayılan 'tarih'; yoksa id'nin YYYY-MM-DD ile başlayan kısmına) göre süzülür; bitiş dahildir.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SIDES_OKUNUR_COLL', array(
	'hedef' => 'takip', 'hsablon' => 'takip', 'workwin' => 'takip', 'sgunluk' => 'takip', 'etut' => 'takip', 'izin' => 'takip', 'kitap' => 'takip', 'takviye' => 'takip', 'seviye' => 'takip', 'dgrup' => 'takip', 'yoklama' => 'takip', 'odev' => 'takip', 'dplan' => 'takip', 'doturum' => 'takip',
	'pkriter' => 'puan', 'phareket' => 'puan', 'pgun' => 'puan', 'podul' => 'puan', 'tv' => 'puan',
	'rsablon' => 'rapor', 'rapor' => 'rapor', 'birlesik' => 'analiz', 'velirapor' => 'analiz',
) );

/* Eğitim yılı: Eylül'de başlar (ayarlardan değiştirilebilir: settings.main.egitim = ['basAy' => 9, 'bitAy' => 6]) */
function sides_egitim_ayar( $org ) {
	$s = sides_get_doc( $org, 'settings', 'main' );
	$e = $s && isset( $s['egitim'] ) && is_array( $s['egitim'] ) ? $s['egitim'] : array();
	return array( 'basAy' => isset( $e['basAy'] ) ? max( 1, min( 12, (int) $e['basAy'] ) ) : 9, 'bitAy' => isset( $e['bitAy'] ) ? max( 1, min( 12, (int) $e['bitAy'] ) ) : 6 );
}
function sides_egitim_yili( $org, $tarih = null ) {
	$a = sides_egitim_ayar( $org );
	$t = $tarih ? strtotime( $tarih ) : current_time( 'timestamp' );
	$y = (int) gmdate( 'Y', $t );
	$m = (int) gmdate( 'n', $t );
	return $m >= $a['basAy'] ? $y : $y - 1;   // 2026-2027 yılı için 2026
}

function sides_rest_koleksiyon( WP_REST_Request $req ) {
	global $wpdb;
	$coll = (string) $req['coll'];
	if ( ! isset( SIDES_OKUNUR_COLL[ $coll ] ) ) {
		return new WP_Error( 'sides_yok', 'Koleksiyon bulunamadı.', array( 'status' => 404 ) );
	}
	if ( ! sides_can( SIDES_OKUNUR_COLL[ $coll ], 1 ) ) {
		return sides_deny( 'Bu modülü görme yetkiniz yok.' );
	}
	$org  = sides_org_id();
	$t    = sides_docs();
	$bas  = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $req['bas'] ) ? (string) $req['bas'] : '';
	$bit  = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $req['bit'] ) ? (string) $req['bit'] : '';
	$ogr  = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $req['ogr'] );
	$alan = preg_match( '/^[a-zA-Z]{1,20}$/', (string) $req['alan'] ) ? (string) $req['alan'] : 'tarih';
	$rows = $wpdb->get_results( $wpdb->prepare( "SELECT id, token, data, updated_at, updated_by FROM $t WHERE org = %d AND coll = %s ORDER BY id", $org, $coll ) ); // phpcs:ignore
	$kisit = sides_sinif_kisit();
	$izin  = null === $kisit ? null : sides_izinli_ogrenciler( $org, $kisit );
	$out   = array();
	foreach ( $rows as $r ) {
		$d = json_decode( $r->data, true );
		if ( ! is_array( $d ) ) {
			continue;
		}
		$sid = isset( $d['studentId'] ) ? (string) $d['studentId'] : '';
		if ( null !== $izin && $sid && ! isset( $izin[ $sid ] ) ) {
			continue;
		}
		$tam = 'takviye' !== $coll || ! function_exists( 'sides_takviye_kapsamda' ) || sides_takviye_kapsamda( $d, $izin );   // v7.3.1: süzmeden önce
		if ( null !== $izin && in_array( $coll, array( 'etut', 'izin', 'kitap', 'takviye', 'dgrup', 'yoklama' ), true ) ) {   // öğrenci haritaları da süzülür (T02)
			$d = sides_takip_suz_belge( $coll, $d, $izin );
			if ( null === $d ) {
				continue;
			}
		}
		if ( function_exists( 'sides_v6_suz' ) ) {   // v6 modülleri: sınıf kapsamına göre süzme (null = gösterme) — includes/odev.php
			$d = sides_v6_suz( $coll, $d, $izin );
			if ( null === $d ) {
				continue;
			}
		}
		if ( $ogr && $sid !== $ogr ) {
			continue;
		}
		if ( $bas || $bit ) {
			$tar = isset( $d[ $alan ] ) ? substr( (string) $d[ $alan ], 0, 10 ) : ( preg_match( '/^\d{4}-\d{2}-\d{2}/', $r->id ) ? substr( $r->id, 0, 10 ) : '' );
			if ( $tar && ( ( $bas && $tar < $bas ) || ( $bit && $tar > $bit ) ) ) {
				continue;
			}
		}
		$d['id'] = $r->id;
		$yazar = ! sides_is_observer() && sides_can( SIDES_OKUNUR_COLL[ $coll ], 2 );
		if ( 'velirapor' === $coll || 'tv' === $coll || 'takviye' === $coll ) {   // paylaşım bağlantıları yalnız yazma yetkisi olana (T04)
			$d['token'] = $r->token && $yazar && $tam ? $r->token : null;
		}
		if ( 'velirapor' === $coll && ! $yazar ) {
			unset( $d['ic'] );   // kurum içi not
		}
		$d['_g'] = $r->updated_at;
		$out[] = $d;
	}
	$res = rest_ensure_response( $out );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'optik-karne/v1', '/koleksiyon/(?P<coll>[a-z]{2,16})', array( 'methods' => 'GET', 'callback' => 'sides_rest_koleksiyon', 'permission_callback' => function () {
		return sides_org_id() ? true : sides_deny( 'Oturum açmanız gerekiyor.' );
	} ) );
} );

/* v5.4: Nehari öğrencileri (3, 4, N5) varsayılan olarak yalnızca Nehari Modülü'nde görünür; ayar: settings.main.nehariAyri === false ise her yerde. */
function sides_nehari_ayri( $org ) {
	$s = sides_get_doc( $org, 'settings', 'main' );
	return ! ( is_array( $s ) && array_key_exists( 'nehariAyri', $s ) && false === $s['nehariAyri'] );
}
function sides_nehari_sinifi( $sinif ) {
	return in_array( strtoupper( trim( (string) $sinif ) ), array( '3', '4', 'N5' ), true );
}
