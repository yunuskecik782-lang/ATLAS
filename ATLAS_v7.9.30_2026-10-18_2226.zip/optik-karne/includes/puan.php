<?php
/**
 * Puan Sistemi (v5.3): kriterler, hareket defteri (artı/eksi), gün durumu (taslak/tamam/muaf), hafta kapatma,
 * dönem özeti. TV panosu da sides_puan_gunler() ile aynı gün/etki verisini kullanır.
 *
 * Koleksiyonlar (sides_docs): pkriter (kriterler), phareket (hareket defteri; id = istemcinin islemId'si),
 * pgun (öğrenci-gün durumu; id = studentId_tarih), podul (ödül ve kapanmış hafta anlık görüntüleri).
 * Ayarlar: settings/main içindeki "puan" nesnesi (başlangıç, yöntem, çakışma kuralı, ödül, günlük limit, kapalı haftalar).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SIDES_PUAN_VAKIT', array( 'sabah', 'ogle', 'ikindi', 'aksam', 'yatsi' ) );
define( 'SIDES_PUAN_KAYNAK', array( 'gunluk', 'manuel', 'izin', 'haftalik' ) );

/* ------------------------------------------------------------------ *
 * Ayarlar
 * ------------------------------------------------------------------ */
function sides_puan_varsayilan() {
	return array( 'baslangic' => 100, 'yontem' => 'haftalik', 'cakisma' => 'topla', 'odulSayisi' => 3, 'asgariTamlik' => 0.7, 'gunlukLimit' => 0, 'esitlik' => 'sirali', 'ondalik' => 2, 'gunler' => array( 1, 2, 3, 4, 5, 6, 7 ), 'kapali' => array() );
}
function sides_puan_ayar( $org ) {
	$s = sides_get_doc( $org, 'settings', 'main' );
	$p = $s && isset( $s['puan'] ) && is_array( $s['puan'] ) ? $s['puan'] : array();
	$a = array_merge( sides_puan_varsayilan(), $p );
	$a['yontem'] = 'haftalik';   // v6.0.4: puan her zaman haftalık; eski ortalama/toplam kaydı yok sayılır
	if ( ! is_array( $a['kapali'] ) ) {
		$a['kapali'] = array();
	}
	return $a;
}
/* Gelen ayarları süzer (kapalı haftalar burada değişmez) */
function sides_puan_ayar_suz( $p, $eski ) {
	$a = $eski;
	if ( isset( $p['baslangic'] ) && is_numeric( $p['baslangic'] ) ) {
		$a['baslangic'] = round( max( -1000, min( 10000, (float) $p['baslangic'] ) ), 2 );
	}
	$a['yontem'] = 'haftalik';
	if ( isset( $p['cakisma'] ) && in_array( $p['cakisma'], array( 'topla', 'gelmeme', 'engelle' ), true ) ) {
		$a['cakisma'] = $p['cakisma'];
	}
	if ( isset( $p['odulSayisi'] ) && is_numeric( $p['odulSayisi'] ) ) {
		$a['odulSayisi'] = max( 1, min( 100, (int) $p['odulSayisi'] ) );
	}
	if ( isset( $p['asgariTamlik'] ) && is_numeric( $p['asgariTamlik'] ) ) {
		$a['asgariTamlik'] = round( max( 0, min( 1, (float) $p['asgariTamlik'] ) ), 2 );
	}
	if ( isset( $p['gunlukLimit'] ) && is_numeric( $p['gunlukLimit'] ) ) {
		$a['gunlukLimit'] = max( 0, min( 1000, (int) $p['gunlukLimit'] ) );
	}
	if ( isset( $p['gunler'] ) && is_array( $p['gunler'] ) ) {
		$g = array_values( array_unique( array_filter( array_map( 'intval', $p['gunler'] ), function ( $x ) {
			return $x >= 1 && $x <= 7;
		} ) ) );
		sort( $g );
		$a['gunler'] = $g ? $g : array( 1, 2, 3, 4, 5, 6, 7 );
	}
	$a['esitlik'] = 'sirali';   // v7: sıra numarası tekrar etmez; eşit puanda alfabetik
	$a['ondalik'] = 2;
	return $a;
}
function sides_puan_ayar_kaydet( $org, $a ) {
	$s = sides_get_doc( $org, 'settings', 'main' );
	$s = $s ? $s : array();
	unset( $s['id'], $s['token'] );
	$s['puan'] = $a;
	return sides_put_doc( $org, 'settings', 'main', $s );
}

/* ------------------------------------------------------------------ *
 * Belge okuma yardımcıları
 * ------------------------------------------------------------------ */
/* Koleksiyon belgeleri; bas/bit belgenin tarih alanına göre (dahil), like: JSON içinde ön süzgeç */
function sides_puan_docs( $org, $coll, $bas = '', $bit = '', $like = '' ) {
	global $wpdb;
	$t    = sides_docs();
	$sql  = "SELECT id, data FROM $t WHERE org = %d AND coll = %s";
	$args = array( $org, $coll );
	if ( $like ) {
		$sql   .= ' AND data LIKE %s';
		$args[] = '%' . $wpdb->esc_like( $like ) . '%';
	}
	$rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ) ); // phpcs:ignore
	$out  = array();
	foreach ( (array) $rows as $r ) {
		$d = json_decode( $r->data, true );
		if ( ! is_array( $d ) ) {
			continue;
		}
		$tar = isset( $d['tarih'] ) ? substr( (string) $d['tarih'], 0, 10 ) : '';
		if ( ( $bas && $tar < $bas ) || ( $bit && $tar > $bit ) ) {
			continue;
		}
		$d['id'] = $r->id;
		$out[]   = $d;
	}
	return $out;
}
function sides_puan_hafta_basi( $tarih ) {
	$ts = strtotime( $tarih . ' 12:00:00' );
	$g  = (int) gmdate( 'N', $ts );   // 1 = Pazartesi
	return gmdate( 'Y-m-d', $ts - ( $g - 1 ) * DAY_IN_SECONDS );
}
function sides_puan_tarih_mi( $s ) {
	return is_string( $s ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $s ) && checkdate( (int) substr( $s, 5, 2 ), (int) substr( $s, 8, 2 ), (int) substr( $s, 0, 4 ) );
}
function sides_puan_ms() {
	return (int) round( microtime( true ) * 1000 );
}
function sides_puan_kim() {
	$u = wp_get_current_user();
	$c = sides_ctx();
	return array( 'id' => (int) $c['uid'], 'ad' => $u && $u->ID ? $u->display_name : 'Sistem' );
}
/* Sınıf kısıtı: null = kısıt yok; aksi hâlde izinli öğrenci kimlikleri (id => true) */
function sides_puan_izin( $org ) {
	$k = sides_sinif_kisit();
	return null === $k ? null : sides_izinli_ogrenciler( $org, $k );
}

/* ------------------------------------------------------------------ *
 * ORTAK HESAP GİRDİSİ — TV panosu da bunu çağırır (imza sabittir)
 * Dönüş: [ ['sid' => ..., 'tarih' => 'YYYY-MM-DD', 'durum' => 'taslak'|'tamam'|'muaf', 'etki' => float], ... ]
 * - durum pgun belgesinden gelir; belgesi olmayan gün 'taslak'tır (işaret olsa bile tam puan sayılmaz).
 * - etki: iptal edilmemiş hareketlerin toplamı. Çakışma kuralı 'gelmeme' ise aynı vakitte gelmeme varken geç gelme etkisi sayılmaz.
 * - 'haftalik' kaynaklı ek düzeltmeler (hedefHafta) haftanın ilk tamamlanmış gününe eklenir; böylece dönem toplamına bir kez girer.
 *   Tamamlanmış gün yoksa hesaba girmez (doğrulama kuyruğunda kalır). Ad, gerekçe gibi hiçbir kişisel alan döndürülmez.
 * ------------------------------------------------------------------ */
function sides_puan_gunler( $org, $bas, $bit ) {
	$ayar = sides_puan_ayar( $org );
	$gun  = array();
	foreach ( sides_puan_docs( $org, 'pgun', $bas, $bit ) as $g ) {
		if ( empty( $g['studentId'] ) || empty( $g['tarih'] ) ) {
			continue;
		}
		$k         = $g['studentId'] . '|' . $g['tarih'];
		$gun[ $k ] = array( 'sid' => (string) $g['studentId'], 'tarih' => (string) $g['tarih'], 'durum' => in_array( $g['durum'] ?? '', array( 'tamam', 'muaf' ), true ) ? $g['durum'] : 'taslak', 'etki' => 0.0 );
	}
	$H       = sides_puan_docs( $org, 'phareket', $bas, $bit );
	$gelmeme = array();
	if ( 'gelmeme' === $ayar['cakisma'] ) {
		foreach ( $H as $h ) {
			if ( empty( $h['iptal'] ) && 'gelmeme' === ( $h['grup'] ?? '' ) && ! empty( $h['vakit'] ) ) {
				$gelmeme[ $h['studentId'] . '|' . $h['tarih'] . '|' . $h['vakit'] ] = true;
			}
		}
	}
	$hafta = array();
	foreach ( $H as $h ) {
		if ( ! empty( $h['iptal'] ) || empty( $h['studentId'] ) || empty( $h['tarih'] ) ) {
			continue;
		}
		$sid = (string) $h['studentId'];
		$e   = isset( $h['etki'] ) ? (float) $h['etki'] : 0.0;
		if ( 'haftalik' === ( $h['kaynak'] ?? '' ) ) {
			$hb           = ! empty( $h['hedefHafta'] ) ? (string) $h['hedefHafta'] : sides_puan_hafta_basi( $h['tarih'] );
			$hafta[ $sid . '|' . $hb ] = ( $hafta[ $sid . '|' . $hb ] ?? 0 ) + $e;
			continue;
		}
		if ( 'gelmeme' === $ayar['cakisma'] && 'gec' === ( $h['grup'] ?? '' ) && ! empty( $h['vakit'] ) && isset( $gelmeme[ $sid . '|' . $h['tarih'] . '|' . $h['vakit'] ] ) ) {
			continue;
		}
		$k = $sid . '|' . $h['tarih'];
		if ( ! isset( $gun[ $k ] ) ) {
			$gun[ $k ] = array( 'sid' => $sid, 'tarih' => (string) $h['tarih'], 'durum' => 'taslak', 'etki' => 0.0 );
		}
		$gun[ $k ]['etki'] += $e;
	}
	foreach ( $hafta as $k => $e ) {
		list( $sid, $hb ) = explode( '|', $k );
		$hs  = gmdate( 'Y-m-d', strtotime( $hb . ' 12:00:00' ) + 6 * DAY_IN_SECONDS );
		$ilk = null;
		foreach ( $gun as $kk => $g ) {
			if ( $g['sid'] === $sid && 'tamam' === $g['durum'] && $g['tarih'] >= $hb && $g['tarih'] <= $hs && ( null === $ilk || $g['tarih'] < $gun[ $ilk ]['tarih'] ) ) {
				$ilk = $kk;
			}
		}
		if ( null === $ilk && 'haftalik' === $ayar['yontem'] ) {   // haftalık yöntemde tamamlanmış gün olmasa da ek düzeltme kaybolmaz
			foreach ( $gun as $kk => $g ) {
				if ( $g['sid'] === $sid && 'muaf' !== $g['durum'] && $g['tarih'] >= $hb && $g['tarih'] <= $hs && ( null === $ilk || $g['tarih'] < $gun[ $ilk ]['tarih'] ) ) {
					$ilk = $kk;
				}
			}
			if ( null === $ilk ) {
				$t         = $hb < $bas ? $bas : $hb;
				$ilk       = $sid . '|' . $t;
				$gun[ $ilk ] = array( 'sid' => $sid, 'tarih' => $t, 'durum' => 'taslak', 'etki' => 0.0 );
			}
		}
		if ( null !== $ilk ) {
			$gun[ $ilk ]['etki'] += $e;
		}
	}
	ksort( $gun );
	$out = array();
	foreach ( $gun as $g ) {
		$g['etki'] = round( $g['etki'], 4 );
		$out[]     = $g;
	}
	return $out;
}

/* ------------------------------------------------------------------ *
 * REST
 * ------------------------------------------------------------------ */
add_action( 'rest_api_init', function () {
	$ns  = 'optik-karne/v1';
	$oku = function () {
		return sides_can( 'puan', 1 ) ? true : sides_deny( 'Puan sistemini görme yetkiniz yok.' );
	};
	$yaz = function () {
		return sides_can( 'puan', 2 ) ? true : sides_deny( 'Puan sisteminde değişiklik yapma yetkiniz yok.' );
	};
	/* Kurum geneli işlemler (ayar, hafta kapatma, kriter silme): puan yazma yetkisi ve sınıf kısıtı olmayan kullanıcı */
	$yonet = function () {
		if ( ! sides_can( 'puan', 2 ) ) {
			return sides_deny( 'Puan sisteminde değişiklik yapma yetkiniz yok.' );
		}
		return null === sides_sinif_kisit() ? true : sides_deny( 'Bu işlem için kurum genelinde yetki gerekir (sınıf kısıtı olan kullanıcı yapamaz).' );
	};
	register_rest_route( $ns, '/puan/hareket', array( 'methods' => 'POST', 'callback' => 'sides_puan_hareket', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/puan/iptal', array( 'methods' => 'POST', 'callback' => 'sides_puan_iptal', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/puan/gun', array( 'methods' => 'POST', 'callback' => 'sides_puan_gun', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/puan/haftaKapat', array( 'methods' => 'POST', 'callback' => 'sides_puan_hafta_kapat', 'permission_callback' => $yonet ) );
	register_rest_route( $ns, '/puan/haftaAc', array( 'methods' => 'POST', 'callback' => 'sides_puan_hafta_ac', 'permission_callback' => $yonet ) );
	register_rest_route( $ns, '/puan/haftaOdul', array( 'methods' => 'POST', 'callback' => 'sides_puan_hafta_odul', 'permission_callback' => $yonet ) );
	register_rest_route( $ns, '/puan/ayar', array( 'methods' => 'POST', 'callback' => 'sides_puan_ayar_rest', 'permission_callback' => $yonet ) );
	register_rest_route( $ns, '/puan/kriterSil', array( 'methods' => 'POST', 'callback' => 'sides_puan_kriter_sil', 'permission_callback' => $yonet ) );
	register_rest_route( $ns, '/puan/ozet', array( 'methods' => 'GET', 'callback' => 'sides_puan_ozet', 'permission_callback' => $oku ) );
	register_rest_route( $ns, '/puan/hareketler', array( 'methods' => 'GET', 'callback' => 'sides_puan_hareketler', 'permission_callback' => $oku ) );
} );

/* Haftalık arşiv yalnız kendi uçlarından değişir; genel belge yazımı kurum geneli denetimini atlayamaz. */
add_filter( 'rest_pre_dispatch', function ( $result, $server, $req ) {
	if ( in_array( $req->get_method(), array( 'POST', 'PUT', 'PATCH', 'DELETE' ), true ) && preg_match( '#^/optik-karne/v1/doc/podul/([^/]+)/?$#', $req->get_route(), $m ) ) {
		$p = $req->get_json_params();
		$d = sides_get_doc( sides_org_id(), 'podul', $m[1] );
		if ( 0 === strpos( $m[1], 'hafta_' ) || 'hafta' === ( $d['tip'] ?? '' ) || ( is_array( $p ) && 'hafta' === ( $p['tip'] ?? '' ) ) ) {
			return sides_deny( 'Haftalık arşiv için hafta kapatma, açma veya ödül düzenleme işlemini kullanın.' );
		}
	}
	return $result;
}, 10, 3 );

function sides_puan_hata( $m, $kod = 400, $ek = array() ) {
	return new WP_Error( 'sides_puan', $m, array_merge( array( 'status' => $kod ), $ek ) );
}
function sides_puan_metin( $s, $n = 300 ) {
	return mb_substr( sanitize_textarea_field( (string) $s ), 0, $n );
}

/* POST puan/hareket — hareket defterine kayıt (aynı islemId ile ikinci kayıt oluşmaz) */
function sides_puan_hareket( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	$p   = is_array( $p ) ? $p : array();
	$islem = isset( $p['islemId'] ) ? (string) $p['islemId'] : '';
	if ( ! preg_match( '/^[A-Za-z0-9_\-]{4,40}$/', $islem ) ) {
		return sides_puan_hata( 'İşlem kimliği geçersiz.' );
	}
	$var = sides_get_doc( $org, 'phareket', $islem );
	if ( $var ) {
		return array( 'data' => $var, 'mevcut' => true );
	}
	$sid    = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) ( $p['studentId'] ?? '' ) );
	$kid    = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) ( $p['kriterId'] ?? '' ) );
	$kaynak = isset( $p['kaynak'] ) && in_array( $p['kaynak'], SIDES_PUAN_KAYNAK, true ) ? $p['kaynak'] : 'gunluk';
	$tarih  = isset( $p['tarih'] ) ? (string) $p['tarih'] : '';
	$hedef  = null;
	if ( 'haftalik' === $kaynak ) {
		$hedef = isset( $p['hedefHafta'] ) ? (string) $p['hedefHafta'] : '';
		if ( ! sides_puan_tarih_mi( $hedef ) || sides_puan_hafta_basi( $hedef ) !== $hedef ) {
			return sides_puan_hata( 'Haftalık ek düzeltme için hedef hafta (Pazartesi tarihi) gerekli.' );
		}
		$tarih = $hedef;
	}
	if ( ! sides_puan_tarih_mi( $tarih ) ) {
		return sides_puan_hata( 'Tarih geçersiz.' );
	}
	if ( $tarih > gmdate( 'Y-m-d', current_time( 'timestamp' ) + DAY_IN_SECONDS ) ) {
		return sides_puan_hata( 'Gelecek bir güne puan girilemez.' );
	}
	if ( ! $sid || ! $kid ) {
		return sides_puan_hata( 'Öğrenci ve kriter gerekli.' );
	}
	$ogr = sides_get_doc( $org, 'students', $sid );
	if ( ! $ogr ) {
		return sides_puan_hata( 'Öğrenci bulunamadı.', 404 );
	}
	$kisit = sides_sinif_kisit();
	if ( null !== $kisit && ! sides_ogrenci_izinli( $ogr, $kisit ) ) {
		return sides_deny( 'Bu öğrenci, yetkili olduğunuz sınıfların dışında.' );
	}
	$kr = sides_get_doc( $org, 'pkriter', $kid );
	if ( ! $kr || 'aktif' !== ( $kr['durum'] ?? 'aktif' ) ) {
		return sides_puan_hata( 'Kriter bulunamadı ya da arşivde.' );
	}
	$vakitler = ! empty( $kr['vakitler'] ) && is_array( $kr['vakitler'] ) ? array_values( array_intersect( $kr['vakitler'], SIDES_PUAN_VAKIT ) ) : array();
	$vakit    = isset( $p['vakit'] ) && '' !== $p['vakit'] && null !== $p['vakit'] ? (string) $p['vakit'] : null;
	if ( null !== $vakit && ( ! in_array( $vakit, SIDES_PUAN_VAKIT, true ) || ! in_array( $vakit, $vakitler, true ) ) ) {
		return sides_puan_hata( 'Bu kriterde böyle bir vakit yok.' );
	}
	if ( null === $vakit && $vakitler && 'gunluk' === $kaynak ) {
		return sides_puan_hata( 'Bu kriter için vakit seçilmeli.' );
	}
	if ( ! empty( $kr['gecerlilik'] ) && sides_puan_tarih_mi( $kr['gecerlilik'] ) && $tarih < $kr['gecerlilik'] ) {
		return sides_puan_hata( 'Bu kriter ' . $kr['gecerlilik'] . ' tarihinden itibaren geçerli; daha eski güne uygulanamaz.' );
	}
	if ( 'gunluk' === $kaynak && ! empty( $kr['kapsam']['gunler'] ) && is_array( $kr['kapsam']['gunler'] ) ) {
		$hg = (int) gmdate( 'N', strtotime( $tarih . ' 12:00:00' ) );
		if ( ! in_array( $hg, array_map( 'intval', $kr['kapsam']['gunler'] ), true ) ) {
			return sides_puan_hata( 'Bu kriter seçili günde kapsam dışı.' );
		}
	}
	$ayar   = sides_puan_ayar( $org );
	$gerekce = sides_puan_metin( $p['gerekce'] ?? '' );
	$hb     = sides_puan_hafta_basi( $tarih );
	if ( isset( $ayar['kapali'][ $hb ] ) && ( 'manuel' !== $kaynak || '' === $gerekce ) ) {
		return sides_puan_hata( 'Bu hafta kapatılmış. Haftayı yeniden açın ya da gerekçeli manuel düzeltme girin.', 409 );
	}
	$yon = in_array( $kr['yon'] ?? '-', array( '-', '+', '±' ), true ) ? $kr['yon'] : '-';
	if ( 'gunluk' === $kaynak ) {
		if ( ! isset( $kr['deger'] ) || null === $kr['deger'] || '' === $kr['deger'] || ! is_numeric( $kr['deger'] ) ) {
			return sides_puan_hata( 'Puanı tanımlanmadı: "' . ( $kr['ad'] ?? $kid ) . '" kriterinin puan değeri Kriterler sayfasından girilmeli.' );
		}
		$deger = (float) $kr['deger'];
		$etki  = '+' === $yon ? abs( $deger ) : ( '-' === $yon ? -abs( $deger ) : $deger );
	} else {
		if ( ! isset( $p['etki'] ) || ! is_numeric( $p['etki'] ) ) {
			return sides_puan_hata( 'Puan girin (örnek: -3 ya da 2,5).' );
		}
		$etki = (float) $p['etki'];
		if ( ! is_finite( $etki ) || abs( $etki ) > 1000 || 0.0 === round( $etki, 2 ) ) {
			return sides_puan_hata( 'Puan sıfır olamaz; en fazla ±1000 girilebilir.' );
		}
		if ( '-' === $yon && $etki > 0 ) {
			return sides_puan_hata( 'Bu kriter yalnızca eksi puan alır.' );
		}
		if ( '+' === $yon && $etki < 0 ) {
			return sides_puan_hata( 'Bu kriter yalnızca artı puan alır.' );
		}
	}
	$etki = round( $etki, 2 );
	/* Aynı öğrenci-gün-kriter-vakit için tekrar sınırı ve çakışma kuralı */
	$ayniGun = sides_puan_docs( $org, 'phareket', $tarih, $tarih, '"studentId":"' . $sid . '"' );
	$tekrar  = max( 1, (int) ( $kr['tekrar'] ?? 1 ) );
	$aktif   = array();
	foreach ( $ayniGun as $h ) {
		if ( empty( $h['iptal'] ) && ( $h['kriterId'] ?? '' ) === $kid && ( $h['vakit'] ?? null ) === $vakit && 'haftalik' !== ( $h['kaynak'] ?? '' ) ) {
			$aktif[] = $h;
		}
	}
	if ( count( $aktif ) >= $tekrar ) {
		return sides_puan_hata( 'Bu öğrenci-gün için "' . ( $kr['ad'] ?? '' ) . '" zaten işaretli (tekrar sınırı ' . $tekrar . '). Yinelenen kayıt oluşturulmadı.', 409, array( 'mevcut' => $aktif[0]['id'] ) );
	}
	$grup = (string) ( $kr['grup'] ?? '' );
	if ( 'engelle' === $ayar['cakisma'] && $vakit && in_array( $grup, array( 'gec', 'gelmeme' ), true ) ) {
		$diger = 'gec' === $grup ? 'gelmeme' : 'gec';
		foreach ( $ayniGun as $h ) {
			if ( empty( $h['iptal'] ) && ( $h['grup'] ?? '' ) === $diger && ( $h['vakit'] ?? null ) === $vakit ) {
				return sides_puan_hata( 'Aynı vakitte geç gelme ve gelmeme birlikte işaretlenemez (çakışma kuralı: engelle).', 409 );
			}
		}
	}
	$kim = sides_puan_kim();
	$bugun = gmdate( 'Y-m-d', current_time( 'timestamp' ) );
	if ( 'manuel' === $kaynak && (int) $ayar['gunlukLimit'] > 0 ) {
		global $wpdb;
		$t = sides_docs();
		$n = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE org = %d AND coll = 'phareket' AND data LIKE %s AND data LIKE %s AND data LIKE %s", $org, '%"kaynak":"manuel"%', '%' . $wpdb->esc_like( '"ogretmen":{"id":' . $kim['id'] . ',' ) . '%', '%' . $wpdb->esc_like( '"kayitGunu":"' . $bugun . '"' ) . '%' ) ); // phpcs:ignore
		if ( $n >= (int) $ayar['gunlukLimit'] ) {
			return sides_puan_hata( 'Günlük manuel işlem sınırına ulaştınız (' . (int) $ayar['gunlukLimit'] . '). Yarın devam edebilir ya da yöneticinizden sınırın artırılmasını isteyebilirsiniz.', 429 );
		}
	}
	$kanaat = isset( $p['kanaat'] ) && in_array( $p['kanaat'], array( 'olumlu', 'olumsuz' ), true ) ? $p['kanaat'] : null;
	$izin   = isset( $p['izinDurum'] ) && in_array( $p['izinDurum'], array( 'erken', 'zamaninda', 'gec' ), true ) ? $p['izinDurum'] : null;
	$d = array(
		'studentId' => $sid, 'tarih' => $tarih, 'kriterId' => $kid, 'grup' => $grup, 'vakit' => $vakit,
		'ad' => mb_substr( (string) ( $kr['ad'] ?? '' ), 0, 80 ), 'deger' => isset( $kr['deger'] ) && is_numeric( $kr['deger'] ) ? (float) $kr['deger'] : null, 'surum' => (int) ( $kr['surum'] ?? 1 ),
		'etki' => $etki, 'kaynak' => $kaynak, 'hedefHafta' => $hedef, 'gerekce' => $gerekce, 'ogretmen' => $kim, 't' => sides_puan_ms(), 'kayitGunu' => $bugun,
		'iptal' => null, 'kanaat' => $kanaat, 'izinDurum' => $izin,
		'olay' => isset( $p['olay'] ) ? sides_puan_metin( $p['olay'], 200 ) : '',
	);
	if ( false === sides_put_doc( $org, 'phareket', $islem, $d ) ) {
		return sides_puan_hata( 'Kayıt yazılamadı.', 500 );
	}
	sides_log( $org, 'Puan: ' . ( $ogr['ad'] ?? $sid ) . ' · ' . $d['ad'] . ( $vakit ? ' (' . $vakit . ')' : '' ) . ' · ' . ( $etki > 0 ? '+' : '' ) . $etki . ' · ' . $tarih . ( $gerekce ? ' · ' . mb_substr( $gerekce, 0, 60 ) : '' ) );
	$d['id'] = $islem;
	return array( 'data' => $d, 'mevcut' => false );
}

/* POST puan/iptal — hareket iptali (kayıt silinmez; denetim izi kalır) */
function sides_puan_iptal( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	$p   = is_array( $p ) ? $p : array();
	$id  = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) ( $p['id'] ?? '' ) );
	$h   = $id ? sides_get_doc( $org, 'phareket', $id ) : null;
	if ( ! $h ) {
		return sides_puan_hata( 'Hareket bulunamadı.', 404 );
	}
	$izin = sides_puan_izin( $org );
	if ( null !== $izin && ! isset( $izin[ (string) ( $h['studentId'] ?? '' ) ] ) ) {
		return sides_deny( 'Bu öğrenci, yetkili olduğunuz sınıfların dışında.' );
	}
	if ( ! empty( $h['iptal'] ) ) {
		return array( 'data' => $h, 'mevcut' => true );
	}
	$gerekce = sides_puan_metin( $p['gerekce'] ?? '' );
	$ayar    = sides_puan_ayar( $org );
	if ( isset( $ayar['kapali'][ sides_puan_hafta_basi( (string) $h['tarih'] ) ] ) && '' === $gerekce ) {
		return sides_puan_hata( 'Bu hafta kapatılmış; iptal için gerekçe gerekli.', 409 );
	}
	unset( $h['id'] );
	$h['iptal'] = array( 't' => sides_puan_ms(), 'ogretmen' => sides_puan_kim(), 'gerekce' => $gerekce );
	if ( false === sides_put_doc( $org, 'phareket', $id, $h ) ) {
		return sides_puan_hata( 'Kayıt yazılamadı.', 500 );
	}
	$ogr = sides_get_doc( $org, 'students', (string) $h['studentId'] );
	sides_log( $org, 'Puan iptali: ' . ( $ogr['ad'] ?? $h['studentId'] ) . ' · ' . ( $h['ad'] ?? '' ) . ' · ' . $h['tarih'] . ( $gerekce ? ' · ' . mb_substr( $gerekce, 0, 60 ) : '' ) );
	$h['id'] = $id;
	return array( 'data' => $h );
}

/* POST puan/gun — öğrenci-gün durumu: { studentId | studentIds[], tarih, durum } */
function sides_puan_gun( WP_REST_Request $req ) {
	$org   = sides_org_id();
	$p     = $req->get_json_params();
	$p     = is_array( $p ) ? $p : array();
	$tarih = (string) ( $p['tarih'] ?? '' );
	$durum = (string) ( $p['durum'] ?? '' );
	$ids   = isset( $p['studentIds'] ) && is_array( $p['studentIds'] ) ? $p['studentIds'] : ( isset( $p['studentId'] ) ? array( $p['studentId'] ) : array() );
	if ( ! sides_puan_tarih_mi( $tarih ) || ! in_array( $durum, array( 'taslak', 'tamam', 'muaf' ), true ) || ! $ids || count( $ids ) > 400 ) {
		return sides_puan_hata( 'Tarih, durum ve öğrenci gerekli.' );
	}
	if ( $tarih > gmdate( 'Y-m-d', current_time( 'timestamp' ) ) && 'tamam' === $durum ) {
		return sides_puan_hata( 'Gelecek bir gün tamamlanamaz.' );
	}
	$ayar = sides_puan_ayar( $org );
	if ( isset( $ayar['kapali'][ sides_puan_hafta_basi( $tarih ) ] ) ) {
		return sides_puan_hata( 'Bu hafta kapatılmış; gün durumu değiştirmek için haftayı yeniden açın.', 409 );
	}
	$izin = sides_puan_izin( $org );
	$kim  = sides_puan_kim();
	$out  = array();
	foreach ( $ids as $sid ) {
		$sid = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $sid );
		if ( ! $sid || ( null !== $izin && ! isset( $izin[ $sid ] ) ) ) {
			return sides_deny( 'Bu öğrenci, yetkili olduğunuz sınıfların dışında.' );
		}
		if ( ! sides_get_doc( $org, 'students', $sid ) ) {
			return sides_puan_hata( 'Öğrenci bulunamadı: ' . $sid, 404 );
		}
		$d = array( 'studentId' => $sid, 'tarih' => $tarih, 'durum' => $durum, 't' => sides_puan_ms(), 'ogretmen' => $kim );
		sides_put_doc( $org, 'pgun', $sid . '_' . $tarih, $d );
		$d['id'] = $sid . '_' . $tarih;
		$out[]   = $d;
	}
	sides_log( $org, 'Puan günü ' . ( 'tamam' === $durum ? 'tamamlandı' : ( 'muaf' === $durum ? 'muaf işaretlendi' : 'taslağa alındı' ) ) . ': ' . $tarih . ' (' . count( $out ) . ' öğrenci)' );
	return array( 'data' => $out );
}

/* Anlık görüntü satırlarını süz (kesinleşen ödül / kapanan hafta) */
function sides_puan_sonuc_suz( $l ) {
	$out = array();
	if ( ! is_array( $l ) ) {
		return $out;
	}
	foreach ( array_slice( $l, 0, 2000 ) as $x ) {
		if ( ! is_array( $x ) || empty( $x['sid'] ) ) {
			continue;
		}
		$out[] = array(
			'sid' => preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $x['sid'] ), 'ad' => mb_substr( sanitize_text_field( (string) ( $x['ad'] ?? '' ) ), 0, 80 ),
			'sinif' => mb_substr( sanitize_text_field( (string) ( $x['sinif'] ?? '' ) ), 0, 10 ), 'sube' => mb_substr( sanitize_text_field( (string) ( $x['sube'] ?? '' ) ), 0, 10 ),
			'puan' => isset( $x['puan'] ) && is_numeric( $x['puan'] ) ? round( (float) $x['puan'], 4 ) : null, 'sira' => isset( $x['sira'] ) && is_numeric( $x['sira'] ) ? (int) $x['sira'] : null,
			'tamlik' => isset( $x['tamlik'] ) && is_numeric( $x['tamlik'] ) ? round( (float) $x['tamlik'], 4 ) : null, 'etki' => isset( $x['etki'] ) && is_numeric( $x['etki'] ) ? round( (float) $x['etki'], 4 ) : 0,
			'tamam' => (int) ( $x['tamam'] ?? 0 ), 'taslak' => (int) ( $x['taslak'] ?? 0 ), 'muaf' => (int) ( $x['muaf'] ?? 0 ), 'odul' => ! empty( $x['odul'] ),
		);
	}
	return $out;
}

/* Aynı kurumdaki kapatma/açma/ödül istekleri ortak kapalı hafta ayarını ezmesin.
   Seçenek adının benzersizliği MySQL ve SQLite üzerinde aynı kilidi sağlar. */
function sides_puan_hafta_kilit( $org, $bas ) {
	global $wpdb;
	$ad  = '_sides_puan_kilit_' . md5( (string) $org );
	$kim = time() . '|' . wp_generate_uuid4();
	$son = microtime( true ) + 5;
	do {
		if ( add_option( $ad, $kim, '', false ) ) {
			return array( $ad, $kim );
		}
		$eski = get_option( $ad );
		if ( is_string( $eski ) && (int) $eski < time() - 120 ) {
			$wpdb->delete( $wpdb->options, array( 'option_name' => $ad, 'option_value' => $eski ) );
			wp_cache_delete( $ad, 'options' );
			wp_cache_delete( 'notoptions', 'options' );
		}
		usleep( 50000 );
	} while ( microtime( true ) < $son );
	return false;
}
function sides_puan_hafta_kilit_birak( $kilit ) {
	global $wpdb;
	$wpdb->delete( $wpdb->options, array( 'option_name' => $kilit[0], 'option_value' => $kilit[1] ) );
	wp_cache_delete( $kilit[0], 'options' );
	wp_cache_delete( 'notoptions', 'options' );
}

/* puanHesapHaftalik + pnHesap ile aynı tek haftalık hesap; istemcinin sonuc/kapsam alanlarına güvenmez.
   Tamamlanmış gün olmasa da başlangıç puanı vardır; taslak etkiler eklenir, muaf etkiler eklenmez. */
function sides_puan_hafta_sonuc( $org, $bas, $bit, $ayar, $gun ) {
	if ( ! class_exists( 'Collator' ) ) {
		return sides_puan_hata( 'Türkçe sıralama için sunucuda PHP intl (Collator) desteği gerekli. Hafta kapatılmadı.', 503 );
	}
	$ogr = sides_puan_ogrenciler( $org );
	$out = array();
	$neh_ayri = sides_nehari_ayri( $org );
	foreach ( $ogr as $sid => $s ) {
		if ( ! empty( $s['pasif'] ) || ( $neh_ayri && sides_nehari_sinifi( $s['sinif'] ?? '' ) ) ) {
			continue;
		}
		$out[ $sid ] = array( 'sid' => (string) $sid, 'ad' => (string) ( $s['ad'] ?? '' ), 'sinif' => (string) ( $s['sinif'] ?? '' ), 'sube' => (string) ( $s['sube'] ?? '' ), 'tamam' => 0, 'taslak' => 0, 'muaf' => 0, 'etki' => 0.0 );
	}
	foreach ( $gun as $g ) {
		if ( ! isset( $out[ $g['sid'] ] ) ) {
			continue;
		}
		$x =& $out[ $g['sid'] ];
		if ( 'muaf' === $g['durum'] ) {
			$x['muaf']++;
		} else {
			$x[ 'tamam' === $g['durum'] ? 'tamam' : 'taslak' ]++;
			$x['etki'] += (float) $g['etki'];
		}
		unset( $x );
	}
	$beklenen = 0;
	$bugun    = gmdate( 'Y-m-d', current_time( 'timestamp' ) );
	$son      = $bit < $bugun ? $bit : $bugun;
	$gunler   = ! empty( $ayar['gunler'] ) ? array_map( 'intval', $ayar['gunler'] ) : array( 1, 2, 3, 4, 5, 6, 7 );
	for ( $d = strtotime( $bas . ' 12:00:00' ); gmdate( 'Y-m-d', $d ) <= $son; $d += DAY_IN_SECONDS ) {
		if ( in_array( (int) gmdate( 'N', $d ), $gunler, true ) ) {
			$beklenen++;
		}
	}
	foreach ( $out as &$x ) {
		$x['puan']   = (float) $ayar['baslangic'] + $x['etki'] / 7;
		$x['tamlik'] = $beklenen ? min( 1, ( $x['tamam'] + $x['muaf'] ) / $beklenen ) : 0;
		$x['eksik']  = max( 0, $beklenen - $x['tamam'] - $x['muaf'] );
		$x['gecici'] = $x['eksik'] > 0 || $x['taslak'] > 0 || $bit >= $bugun;
	}
	unset( $x );
	$tr = new Collator( 'tr_TR' );
	$siniflar = array( '3', '4', 'N5', '5', '6', '7', '8' );
	usort( $out, function ( $a, $b ) use ( $tr, $ogr, $siniflar ) {
		/* JS Math.round: negatif yarım değerler de +sonsuz yönüne yuvarlanır. */
		$pa = floor( ( $a['puan'] + PHP_FLOAT_EPSILON ) * 100 + 0.5 );
		$pb = floor( ( $b['puan'] + PHP_FLOAT_EPSILON ) * 100 + 0.5 );
		$c  = $pb <=> $pa;
		if ( ! $c ) {
			$c = $tr->compare( $a['ad'], $b['ad'] );
		}
		/* Adlar da aynıysa tkOgrenciler'in kararlı sınıf/şube/no sırasını koru. */
		if ( ! $c ) {
			$ia = array_search( $a['sinif'], $siniflar, true );
			$ib = array_search( $b['sinif'], $siniflar, true );
			$c  = ( false === $ia ? 99 : $ia ) - ( false === $ib ? 99 : $ib );
			$c  = $c ?: $tr->compare( $a['sinif'], $b['sinif'] );
			$c  = $c ?: $tr->compare( $a['sube'], $b['sube'] );
			$c  = $c ?: ( (float) ( $ogr[ $a['sid'] ]['no'] ?? 0 ) <=> (float) ( $ogr[ $b['sid'] ]['no'] ?? 0 ) );
		}
		return $c ?: strcmp( $a['sid'], $b['sid'] );
	} );
	foreach ( $out as $i => &$x ) {
		$x['sira'] = $i + 1;
		$x['odul'] = $i < 3;
	}
	unset( $x );
	return sides_puan_sonuc_suz( $out );
}

/* Önceki kazananları puanları ve adlarıyla tut; hareket defteri ve haftanın sonuçları değişmez. */
function sides_puan_odul_gecmisi( $doc ) {
	$gecmis = isset( $doc['odulGecmisi'] ) && is_array( $doc['odulGecmisi'] ) ? $doc['odulGecmisi'] : array();
	if ( ! empty( $doc['odulKaydi'] ) ) {
		$kazananlar = array();
		foreach ( $doc['sonuc'] ?? array() as $x ) {
			if ( ! empty( $x['odul'] ) ) {
				$kazananlar[] = array_intersect_key( $x, array_flip( array( 'sid', 'ad', 'sira', 'puan' ) ) );
			}
		}
		$duzenleme = $doc['odulDuzenleme'] ?? array();
		$gecmis[] = array( 't' => $duzenleme['t'] ?? $doc['t'], 'ogretmen' => $duzenleme['ogretmen'] ?? $doc['olusturan'], 'gerekce' => $duzenleme['gerekce'] ?? '', 'mod' => $doc['odulModu'] ?? 'otomatik', 'kazananlar' => $kazananlar );
	}
	return array_slice( $gecmis, -20 );
}

/* POST puan/haftaKapat — { bas }: sunucuda hesaplanan sonuç ve tam ilk üç aynı haftalık belgede saklanır.
   Hareketler ve gün durumları silinmez; mevcut kapalı haftaya tekrar istek sonuçları değiştirmez. */
function sides_puan_hafta_kapat( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	$p   = is_array( $p ) ? $p : array();
	$bas = (string) ( $p['bas'] ?? '' );
	if ( ! sides_puan_tarih_mi( $bas ) || sides_puan_hafta_basi( $bas ) !== $bas ) {
		return sides_puan_hata( 'Hafta başlangıcı (Pazartesi) gerekli.' );
	}
	if ( $bas > gmdate( 'Y-m-d', current_time( 'timestamp' ) ) ) {
		return sides_puan_hata( 'Gelecek hafta kapatılamaz.' );
	}
	$kilit = sides_puan_hafta_kilit( $org, $bas );
	if ( ! $kilit ) {
		return sides_puan_hata( 'Bu hafta başka bir işlemle güncelleniyor. Tekrar deneyin.', 503 );
	}
	try {
		$ayar = sides_puan_ayar( $org );
		$id   = 'hafta_' . $bas;
		$eski = sides_get_doc( $org, 'podul', $id );
		if ( isset( $ayar['kapali'][ $bas ] ) && $eski ) {
			return array( 'data' => $eski, 'puan' => $ayar );
		}
		$kim   = sides_puan_kim();
		$bit   = gmdate( 'Y-m-d', strtotime( $bas . ' 12:00:00' ) + 6 * DAY_IN_SECONDS );
		$gun   = sides_puan_gunler( $org, $bas, $bit );
		$sonuc = sides_puan_hafta_sonuc( $org, $bas, $bit, $ayar, $gun );
		if ( is_wp_error( $sonuc ) ) {
			return $sonuc;
		}
		$elle = $eski && ! empty( $eski['odulKaydi'] ) && 'elle' === ( $eski['odulModu'] ?? '' );
		if ( $elle ) {
			$ids = array();
			foreach ( $eski['sonuc'] ?? array() as $x ) {
				if ( ! empty( $x['odul'] ) ) {
					$ids[ $x['sid'] ] = true;
				}
			}
			foreach ( $sonuc as &$x ) {
				$x['odul'] = isset( $ids[ $x['sid'] ] );
			}
			unset( $x );
		}
		$doc = array(
			'tip' => 'hafta', 'aralik' => array( 'tip' => '1h', 'bas' => $bas, 'bit' => $bit, 'ad' => 'Hafta ' . $bas ),
			'kapsam' => array( 'sinif' => '', 'sube' => '' ), 'yontem' => $ayar['yontem'], 'baslangic' => $ayar['baslangic'], 'cakisma' => $ayar['cakisma'],
			'sonuc' => $sonuc, 'gunSayisi' => count( $gun ), 'kesin' => true, 't' => sides_puan_ms(), 'olusturan' => $kim, 'acildi' => null,
			'odulKaydi' => true, 'odulModu' => $elle ? 'elle' : 'otomatik', 'odulSayisi' => 3, 'odulGecmisi' => $eski ? sides_puan_odul_gecmisi( $eski ) : array(),
		);
		if ( $elle && isset( $eski['odulDuzenleme'] ) ) {
			$doc['odulDuzenleme'] = $eski['odulDuzenleme'];
		}
		if ( false === sides_put_doc( $org, 'podul', $id, $doc ) ) {
			return sides_puan_hata( 'Hafta arşivi yazılamadı. Hafta kapatılmadı.', 500 );
		}
		$ayar['kapali'][ $bas ] = array( 't' => $doc['t'], 'ogretmen' => $kim );
		if ( false === sides_puan_ayar_kaydet( $org, $ayar ) ) {
			return sides_puan_hata( 'Hafta arşivi kaydedildi ancak kapalı durumu yazılamadı. Tekrar deneyin.', 500 );
		}
		$sayi = count( array_filter( $sonuc, function ( $x ) { return ! empty( $x['odul'] ); } ) );
		sides_log( $org, 'Puan haftası kapatıldı: ' . $bas . ' – ' . $bit . ' (' . count( $sonuc ) . ' öğrenci, ' . $sayi . ' ödül; ' . ( $elle ? 'elle seçim korundu' : 'otomatik ilk üç' ) . ')' );
		$doc['id'] = $id;
		return array( 'data' => $doc, 'puan' => $ayar, 'uyari' => $sonuc ? '' : 'Bu haftanın kapsamında öğrenci yok; ödül alan öğrenci bulunmuyor.' );
	} finally {
		sides_puan_hafta_kilit_birak( $kilit );
	}
}
/* POST puan/haftaAc — { bas } : kapalı işaretini kaldırır; saklı anlık görüntü kalır (acildi zamanı yazılır). */
function sides_puan_hafta_ac( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	$bas = is_array( $p ) ? (string) ( $p['bas'] ?? '' ) : '';
	if ( ! sides_puan_tarih_mi( $bas ) || sides_puan_hafta_basi( $bas ) !== $bas ) {
		return sides_puan_hata( 'Hafta başlangıcı (Pazartesi) gerekli.' );
	}
	$kilit = sides_puan_hafta_kilit( $org, $bas );
	if ( ! $kilit ) {
		return sides_puan_hata( 'Bu hafta başka bir işlemle güncelleniyor. Tekrar deneyin.', 503 );
	}
	try {
		$ayar = sides_puan_ayar( $org );
		$doc  = sides_get_doc( $org, 'podul', 'hafta_' . $bas );
		if ( ! isset( $ayar['kapali'][ $bas ] ) ) {
			return array( 'puan' => $ayar, 'data' => $doc );
		}
		if ( $doc ) {
			$doc['acildi'] = array( 't' => sides_puan_ms(), 'ogretmen' => sides_puan_kim() );
			if ( false === sides_put_doc( $org, 'podul', 'hafta_' . $bas, $doc ) ) {
				return sides_puan_hata( 'Hafta arşivi yazılamadı. Hafta yeniden açılmadı.', 500 );
			}
		}
		unset( $ayar['kapali'][ $bas ] );
		if ( false === sides_puan_ayar_kaydet( $org, $ayar ) ) {
			return sides_puan_hata( 'Haftanın açık durumu yazılamadı. Tekrar deneyin.', 500 );
		}
		sides_log( $org, 'Puan haftası yeniden açıldı: ' . $bas . '; saklı sonuçlar ve ödül alanlar korundu' );
		return array( 'puan' => $ayar, 'data' => $doc );
	} finally {
		sides_puan_hafta_kilit_birak( $kilit );
	}
}

/* POST puan/haftaOdul — { bas, studentIds[], gerekce? }: yalnız saklı sonuçtaki ödül işaretleri değişir. */
function sides_puan_hafta_odul( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	$p   = is_array( $p ) ? $p : array();
	$bas = (string) ( $p['bas'] ?? '' );
	if ( ! sides_puan_tarih_mi( $bas ) || sides_puan_hafta_basi( $bas ) !== $bas ) {
		return sides_puan_hata( 'Hafta başlangıcı (Pazartesi) gerekli.' );
	}
	if ( ! isset( $p['studentIds'] ) || ! is_array( $p['studentIds'] ) || count( $p['studentIds'] ) > 2000 ) {
		return sides_puan_hata( 'Ödül alacak öğrencilerin listesi gerekli.' );
	}
	$ids = array();
	foreach ( $p['studentIds'] as $sid ) {
		if ( ! is_string( $sid ) || ! preg_match( '/^[A-Za-z0-9_\-]{1,64}$/', $sid ) ) {
			return sides_puan_hata( 'Öğrenci kimliği geçersiz.' );
		}
		$ids[ $sid ] = true;
	}
	if ( isset( $p['gerekce'] ) && ! is_string( $p['gerekce'] ) ) {
		return sides_puan_hata( 'Gerekçe metin olmalı.' );
	}
	$gerekce = sides_puan_metin( $p['gerekce'] ?? '', 300 );
	$kilit   = sides_puan_hafta_kilit( $org, $bas );
	if ( ! $kilit ) {
		return sides_puan_hata( 'Bu hafta başka bir işlemle güncelleniyor. Tekrar deneyin.', 503 );
	}
	try {
		$id  = 'hafta_' . $bas;
		$doc = sides_get_doc( $org, 'podul', $id );
		if ( ! $doc || 'hafta' !== ( $doc['tip'] ?? '' ) || ! isset( $doc['sonuc'] ) || ! is_array( $doc['sonuc'] ) ) {
			return sides_puan_hata( 'Önce bu haftanın sonuçlarını kaydedin (haftayı tamamlayın).', 404 );
		}
		$kayitli = array();
		$onceki  = array();
		foreach ( $doc['sonuc'] as $x ) {
			$kayitli[ $x['sid'] ] = true;
			if ( ! empty( $x['odul'] ) ) {
				$onceki[ $x['sid'] ] = true;
			}
		}
		if ( array_diff_key( $ids, $kayitli ) ) {
			return sides_puan_hata( 'Yalnızca bu haftanın saklı sonuçlarındaki öğrenciler seçilebilir.' );
		}
		if ( ! empty( $doc['odulKaydi'] ) && 'elle' === ( $doc['odulModu'] ?? '' ) && ! array_diff_key( $ids, $onceki ) && ! array_diff_key( $onceki, $ids ) && $gerekce === ( $doc['odulDuzenleme']['gerekce'] ?? '' ) ) {
			return array( 'data' => $doc );
		}
		$doc['odulGecmisi'] = sides_puan_odul_gecmisi( $doc );
		foreach ( $doc['sonuc'] as &$x ) {
			$x['odul'] = isset( $ids[ $x['sid'] ] );
		}
		unset( $x );
		$doc['odulKaydi']     = true;
		$doc['odulModu']      = 'elle';
		$doc['odulSayisi']    = 3;
		$doc['odulDuzenleme'] = array( 't' => sides_puan_ms(), 'ogretmen' => sides_puan_kim(), 'gerekce' => $gerekce );
		if ( false === sides_put_doc( $org, 'podul', $id, $doc ) ) {
			return sides_puan_hata( 'Ödül alanlar kaydedilemedi.', 500 );
		}
		sides_log( $org, 'Haftalık ödül alanlar düzenlendi: ' . $bas . ' (' . count( $ids ) . ' öğrenci)' . ( $gerekce ? ' · ' . $gerekce : '' ) );
		return array( 'data' => $doc );
	} finally {
		sides_puan_hafta_kilit_birak( $kilit );
	}
}
/* POST puan/ayar — kurum puan ayarları */
function sides_puan_ayar_rest( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	$a   = sides_puan_ayar_suz( is_array( $p ) ? $p : array(), sides_puan_ayar( $org ) );
	if ( false === sides_puan_ayar_kaydet( $org, $a ) ) {
		return sides_puan_hata( 'Ayarlar yazılamadı.', 500 );
	}
	sides_log( $org, 'Puan ayarları güncellendi: başlangıç ' . $a['baslangic'] . ', yöntem ' . $a['yontem'] . ', çakışma ' . $a['cakisma'] );
	return array( 'puan' => $a );
}
/* POST puan/kriterSil — kullanılmamış kriter silinir; kullanılmış kriter arşivlenir */
function sides_puan_kriter_sil( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$p   = $req->get_json_params();
	$id  = preg_replace( '/[^A-Za-z0-9_\-]/', '', is_array( $p ) ? (string) ( $p['id'] ?? '' ) : '' );
	$kr  = $id ? sides_get_doc( $org, 'pkriter', $id ) : null;
	if ( ! $kr ) {
		return sides_puan_hata( 'Kriter bulunamadı.', 404 );
	}
	$t = sides_docs();
	$n = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE org = %d AND coll = 'phareket' AND data LIKE %s", $org, '%' . $wpdb->esc_like( '"kriterId":"' . $id . '"' ) . '%' ) ); // phpcs:ignore
	if ( $n > 0 ) {
		unset( $kr['id'] );
		$kr['durum'] = 'arsiv';
		sides_put_doc( $org, 'pkriter', $id, $kr );
		sides_log( $org, 'Puan kriteri arşivlendi (kullanımda, ' . $n . ' hareket): ' . ( $kr['ad'] ?? $id ) );
		$kr['id'] = $id;
		return array( 'arsiv' => true, 'hareket' => $n, 'data' => $kr );
	}
	$wpdb->delete( $t, array( 'org' => $org, 'coll' => 'pkriter', 'id' => $id ) );
	sides_log( $org, 'Puan kriteri silindi: ' . ( $kr['ad'] ?? $id ) );
	return array( 'arsiv' => false, 'hareket' => 0 );
}

/* Öğrenci süzgeci: sınıf kısıtı + isteğe bağlı sınıf/şube (id => öğrenci) */
function sides_puan_ogrenciler( $org, $sinif = '', $sube = '' ) {
	global $wpdb;
	$t     = sides_docs();
	$kisit = sides_sinif_kisit();
	$out   = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = 'students'", $org ) ) as $r ) { // phpcs:ignore
		$d = json_decode( $r->data, true );
		if ( ! is_array( $d ) || ! sides_ogrenci_izinli( $d, $kisit ) ) {
			continue;
		}
		if ( '' !== $sinif && (string) ( $d['sinif'] ?? '' ) !== $sinif ) {
			continue;
		}
		if ( '' !== $sube && mb_strtoupper( (string) ( $d['sube'] ?? '' ), 'UTF-8' ) !== mb_strtoupper( $sube, 'UTF-8' ) ) {
			continue;
		}
		$out[ (string) $r->id ] = $d;
	}
	return $out;
}
/* GET puan/ozet?bas=&bit=&sinif=&sube= → { gunler, hareketSayisi, kapsam, ayar } (adsız, gerekçesiz) */
function sides_puan_ozet( WP_REST_Request $req ) {
	$org = sides_org_id();
	$bas = sides_puan_tarih_mi( (string) $req['bas'] ) ? (string) $req['bas'] : sides_puan_hafta_basi( gmdate( 'Y-m-d', current_time( 'timestamp' ) ) );
	$bit = sides_puan_tarih_mi( (string) $req['bit'] ) ? (string) $req['bit'] : gmdate( 'Y-m-d', strtotime( $bas . ' 12:00:00' ) + 6 * DAY_IN_SECONDS );
	if ( $bit < $bas || ( strtotime( $bit ) - strtotime( $bas ) ) > 400 * DAY_IN_SECONDS ) {
		return sides_puan_hata( 'Tarih aralığı geçersiz (en fazla 400 gün).' );
	}
	$sinif = mb_substr( sanitize_text_field( (string) $req['sinif'] ), 0, 10 );
	$sube  = mb_substr( sanitize_text_field( (string) $req['sube'] ), 0, 10 );
	$ogr   = sides_puan_ogrenciler( $org, $sinif, $sube );
	$gun   = array_values( array_filter( sides_puan_gunler( $org, $bas, $bit ), function ( $g ) use ( $ogr ) {
		return isset( $ogr[ $g['sid'] ] );
	} ) );
	$ayar  = sides_puan_ayar( $org );
	$n     = 0;
	foreach ( sides_puan_docs( $org, 'phareket', $bas, $bit ) as $h ) {
		if ( empty( $h['iptal'] ) && isset( $ogr[ (string) ( $h['studentId'] ?? '' ) ] ) ) {
			$n++;
		}
	}
	$res = rest_ensure_response( array( 'gunler' => $gun, 'hareketSayisi' => $n, 'kapsam' => array( 'bas' => $bas, 'bit' => $bit, 'sinif' => $sinif, 'sube' => $sube, 'ogrenci' => count( $ogr ) ), 'ayar' => array( 'baslangic' => $ayar['baslangic'], 'yontem' => $ayar['yontem'], 'cakisma' => $ayar['cakisma'], 'ondalik' => 2, 'gunler' => $ayar['gunler'], 'kapali' => array_keys( $ayar['kapali'] ) ) ) );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}
/* GET puan/hareketler?bas=&bit=&ogr=&kriter= → hareket defteri satırları (sınıf kısıtı uygulanır) */
function sides_puan_hareketler( WP_REST_Request $req ) {
	$org = sides_org_id();
	$bas = sides_puan_tarih_mi( (string) $req['bas'] ) ? (string) $req['bas'] : '';
	$bit = sides_puan_tarih_mi( (string) $req['bit'] ) ? (string) $req['bit'] : '';
	$ogr = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $req['ogr'] );
	$kri = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $req['kriter'] );
	if ( ! $bas && ! $bit && ! $ogr ) {
		$bas = gmdate( 'Y-m-d', current_time( 'timestamp' ) - 90 * DAY_IN_SECONDS );
	}
	$izin = sides_puan_izin( $org );
	$like = $ogr ? '"studentId":"' . $ogr . '"' : ( $kri ? '"kriterId":"' . $kri . '"' : '' );
	$out  = array();
	foreach ( sides_puan_docs( $org, 'phareket', $bas, $bit, $like ) as $h ) {
		$sid = (string) ( $h['studentId'] ?? '' );
		if ( ( null !== $izin && ! isset( $izin[ $sid ] ) ) || ( $ogr && $sid !== $ogr ) || ( $kri && ( $h['kriterId'] ?? '' ) !== $kri ) ) {
			continue;
		}
		$out[] = $h;
	}
	usort( $out, function ( $a, $b ) {
		return strcmp( (string) ( $a['tarih'] ?? '' ), (string) ( $b['tarih'] ?? '' ) ) ?: ( (int) ( $a['t'] ?? 0 ) <=> (int) ( $b['t'] ?? 0 ) );
	} );
	$res = rest_ensure_response( array( 'data' => $out, 'kapsam' => array( 'bas' => $bas, 'bit' => $bit ) ) );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}
