<?php
/* ------------------------------------------------------------------ *
 * v7 Akademik ek modüller (EK01, EK04–EK08): sunucu uçları (optik-karne/v1, önek eka/).
 * Koleksiyonlar (sides_docs; genel /doc ve /koleksiyon izin listesinde yok, yedeğe kendiliğinden girer):
 *   ekacikti  c_<md5>   EK01 öğretmen kararı: { sinif, sube, ogrenci, ders, anahtar, kod, ad, durum, oncelik, not, gorevler[], gecmis[] }
 *   ekatekrar t_<islem> EK04 aralıklı tekrar planı: { konu, ders, sinif, sube, ogrenciler[], ilk, araliklar[], gorev, sure, kanit, aktif, adimlar[] }
 *   ekahata   h_<…>     EK05 hata defteri: { studentId, sinif, sube, kaynak{}, soru, nedenler[], ogrAciklama, duzeltme, durum, kontroller[] }
 *   ekabilet  b_<islem> EK06 çıkış bileti: { tur, tarih, ders, konu, sinif, sube, olcek, max, sorular[], ogrenciler[], yanitlar{sid:[]|'X'}, karar{} }
 *   ekalgs    l_<md5>   EK07 haftalık LGS planı: { studentId, hafta, oncelikler[], hedef, gorevler[], kontrolTarih, tekrarOlcum, not }
 *   ekasure   s_<md5>   EK08 süre ve strateji: { studentId, sinavId, sinavAd, tarih, dersler[], stratejiler[], donusSira, ogrDegerlendirme, ogretmenNot, degisiklik }
 * Her uç: sides_can('ek', 1|2) + sides_ek_erisim (tanımlıysa) + sınıf kısıtı; gözlemci salt okur ve iç notları almaz.
 * ------------------------------------------------------------------ */
defined( 'ABSPATH' ) || exit;

function sides_eka_turler() {
	return array( 'cikti' => 'EK01', 'tekrar' => 'EK04', 'hata' => 'EK05', 'bilet' => 'EK06', 'lgs' => 'EK07', 'sure' => 'EK08' );
}
function sides_eka_hata( $m, $s = 400 ) {
	return new WP_Error( 'sides_gecersiz', $m, array( 'status' => $s ) );
}
function sides_eka_metin( $v, $n ) {
	return is_scalar( $v ) ? mb_substr( trim( sanitize_text_field( (string) $v ) ), 0, $n ) : '';
}
function sides_eka_uzun( $v, $n ) {
	return is_scalar( $v ) ? mb_substr( trim( sanitize_textarea_field( (string) $v ) ), 0, $n ) : '';
}
function sides_eka_tarih( $v ) {
	$v = is_scalar( $v ) ? (string) $v : '';
	return preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $v, $m ) && checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ? $v : '';
}
function sides_eka_sid( $k ) {
	return is_scalar( $k ) && preg_match( '/^[A-Za-z0-9_\-]{1,64}$/', (string) $k );
}
function sides_eka_sinif( $s ) {
	return is_scalar( $s ) ? sides_sinif_norm( str_replace( '/', ' ', (string) $s ) ) : '';
}
function sides_eka_sube( $s ) {
	return is_scalar( $s ) ? mb_strtoupper( mb_substr( trim( sanitize_text_field( (string) $s ) ), 0, 20 ), 'UTF-8' ) : '';
}
function sides_eka_bugun() {
	return ( new DateTime( 'now', new DateTimeZone( 'Europe/Istanbul' ) ) )->format( 'Y-m-d' );
}
function sides_eka_gun_ekle( $iso, $n ) {
	$d = new DateTime( $iso . ' 12:00:00', new DateTimeZone( 'Europe/Istanbul' ) );
	$d->modify( ( $n >= 0 ? '+' : '' ) . (int) $n . ' day' );
	return $d->format( 'Y-m-d' );
}
function sides_eka_int( $v, $min, $max ) {
	if ( null === $v || '' === $v || ! is_numeric( $v ) ) {
		return null;
	}
	$v = (int) round( (float) $v );
	return $v < $min || $v > $max ? null : $v;
}
function sides_eka_ben() {
	$u = wp_get_current_user();
	return array( 'u' => (int) $u->ID, 'ad' => (string) $u->display_name );
}
function sides_eka_yonetici() {
	return 'yonetici' === sides_ctx()['rol'] || ( function_exists( 'sides_is_super' ) && sides_is_super() );
}
/* Sınıf kapsamı (odev.php sides_kt_kapsam ile aynı kural): kısmi = şubesiz kayıtta kullanıcının o sınıftan bir şubesi olması yeter */
function sides_eka_kapsam( $sinif, $sube, $kismi = false ) {
	if ( function_exists( 'sides_kt_kapsam' ) ) {
		return sides_kt_kapsam( $sinif, $sube, $kismi );
	}
	$kisit = sides_sinif_kisit();
	if ( null === $kisit ) {
		return true;
	}
	$g = sides_eka_sinif( $sinif );
	$b = sides_eka_sube( $sube );
	if ( '' === $g ) {
		return false;
	}
	if ( in_array( $g, $kisit, true ) ) {
		return true;
	}
	if ( '' !== $b ) {
		return in_array( $g . '/' . $b, $kisit, true );
	}
	if ( $kismi ) {
		foreach ( $kisit as $k ) {
			if ( 0 === strpos( (string) $k, $g . '/' ) ) {
				return true;
			}
		}
	}
	return false;
}
function sides_eka_izin( $org ) {
	$k = sides_sinif_kisit();
	return null === $k ? null : sides_izinli_ogrenciler( $org, $k );
}
function sides_eka_ogr( $org, $sid ) {
	if ( ! sides_eka_sid( $sid ) ) {
		return null;
	}
	$s = sides_get_doc( $org, 'students', (string) $sid );
	return is_array( $s ) ? $s : null;
}
/* Sınıf/şubedeki öğrenci kimlikleri (bilet anlık listesi için) */
function sides_eka_sinif_ogr( $org, $sinif, $sube ) {
	global $wpdb;
	$t   = sides_docs();
	$out = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = 'students'", $org ) ) as $r ) { // phpcs:ignore
		$d = json_decode( $r->data, true );
		if ( ! is_array( $d ) || sides_eka_sinif( isset( $d['sinif'] ) ? $d['sinif'] : '' ) !== $sinif ) {
			continue;
		}
		if ( '' !== $sube && sides_eka_sube( isset( $d['sube'] ) ? $d['sube'] : '' ) !== $sube ) {
			continue;
		}
		$out[] = (string) $r->id;
	}
	return $out;
}

/* ---------- izinler ---------- */
function sides_eka_okur() {
	return sides_can( 'ek', 1 ) ? true : sides_deny( 'Ek Modüller için yetkiniz yok. Yöneticinizden izin isteyin.' );
}
function sides_eka_yazar() {
	return sides_can( 'ek', 2 ) && ! sides_is_observer() ? true : sides_deny( 'Ek Modüllerde değişiklik yapma yetkiniz yok.' );
}
/* Modül etkin mi (EK çekirdeği tanımladıysa); tür geçerli mi */
function sides_eka_tur( $tur ) {
	$T = sides_eka_turler();
	if ( ! is_string( $tur ) || ! isset( $T[ $tur ] ) ) {
		return sides_eka_hata( 'Geçersiz modül.' );
	}
	$ok = function_exists( 'sides_ek_erisim' ) ? sides_ek_erisim( sides_org_id(), $T[ $tur ] ) : true;
	return $ok ? true : sides_deny( 'Bu modül sizin için etkinleştirilmemiş. Yöneticinizden izin isteyin.' );
}
function sides_eka_ogrenci_turu( $tur ) {
	return in_array( $tur, array( 'hata', 'lgs', 'sure' ), true );
}

/* ---------- okuma süzgeci: sınıf kısıtı ve gözlemci ---------- */
function sides_eka_suz( $tur, $d, $izin, $gozlem ) {
	if ( ! is_array( $d ) ) {
		return null;
	}
	if ( sides_eka_ogrenci_turu( $tur ) ) {
		if ( null !== $izin && ! isset( $izin[ (string) ( isset( $d['studentId'] ) ? $d['studentId'] : '' ) ] ) ) {
			return null;
		}
	} elseif ( null !== $izin ) {
		$liste = 'cikti' === $tur ? ( empty( $d['ogrenci'] ) ? array() : array( (string) $d['ogrenci'] ) ) : ( isset( $d['ogrenciler'] ) && is_array( $d['ogrenciler'] ) ? $d['ogrenciler'] : array() );
		if ( 'bilet' === $tur || ! $liste ) {
			if ( ! sides_eka_kapsam( isset( $d['sinif'] ) ? $d['sinif'] : '', isset( $d['sube'] ) ? $d['sube'] : '', true ) ) {
				return null;
			}
		} else {
			$gor = array_values( array_filter( $liste, function ( $s ) use ( $izin ) { return isset( $izin[ (string) $s ] ); } ) );
			if ( ! $gor ) {
				return null;
			}
			if ( 'tekrar' === $tur ) {
				$d['ogrenciler'] = $gor;
			}
		}
		if ( 'bilet' === $tur ) {
			$d['ogrenciler'] = array_values( array_filter( (array) ( isset( $d['ogrenciler'] ) ? $d['ogrenciler'] : array() ), function ( $s ) use ( $izin ) { return isset( $izin[ (string) $s ] ); } ) );
			$y = array();
			foreach ( (array) ( isset( $d['yanitlar'] ) ? $d['yanitlar'] : array() ) as $s => $v ) {
				if ( isset( $izin[ (string) $s ] ) ) {
					$y[ (string) $s ] = $v;
				}
			}
			$d['yanitlar'] = (object) $y;
		}
	}
	if ( $gozlem ) {   // iç notlar gözlemciye gitmez
		foreach ( array( 'not', 'ogrAciklama', 'duzeltme', 'ogrDegerlendirme', 'ogretmenNot' ) as $k ) {
			unset( $d[ $k ] );
		}
		if ( isset( $d['karar'] ) && is_array( $d['karar'] ) ) {
			unset( $d['karar']['metin'] );
		}
		foreach ( array( 'adimlar', 'kontroller', 'gecmis' ) as $k ) {
			if ( isset( $d[ $k ] ) && is_array( $d[ $k ] ) ) {
				foreach ( $d[ $k ] as $i => $x ) {
					if ( is_array( $x ) ) {
						unset( $d[ $k ][ $i ]['not'] );
					}
				}
			}
		}
	}
	return $d;
}

add_action( 'rest_api_init', function () {
	$ns = 'optik-karne/v1';
	register_rest_route( $ns, '/eka/liste', array( 'methods' => 'GET', 'callback' => 'sides_eka_liste', 'permission_callback' => 'sides_eka_okur' ) );
	register_rest_route( $ns, '/eka/kaydet', array( 'methods' => 'POST', 'callback' => 'sides_eka_kaydet', 'permission_callback' => 'sides_eka_yazar' ) );
	register_rest_route( $ns, '/eka/sil', array( 'methods' => 'POST', 'callback' => 'sides_eka_sil', 'permission_callback' => 'sides_eka_yazar' ) );
	register_rest_route( $ns, '/eka/tekrar/adim', array( 'methods' => 'POST', 'callback' => 'sides_eka_tekrar_adim', 'permission_callback' => 'sides_eka_yazar' ) );
	register_rest_route( $ns, '/eka/hata/aktar', array( 'methods' => 'POST', 'callback' => 'sides_eka_hata_aktar', 'permission_callback' => 'sides_eka_yazar' ) );
	register_rest_route( $ns, '/eka/hata/kontrol', array( 'methods' => 'POST', 'callback' => 'sides_eka_hata_kontrol', 'permission_callback' => 'sides_eka_yazar' ) );
	register_rest_route( $ns, '/eka/bilet/yanit', array( 'methods' => 'POST', 'callback' => 'sides_eka_bilet_yanit', 'permission_callback' => 'sides_eka_yazar' ) );
} );

/* GET eka/liste?tur=… → görebildiği kayıtlar */
function sides_eka_liste( WP_REST_Request $req ) {
	$tur = (string) $req->get_param( 'tur' );
	$ok  = sides_eka_tur( $tur );
	if ( true !== $ok ) {
		return $ok;
	}
	global $wpdb;
	$org  = sides_org_id();
	$t    = sides_docs();
	$izin = sides_eka_izin( $org );
	$gz   = sides_is_observer();
	$out  = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = %s ORDER BY id", $org, 'eka' . $tur ) ) as $r ) { // phpcs:ignore
		$d = sides_eka_suz( $tur, json_decode( $r->data, true ), $izin, $gz );
		if ( null !== $d ) {
			$d['id'] = (string) $r->id;
			$out[]   = $d;
		}
	}
	$res = rest_ensure_response( $out );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}

/* ---------- tür başına doğrulama ($e: eski kayıt ya da null) ---------- */
function sides_eka_temiz( $tur, $p, $e, $org ) {
	$g   = function ( $k, $d = '' ) use ( $p ) { return isset( $p[ $k ] ) ? $p[ $k ] : $d; };
	$ben = sides_eka_ben();
	$o   = array();
	if ( sides_eka_ogrenci_turu( $tur ) ) {
		$sid = $e ? (string) $e['studentId'] : (string) $g( 'studentId' );
		$s   = sides_eka_ogr( $org, $sid );
		if ( ! $s ) {
			return sides_eka_hata( 'Öğrenci bulunamadı.' );
		}
		$o['studentId'] = $sid;
		$o['sinif']     = sides_eka_sinif( isset( $s['sinif'] ) ? $s['sinif'] : '' );
		$o['sube']      = sides_eka_sube( isset( $s['sube'] ) ? $s['sube'] : '' );
	}
	if ( 'cikti' === $tur ) {
		$o['sinif']   = sides_eka_sinif( $g( 'sinif' ) );
		$o['sube']    = sides_eka_sube( $g( 'sube' ) );
		$o['ogrenci'] = sides_eka_sid( $g( 'ogrenci' ) ) ? (string) $g( 'ogrenci' ) : '';
		$o['ders']    = sides_eka_metin( $g( 'ders' ), 60 );
		$o['anahtar'] = is_scalar( $g( 'anahtar' ) ) ? mb_substr( trim( preg_replace( '/[\x00-\x1F\x7F<>]/u', '', (string) $g( 'anahtar' ) ) ), 0, 200 ) : '';
		$o['kod']     = sides_eka_metin( $g( 'kod' ), 40 );
		$o['ad']      = sides_eka_metin( $g( 'ad' ), 300 );
		$o['durum']   = in_array( $g( 'durum' ), array( 'islendi', 'kanit', 'destek', 'dogrulandi' ), true ) ? $g( 'durum' ) : '';
		$o['oncelik'] = ! empty( $p['oncelik'] );
		$o['not']     = sides_eka_metin( $g( 'not' ), 300 );
		if ( '' === $o['sinif'] || '' === $o['anahtar'] ) {
			return sides_eka_hata( 'Sınıf ve çıktı gerekli.' );
		}
		if ( $o['ogrenci'] ) {
			$s = sides_eka_ogr( $org, $o['ogrenci'] );
			if ( ! $s ) {
				return sides_eka_hata( 'Öğrenci bulunamadı.' );
			}
		}
		$gor = $e && isset( $e['gorevler'] ) && is_array( $e['gorevler'] ) ? $e['gorevler'] : array();
		$var = array();
		foreach ( $gor as $x ) {
			$var[ (string) $x['id'] ] = true;
		}
		foreach ( is_array( $g( 'gorevler', null ) ) ? $g( 'gorevler' ) : array() as $x ) {
			if ( is_array( $x ) && isset( $x['id'] ) && sides_eka_sid( $x['id'] ) && ! isset( $var[ (string) $x['id'] ] ) && count( $gor ) < 30 ) {
				$gor[] = array( 'id' => (string) $x['id'], 'tarih' => sides_eka_bugun(), 'n' => (int) sides_eka_int( isset( $x['n'] ) ? $x['n'] : 0, 0, 600 ), 'hedef' => isset( $x['hedef'] ) && 'zorlanan' === $x['hedef'] ? 'zorlanan' : 'sinif', 'son' => sides_eka_tarih( isset( $x['son'] ) ? $x['son'] : '' ) );
				$var[ (string) $x['id'] ] = true;
			}
		}
		$o['gorevler'] = $gor;
		$gec = $e && isset( $e['gecmis'] ) && is_array( $e['gecmis'] ) ? $e['gecmis'] : array();
		if ( $e && ( $e['durum'] !== $o['durum'] || ! empty( $e['oncelik'] ) !== $o['oncelik'] || (string) $e['not'] !== $o['not'] ) ) {
			array_unshift( $gec, array( 'durum' => $e['durum'], 'oncelik' => ! empty( $e['oncelik'] ), 'not' => (string) $e['not'], 't' => isset( $e['guncelleme'] ) ? (int) $e['guncelleme'] : 0, 'ad' => isset( $e['yazan']['ad'] ) ? $e['yazan']['ad'] : '' ) );
		}
		$o['gecmis'] = array_slice( $gec, 0, 30 );
		$o['yazan']  = $ben;
	} elseif ( 'tekrar' === $tur ) {
		$o['konu']  = sides_eka_metin( $g( 'konu' ), 120 );
		$o['ders']  = sides_eka_metin( $g( 'ders' ), 60 );
		$o['kod']   = sides_eka_metin( $g( 'kod' ), 40 );
		$o['sinif'] = sides_eka_sinif( $g( 'sinif' ) );
		$o['sube']  = sides_eka_sube( $g( 'sube' ) );
		$o['ilk']   = sides_eka_tarih( $g( 'ilk' ) );
		$o['gorev'] = sides_eka_metin( $g( 'gorev' ), 300 );
		$o['kanit'] = sides_eka_metin( $g( 'kanit' ), 120 );
		$o['sure']  = sides_eka_int( $g( 'sure', null ), 0, 240 );
		$o['aktif'] = ! isset( $p['aktif'] ) || ! empty( $p['aktif'] );
		if ( '' === $o['konu'] || '' === $o['sinif'] || '' === $o['ilk'] ) {
			return sides_eka_hata( 'Konu, sınıf ve ilk çalışma tarihi gerekli.' );
		}
		$og = array();
		foreach ( is_array( $g( 'ogrenciler', null ) ) ? $g( 'ogrenciler' ) : array() as $s ) {
			if ( sides_eka_sid( $s ) && count( $og ) < 80 ) {
				$og[ (string) $s ] = true;
			}
		}
		$o['ogrenciler'] = array_keys( $og );
		$ar = array();
		foreach ( is_array( $g( 'araliklar', null ) ) ? $g( 'araliklar' ) : array() as $x ) {
			$n = sides_eka_int( $x, 1, 365 );
			if ( null === $n ) {
				return sides_eka_hata( 'Tekrar aralıkları 1–365 gün arasında tam sayı olmalı.' );
			}
			$ar[ $n ] = true;
		}
		$ar = array_keys( $ar );
		sort( $ar );
		if ( ! $ar || count( $ar ) > 10 ) {
			return sides_eka_hata( 'En az 1, en çok 10 tekrar aralığı girin.' );
		}
		$o['araliklar'] = $ar;
		/* Adımlar: işlenmiş (yapıldı/eksik/ertelenmiş) adımlar geçmiş olarak korunur; bekleyenler yeni aralıklardan yeniden üretilir */
		$kalan = array();
		$gunler = array();
		foreach ( $e && isset( $e['adimlar'] ) && is_array( $e['adimlar'] ) ? $e['adimlar'] : array() as $a ) {
			if ( 'B' !== $a['durum'] || ! empty( $a['ertelendi'] ) || null !== $a['oran'] || '' !== (string) $a['not'] ) {
				$kalan[]                    = $a;
				$gunler[ (int) $a['gun'] ] = true;
			}
		}
		foreach ( $ar as $n ) {
			if ( ! isset( $gunler[ $n ] ) ) {
				$kalan[] = array( 'a' => 'g' . $n, 'gun' => $n, 'tarih' => sides_eka_gun_ekle( $o['ilk'], $n ), 'durum' => 'B', 'oran' => null, 'not' => '', 'ertelendi' => array(), 'kim' => null );
			}
		}
		usort( $kalan, function ( $x, $y ) { return strcmp( $x['tarih'], $y['tarih'] ) ?: ( $x['gun'] - $y['gun'] ); } );
		$o['adimlar'] = $kalan;
	} elseif ( 'hata' === $tur ) {
		if ( $e ) {
			$o['kaynak'] = $e['kaynak'];   // kaynak (sınav, soru, cevap) değiştirilemez
			$o['soru']   = isset( $e['soru'] ) ? $e['soru'] : '';
		} else {
			$k           = is_array( $g( 'kaynak', null ) ) ? $g( 'kaynak' ) : array();
			$o['kaynak'] = array( 'tur' => 'manuel', 'id' => '', 'ad' => sides_eka_metin( isset( $k['ad'] ) ? $k['ad'] : '', 120 ), 'tarih' => sides_eka_tarih( isset( $k['tarih'] ) ? $k['tarih'] : '' ), 'ders' => sides_eka_metin( isset( $k['ders'] ) ? $k['ders'] : '', 60 ), 'konu' => sides_eka_metin( isset( $k['konu'] ) ? $k['konu'] : '', 200 ), 'kazanim' => '', 'soruNo' => null, 'cevap' => '', 'dogru' => '' );
			$o['soru']   = sides_eka_metin( $g( 'soru' ), 300 );
			if ( '' === $o['soru'] && '' === $o['kaynak']['konu'] ) {
				return sides_eka_hata( 'Soru ya da konu yazın.' );
			}
		}
		$nd = array();
		foreach ( is_array( $g( 'nedenler', null ) ) ? $g( 'nedenler' ) : array() as $x ) {
			if ( in_array( $x, array( 'bilgi', 'islem', 'okuma', 'zaman', 'dikkat', 'belirsiz' ), true ) ) {
				$nd[ $x ] = true;
			}
		}
		$o['nedenler']    = array_keys( $nd );
		$o['ogrAciklama'] = sides_eka_uzun( $g( 'ogrAciklama' ), 500 );
		$o['duzeltme']    = sides_eka_uzun( $g( 'duzeltme' ), 500 );
		$o['kontroller']  = $e && isset( $e['kontroller'] ) && is_array( $e['kontroller'] ) ? $e['kontroller'] : array();
		$o['durum']       = 'kapali' === $g( 'durum' ) ? 'kapali' : 'acik';
		if ( 'kapali' === $o['durum'] && ( ! $e || 'kapali' !== $e['durum'] ) ) {
			$son = end( $o['kontroller'] );
			if ( ! $son || 'D' !== $son['sonuc'] ) {
				return sides_eka_hata( 'Kayıt, yeni bir soruyla yapılan son kontrol doğru olduğunda kapatılabilir.' );
			}
		}
	} elseif ( 'bilet' === $tur ) {
		$o['tur']   = 'baslangic' === $g( 'tur' ) ? 'baslangic' : 'cikis';
		$o['tarih'] = sides_eka_tarih( $g( 'tarih' ) );
		$o['ders']  = sides_eka_metin( $g( 'ders' ), 60 );
		$o['konu']  = sides_eka_metin( $g( 'konu' ), 160 );
		$o['sinif'] = sides_eka_sinif( $g( 'sinif' ) );
		$o['sube']  = sides_eka_sube( $g( 'sube' ) );
		$o['olcek'] = 'puan' === $g( 'olcek' ) ? 'puan' : 'dky';
		$o['max']   = 'puan' === $o['olcek'] ? sides_eka_int( $g( 'max', null ), 1, 10 ) : null;
		if ( 'puan' === $o['olcek'] && null === $o['max'] ) {
			return sides_eka_hata( 'Puan ölçeğinde en yüksek puan 1–10 olmalı.' );
		}
		$sr = array();
		foreach ( is_array( $g( 'sorular', null ) ) ? $g( 'sorular' ) : array() as $x ) {
			$x = sides_eka_metin( $x, 200 );
			if ( '' !== $x ) {
				$sr[] = $x;
			}
		}
		if ( count( $sr ) < 2 || count( $sr ) > 5 ) {
			return sides_eka_hata( '2 ile 5 arasında kısa soru yazın.' );
		}
		if ( '' === $o['tarih'] || '' === $o['sinif'] ) {
			return sides_eka_hata( 'Tarih ve sınıf gerekli.' );
		}
		$o['sorular'] = $sr;
		$k            = is_array( $g( 'karar', null ) ) ? $g( 'karar' ) : array();
		$o['karar']   = array( 'tur' => isset( $k['tur'] ) && in_array( $k['tur'], array( 'anlatim', 'grup', 'devam' ), true ) ? $k['tur'] : '', 'metin' => sides_eka_metin( isset( $k['metin'] ) ? $k['metin'] : '', 300 ) );
		if ( $e ) {
			$ayni = $e['sinif'] === $o['sinif'] && $e['sube'] === $o['sube'] && count( $e['sorular'] ) === count( $sr ) && $e['olcek'] === $o['olcek'] && $e['max'] === $o['max'];
			if ( ! $ayni && ! empty( (array) $e['yanitlar'] ) ) {
				return sides_eka_hata( 'Yanıt girilmiş bilette sınıf, soru sayısı ve ölçek değiştirilemez; yeni bilet açın.' );
			}
			$o['ogrenciler'] = $ayni ? $e['ogrenciler'] : sides_eka_sinif_ogr( $org, $o['sinif'], $o['sube'] );
			$o['yanitlar']   = (object) $e['yanitlar'];
		} else {
			$o['ogrenciler'] = sides_eka_sinif_ogr( $org, $o['sinif'], $o['sube'] );
			$o['yanitlar']   = (object) array();
		}
	} elseif ( 'lgs' === $tur ) {
		$o['hafta'] = $e ? $e['hafta'] : sides_eka_tarih( $g( 'hafta' ) );
		if ( '' === $o['hafta'] || '1' !== ( new DateTime( $o['hafta'] . ' 12:00:00' ) )->format( 'N' ) ) {
			return sides_eka_hata( 'Hafta başlangıcı pazartesi olmalı.' );
		}
		$on = array();
		foreach ( is_array( $g( 'oncelikler', null ) ) ? $g( 'oncelikler' ) : array() as $x ) {
			if ( is_array( $x ) && count( $on ) < 2 ) {
				$k = sides_eka_metin( isset( $x['konu'] ) ? $x['konu'] : '', 200 );
				if ( '' !== $k ) {
					$on[] = array( 'ders' => sides_eka_metin( isset( $x['ders'] ) ? $x['ders'] : '', 60 ), 'konu' => $k );
				}
			}
		}
		$o['oncelikler'] = $on;
		$gv              = array();
		foreach ( is_array( $g( 'gorevler', null ) ) ? $g( 'gorevler' ) : array() as $x ) {
			if ( is_array( $x ) && count( $gv ) < 5 ) {
				$m = sides_eka_metin( isset( $x['metin'] ) ? $x['metin'] : '', 160 );
				if ( '' !== $m ) {
					$gv[] = array( 'metin' => $m, 'durum' => isset( $x['durum'] ) && in_array( $x['durum'], array( 'B', 'T', 'E' ), true ) ? $x['durum'] : 'B' );
				}
			}
		}
		$o['gorevler']     = $gv;
		$o['hedef']        = sides_eka_metin( $g( 'hedef' ), 300 );
		$o['kontrolTarih'] = sides_eka_tarih( $g( 'kontrolTarih' ) );
		$o['tekrarOlcum']  = sides_eka_metin( $g( 'tekrarOlcum' ), 160 );
		$o['not']          = sides_eka_metin( $g( 'not' ), 300 );
	} elseif ( 'sure' === $tur ) {
		$o['sinavId'] = $e ? $e['sinavId'] : ( sides_eka_sid( $g( 'sinavId' ) ) ? (string) $g( 'sinavId' ) : '' );
		if ( $o['sinavId'] && ! $e && ! sides_get_doc( $org, 'exams', $o['sinavId'] ) ) {
			return sides_eka_hata( 'Deneme bulunamadı.' );
		}
		$o['sinavAd'] = sides_eka_metin( $g( 'sinavAd' ), 120 );
		$o['tarih']   = sides_eka_tarih( $g( 'tarih' ) );
		if ( '' === $o['tarih'] || '' === $o['sinavAd'] ) {
			return sides_eka_hata( 'Deneme adı ve tarih gerekli.' );
		}
		$dl = array();
		foreach ( is_array( $g( 'dersler', null ) ) ? $g( 'dersler' ) : array() as $x ) {
			if ( is_array( $x ) && count( $dl ) < 12 ) {
				$ad = sides_eka_metin( isset( $x['ad'] ) ? $x['ad'] : '', 60 );
				if ( '' !== $ad ) {
					$dl[] = array( 'ad' => $ad, 'plan' => sides_eka_int( isset( $x['plan'] ) ? $x['plan'] : null, 0, 300 ), 'sure' => sides_eka_int( isset( $x['sure'] ) ? $x['sure'] : null, 0, 300 ), 'olcum' => isset( $x['olcum'] ) && 'tahmin' === $x['olcum'] ? 'tahmin' : 'gercek', 'bos' => sides_eka_int( isset( $x['bos'] ) ? $x['bos'] : null, 0, 200 ), 'donus' => sides_eka_int( isset( $x['donus'] ) ? $x['donus'] : null, 0, 200 ) );
				}
			}
		}
		$o['dersler'] = $dl;
		$st           = array();
		foreach ( is_array( $g( 'stratejiler', null ) ) ? $g( 'stratejiler' ) : array() as $x ) {
			if ( in_array( $x, array( 'kolay', 'isaretle', 'sirayla', 'dersSira', 'kontrol' ), true ) ) {
				$st[ $x ] = true;
			}
		}
		$o['stratejiler']      = array_keys( $st );
		$o['donusSira']        = sides_eka_metin( $g( 'donusSira' ), 200 );
		$o['ogrDegerlendirme'] = sides_eka_uzun( $g( 'ogrDegerlendirme' ), 500 );
		$o['ogretmenNot']      = sides_eka_uzun( $g( 'ogretmenNot' ), 500 );
		$o['degisiklik']       = sides_eka_metin( $g( 'degisiklik' ), 200 );
	}
	return $o;
}
/* Kaydın kimliği: kararlı (cikti, lgs, sure) ya da istemci işlem kimliğinden (tekrar, hata, bilet) */
function sides_eka_kimlik( $tur, $o, $islem ) {
	if ( 'cikti' === $tur ) {
		return 'c_' . substr( md5( $o['sinif'] . '|' . $o['sube'] . '|' . $o['ogrenci'] . '|' . $o['anahtar'] ), 0, 24 );
	}
	if ( 'lgs' === $tur ) {
		return 'l_' . substr( md5( $o['studentId'] . '|' . $o['hafta'] ), 0, 24 );
	}
	if ( 'sure' === $tur ) {
		return 's_' . substr( md5( $o['studentId'] . '|' . ( $o['sinavId'] ? $o['sinavId'] : 'i:' . $islem ) ), 0, 24 );
	}
	return substr( $tur, 0, 1 ) . '_' . $islem;
}
/* Yazma kapsamı: öğrenci kaydında öğrenci, sınıf kaydında sınıf/şube (öğrenci listeli kayıtta listedeki herkes) */
function sides_eka_yazabilir( $tur, $d, $izin ) {
	if ( null === $izin ) {
		return true;
	}
	if ( sides_eka_ogrenci_turu( $tur ) ) {
		return isset( $izin[ (string) $d['studentId'] ] );
	}
	$liste = 'cikti' === $tur ? ( $d['ogrenci'] ? array( $d['ogrenci'] ) : array() ) : ( 'tekrar' === $tur ? $d['ogrenciler'] : array() );
	if ( $liste ) {
		foreach ( $liste as $s ) {
			if ( ! isset( $izin[ (string) $s ] ) ) {
				return false;
			}
		}
		return true;
	}
	return sides_eka_kapsam( $d['sinif'], $d['sube'], false );
}

/* POST eka/kaydet { tur, id?, islemId?, data } → kayıt */
function sides_eka_kaydet( WP_REST_Request $req ) {
	$p   = $req->get_json_params();
	$tur = isset( $p['tur'] ) ? (string) $p['tur'] : '';
	$ok  = sides_eka_tur( $tur );
	if ( true !== $ok ) {
		return $ok;
	}
	$org   = sides_org_id();
	$coll  = 'eka' . $tur;
	$data  = isset( $p['data'] ) && is_array( $p['data'] ) ? $p['data'] : null;
	$id    = isset( $p['id'] ) ? (string) $p['id'] : '';
	$islem = isset( $p['islemId'] ) ? (string) $p['islemId'] : '';
	if ( ! $data || strlen( (string) wp_json_encode( $data ) ) > 60000 ) {
		return sides_eka_hata( 'Geçersiz kayıt.' );
	}
	if ( '' !== $id && ! preg_match( '/^[a-z]_[A-Za-z0-9_\-]{4,60}$/', $id ) ) {
		return sides_eka_hata( 'Geçersiz kayıt kimliği.' );
	}
	if ( ! preg_match( '/^[A-Za-z0-9_\-]{6,40}$/', $islem ) ) {
		if ( '' === $id && ! in_array( $tur, array( 'cikti', 'lgs', 'sure' ), true ) ) {
			return sides_eka_hata( 'İşlem kimliği gerekli.' );
		}
		$islem = 'x' . substr( md5( wp_json_encode( $data ) ), 0, 12 );   // kararlı kimlikli türlerde işlem kimliği isteğe bağlı
	}
	$izin = sides_eka_izin( $org );
	$kil  = function_exists( 'sides_takip_kilit' ) ? sides_takip_kilit( 'eka|' . $org . '|' . $coll . '|' . ( $id ? $id : $islem ) ) : '';
	if ( false === $kil ) {
		return function_exists( 'sides_kilit_mesgul' ) ? sides_kilit_mesgul() : sides_eka_hata( 'Kayıt meşgul, tekrar deneyin.', 503 );
	}
	try {
		$e = $id ? sides_get_doc( $org, $coll, $id ) : null;
		if ( $id && ! $e ) {
			if ( ! in_array( $tur, array( 'cikti', 'lgs', 'sure' ), true ) ) {
				return sides_eka_hata( 'Kayıt bulunamadı; silinmiş olabilir.', 404 );
			}
			$id = '';   // kararlı kimlik içerikten yeniden hesaplanır
		}
		if ( $e && ! sides_eka_yazabilir( $tur, $e, $izin ) ) {
			return sides_deny( 'Bu kayıt sınıf yetkinizin dışında.' );
		}
		$o = sides_eka_temiz( $tur, $data, $e, $org );
		if ( is_wp_error( $o ) ) {
			return $o;
		}
		if ( ! sides_eka_yazabilir( $tur, $o, $izin ) ) {
			return sides_deny( 'Bu sınıf ya da öğrenci için yetkiniz yok.' );
		}
		$kid = $id ? $id : sides_eka_kimlik( $tur, $o, $islem );
		if ( ! $e ) {
			$e = sides_get_doc( $org, $coll, $kid );   // kararlı kimlik ya da aynı işlemin tekrarı
			if ( $e ) {
				if ( ! in_array( $tur, array( 'cikti', 'lgs', 'sure' ), true ) ) {
					$e['id']     = $kid;
					$e['tekrar'] = true;   // aynı islemId ikinci kez geldi: yeni kayıt açılmaz
					return rest_ensure_response( sides_eka_suz( $tur, $e, $izin, false ) );
				}
				if ( ! sides_eka_yazabilir( $tur, $e, $izin ) ) {
					return sides_deny( 'Bu kayıt sınıf yetkinizin dışında.' );
				}
				$o = sides_eka_temiz( $tur, $data, $e, $org );
				if ( is_wp_error( $o ) ) {
					return $o;
				}
			}
		}
		$o['olusturan']  = $e && isset( $e['olusturan'] ) ? $e['olusturan'] : sides_eka_ben();
		$o['olusturma']  = $e && isset( $e['olusturma'] ) ? (int) $e['olusturma'] : time();
		$o['guncelleme'] = time();
		$o['islemId']    = $e && isset( $e['islemId'] ) ? $e['islemId'] : $islem;
		if ( ! isset( $o['tarih'] ) ) {
			$o['tarih'] = 'tekrar' === $tur ? $o['ilk'] : ( 'lgs' === $tur ? $o['hafta'] : ( $e && isset( $e['tarih'] ) ? $e['tarih'] : sides_eka_bugun() ) );
		}
		if ( false === sides_put_doc( $org, $coll, $kid, $o ) ) {
			return sides_eka_hata( 'Kayıt yazılamadı.', 500 );
		}
		if ( ! $e ) {
			sides_log( $org, 'Ek modül kaydı oluşturuldu (' . sides_eka_turler()[ $tur ] . ')' );
		} elseif ( 'hata' === $tur && $e['durum'] !== $o['durum'] ) {
			sides_log( $org, 'Hata defteri kaydı ' . ( 'kapali' === $o['durum'] ? 'kapatıldı' : 'yeniden açıldı' ) );
		}
		$o['id'] = $kid;
		return rest_ensure_response( $o );
	} finally {
		if ( function_exists( 'sides_takip_kilit_birak' ) ) {
			sides_takip_kilit_birak( $kil );
		}
	}
}

/* POST eka/sil { tur, id } — oluşturan ya da yönetici */
function sides_eka_sil( WP_REST_Request $req ) {
	$p   = $req->get_json_params();
	$tur = isset( $p['tur'] ) ? (string) $p['tur'] : '';
	$ok  = sides_eka_tur( $tur );
	if ( true !== $ok ) {
		return $ok;
	}
	$org = sides_org_id();
	$id  = isset( $p['id'] ) ? (string) $p['id'] : '';
	if ( ! preg_match( '/^[a-z]_[A-Za-z0-9_\-]{4,60}$/', $id ) ) {
		return sides_eka_hata( 'Geçersiz kayıt kimliği.' );
	}
	$e = sides_get_doc( $org, 'eka' . $tur, $id );
	if ( ! $e ) {
		return rest_ensure_response( array( 'ok' => true, 'yok' => true ) );
	}
	if ( ! sides_eka_yazabilir( $tur, $e, sides_eka_izin( $org ) ) ) {
		return sides_deny( 'Bu kayıt sınıf yetkinizin dışında.' );
	}
	if ( ! sides_eka_yonetici() && ( ! isset( $e['olusturan']['u'] ) || (int) $e['olusturan']['u'] !== get_current_user_id() ) ) {
		return sides_deny( 'Kaydı yalnızca oluşturan öğretmen ya da yönetici silebilir.' );
	}
	global $wpdb;
	$wpdb->delete( sides_docs(), array( 'org' => $org, 'coll' => 'eka' . $tur, 'id' => $id ) );
	sides_log( $org, 'Ek modül kaydı silindi (' . sides_eka_turler()[ $tur ] . ')' );
	return rest_ensure_response( array( 'ok' => true ) );
}

/* Kilitli oku-değiştir-yaz yardımcısı */
function sides_eka_yama( $tur, $id, $fn ) {
	$ok = sides_eka_tur( $tur );
	if ( true !== $ok ) {
		return $ok;
	}
	if ( ! is_string( $id ) || ! preg_match( '/^[a-z]_[A-Za-z0-9_\-]{4,60}$/', $id ) ) {
		return sides_eka_hata( 'Geçersiz kayıt kimliği.' );
	}
	$org  = sides_org_id();
	$coll = 'eka' . $tur;
	$kil  = function_exists( 'sides_takip_kilit' ) ? sides_takip_kilit( 'eka|' . $org . '|' . $coll . '|' . $id ) : '';
	if ( false === $kil ) {
		return function_exists( 'sides_kilit_mesgul' ) ? sides_kilit_mesgul() : sides_eka_hata( 'Kayıt meşgul, tekrar deneyin.', 503 );
	}
	try {
		$d = sides_get_doc( $org, $coll, $id );
		if ( ! $d ) {
			return sides_eka_hata( 'Kayıt bulunamadı; silinmiş olabilir.', 404 );
		}
		$izin = sides_eka_izin( $org );
		$r    = $fn( $d, $izin, $org );
		if ( is_wp_error( $r ) ) {
			return $r;
		}
		unset( $r['id'] );
		$r['guncelleme'] = time();
		if ( false === sides_put_doc( $org, $coll, $id, $r ) ) {
			return sides_eka_hata( 'Kayıt yazılamadı.', 500 );
		}
		$r = sides_eka_suz( $tur, $r, $izin, false );
		$r['id'] = $id;
		return rest_ensure_response( $r );
	} finally {
		if ( function_exists( 'sides_takip_kilit_birak' ) ) {
			sides_takip_kilit_birak( $kil );
		}
	}
}

/* POST eka/tekrar/adim { id, a, durum: B|T|E, oran?, not?, yeniTarih? } */
function sides_eka_tekrar_adim( WP_REST_Request $req ) {
	$p = $req->get_json_params();
	return sides_eka_yama( 'tekrar', isset( $p['id'] ) ? $p['id'] : '', function ( $d, $izin ) use ( $p ) {
		if ( ! sides_eka_yazabilir( 'tekrar', $d, $izin ) ) {
			return sides_deny( 'Bu plan sınıf yetkinizin dışında.' );
		}
		$a   = isset( $p['a'] ) ? (string) $p['a'] : '';
		$yt  = sides_eka_tarih( isset( $p['yeniTarih'] ) ? $p['yeniTarih'] : '' );
		$dur = isset( $p['durum'] ) && in_array( $p['durum'], array( 'B', 'T', 'E' ), true ) ? $p['durum'] : null;
		if ( ! $dur && ! $yt ) {
			return sides_eka_hata( 'Geçersiz adım durumu.' );
		}
		foreach ( $d['adimlar'] as $i => $x ) {
			if ( $x['a'] !== $a ) {
				continue;
			}
			if ( $yt ) {   // kaçırılan ya da eksik kalan tekrar için yeni tarih: eski tarih geçmişte kalır, başarı düşürülmez
				$x['ertelendi'][] = array( 'tarih' => $x['tarih'], 'durum' => $x['durum'] );
				$x['ertelendi']   = array_slice( $x['ertelendi'], -10 );
				$x['tarih']       = $yt;
				$x['durum']       = 'B';
			} else {
				$x['durum'] = $dur;
			}
			if ( array_key_exists( 'oran', $p ) ) {
				$x['oran'] = sides_eka_int( $p['oran'], 0, 100 );
			}
			if ( isset( $p['not'] ) ) {
				$x['not'] = sides_eka_metin( $p['not'], 200 );
			}
			$x['kim']           = array_merge( sides_eka_ben(), array( 't' => time() ) );
			$d['adimlar'][ $i ] = $x;
			usort( $d['adimlar'], function ( $m, $n ) { return strcmp( $m['tarih'], $n['tarih'] ) ?: ( $m['gun'] - $n['gun'] ); } );
			return $d;
		}
		return sides_eka_hata( 'Tekrar adımı bulunamadı.', 404 );
	} );
}

/* POST eka/hata/kontrol { id, islemId, tarih, sonuc: D|Y, soru, not? } — yeni soruyla kontrol (ilk kanıt silinmez) */
function sides_eka_hata_kontrol( WP_REST_Request $req ) {
	$p = $req->get_json_params();
	return sides_eka_yama( 'hata', isset( $p['id'] ) ? $p['id'] : '', function ( $d, $izin ) use ( $p ) {
		if ( ! sides_eka_yazabilir( 'hata', $d, $izin ) ) {
			return sides_deny( 'Bu öğrenci için yetkiniz yok.' );
		}
		$is = isset( $p['islemId'] ) ? (string) $p['islemId'] : '';
		if ( ! preg_match( '/^[A-Za-z0-9_\-]{6,40}$/', $is ) ) {
			return sides_eka_hata( 'İşlem kimliği gerekli.' );
		}
		foreach ( (array) $d['kontroller'] as $k ) {
			if ( isset( $k['id'] ) && $k['id'] === $is ) {
				return $d;   // aynı işlem ikinci kez: değişiklik yok
			}
		}
		$t   = sides_eka_tarih( isset( $p['tarih'] ) ? $p['tarih'] : '' );
		$sn  = isset( $p['sonuc'] ) && in_array( $p['sonuc'], array( 'D', 'Y' ), true ) ? $p['sonuc'] : '';
		$sr  = sides_eka_metin( isset( $p['soru'] ) ? $p['soru'] : '', 200 );
		$ilk = trim( (string) ( isset( $d['kaynak']['ad'] ) ? $d['kaynak']['ad'] : '' ) . ( isset( $d['kaynak']['soruNo'] ) && $d['kaynak']['soruNo'] ? ' · ' . $d['kaynak']['soruNo'] . '. soru' : '' ) );
		if ( ! $t || ! $sn || '' === $sr ) {
			return sides_eka_hata( 'Tarih, sonuç ve yeni sorunun kimliği ya da kısa tanımı gerekli.' );
		}
		if ( mb_strtolower( $sr, 'UTF-8' ) === mb_strtolower( $ilk, 'UTF-8' ) || ( '' !== (string) $d['soru'] && mb_strtolower( $sr, 'UTF-8' ) === mb_strtolower( (string) $d['soru'], 'UTF-8' ) ) ) {
			return sides_eka_hata( 'Kontrol yeni bir soruyla yapılmalı; ilk soruyla aynı olamaz.' );
		}
		if ( count( (array) $d['kontroller'] ) >= 20 ) {
			return sides_eka_hata( 'Bir kayıtta en çok 20 kontrol tutulur.' );
		}
		$d['kontroller'][] = array_merge( array( 'id' => $is, 'tarih' => $t, 'sonuc' => $sn, 'soru' => $sr, 'not' => sides_eka_metin( isset( $p['not'] ) ? $p['not'] : '', 200 ) ), array( 'kim' => sides_eka_ben() ) );
		return $d;
	} );
}

/* POST eka/bilet/yanit { id, sid, y: [..] | 'X' (katılmadı) | null (sil) } */
function sides_eka_bilet_yanit( WP_REST_Request $req ) {
	$p = $req->get_json_params();
	return sides_eka_yama( 'bilet', isset( $p['id'] ) ? $p['id'] : '', function ( $d, $izin, $org ) use ( $p ) {
		$sid = isset( $p['sid'] ) ? (string) $p['sid'] : '';
		if ( ! sides_eka_sid( $sid ) || ( null !== $izin && ! isset( $izin[ $sid ] ) ) ) {
			return sides_deny( 'Bu öğrenci için yetkiniz yok.' );
		}
		if ( ! in_array( $sid, (array) $d['ogrenciler'], true ) ) {
			$s = sides_eka_ogr( $org, $sid );
			if ( ! $s || sides_eka_sinif( isset( $s['sinif'] ) ? $s['sinif'] : '' ) !== $d['sinif'] || ( '' !== $d['sube'] && sides_eka_sube( isset( $s['sube'] ) ? $s['sube'] : '' ) !== $d['sube'] ) ) {
				return sides_eka_hata( 'Öğrenci bu bilette değil.' );
			}
			$d['ogrenciler'][] = $sid;
		}
		$y = (array) $d['yanitlar'];
		$v = array_key_exists( 'y', (array) $p ) ? $p['y'] : null;
		if ( null === $v ) {
			unset( $y[ $sid ] );
		} elseif ( 'X' === $v ) {
			$y[ $sid ] = 'X';
		} elseif ( is_array( $v ) && count( $v ) === count( $d['sorular'] ) ) {
			$o = array();
			foreach ( array_values( $v ) as $x ) {
				if ( null === $x || '' === $x ) {
					$o[] = null;
				} elseif ( 'N' === $x ) {
					$o[] = 'N';
				} elseif ( 'dky' === $d['olcek'] && in_array( $x, array( 'D', 'K', 'Y' ), true ) ) {
					$o[] = $x;
				} elseif ( 'puan' === $d['olcek'] && null !== sides_eka_int( $x, 0, (int) $d['max'] ) && is_numeric( $x ) && (float) $x === (float) (int) $x ) {
					$o[] = (int) $x;
				} else {
					return sides_eka_hata( 'Geçersiz yanıt değeri.' );
				}
			}
			$y[ $sid ] = $o;
		} else {
			return sides_eka_hata( 'Geçersiz yanıt.' );
		}
		$d['yanitlar'] = (object) $y;
		return $d;
	} );
}

/* POST eka/hata/aktar { items: [ { studentId, tur: deneme|test, id, di, q, konu?, kazanim? } ] }
   Yalnız kayıtlı sonuçtaki gerçek yanlışlar alınır: sonuç bulunur, öğrencinin cevabı ve anahtar sunucuda okunur. */
function sides_eka_hata_aktar( WP_REST_Request $req ) {
	$ok = sides_eka_tur( 'hata' );
	if ( true !== $ok ) {
		return $ok;
	}
	global $wpdb;
	$p     = $req->get_json_params();
	$items = isset( $p['items'] ) && is_array( $p['items'] ) ? array_slice( $p['items'], 0, 60 ) : array();
	if ( ! $items ) {
		return sides_eka_hata( 'Aktarılacak soru seçilmedi.' );
	}
	$org  = sides_org_id();
	$t    = sides_docs();
	$izin = sides_eka_izin( $org );
	$out  = array( 'eklenen' => array(), 'mevcut' => 0, 'red' => array() );
	foreach ( $items as $it ) {
		$sid = isset( $it['studentId'] ) ? (string) $it['studentId'] : '';
		$tr  = isset( $it['tur'] ) && in_array( $it['tur'], array( 'deneme', 'test' ), true ) ? $it['tur'] : '';
		$kid = isset( $it['id'] ) ? (string) $it['id'] : '';
		$di  = isset( $it['di'] ) ? (int) $it['di'] : -1;
		$q   = isset( $it['q'] ) ? (int) $it['q'] : -1;
		if ( ! sides_eka_sid( $sid ) || ! $tr || ! sides_eka_sid( $kid ) || $di < 0 || $q < 0 || ( null !== $izin && ! isset( $izin[ $sid ] ) ) ) {
			$out['red'][] = 'Geçersiz ya da yetki dışı öğe';
			continue;
		}
		$s = sides_eka_ogr( $org, $sid );
		if ( ! $s ) {
			$out['red'][] = 'Öğrenci bulunamadı';
			continue;
		}
		$id = 'h_' . substr( md5( $sid . '|' . $tr . '|' . $kid . '|' . $di . '|' . $q ), 0, 24 );
		if ( sides_get_doc( $org, 'ekahata', $id ) ) {
			$out['mevcut']++;
			continue;
		}
		$cevap = '';
		$dogru = '';
		$ders  = '';
		$ad    = '';
		$tarih = '';
		$sno   = $q + 1;
		if ( 'deneme' === $tr ) {
			$e = sides_get_doc( $org, 'exams', $kid );
			if ( ! $e || ! isset( $e['dersler'][ $di ] ) || $q >= (int) $e['dersler'][ $di ]['soru'] ) {
				$out['red'][] = 'Deneme ya da soru bulunamadı';
				continue;
			}
			$rows = $wpdb->get_col( $wpdb->prepare( "SELECT data FROM $t WHERE org = %d AND coll = 'results' AND exam_id = %s", $org, $kid ) ); // phpcs:ignore
			$off  = 0;
			for ( $i = 0; $i < $di; $i++ ) {
				$off += (int) $e['dersler'][ $i ]['soru'];
			}
			$hasB = isset( $e['anahtar']['B'] ) && is_array( $e['anahtar']['B'] ) && '' !== trim( implode( '', array_map( 'strval', $e['anahtar']['B'] ) ) );
			foreach ( $rows as $rj ) {
				$r = json_decode( $rj, true );
				if ( ! is_array( $r ) || (string) ( isset( $r['studentId'] ) ? $r['studentId'] : '' ) !== $sid ) {
					continue;
				}
				$kit = isset( $r['kitapcik'] ) && 'B' === $r['kitapcik'] && $hasB ? 'B' : 'A';
				$a   = mb_substr( (string) ( isset( $r['cevap'] ) ? $r['cevap'] : '' ), $off + $q, 1 );
				$c   = mb_strtoupper( mb_substr( (string) ( isset( $e['anahtar'][ $kit ][ $di ] ) ? $e['anahtar'][ $kit ][ $di ] : '' ), $q, 1 ), 'UTF-8' );
				if ( '' !== $a && '-' !== $a && ' ' !== $a && '' !== $c && '?' !== $c && 'X' !== $c && $a !== $c ) {
					$cevap = $a;
					$dogru = $c;
				}
			}
			$ders  = (string) $e['dersler'][ $di ]['ad'];
			$ad    = (string) ( isset( $e['ad'] ) ? $e['ad'] : 'Deneme' );
			$tarih = sides_eka_tarih( isset( $e['tarih'] ) ? $e['tarih'] : '' );
		} else {
			$tt = sides_get_doc( $org, 'testler', $kid );
			$qs = $tt && isset( $tt['sorular'] ) && is_array( $tt['sorular'] ) ? $tt['sorular'] : array();
			if ( ! $tt || 0 !== $di || ! isset( $qs[ $q ] ) ) {
				$out['red'][] = 'Test ya da soru bulunamadı';
				continue;
			}
			$rows = $wpdb->get_col( $wpdb->prepare( "SELECT data FROM $t WHERE org = %d AND coll = 'tsonuc' AND id LIKE %s", $org, $wpdb->esc_like( $kid ) . '%' ) ); // phpcs:ignore
			$c    = mb_strtoupper( (string) ( isset( $qs[ $q ]['cevap'] ) ? $qs[ $q ]['cevap'] : '' ), 'UTF-8' );
			foreach ( $rows as $rj ) {
				$r = json_decode( $rj, true );
				if ( ! is_array( $r ) || (string) ( isset( $r['studentId'] ) ? $r['studentId'] : '' ) !== $sid || (string) ( isset( $r['testId'] ) ? $r['testId'] : '' ) !== $kid ) {
					continue;
				}
				$a = mb_substr( (string) ( isset( $r['cevap'] ) ? $r['cevap'] : '' ), $q, 1 );
				if ( '' !== $a && '-' !== $a && ' ' !== $a && '' !== $c && '?' !== $c && 'X' !== $c && $a !== $c ) {
					$cevap = $a;
					$dogru = $c;
				}
			}
			$ders  = (string) ( isset( $tt['ders'] ) ? $tt['ders'] : 'Test' );
			$ad    = (string) ( isset( $tt['ad'] ) ? $tt['ad'] : 'Test' );
			$tarih = sides_eka_tarih( isset( $tt['tarih'] ) ? $tt['tarih'] : '' );
		}
		if ( '' === $cevap ) {
			$out['red'][] = $ad . ' ' . $sno . '. soru: kayıtlı sonuçta yanlış cevap bulunamadı';
			continue;
		}
		$o = array(
			'studentId'   => $sid,
			'sinif'       => sides_eka_sinif( isset( $s['sinif'] ) ? $s['sinif'] : '' ),
			'sube'        => sides_eka_sube( isset( $s['sube'] ) ? $s['sube'] : '' ),
			'kaynak'      => array( 'tur' => $tr, 'id' => $kid, 'ad' => mb_substr( $ad, 0, 120 ), 'tarih' => $tarih, 'ders' => mb_substr( $ders, 0, 60 ), 'di' => $di, 'soruNo' => $sno, 'aNo' => sides_eka_int( isset( $it['aNo'] ) ? $it['aNo'] : null, 1, 300 ), 'cevap' => $cevap, 'dogru' => $dogru, 'konu' => sides_eka_metin( isset( $it['konu'] ) ? $it['konu'] : '', 200 ), 'kazanim' => sides_eka_metin( isset( $it['kazanim'] ) ? $it['kazanim'] : '', 300 ) ),
			'soru'        => '',
			'nedenler'    => array(),
			'ogrAciklama' => '',
			'duzeltme'    => '',
			'kontroller'  => array(),
			'durum'       => 'acik',
			'tarih'       => sides_eka_bugun(),
			'olusturan'   => sides_eka_ben(),
			'olusturma'   => time(),
			'guncelleme'  => time(),
			'islemId'     => '',
		);
		if ( false !== sides_put_doc( $org, 'ekahata', $id, $o ) ) {
			$o['id']            = $id;
			$out['eklenen'][] = $o;
		}
	}
	if ( $out['eklenen'] ) {
		sides_log( $org, 'Hata defterine ' . count( $out['eklenen'] ) . ' yanlış soru aktarıldı (EK05)' );
	}
	return rest_ensure_response( $out );
}
