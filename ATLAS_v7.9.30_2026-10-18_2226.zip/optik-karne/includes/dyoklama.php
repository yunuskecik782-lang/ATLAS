<?php
/* Deneme klasörleri ve deneme yoklaması (v7.4; v7.5: klasör + birden fazla denemeli yoklama).
   DENEME KLASÖRÜ — sides_docs 'dklasor': { ad, tarih, examIds: [...], olusturma, guncelleme }
   - Aynı tarihte uygulanan denemeleri (ör. "9 Ekim Cuma Denemesi" → 5, 6, 7, 8. sınıf) bir başlık altında toplar. Bir deneme en çok bir
     klasörde olur (kaydedilen klasöre eklenen deneme diğer klasörlerden çıkarılır). Klasör silinince denemeler silinmez.
   - Uygulamaya 'all' yanıtıyla gelir (dklasor). Rotalar: PUT/DELETE dklasor/<id>.
   DENEME YOKLAMASI — sides_docs 'dyoklama': { ad, examIds: [...], klasor, olusturma, olusturan, durum: { "<deneme>|<öğrenci>": { d, tarih, not, u, t } } }
   - Bir yoklama birden çok denemeyi kapsar (bütün kurum: 5, 6, 7, 8 …); deneme ekleyip çıkarabilirsiniz.
   - Formu okutulmuş öğrenci kendiliğinden "Girdi", olmayan "Girmedi". Elle durum: G Girdi · Y Girmedi · H Hasta · I İzinli · S Sonra girecek
     (isteğe bağlı telafi tarihi ve not).
   - v7.4.0 kayıtları (kimlik = deneme, durum anahtarı = öğrenci) okunurken yeni biçime çevrilir.
   - Yetki: her deneme için Nehari sınıfıysa Nehari, değilse Deneme Modülü (sinav); görme 1, işaretleme 2; gözlemci işaretleyemez.
     Sınıf kısıtlı kullanıcı yalnız kendi sınıflarındaki öğrencileri görür ve işaretler; yoklamanın adını/denemelerini değiştiremez, silemez.
   Rotalar: GET/POST dyoklama · GET/PUT/DELETE dyoklama/<id> · POST dyoklama/<id>/isaret { items:[{e,s}], d, tarih, not } */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function sides_dy_kodlar() {
	return array( 'G', 'Y', 'H', 'I', 'S' );
}
function sides_dy_modul( $e ) {
	return sides_neh_sinif( isset( $e['sinif'] ) ? $e['sinif'] : '' ) ? 'nehari' : 'sinav';
}
function sides_dy_gorebilir( $e ) {
	return sides_can( sides_dy_modul( $e ), 1 );
}
function sides_dy_yazabilir( $e ) {
	return ! sides_is_observer() && sides_can( sides_dy_modul( $e ), 2 );
}
function sides_dy_kimlik( $v, $n = 64 ) {
	return is_scalar( $v ) ? substr( preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $v ), 0, $n ) : '';
}
function sides_dy_yeni_id( $on ) {
	return $on . bin2hex( random_bytes( 6 ) );
}
/* İstekteki deneme listesi: tekil, var olan denemeler (en çok 30) */
function sides_dy_denemeler( $org, $ids ) {
	$out = array();
	foreach ( array_slice( (array) $ids, 0, 30 ) as $x ) {
		$id = sides_dy_kimlik( $x );
		if ( '' !== $id && ! isset( $out[ $id ] ) ) {
			$e = sides_get_doc( $org, 'exams', $id );
			if ( $e ) {
				$out[ $id ] = $e;
			}
		}
	}
	return $out;
}
/* Denemenin sınıfındaki (ve kullanıcının kapsamındaki) öğrenciler: id => true */
function sides_dy_ogrenciler( $org, $sinif ) {
	global $wpdb;
	static $tum = array();
	if ( ! isset( $tum[ $org ] ) ) {
		$t           = sides_docs();
		$tum[ $org ] = array();
		foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT coll, id, token, data FROM $t WHERE org = %d AND coll = 'students'", $org ) ) as $r ) { // phpcs:ignore
			$tum[ $org ][] = sides_row_out( $r );
		}
	}
	$kisit = sides_sinif_kisit();
	$out   = array();
	foreach ( $tum[ $org ] as $s ) {
		if ( isset( $s['sinif'] ) && (string) $s['sinif'] === (string) $sinif && ( null === $kisit || sides_ogrenci_izinli( $s, $kisit ) ) ) {
			$out[ (string) $s['id'] ] = true;
		}
	}
	return $out;
}
/* Okutulmuş formu olan öğrenciler: id => true */
function sides_dy_okutulan( $org, $exam_id ) {
	global $wpdb;
	$t   = sides_docs();
	$out = array();
	foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT data FROM $t WHERE org = %d AND coll = 'results' AND exam_id = %s", $org, $exam_id ) ) as $r ) { // phpcs:ignore
		$d = json_decode( $r->data, true );
		if ( ! empty( $d['studentId'] ) ) {
			$out[ (string) $d['studentId'] ] = true;
		}
	}
	return $out;
}
/* Kaydı yeni biçime getirir (v7.4.0 tek denemeli kayıtlar dahil) */
function sides_dy_norm( $doc, $id ) {
	if ( ! is_array( $doc ) ) {
		return null;
	}
	$ex = isset( $doc['examIds'] ) && is_array( $doc['examIds'] ) ? array_values( array_unique( array_filter( array_map( 'sides_dy_kimlik', $doc['examIds'] ) ) ) ) : array( sides_dy_kimlik( isset( $doc['examId'] ) ? $doc['examId'] : $id ) );
	$dur = array();
	foreach ( ( isset( $doc['durum'] ) && is_array( $doc['durum'] ) ? $doc['durum'] : array() ) as $k => $x ) {
		$k = (string) $k;
		if ( false === strpos( $k, '|' ) ) {
			$k = ( $ex ? $ex[0] : '' ) . '|' . $k;   // v7.4.0: anahtar yalnız öğrenciydi
		}
		if ( is_array( $x ) ) {
			$dur[ $k ] = $x;
		}
	}
	return array(
		'id'        => (string) $id,
		'ad'        => isset( $doc['ad'] ) ? (string) $doc['ad'] : '',
		'examIds'   => $ex,
		'klasor'    => isset( $doc['klasor'] ) ? sides_dy_kimlik( $doc['klasor'] ) : '',
		'olusturma' => isset( $doc['olusturma'] ) ? (int) $doc['olusturma'] : 0,
		'olusturan' => isset( $doc['olusturan'] ) ? (string) $doc['olusturan'] : '',
		'durum'     => $dur,
	);
}
function sides_dy_kaydet( $org, $y ) {
	$id = $y['id'];
	unset( $y['id'] );
	$y['durum'] = $y['durum'] ? $y['durum'] : new stdClass();
	return sides_put_doc( $org, 'dyoklama', $id, $y );
}
function sides_dy_al( $org, $id ) {
	$id = sides_dy_kimlik( $id );
	return '' === $id ? null : sides_dy_norm( sides_get_doc( $org, 'dyoklama', $id ), $id );
}
/* Yoklamanın kullanıcının görebildiği denemeleri: id => deneme */
function sides_dy_gorunen( $org, $y ) {
	$out = array();
	foreach ( $y['examIds'] as $eid ) {
		$e = sides_get_doc( $org, 'exams', $eid );
		if ( $e && sides_dy_gorebilir( $e ) ) {
			$out[ $eid ] = $e;
		}
	}
	return $out;
}
function sides_dy_kisa( $e ) {
	return array( 'id' => $e['id'], 'ad' => isset( $e['ad'] ) ? (string) $e['ad'] : '', 'sinif' => isset( $e['sinif'] ) ? (string) $e['sinif'] : '', 'tarih' => isset( $e['tarih'] ) ? (string) $e['tarih'] : '', 'yazabilir' => sides_dy_yazabilir( $e ) );
}
/* Özet ve ayrıntı: görünen denemelerdeki kapsam içi öğrenciler */
function sides_dy_hesap( $org, $y, $ayrinti ) {
	$E   = sides_dy_gorunen( $org, $y );
	$n   = array_fill_keys( sides_dy_kodlar(), 0 );
	$top = 0;
	$okn = 0;
	$dur = array();
	$oku = array();
	$exs = array();
	foreach ( $E as $eid => $e ) {
		$ogr  = sides_dy_ogrenciler( $org, isset( $e['sinif'] ) ? $e['sinif'] : '' );
		$ok   = sides_dy_okutulan( $org, $eid );
		$en   = array_fill_keys( sides_dy_kodlar(), 0 );
		foreach ( array_keys( $ogr ) as $sid ) {
			$k = $eid . '|' . $sid;
			$x = isset( $y['durum'][ $k ] ) ? $y['durum'][ $k ] : null;
			$d = $x && isset( $x['d'] ) && in_array( $x['d'], sides_dy_kodlar(), true ) ? $x['d'] : ( isset( $ok[ $sid ] ) ? 'G' : 'Y' );
			$n[ $d ]++;
			$en[ $d ]++;
			if ( $x ) {
				$dur[ $k ] = $x;
			}
			if ( isset( $ok[ $sid ] ) ) {
				$oku[] = $k;
				$okn++;
			}
		}
		$top  += count( $ogr );
		$kisa  = sides_dy_kisa( $e );
		$kisa['n'] = $en;
		$kisa['toplam'] = count( $ogr );
		$exs[] = $kisa;
	}
	$o = array(
		'id'        => $y['id'],
		'ad'        => '' !== $y['ad'] ? $y['ad'] : ( 1 === count( $exs ) ? $exs[0]['ad'] : 'Deneme yoklaması' ),
		'examIds'   => array_keys( $E ),
		'exams'     => $exs,
		'klasor'    => $y['klasor'],
		'olusturma' => $y['olusturma'],
		'olusturan' => $y['olusturan'],
		'n'         => $n,
		'toplam'    => $top,
		'okutulanN' => $okn,
	);
	if ( $ayrinti ) {
		$yaz             = false;
		$hepsi           = (bool) $E;
		foreach ( $E as $e ) {
			$w     = sides_dy_yazabilir( $e );
			$yaz   = $yaz || $w;
			$hepsi = $hepsi && $w;
		}
		$o['durum']        = (object) $dur;
		$o['okutulan']     = $oku;
		$o['yazabilir']    = $yaz;
		$o['duzenleyebilir'] = $hepsi && null === sides_sinif_kisit() && count( $E ) === count( $y['examIds'] );
		$o['silebilir']    = $o['duzenleyebilir'];
	}
	return $o;
}

function sides_dy_rest_liste( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$t   = sides_docs();
	$out = array();
	foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT coll, id, token, data FROM $t WHERE org = %d AND coll = 'dyoklama'", $org ) ) as $r ) { // phpcs:ignore
		$y = sides_dy_norm( sides_row_out( $r ), (string) $r->id );
		if ( ! $y ) {
			continue;
		}
		$h = sides_dy_hesap( $org, $y, false );
		if ( $h['exams'] ) {
			$out[] = $h;
		}
	}
	$res = rest_ensure_response( array( 'liste' => $out ) );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}
function sides_dy_rest_al( WP_REST_Request $req ) {
	$org = sides_org_id();
	$y   = sides_dy_al( $org, $req['id'] );
	if ( ! $y ) {
		return new WP_Error( 'sides_yok', 'Deneme yoklaması bulunamadı.', array( 'status' => 404 ) );
	}
	$h = sides_dy_hesap( $org, $y, true );
	if ( ! $h['exams'] ) {
		return sides_deny();
	}
	$res = rest_ensure_response( $h );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}
/* Yoklama aç: { ad, examIds, klasor } */
function sides_dy_rest_olustur( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = (array) $req->get_json_params();
	$E   = sides_dy_denemeler( $org, isset( $p['examIds'] ) ? $p['examIds'] : array() );
	if ( ! $E ) {
		return new WP_Error( 'sides_gecersiz', 'Yoklamaya en az bir deneme ekleyin.', array( 'status' => 400 ) );
	}
	foreach ( $E as $e ) {
		if ( ! sides_dy_yazabilir( $e ) ) {
			return sides_deny( 'Seçilen denemelerden birinde yoklama alma yetkiniz yok.' );
		}
	}
	$klasor = isset( $p['klasor'] ) ? sides_dy_kimlik( $p['klasor'] ) : '';
	if ( '' !== $klasor && ! sides_get_doc( $org, 'dklasor', $klasor ) ) {
		$klasor = '';
	}
	$ad = isset( $p['ad'] ) && is_scalar( $p['ad'] ) ? mb_substr( trim( sanitize_text_field( (string) $p['ad'] ) ), 0, 80 ) : '';
	if ( '' === $ad && $klasor ) {
		$k  = sides_get_doc( $org, 'dklasor', $klasor );
		$ad = isset( $k['ad'] ) ? (string) $k['ad'] : '';
	}
	$u = wp_get_current_user();
	$y = array( 'id' => sides_dy_yeni_id( 'dy' ), 'ad' => $ad, 'examIds' => array_keys( $E ), 'klasor' => $klasor, 'olusturma' => (int) round( microtime( true ) * 1000 ), 'olusturan' => $u && $u->ID ? $u->display_name : '', 'durum' => array() );
	if ( false === sides_dy_kaydet( $org, $y ) ) {
		return new WP_Error( 'sides_db', 'Yoklama kaydedilemedi.', array( 'status' => 500 ) );
	}
	sides_log( $org, 'Deneme yoklaması açıldı: ' . ( '' !== $ad ? $ad : implode( ', ', array_map( function ( $e ) { return isset( $e['ad'] ) ? $e['ad'] : $e['id']; }, $E ) ) ) );
	return sides_dy_hesap( $org, sides_dy_al( $org, $y['id'] ), true );
}
/* Ad ve deneme listesi: { ad?, examIds? } — çıkarılan denemenin işaretleri silinir */
function sides_dy_rest_guncelle( WP_REST_Request $req ) {
	$org = sides_org_id();
	if ( sides_is_observer() || null !== sides_sinif_kisit() ) {
		return sides_deny( 'Yoklamanın adını ve denemelerini yalnız sınıf kısıtı olmayan, Deneme Modülü’nde tam yetkili kullanıcı değiştirebilir.' );
	}
	$kilit = function_exists( 'sides_takip_kilit' ) ? sides_takip_kilit( 'dyoklama|' . $org . '|' . sides_dy_kimlik( $req['id'] ) ) : '';
	if ( false === $kilit ) {
		return sides_kilit_mesgul();
	}
	$son = sides_dy_guncelle_uygula( $org, $req );
	if ( $kilit ) {
		sides_takip_kilit_birak( $kilit );
	}
	return $son;
}
function sides_dy_guncelle_uygula( $org, WP_REST_Request $req ) {
	$y = sides_dy_al( $org, $req['id'] );
	if ( ! $y ) {
		return new WP_Error( 'sides_yok', 'Deneme yoklaması bulunamadı.', array( 'status' => 404 ) );
	}
	foreach ( sides_dy_denemeler( $org, $y['examIds'] ) as $e ) {
		if ( ! sides_dy_yazabilir( $e ) ) {
			return sides_deny();
		}
	}
	$p = (array) $req->get_json_params();
	if ( isset( $p['ad'] ) && is_scalar( $p['ad'] ) ) {
		$y['ad'] = mb_substr( trim( sanitize_text_field( (string) $p['ad'] ) ), 0, 80 );
	}
	if ( isset( $p['examIds'] ) ) {
		$E = sides_dy_denemeler( $org, $p['examIds'] );
		if ( ! $E ) {
			return new WP_Error( 'sides_gecersiz', 'Yoklamada en az bir deneme kalmalı; yoklamayı kaldırmak için “Bu yoklamayı sil”i kullanın.', array( 'status' => 400 ) );
		}
		foreach ( $E as $e ) {
			if ( ! sides_dy_yazabilir( $e ) ) {
				return sides_deny( 'Eklenen denemelerden birinde yoklama alma yetkiniz yok.' );
			}
		}
		$y['examIds'] = array_keys( $E );
		foreach ( array_keys( $y['durum'] ) as $k ) {
			if ( ! isset( $E[ strtok( $k, '|' ) ] ) ) {
				unset( $y['durum'][ $k ] );
			}
		}
	}
	if ( false === sides_dy_kaydet( $org, $y ) ) {
		return new WP_Error( 'sides_db', 'Yoklama kaydedilemedi.', array( 'status' => 500 ) );
	}
	return sides_dy_hesap( $org, sides_dy_al( $org, $y['id'] ), true );
}
function sides_dy_rest_isaret( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = (array) $req->get_json_params();
	$d   = isset( $p['d'] ) && null !== $p['d'] && '' !== $p['d'] ? (string) $p['d'] : null;
	if ( null !== $d && ! in_array( $d, sides_dy_kodlar(), true ) ) {
		return new WP_Error( 'sides_gecersiz', 'Geçersiz yoklama durumu.', array( 'status' => 400 ) );
	}
	$tarih = isset( $p['tarih'] ) && is_string( $p['tarih'] ) ? $p['tarih'] : '';
	if ( '' !== $tarih && ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $tarih ) ) {
		return new WP_Error( 'sides_gecersiz', 'Tarih YYYY-AA-GG biçiminde olmalı.', array( 'status' => 400 ) );
	}
	$not   = isset( $p['not'] ) && is_scalar( $p['not'] ) ? mb_substr( sanitize_text_field( (string) $p['not'] ), 0, 120 ) : '';
	$items = array();
	foreach ( array_slice( (array) ( isset( $p['items'] ) ? $p['items'] : array() ), 0, 300 ) as $it ) {
		$e = is_array( $it ) && isset( $it['e'] ) ? sides_dy_kimlik( $it['e'] ) : '';
		$s = is_array( $it ) && isset( $it['s'] ) ? sides_dy_kimlik( $it['s'] ) : '';
		if ( '' !== $e && '' !== $s ) {
			$items[ $e . '|' . $s ] = array( $e, $s );
		}
	}
	if ( ! $items ) {
		return new WP_Error( 'sides_gecersiz', 'Öğrenci seçilmedi.', array( 'status' => 400 ) );
	}
	$kilit = function_exists( 'sides_takip_kilit' ) ? sides_takip_kilit( 'dyoklama|' . $org . '|' . sides_dy_kimlik( $req['id'] ) ) : '';
	if ( false === $kilit ) {
		return sides_kilit_mesgul();
	}
	$son = sides_dy_isaret_uygula( $org, $req['id'], $items, $d, $tarih, $not );
	if ( $kilit ) {
		sides_takip_kilit_birak( $kilit );
	}
	return $son;
}
function sides_dy_isaret_uygula( $org, $id, $items, $d, $tarih, $not ) {
	$y = sides_dy_al( $org, $id );
	if ( ! $y ) {
		return new WP_Error( 'sides_yok', 'Deneme yoklaması bulunamadı.', array( 'status' => 404 ) );
	}
	$E   = sides_dy_denemeler( $org, $y['examIds'] );
	$ogr = array();
	foreach ( $items as list( $e, $s ) ) {
		if ( ! isset( $E[ $e ] ) ) {
			return new WP_Error( 'sides_gecersiz', 'Bu deneme yoklamada değil.', array( 'status' => 400 ) );
		}
		if ( ! sides_dy_yazabilir( $E[ $e ] ) ) {
			return sides_deny();
		}
		if ( ! isset( $ogr[ $e ] ) ) {
			$ogr[ $e ] = sides_dy_ogrenciler( $org, isset( $E[ $e ]['sinif'] ) ? $E[ $e ]['sinif'] : '' );
		}
		if ( ! isset( $ogr[ $e ][ $s ] ) ) {
			return sides_deny( 'Bu öğrenci denemenin sınıfında değil ya da yetkiniz dışında.' );
		}
	}
	$u = wp_get_current_user();
	foreach ( array_keys( $items ) as $k ) {
		if ( null === $d ) {
			unset( $y['durum'][ $k ] );
		} else {
			$y['durum'][ $k ] = array( 'd' => $d, 'tarih' => $tarih, 'not' => $not, 'u' => $u && $u->ID ? $u->display_name : '', 't' => time() );
		}
	}
	if ( false === sides_dy_kaydet( $org, $y ) ) {
		return new WP_Error( 'sides_db', 'Yoklama kaydedilemedi.', array( 'status' => 500 ) );
	}
	return sides_dy_hesap( $org, sides_dy_al( $org, $y['id'] ), true );
}
function sides_dy_rest_sil( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$y   = sides_dy_al( $org, $req['id'] );
	if ( ! $y ) {
		return new WP_Error( 'sides_yok', 'Deneme yoklaması bulunamadı.', array( 'status' => 404 ) );
	}
	$h = sides_dy_hesap( $org, $y, true );
	if ( empty( $h['silebilir'] ) ) {
		return sides_deny( 'Deneme yoklamasını yalnız sınıf kısıtı olmayan, bütün denemelerinde tam yetkili kullanıcı silebilir.' );
	}
	$wpdb->delete( sides_docs(), array( 'org' => $org, 'coll' => 'dyoklama', 'id' => $y['id'] ) );
	sides_log( $org, 'Deneme yoklaması silindi: ' . $h['ad'] );
	return array( 'ok' => true );
}

/* ---------------- Deneme klasörleri ---------------- */
function sides_dk_liste( $org ) {
	global $wpdb;
	$t   = sides_docs();
	$out = array();
	foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT coll, id, token, data FROM $t WHERE org = %d AND coll = 'dklasor' ORDER BY id", $org ) ) as $r ) { // phpcs:ignore
		$d     = sides_row_out( $r );
		$out[] = array(
			'id'         => (string) $r->id,
			'ad'         => isset( $d['ad'] ) ? (string) $d['ad'] : '',
			'tarih'      => isset( $d['tarih'] ) ? (string) $d['tarih'] : '',
			'examIds'    => isset( $d['examIds'] ) && is_array( $d['examIds'] ) ? array_values( array_map( 'strval', $d['examIds'] ) ) : array(),
			'olusturma'  => isset( $d['olusturma'] ) ? (int) $d['olusturma'] : 0,
			'guncelleme' => isset( $d['guncelleme'] ) ? (int) $d['guncelleme'] : 0,
		);
	}
	return $out;
}
function sides_dk_yazabilir() {
	return ! sides_is_observer() && ( sides_can( 'sinav', 2 ) || sides_can( 'nehari', 2 ) );
}
function sides_dk_rest_kaydet( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$id  = sides_dy_kimlik( $req['id'], 40 );
	$p   = (array) $req->get_json_params();
	$ad  = isset( $p['ad'] ) && is_scalar( $p['ad'] ) ? mb_substr( trim( sanitize_text_field( (string) $p['ad'] ) ), 0, 80 ) : '';
	if ( '' === $ad ) {
		return new WP_Error( 'sides_gecersiz', 'Klasör adını yazın.', array( 'status' => 400 ) );
	}
	$tarih = isset( $p['tarih'] ) && is_string( $p['tarih'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $p['tarih'] ) ? $p['tarih'] : '';
	$E     = sides_dy_denemeler( $org, isset( $p['examIds'] ) ? $p['examIds'] : array() );
	$eski  = sides_get_doc( $org, 'dklasor', $id );
	$simdi = (int) round( microtime( true ) * 1000 );
	$doc   = array( 'ad' => $ad, 'tarih' => $tarih, 'examIds' => array_keys( $E ), 'olusturma' => $eski && isset( $eski['olusturma'] ) ? (int) $eski['olusturma'] : $simdi, 'guncelleme' => $simdi );
	if ( false === sides_put_doc( $org, 'dklasor', $id, $doc ) ) {
		return new WP_Error( 'sides_db', 'Klasör kaydedilemedi.', array( 'status' => 500 ) );
	}
	// bir deneme tek klasörde: bu klasöre eklenenler diğerlerinden çıkar
	if ( $E ) {
		foreach ( sides_dk_liste( $org ) as $k ) {
			if ( $k['id'] !== $id && array_intersect( $k['examIds'], array_keys( $E ) ) ) {
				$k2 = sides_get_doc( $org, 'dklasor', $k['id'] );
				unset( $k2['id'] );
				$k2['examIds'] = array_values( array_diff( $k['examIds'], array_keys( $E ) ) );
				sides_put_doc( $org, 'dklasor', $k['id'], $k2 );
			}
		}
	}
	if ( ! $eski ) {
		sides_log( $org, 'Deneme klasörü oluşturuldu: ' . $ad );
	}
	return array( 'klasorler' => sides_dk_liste( $org ) );
}
function sides_dk_rest_sil( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$id  = sides_dy_kimlik( $req['id'], 40 );
	$k   = sides_get_doc( $org, 'dklasor', $id );
	if ( ! $k ) {
		return new WP_Error( 'sides_yok', 'Klasör bulunamadı.', array( 'status' => 404 ) );
	}
	$wpdb->delete( sides_docs(), array( 'org' => $org, 'coll' => 'dklasor', 'id' => $id ) );
	sides_log( $org, 'Deneme klasörü silindi (denemeler yerinde): ' . ( isset( $k['ad'] ) ? $k['ad'] : $id ) );
	return array( 'klasorler' => sides_dk_liste( $org ) );
}

add_action( 'rest_api_init', function () {
	$ns  = 'optik-karne/v1';
	$oku = function () {
		return sides_is_panel() && ( sides_can( 'sinav', 1 ) || sides_can( 'nehari', 1 ) ) ? true : sides_deny();
	};
	$yaz = function () {
		if ( sides_is_observer() ) {
			return sides_deny( 'Gözlemci hesabının işlem yetkisi yok. Yöneticinizden izin isteyin.' );
		}
		return sides_is_panel() && ( sides_can( 'sinav', 2 ) || sides_can( 'nehari', 2 ) ) ? true : sides_deny();
	};
	register_rest_route( $ns, '/dyoklama', array(
		array( 'methods' => 'GET', 'callback' => 'sides_dy_rest_liste', 'permission_callback' => $oku ),
		array( 'methods' => 'POST', 'callback' => 'sides_dy_rest_olustur', 'permission_callback' => $yaz ),
	) );
	register_rest_route( $ns, '/dyoklama/(?P<id>[A-Za-z0-9_\-]{1,64})', array(
		array( 'methods' => 'GET', 'callback' => 'sides_dy_rest_al', 'permission_callback' => $oku ),
		array( 'methods' => 'PUT', 'callback' => 'sides_dy_rest_guncelle', 'permission_callback' => $yaz ),
		array( 'methods' => 'DELETE', 'callback' => 'sides_dy_rest_sil', 'permission_callback' => $yaz ),
	) );
	register_rest_route( $ns, '/dyoklama/(?P<id>[A-Za-z0-9_\-]{1,64})/isaret', array( 'methods' => 'POST', 'callback' => 'sides_dy_rest_isaret', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/dklasor/(?P<id>[A-Za-z0-9_\-]{1,40})', array(
		array( 'methods' => 'PUT', 'callback' => 'sides_dk_rest_kaydet', 'permission_callback' => function () {
			return sides_is_panel() && sides_dk_yazabilir() ? true : sides_deny( 'Deneme klasörlerini düzenleme yetkiniz yok.' );
		} ),
		array( 'methods' => 'DELETE', 'callback' => 'sides_dk_rest_sil', 'permission_callback' => function () {
			return sides_is_panel() && sides_dk_yazabilir() ? true : sides_deny( 'Deneme klasörlerini düzenleme yetkiniz yok.' );
		} ),
	) );
} );

add_filter( 'rest_post_dispatch', function ( $res, $server, $req ) {
	if ( ! ( $res instanceof WP_REST_Response ) || $res->is_error() ) {
		return $res;
	}
	$route = (string) $req->get_route();
	// klasörler 'all' yanıtıyla gelir (deneme görme yetkisi olana)
	if ( '/optik-karne/v1/all' === $route && 'GET' === $req->get_method() && function_exists( 'sides_sinav_okur' ) && sides_sinav_okur() ) {
		$d = $res->get_data();
		if ( is_array( $d ) ) {
			$d['dklasor'] = sides_dk_liste( sides_org_id() );
			$res->set_data( $d );
		}
		return $res;
	}
	// deneme silinince klasörlerden ve yoklamalardan çıkar (boş kalan yoklama silinir)
	if ( 'DELETE' === $req->get_method() && preg_match( '#^/optik-karne/v1/doc/exams/([A-Za-z0-9_\-]{1,64})$#', $route, $m ) ) {
		global $wpdb;
		$org = sides_org_id();
		$eid = $m[1];
		foreach ( sides_dk_liste( $org ) as $k ) {
			if ( in_array( $eid, $k['examIds'], true ) ) {
				$k2 = sides_get_doc( $org, 'dklasor', $k['id'] );
				unset( $k2['id'] );
				$k2['examIds'] = array_values( array_diff( $k['examIds'], array( $eid ) ) );
				sides_put_doc( $org, 'dklasor', $k['id'], $k2 );
			}
		}
		$t = sides_docs();
		foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT coll, id, token, data FROM $t WHERE org = %d AND coll = 'dyoklama'", $org ) ) as $r ) { // phpcs:ignore
			$y = sides_dy_norm( sides_row_out( $r ), (string) $r->id );
			if ( ! $y || ! in_array( $eid, $y['examIds'], true ) ) {
				continue;
			}
			$y['examIds'] = array_values( array_diff( $y['examIds'], array( $eid ) ) );
			if ( ! $y['examIds'] ) {
				$wpdb->delete( $t, array( 'org' => $org, 'coll' => 'dyoklama', 'id' => $y['id'] ) );
				continue;
			}
			foreach ( array_keys( $y['durum'] ) as $k ) {
				if ( 0 === strpos( $k, $eid . '|' ) ) {
					unset( $y['durum'][ $k ] );
				}
			}
			sides_dy_kaydet( $org, $y );
		}
	}
	return $res;
}, 10, 3 );
