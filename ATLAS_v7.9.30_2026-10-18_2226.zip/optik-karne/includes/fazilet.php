<?php
/**
 * v7 R05 — Fazilet Takvimi'nden otomatik namaz vakti çekimi (TV panosu; Puan Sistemi modülü).
 *
 * Fazilet Takvimi verisi kurumun izniyle kullanılır. Sunucu, yöneticinin girdiği ve fazilettakvimi.com alan adıyla sınırlı
 * veri yolundan günde iki kez (03:40 ve 15:40) okur. TV ekranları kaynağa hiç bağlanmaz; yalnızca kayıtlı aylık çizelgeyi (tv/vakit_<YYYY-MM>) okur.
 *
 * Belgeler (coll: fazilet — genel /doc ve /koleksiyon yolları bu koleksiyona erişemez; yedekte kurumun diğer belgeleriyle gelir):
 *   fazilet/ayar           { otomatik 0|1, ilceId, sehirId, url ('{ilce}' yer tutuculu şablon), tz, degistiren, degisti }
 *   fazilet/durum          { sonBasari {...}, sonHata {...}, deneme, sonDeneme, cakisma { tarih: { elle, oto } }, gecmis [...] }
 *   fazilet/oto_<YYYY-MM>  { gunler: { tarih: {7 vakit} }, t: { tarih: unix } }   otomatik yazılan son değerler
 * Birleştirme (tv/vakit_<YYYY-MM>.gunler, gün gün): boş gün doldurulur; otomatik yazılmış ve sonradan elle değiştirilmemiş gün
 *   güncellenir; elle girilmiş ve farklı olan gün korunur ve "cakisma" listesine yazılır ("Otomatik veriyle değiştir" onayı ister).
 *   Yanıttaki tek bir gün bile denetimden geçmezse hiçbir şey yazılmaz; son doğrulanmış veriler korunur.
 *
 * GET  fazilet/durum     (puan ≥ 1)
 * POST fazilet/ayar      (yalnız yönetici)
 * POST fazilet/cek       "Şimdi çek": yönetici; ya da puan ≥ 2 ve otomatik çekim açık
 * POST fazilet/degistir  (puan ≥ 2) { tarihler: [...] } elle girilmiş günleri otomatik veriyle değiştirir
 * Zamanlama: sides_fazilet_gunluk (günde iki kez 03:40 ve 15:40, Europe/Istanbul); hatada sides_fazilet_tekrar 1 saat arayla en çok 3 kez.
 * Test: apply_filters( 'sides_fazilet_url', $url, $ilceId ) veri yolunu yerel sahte yanıta yönlendirebilir (yalnız eklenti kodu).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SIDES_FZ_MAX_BAYT', 1048576 );
/* v7.0.3: Fazilet Takvimi'nin herkese açık günlük veri yolu (kurumun bildirdiği; yanıt: success, bolge_saatdilimi, form.ilce_id/sehir_id,
   vakitler[ { tarih, imsak: [ { tarih: ISO UTC, is_takdiri } ], sabah, gunes, ogle, ikindi, aksam, yatsi } ] — 3 gün) */
define( 'SIDES_FZ_URL', 'https://backend.fazilettakvimi.com/content/public/daily?districtId={ilce}&lang=tr' );
define( 'SIDES_FZ_TZ', 'Europe/Istanbul' );
define( 'SIDES_FZ_KAYNAK', 'Fazilet (otomatik)' );
define( 'SIDES_FZ_TEKRAR', 3 );

add_action( 'rest_api_init', function () {
	$ns   = 'optik-karne/v1';
	$oku  = function () {
		return sides_can( 'puan', 1 ) ? true : sides_deny();
	};
	$yon  = function () {
		if ( sides_is_observer() ) {
			return sides_deny( 'Gözlemci hesabının işlem yetkisi yok.' );
		}
		return 'yonetici' === sides_ctx()['rol'] ? true : sides_deny( 'Otomatik çekim ayarlarını yalnızca yönetici değiştirebilir.' );
	};
	$yaz  = function () {
		if ( sides_is_observer() ) {
			return sides_deny( 'Gözlemci hesabının işlem yetkisi yok.' );
		}
		return sides_can( 'puan', 2 ) ? true : sides_deny( 'Bu işlem için Puan Sistemi düzenleme yetkisi gerekir.' );
	};
	register_rest_route( $ns, '/fazilet/durum', array( 'methods' => 'GET', 'callback' => 'sides_fz_durum_oku', 'permission_callback' => $oku ) );
	register_rest_route( $ns, '/fazilet/ayar', array( 'methods' => 'POST', 'callback' => 'sides_fz_ayar_yaz', 'permission_callback' => $yon ) );
	register_rest_route( $ns, '/fazilet/cek', array( 'methods' => 'POST', 'callback' => 'sides_fz_simdi', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/fazilet/degistir', array( 'methods' => 'POST', 'callback' => 'sides_fz_degistir', 'permission_callback' => $yaz ) );
} );

/* ------------------------------------------------------------------ *
 * Zamanlama
 * ------------------------------------------------------------------ */
add_action( 'init', function () {
	if ( wp_next_scheduled( 'sides_fazilet_gunluk' ) && 'twicedaily' !== wp_get_schedule( 'sides_fazilet_gunluk' ) ) {
		wp_clear_scheduled_hook( 'sides_fazilet_gunluk' );   // v7.0.3: günde bir → günde iki çekim
	}
	if ( ! wp_next_scheduled( 'sides_fazilet_gunluk' ) ) {
		$t = new DateTime( 'tomorrow 03:40', new DateTimeZone( SIDES_FZ_TZ ) );
		wp_schedule_event( $t->getTimestamp(), 'twicedaily', 'sides_fazilet_gunluk' );   // 03:40 ve 15:40
	}
} );
add_action( 'sides_fazilet_gunluk', 'sides_fz_gunluk_is' );
add_action( 'sides_fazilet_tekrar', 'sides_fz_tekrar_is', 10, 1 );

/* Otomatik çekimi açık kurumlar (modülü kapalı ya da engelli kurum atlanır) */
function sides_fz_acik_kurumlar() {
	global $wpdb;
	$t   = sides_docs();
	$out = array();
	foreach ( (array) $wpdb->get_results( "SELECT org, data FROM $t WHERE coll = 'fazilet' AND id = 'ayar'" ) as $r ) { // phpcs:ignore
		$d   = json_decode( $r->data, true );
		$org = (int) $r->org;
		if ( ! is_array( $d ) || empty( $d['otomatik'] ) ) {
			continue;
		}
		if ( function_exists( 'sides_kapali_moduller' ) && in_array( 'puan', sides_kapali_moduller( $org ), true ) ) {
			continue;
		}
		$o = sides_org( $org );
		if ( ! $o || ( function_exists( 'sides_org_blok' ) && sides_org_blok( $o ) ) ) {
			continue;
		}
		$out[] = $org;
	}
	return $out;
}
function sides_fz_gunluk_is() {
	foreach ( sides_fz_acik_kurumlar() as $org ) {
		sides_fz_calistir( $org, 'zamanli' );
	}
}
function sides_fz_tekrar_is( $org ) {
	$org = (int) $org;
	if ( in_array( $org, sides_fz_acik_kurumlar(), true ) ) {
		sides_fz_calistir( $org, 'tekrar' );
	}
}

/* ------------------------------------------------------------------ *
 * Ayar ve durum
 * ------------------------------------------------------------------ */
function sides_fz_ayar( $org ) {
	$d = sides_get_doc( $org, 'fazilet', 'ayar' );
	$d = is_array( $d ) ? $d : array();
	return array(
		'otomatik'   => empty( $d['otomatik'] ) ? 0 : 1,
		'ilceId'     => isset( $d['ilceId'] ) && (int) $d['ilceId'] > 0 ? (int) $d['ilceId'] : 1508,   // Fatih (İstanbul şehir kimliği 31 yerine kullanılmaz)
		'sehirId'    => isset( $d['sehirId'] ) ? max( 0, (int) $d['sehirId'] ) : 31,
		'url'        => isset( $d['url'] ) && '' !== $d['url'] ? (string) $d['url'] : SIDES_FZ_URL,
		'tz'         => SIDES_FZ_TZ,
		'degistiren' => isset( $d['degistiren'] ) ? (string) $d['degistiren'] : '',
		'degisti'    => isset( $d['degisti'] ) ? (int) $d['degisti'] : 0,
	);
}
function sides_fz_durum( $org ) {
	$d = sides_get_doc( $org, 'fazilet', 'durum' );
	$d = is_array( $d ) ? $d : array();
	unset( $d['id'] );
	foreach ( array( 'cakisma' => array(), 'gecmis' => array(), 'deneme' => 0, 'sonDeneme' => 0, 'sonBasari' => null, 'sonHata' => null ) as $k => $v ) {
		if ( ! isset( $d[ $k ] ) ) {
			$d[ $k ] = $v;
		}
	}
	$d['cakisma'] = is_array( $d['cakisma'] ) ? $d['cakisma'] : array();
	$d['gecmis']  = is_array( $d['gecmis'] ) ? $d['gecmis'] : array();
	return $d;
}
/* Veri yolu şablonu: https, yalnız fazilettakvimi.com (ve alt alan adları), {ilce} yer tutucusu zorunlu */
function sides_fz_url_gecerli( $u ) {
	if ( '' === $u ) {
		return true;
	}
	if ( strlen( $u ) > 300 || preg_match( '/[\s<>"\'\\\\]/', $u ) || false === strpos( $u, '{ilce}' ) ) {
		return false;
	}
	$p = wp_parse_url( str_replace( array( '{ilce}', '{sehir}' ), array( '1', '1' ), $u ) );
	if ( ! is_array( $p ) || empty( $p['host'] ) || 'https' !== ( isset( $p['scheme'] ) ? strtolower( $p['scheme'] ) : '' ) || isset( $p['user'] ) || isset( $p['pass'] ) || ( isset( $p['port'] ) && 443 !== (int) $p['port'] ) ) {
		return false;
	}
	$h = strtolower( $p['host'] );
	return 'fazilettakvimi.com' === $h || '.fazilettakvimi.com' === substr( $h, -19 );
}
function sides_fz_bugun() {
	return ( new DateTime( 'now', new DateTimeZone( SIDES_FZ_TZ ) ) )->format( 'Y-m-d' );
}
function sides_fz_gun_ekle( $iso, $n ) {
	$d = new DateTime( $iso . ' 12:00:00', new DateTimeZone( SIDES_FZ_TZ ) );
	$d->modify( ( $n >= 0 ? '+' : '' ) . (int) $n . ' days' );
	return $d->format( 'Y-m-d' );
}

/* ------------------------------------------------------------------ *
 * Yanıt çözümleyici (belgelenmiş biçim: success, ilce_id, sehir_id, bolge_saatdilimi ve UTC tarihli vakitler)
 * ------------------------------------------------------------------ */
function sides_fz_norm( $k ) {
	$k = mb_strtolower( (string) $k, 'UTF-8' );
	$k = strtr( $k, array( 'ı' => 'i', 'i̇' => 'i', 'ğ' => 'g', 'ü' => 'u', 'ş' => 's', 'ö' => 'o', 'ç' => 'c', 'â' => 'a', 'î' => 'i', 'û' => 'u' ) );
	return preg_replace( '/[^a-z0-9]/', '', $k );
}
/* Anahtarı (normalleştirilmiş adla) önce üst düzeyde, sonra iç içe nesnelerde arar; vakit listelerinin içine girmez */
function sides_fz_bul( $a, $adlar, $derin = 0 ) {
	if ( ! is_array( $a ) || $derin > 3 ) {
		return null;
	}
	foreach ( $a as $k => $v ) {
		if ( is_string( $k ) && in_array( sides_fz_norm( $k ), $adlar, true ) && ! is_array( $v ) ) {
			return $v;
		}
	}
	foreach ( $a as $k => $v ) {
		if ( is_array( $v ) && is_string( $k ) && ! wp_is_numeric_array( $v ) ) {
			$r = sides_fz_bul( $v, $adlar, $derin + 1 );
			if ( null !== $r ) {
				return $r;
			}
		}
	}
	return null;
}
function sides_fz_alan( $k ) {
	$n = sides_fz_norm( $k );
	foreach ( array( 'imsak', 'sabah', 'gunes', 'ogle', 'ikindi', 'aksam', 'yatsi' ) as $a ) {
		if ( 0 === strpos( $n, $a ) ) {
			return $a;
		}
	}
	return '';
}
function sides_fz_vakit_say( $x ) {
	$n = array();
	foreach ( is_array( $x ) ? array_keys( $x ) : array() as $k ) {
		$a = sides_fz_alan( $k );
		if ( $a ) {
			$n[ $a ] = 1;
		}
	}
	return count( $n );
}
/* Vakit kayıtlarının listesi: [ {tarih?, imsak, …} ] ya da { 'YYYY-MM-DD…': {imsak, …} } */
function sides_fz_liste( $a, $derin = 0 ) {
	if ( ! is_array( $a ) || $derin > 4 ) {
		return null;
	}
	if ( $a && wp_is_numeric_array( $a ) && is_array( reset( $a ) ) && sides_fz_vakit_say( reset( $a ) ) >= 5 ) {
		return array_values( $a );
	}
	$tarihli = array();
	foreach ( $a as $k => $v ) {
		if ( is_string( $k ) && preg_match( '/^\d{4}-\d{2}-\d{2}/', $k ) && is_array( $v ) && sides_fz_vakit_say( $v ) >= 5 ) {
			$tarihli[] = array_merge( array( 'tarih' => $k ), $v );
		}
	}
	if ( $tarihli ) {
		return $tarihli;
	}
	foreach ( $a as $v ) {
		$r = is_array( $v ) ? sides_fz_liste( $v, $derin + 1 ) : null;
		if ( $r ) {
			return $r;
		}
	}
	return null;
}
/* Bir vakit değeri → yerel (Europe/Istanbul) DateTime. Kaynak değerleri UTC'dir: ISO tarih-saat (Z/±hh:mm ya da bölgesiz = UTC),
   Unix zaman damgası (sn/ms) ya da kaydın tarihiyle birlikte 'HH:MM' (UTC). */
function sides_fz_an( $v, $tarih, $zone ) {
	$utc = new DateTimeZone( 'UTC' );
	try {
		if ( is_int( $v ) || is_float( $v ) || ( is_string( $v ) && preg_match( '/^\d{9,13}$/', $v ) ) ) {
			$s = (float) $v;
			$s = $s > 1e11 ? $s / 1000 : $s;
			$d = new DateTime( '@' . (int) round( $s ) );
		} elseif ( is_string( $v ) && preg_match( '/^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2}(?::\d{2}(?:\.\d+)?)?)(Z|[+-]\d{2}:?\d{2})?$/', trim( $v ), $m ) ) {
			$d = empty( $m[3] ) ? new DateTime( $m[1] . ' ' . $m[2], $utc ) : new DateTime( trim( $v ) );
		} elseif ( is_string( $v ) && $tarih && preg_match( '/^(\d{1,2}):(\d{2})(?::\d{2})?$/', trim( $v ), $m ) && (int) $m[1] < 24 ) {
			$d = new DateTime( $tarih . ' ' . str_pad( $m[1], 2, '0', STR_PAD_LEFT ) . ':' . $m[2] . ':00', $utc );
		} else {
			return null;
		}
	} catch ( Exception $e ) {
		return null;
	}
	$d->setTimezone( $zone );
	return $d;
}
function sides_fz_tarih( $v, $zone ) {
	if ( ! is_string( $v ) && ! is_int( $v ) ) {
		return '';
	}
	$v = trim( (string) $v );
	if ( preg_match( '/^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}.*(Z|[+-]\d{2}:?\d{2})$/', $v ) ) {
		$d = sides_fz_an( $v, '', $zone );
		return $d ? $d->format( 'Y-m-d' ) : '';
	}
	if ( preg_match( '/^(\d{4})-(\d{2})-(\d{2})/', $v, $m ) && checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ) {
		return $m[1] . '-' . $m[2] . '-' . $m[3];
	}
	if ( preg_match( '/^(\d{1,2})[.\/](\d{1,2})[.\/](\d{4})$/', $v, $m ) && checkdate( (int) $m[2], (int) $m[1], (int) $m[3] ) ) {
		return $m[3] . '-' . str_pad( $m[2], 2, '0', STR_PAD_LEFT ) . '-' . str_pad( $m[1], 2, '0', STR_PAD_LEFT );
	}
	return '';
}
/* Ayrıştır + doğrula. Dönüş: { gunler: { tarih: {imsak, sabah, gunes, ogle, ikindi, aksam, yatsi} }, ilceId, sehirId, tz } ya da WP_Error */
function sides_fz_coz( $j, $ayar ) {
	$hata = function ( $m ) {
		return new WP_Error( 'sides_fazilet', $m, array( 'status' => 502 ) );
	};
	if ( ! is_array( $j ) ) {
		return $hata( 'Yanıt JSON değil.' );
	}
	$ok = sides_fz_bul( $j, array( 'success' ) );
	if ( ! ( true === $ok || 1 === $ok || 'true' === $ok || '1' === $ok ) ) {
		return $hata( 'Yanıtta başarı işareti (success) yok ya da yanlış.' );
	}
	$ilce = sides_fz_bul( $j, array( 'ilceid' ) );
	if ( null === $ilce || ! is_numeric( $ilce ) || (int) $ilce !== (int) $ayar['ilceId'] ) {
		return $hata( 'Yanıttaki ilçe kimliği (' . ( null === $ilce ? 'yok' : sanitize_text_field( (string) $ilce ) ) . ') beklenen ' . (int) $ayar['ilceId'] . ' değil; veri yazılmadı.' );
	}
	$sehir = sides_fz_bul( $j, array( 'sehirid' ) );
	if ( null !== $sehir && $ayar['sehirId'] && (int) $sehir !== (int) $ayar['sehirId'] ) {
		return $hata( 'Yanıttaki şehir kimliği (' . (int) $sehir . ') beklenen ' . (int) $ayar['sehirId'] . ' değil.' );
	}
	$tz = sides_fz_bul( $j, array( 'bolgesaatdilimi' ) );
	if ( $ayar['tz'] !== $tz ) {
		return $hata( 'Yanıttaki saat dilimi (' . ( $tz ? sanitize_text_field( (string) $tz ) : 'yok' ) . ') ' . $ayar['tz'] . ' değil.' );
	}
	$L = sides_fz_liste( $j );
	if ( ! $L ) {
		return $hata( 'Yanıtta vakit listesi bulunamadı.' );
	}
	if ( count( $L ) > 400 ) {
		return $hata( 'Yanıtta beklenenden çok gün var (' . count( $L ) . ').' );
	}
	$zone  = new DateTimeZone( $ayar['tz'] );
	$bugun = sides_fz_bugun();
	$alt   = sides_fz_gun_ekle( $bugun, -40 );
	$ust   = sides_fz_gun_ekle( $bugun, 400 );
	$sira  = array( 'imsak', 'sabah', 'gunes', 'ogle', 'ikindi', 'aksam', 'yatsi' );
	$out   = array();
	foreach ( $L as $i => $x ) {
		$no = 'Kayıt ' . ( $i + 1 ) . ': ';
		if ( ! is_array( $x ) ) {
			return $hata( $no . 'biçim bozuk.' );
		}
		$ham = array();
		$tar = '';
		foreach ( $x as $k => $v ) {
			$n = sides_fz_norm( $k );
			if ( in_array( $n, array( 'tarih', 'miladitarih', 'miladi', 'date', 'gun', 'gregoriandate' ), true ) && ! $tar ) {
				$tar = sides_fz_tarih( $v, $zone );
				if ( ! $tar ) {
					return $hata( $no . 'tarih biçimi okunamadı.' );
				}
			} elseif ( ( $a = sides_fz_alan( $k ) ) && ! isset( $ham[ $a ] ) && ! is_array( $v ) ) {
				$ham[ $a ] = $v;
			} elseif ( ( $a = sides_fz_alan( $k ) ) && ! isset( $ham[ $a ] ) && is_array( $v ) && $v && wp_is_numeric_array( $v ) ) {
				// v7.0.3: Fazilet biçimi — her vakit bir dizi: [ { tarih: '…Z', is_takdiri } ]; takdirî olmayan ilk değer, yoksa ilki
				$sec = null;
				foreach ( $v as $e ) {
					if ( is_array( $e ) && isset( $e['tarih'] ) && ! is_array( $e['tarih'] ) && ( null === $sec || ( ! empty( $sec['is_takdiri'] ) && empty( $e['is_takdiri'] ) ) ) ) {
						$sec = $e;
					}
				}
				if ( $sec ) {
					$ham[ $a ] = $sec['tarih'];
				}
			}
		}
		if ( ! $tar ) {   // tarih alanı yoksa öğle vaktinin yerel tarihi
			$o   = isset( $ham['ogle'] ) ? sides_fz_an( $ham['ogle'], '', $zone ) : null;
			$tar = $o ? $o->format( 'Y-m-d' ) : '';
			if ( ! $tar ) {
				return $hata( $no . 'tarih bulunamadı.' );
			}
		}
		if ( $tar < $alt || $tar > $ust ) {
			return $hata( $no . 'tarih (' . $tar . ') beklenen aralığın dışında.' );
		}
		$g   = array();
		$dk  = array();
		foreach ( $sira as $a ) {
			if ( ! isset( $ham[ $a ] ) || '' === $ham[ $a ] || null === $ham[ $a ] ) {
				if ( 'sabah' === $a ) {
					$g['sabah'] = '';
					continue;
				}
				return $hata( $no . $a . ' vakti eksik.' );
			}
			$d = sides_fz_an( $ham[ $a ], $tar, $zone );
			if ( ! $d ) {
				return $hata( $no . $a . ' vakti okunamadı.' );
			}
			if ( $d->format( 'Y-m-d' ) !== $tar ) {
				return $hata( $no . $a . ' vakti ' . $tar . ' gününe ait değil (saat dilimi tutarsız).' );
			}
			$g[ $a ]  = $d->format( 'H:i' );
			$dk[ $a ] = (int) $d->format( 'G' ) * 60 + (int) $d->format( 'i' );
		}
		$s = isset( $dk['sabah'] ) ? $dk['sabah'] : null;
		if ( ( null !== $s && ( $dk['imsak'] > $s || $s >= $dk['gunes'] ) ) || $dk['imsak'] >= $dk['gunes'] || $dk['gunes'] >= $dk['ogle'] || $dk['ogle'] >= $dk['ikindi'] || $dk['ikindi'] >= $dk['aksam'] || $dk['aksam'] >= $dk['yatsi'] ) {
			return $hata( $no . 'vakit sırası bozuk (' . $tar . ': ' . implode( ' ', array_filter( $g ) ) . ').' );
		}
		if ( $dk['ogle'] < 660 || $dk['ogle'] > 870 ) {
			return $hata( $no . 'öğle vakti (' . $g['ogle'] . ') yerel saatle olağan aralıkta değil; saat dilimi dönüşümü tutarsız.' );
		}
		if ( isset( $out[ $tar ] ) && $out[ $tar ] !== $g ) {
			return $hata( $no . $tar . ' günü yanıtta farklı değerlerle iki kez var.' );
		}
		$out[ $tar ] = $g;
	}
	ksort( $out );
	return array( 'gunler' => $out, 'ilceId' => (int) $ilce, 'sehirId' => null === $sehir ? null : (int) $sehir, 'tz' => $tz );
}

/* ------------------------------------------------------------------ *
 * Çekim
 * ------------------------------------------------------------------ */
function sides_fz_cek( $ayar ) {
	if ( '' === $ayar['url'] || ! sides_fz_url_gecerli( $ayar['url'] ) ) {
		return new WP_Error( 'sides_fazilet', 'Veri yolu (URL şablonu) girilmemiş ya da geçersiz.', array( 'status' => 400 ) );
	}
	$asil = str_replace( array( '{ilce}', '{sehir}' ), array( (string) (int) $ayar['ilceId'], (string) (int) $ayar['sehirId'] ), $ayar['url'] );
	$url  = (string) apply_filters( 'sides_fazilet_url', $asil, (int) $ayar['ilceId'] );
	$args = array(
		'timeout'             => 12,
		'redirection'         => 0,
		'limit_response_size' => SIDES_FZ_MAX_BAYT,
		'user-agent'          => 'ATLAS/' . ( defined( 'OPTIK_KARNE_VER' ) ? OPTIK_KARNE_VER : '' ) . '; ' . home_url( '/' ),
		'headers'             => array( 'Accept' => 'application/json' ),
	);
	$r = $url === $asil ? wp_safe_remote_get( $url, $args ) : wp_remote_get( $url, $args );
	if ( is_wp_error( $r ) ) {
		return new WP_Error( 'sides_fazilet', 'Bağlantı kurulamadı: ' . mb_substr( $r->get_error_message(), 0, 160 ), array( 'status' => 502 ) );
	}
	$kod = (int) wp_remote_retrieve_response_code( $r );
	if ( 200 !== $kod ) {
		return new WP_Error( 'sides_fazilet', 'Kaynak HTTP ' . $kod . ' döndürdü.', array( 'status' => 502 ) );
	}
	$govde = (string) wp_remote_retrieve_body( $r );
	$uz    = (int) wp_remote_retrieve_header( $r, 'content-length' );
	if ( strlen( $govde ) >= SIDES_FZ_MAX_BAYT || $uz > SIDES_FZ_MAX_BAYT ) {
		return new WP_Error( 'sides_fazilet', 'Yanıt çok büyük (en çok ' . (int) ( SIDES_FZ_MAX_BAYT / 1024 ) . ' KB).', array( 'status' => 502 ) );
	}
	$j = json_decode( $govde, true );
	if ( ! is_array( $j ) ) {
		return new WP_Error( 'sides_fazilet', 'Yanıt JSON değil.', array( 'status' => 502 ) );
	}
	$c = sides_fz_coz( $j, $ayar );
	if ( is_wp_error( $c ) ) {
		return $c;
	}
	$c['url'] = $url;
	return $c;
}
function sides_fz_yedi( $x ) {
	$o = array();
	foreach ( SIDES_TV_VAKIT_ALAN as $k ) {
		$o[ $k ] = function_exists( 'sides_tv_saat' ) ? sides_tv_saat( is_array( $x ) && isset( $x[ $k ] ) ? $x[ $k ] : '' ) : (string) ( is_array( $x ) && isset( $x[ $k ] ) ? $x[ $k ] : '' );
	}
	return $o;
}
/* Gün gün birleştirme; $zorla: elle girilmiş olsa da değiştirilecek tarihler (onaylı) */
function sides_fz_birlestir( $org, $gunler, $meta, $zorla = array() ) {
	$say   = array( 'yeni' => 0, 'guncel' => 0, 'ayni' => 0, 'korunan' => 0 );
	$cak   = array();
	$aylar = array();
	foreach ( $gunler as $t => $g ) {
		$aylar[ substr( $t, 0, 7 ) ][ $t ] = $g;
	}
	$simdi = time();
	foreach ( $aylar as $ay => $G ) {
		$kilit = function_exists( 'sides_takip_kilit' ) ? sides_takip_kilit( $org . '|tv|vakit_' . $ay ) : '';
		$doc   = sides_get_doc( $org, 'tv', 'vakit_' . $ay );
		$yeni  = ! is_array( $doc );
		$doc   = $yeni ? array( 'ay' => $ay, 'kaynak' => SIDES_FZ_KAYNAK, 'kaynakTip' => 'fazilet', 'veriTarihi' => '', 'gunler' => array() ) : $doc;
		unset( $doc['id'] );
		$oto = sides_get_doc( $org, 'fazilet', 'oto_' . $ay );
		$oto = is_array( $oto ) ? $oto : array();
		$oto = array( 'gunler' => isset( $oto['gunler'] ) && is_array( $oto['gunler'] ) ? $oto['gunler'] : array(), 't' => isset( $oto['t'] ) && is_array( $oto['t'] ) ? $oto['t'] : array() );
		$gl  = isset( $doc['gunler'] ) && is_array( $doc['gunler'] ) ? $doc['gunler'] : array();
		$deg = false;
		foreach ( $G as $t => $N ) {
			$N = sides_fz_yedi( $N );
			$C = isset( $gl[ $t ] ) ? sides_fz_yedi( $gl[ $t ] ) : null;
			$A = isset( $oto['gunler'][ $t ] ) ? sides_fz_yedi( $oto['gunler'][ $t ] ) : null;
			if ( null === $C || ! array_filter( $C ) ) {
				$gl[ $t ] = $N;
				$say['yeni']++;
				$deg = true;
			} elseif ( $C === $N ) {
				$say['ayni']++;
			} elseif ( ( null !== $A && $C === $A ) || in_array( $t, $zorla, true ) ) {
				$gl[ $t ] = $N;
				$say['guncel']++;
				$deg = true;
			} else {
				$say['korunan']++;
				$cak[ $t ] = array( 'elle' => $C, 'oto' => $N );
				continue;
			}
			$oto['gunler'][ $t ] = $N;
			$oto['t'][ $t ]      = $simdi;
		}
		if ( $deg ) {
			ksort( $gl );
			$doc['gunler']     = $gl;
			$doc['veriTarihi'] = sides_fz_bugun();
			$doc['otoKaynak']  = $meta;
			if ( empty( $doc['kaynak'] ) ) {
				$doc['kaynak'] = SIDES_FZ_KAYNAK;
			}
			if ( empty( $doc['kaynakTip'] ) ) {
				$doc['kaynakTip'] = 'fazilet';
			}
			sides_put_doc( $org, 'tv', 'vakit_' . $ay, $doc );
		}
		ksort( $oto['gunler'] );
		sides_put_doc( $org, 'fazilet', 'oto_' . $ay, $oto );
		if ( $kilit && function_exists( 'sides_takip_kilit_birak' ) ) {
			sides_takip_kilit_birak( $kilit );
		}
	}
	return array( $say, $cak );
}
/* Bir kurum için çek → doğrula → birleştir; durum belgesine yaz. $tetik: zamanli | tekrar | elle */
function sides_fz_calistir( $org, $tetik ) {
	$ayar  = sides_fz_ayar( $org );
	$durum = sides_fz_durum( $org );
	$simdi = time();
	$durum['sonDeneme'] = $simdi;
	$c = sides_fz_cek( $ayar );
	$u = wp_get_current_user();
	$kim = $u && $u->ID ? $u->display_name : 'Zamanlanmış görev';
	if ( is_wp_error( $c ) ) {
		$m = $c->get_error_message();
		$durum['sonHata'] = array( 't' => $simdi, 'mesaj' => mb_substr( $m, 0, 300 ), 'tetik' => $tetik, 'kim' => $kim );
		if ( 'elle' !== $tetik ) {
			$durum['deneme'] = ( 'zamanli' === $tetik ? 0 : (int) $durum['deneme'] ) + 1;   // her günlük çekim yeni bir deneme dizisi başlatır
			if ( $durum['deneme'] <= SIDES_FZ_TEKRAR && ! wp_next_scheduled( 'sides_fazilet_tekrar', array( (int) $org ) ) ) {
				wp_schedule_single_event( $simdi + HOUR_IN_SECONDS, 'sides_fazilet_tekrar', array( (int) $org ) );
			}
		}
		$durum['gecmis'] = array_slice( array_merge( array( array( 't' => $simdi, 'ok' => 0, 'm' => mb_substr( $m, 0, 160 ), 'tetik' => $tetik ) ), $durum['gecmis'] ), 0, 20 );
		sides_put_doc( $org, 'fazilet', 'durum', $durum );
		sides_log( $org, 'Fazilet vakit çekimi başarısız (' . $tetik . '): ' . mb_substr( $m, 0, 200 ) . ' — kayıtlı vakitler korundu', $kim );
		return $c;
	}
	$T    = array_keys( $c['gunler'] );
	$meta = array( 'saglayici' => 'Fazilet Takvimi', 'kaynak' => SIDES_FZ_KAYNAK, 'ilceId' => $c['ilceId'], 'sehirId' => $c['sehirId'], 'tz' => $c['tz'], 'fetchedAt' => $simdi, 'url' => mb_substr( $c['url'], 0, 300 ), 'aralik' => array( $T[0], end( $T ) ) );
	list( $say, $cak ) = sides_fz_birlestir( $org, $c['gunler'], $meta );
	foreach ( $T as $t ) {
		unset( $durum['cakisma'][ $t ] );
	}
	$alt = sides_fz_gun_ekle( sides_fz_bugun(), -7 );
	$durum['cakisma'] = array_filter( array_merge( $durum['cakisma'], $cak ), function ( $t ) use ( $alt ) {
		return $t >= $alt;
	}, ARRAY_FILTER_USE_KEY );
	ksort( $durum['cakisma'] );
	$durum['cakisma'] = array_slice( $durum['cakisma'], 0, 120, true );
	$durum['sonBasari'] = array_merge( $meta, $say, array( 't' => $simdi, 'gun' => count( $T ), 'tetik' => $tetik, 'kim' => $kim ) );
	$durum['deneme']    = 0;
	wp_clear_scheduled_hook( 'sides_fazilet_tekrar', array( (int) $org ) );
	$ozet = count( $T ) . ' gün (' . $T[0] . ' – ' . end( $T ) . '): ' . $say['yeni'] . ' yeni, ' . $say['guncel'] . ' güncellendi, ' . $say['ayni'] . ' aynı' . ( $say['korunan'] ? ', ' . $say['korunan'] . ' elle girilmiş gün korundu' : '' );
	$durum['gecmis'] = array_slice( array_merge( array( array( 't' => $simdi, 'ok' => 1, 'm' => $ozet, 'tetik' => $tetik ) ), $durum['gecmis'] ), 0, 20 );
	sides_put_doc( $org, 'fazilet', 'durum', $durum );
	sides_log( $org, 'Fazilet vakitleri çekildi (' . $tetik . '): ' . $ozet, $kim );
	return array_merge( $say, array( 'ok' => true, 'gun' => count( $T ), 'aralik' => $meta['aralik'], 'cakisma' => count( $cak ) ) );
}

/* ------------------------------------------------------------------ *
 * REST
 * ------------------------------------------------------------------ */
function sides_fz_durum_disari( $org ) {
	$ayar  = sides_fz_ayar( $org );
	$durum = sides_fz_durum( $org );
	$bu    = substr( sides_fz_bugun(), 0, 7 );
	$sonra = ( new DateTime( $bu . '-15', new DateTimeZone( SIDES_FZ_TZ ) ) )->modify( 'first day of next month' )->format( 'Y-m' );
	$oto   = array();
	foreach ( array( $bu, $sonra ) as $ay ) {
		$o           = sides_get_doc( $org, 'fazilet', 'oto_' . $ay );
		$v           = sides_get_doc( $org, 'tv', 'vakit_' . $ay );
		$gl          = is_array( $v ) && isset( $v['gunler'] ) && is_array( $v['gunler'] ) ? $v['gunler'] : array();
		$n           = 0;
		$elle        = 0;
		foreach ( $gl as $t => $x ) {
			$C = sides_fz_yedi( $x );
			if ( ! array_filter( $C ) ) {
				continue;
			}
			if ( is_array( $o ) && isset( $o['gunler'][ $t ] ) && sides_fz_yedi( $o['gunler'][ $t ] ) === $C ) {
				$n++;
			} else {
				$elle++;
			}
		}
		$oto[ $ay ] = array( 'oto' => $n, 'elle' => $elle, 'gun' => (int) ( new DateTime( $ay . '-01' ) )->format( 't' ) );
	}
	$c = array();
	foreach ( $durum['cakisma'] as $t => $x ) {
		$c[] = array( 't' => $t, 'elle' => $x['elle'], 'oto' => $x['oto'] );
	}
	$yon = 'yonetici' === sides_ctx()['rol'] && ! sides_is_observer();
	return array(
		'ayar'      => array( 'otomatik' => $ayar['otomatik'], 'ilceId' => $ayar['ilceId'], 'sehirId' => $ayar['sehirId'], 'url' => $ayar['url'], 'tz' => $ayar['tz'], 'degistiren' => sides_is_observer() ? '' : $ayar['degistiren'], 'degisti' => $ayar['degisti'] ),
		'sonBasari' => $durum['sonBasari'],
		'sonHata'   => $durum['sonHata'],
		'sonDeneme' => (int) $durum['sonDeneme'],
		'deneme'    => (int) $durum['deneme'],
		'tekrarMax' => SIDES_FZ_TEKRAR,
		'cakisma'   => $c,
		'gecmis'    => array_slice( $durum['gecmis'], 0, 10 ),
		'aylar'     => $oto,
		'sonraki'   => (int) wp_next_scheduled( 'sides_fazilet_gunluk' ),
		'tekrar'    => (int) wp_next_scheduled( 'sides_fazilet_tekrar', array( (int) $org ) ),
		'yetki'     => array( 'ayar' => $yon, 'cek' => ! sides_is_observer() && ( $yon || ( sides_can( 'puan', 2 ) && $ayar['otomatik'] ) ), 'degistir' => ! sides_is_observer() && sides_can( 'puan', 2 ) ),
	);
}
function sides_fz_durum_oku() {
	$r = rest_ensure_response( sides_fz_durum_disari( sides_org_id() ) );
	$r->header( 'Cache-Control', 'no-store' );
	return $r;
}
function sides_fz_ayar_yaz( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	$p   = is_array( $p ) ? $p : array();
	$a   = sides_fz_ayar( $org );
	$ilce  = isset( $p['ilceId'] ) ? $p['ilceId'] : $a['ilceId'];
	$sehir = isset( $p['sehirId'] ) ? $p['sehirId'] : $a['sehirId'];
	$url   = isset( $p['url'] ) ? trim( (string) $p['url'] ) : $a['url'];
	if ( '' === $url ) {
		$url = SIDES_FZ_URL;   // v7.0.3: boş bırakılırsa bilinen veri yolu
	}
	$oto   = isset( $p['otomatik'] ) ? ( $p['otomatik'] ? 1 : 0 ) : $a['otomatik'];
	if ( ! is_numeric( $ilce ) || (int) $ilce != $ilce || (int) $ilce < 1 || (int) $ilce > 999999 ) { // phpcs:ignore
		return new WP_Error( 'sides_gecersiz', 'İlçe kimliği pozitif bir tam sayı olmalı (Fatih: 1508).', array( 'status' => 400 ) );
	}
	if ( ! is_numeric( $sehir ) || (int) $sehir != $sehir || (int) $sehir < 0 || (int) $sehir > 999999 ) { // phpcs:ignore
		return new WP_Error( 'sides_gecersiz', 'Şehir kimliği 0 ya da pozitif bir tam sayı olmalı (İstanbul: 31).', array( 'status' => 400 ) );
	}
	if ( ! sides_fz_url_gecerli( $url ) ) {
		return new WP_Error( 'sides_gecersiz', 'Veri yolu https://…fazilettakvimi.com/… biçiminde olmalı ve {ilce} yer tutucusunu içermeli.', array( 'status' => 400 ) );
	}
	if ( $oto && '' === $url ) {
		return new WP_Error( 'sides_gecersiz', 'Otomatik çekimi açmak için önce veri yolunu girin.', array( 'status' => 400 ) );
	}
	$u = wp_get_current_user();
	$d = array( 'otomatik' => $oto, 'ilceId' => (int) $ilce, 'sehirId' => (int) $sehir, 'url' => $url, 'tz' => SIDES_FZ_TZ, 'degistiren' => $u ? $u->display_name : '', 'degisti' => time() );
	if ( false === sides_put_doc( $org, 'fazilet', 'ayar', $d ) ) {
		return new WP_Error( 'sides_db', 'Kaydedilemedi.', array( 'status' => 500 ) );
	}
	$deg = array();
	if ( $oto !== $a['otomatik'] ) {
		$deg[] = 'otomatik çekim ' . ( $oto ? 'açıldı' : 'kapatıldı' );
	}
	if ( (int) $ilce !== $a['ilceId'] || (int) $sehir !== $a['sehirId'] ) {
		$deg[] = 'konum ilçe ' . (int) $ilce . ' / şehir ' . (int) $sehir;
	}
	if ( $url !== $a['url'] ) {
		$deg[] = 'veri yolu değişti';
	}
	if ( ! $oto ) {
		wp_clear_scheduled_hook( 'sides_fazilet_tekrar', array( (int) $org ) );
	}
	sides_log( $org, 'Fazilet otomatik çekim ayarı: ' . ( $deg ? implode( ', ', $deg ) : 'değişiklik yok' ) );
	return sides_fz_durum_disari( $org );
}
function sides_fz_simdi() {
	$org = sides_org_id();
	$a   = sides_fz_ayar( $org );
	if ( 'yonetici' !== sides_ctx()['rol'] && ! $a['otomatik'] ) {
		return new WP_Error( 'sides_yetki', 'Otomatik çekim kapalı; yönetici açtığında vakitleri buradan çekebilirsiniz.', array( 'status' => 403 ) );
	}
	if ( ! sides_rl( 'fazilet_cek|' . $org, 10, 600 ) ) {
		return new WP_Error( 'sides_rl', 'Çok sık denendi; birkaç dakika sonra tekrar deneyin.', array( 'status' => 429 ) );
	}
	$r = sides_fz_calistir( $org, 'elle' );
	$d = sides_fz_durum_disari( $org );
	if ( is_wp_error( $r ) ) {
		return new WP_Error( 'sides_fazilet', 'Vakitler çekilemedi: ' . $r->get_error_message() . ' Kayıtlı vakitler korundu.', array( 'status' => 502, 'durum' => $d ) );
	}
	return array( 'sonuc' => $r, 'durum' => $d );
}
function sides_fz_degistir( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	$L   = isset( $p['tarihler'] ) && is_array( $p['tarihler'] ) ? array_values( array_unique( array_map( 'strval', $p['tarihler'] ) ) ) : array();
	if ( ! $L || count( $L ) > 400 ) {
		return new WP_Error( 'sides_gecersiz', 'Değiştirilecek gün seçilmedi.', array( 'status' => 400 ) );
	}
	$durum  = sides_fz_durum( $org );
	$gunler = array();
	foreach ( $L as $t ) {
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $t ) || ! isset( $durum['cakisma'][ $t ]['oto'] ) ) {
			return new WP_Error( 'sides_gecersiz', $t . ' için bekleyen otomatik veri yok; sayfayı yenileyin.', array( 'status' => 400 ) );
		}
		$gunler[ $t ] = sides_fz_yedi( $durum['cakisma'][ $t ]['oto'] );
	}
	ksort( $gunler );
	$T    = array_keys( $gunler );
	$meta = is_array( $durum['sonBasari'] ) ? array_intersect_key( $durum['sonBasari'], array_flip( array( 'saglayici', 'kaynak', 'ilceId', 'sehirId', 'tz', 'fetchedAt', 'url', 'aralik' ) ) ) : array( 'saglayici' => 'Fazilet Takvimi', 'kaynak' => SIDES_FZ_KAYNAK );
	list( $say ) = sides_fz_birlestir( $org, $gunler, $meta, $T );
	$durum = sides_fz_durum( $org );   // birleştirme sırasında değişmiş olabilir
	foreach ( $T as $t ) {
		unset( $durum['cakisma'][ $t ] );
	}
	sides_put_doc( $org, 'fazilet', 'durum', $durum );
	sides_log( $org, 'Elle girilmiş ' . count( $T ) . ' günün namaz vakitleri otomatik (Fazilet) veriyle değiştirildi: ' . implode( ', ', array_slice( $T, 0, 10 ) ) . ( count( $T ) > 10 ? '…' : '' ) );
	return array( 'sonuc' => $say, 'durum' => sides_fz_durum_disari( $org ) );
}
