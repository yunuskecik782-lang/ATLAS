<?php
/**
 * ATLAS v7.8 — ÖDS kayıt formu (form düzenleyici) ve ÖDS aday listesi.
 *
 * Herkese açık bağlantı (/ods/, /?ods=1, /?ods=<kurum anahtarı>) tanıtım sitesi yerine bu formu gösterir (sides_ods_sayfa).
 *   Sunucuda basılır; uygulama paketi yüklenmez. Gönderim küçük bir satır içi betikle POST ods/basvuru ucuna gider.
 * Veri (sides_docs):
 *   ods/form      form tanımı (başlık, açıklama, açık/kapalı, son kayıt zamanı, kontenjan, alanlar)
 *   ods/kvkk      kayıtlarda onaylanan KVKK metinlerinin geçmişi (özet → metin)
 *   odskayit/<k…> başvurular: c (alan → değer), o (seçim alanı → seçenek kimliği), t (gönderim, ms), kvkk { t, h }
 *   ods/ayar      eski tanıtım sitesi ayarları — saklanır ama gösterilmez; logo, renk ve kök yönlendirme hâlâ buradan okunur.
 * Başvurular CRM adaylarına kendiliğinden yazılmaz; listeden "Adaylara aktar" ile (satır ya da toplu) aktarılır.
 * REST (optik-karne/v1):
 *   GET  ods/form            tanım + durum + adresler (kayit ≥ 1; kayit.ods ya da kayit.odsliste sayfası ≥ 1)
 *   POST ods/form            kaydet (kayit ≥ 2, gözlemci değil, kayit.ods ≥ 2); sürüm çakışması 409
 *   POST ods/onizleme        kaydedilmemiş tanımın herkese açık sayfa HTML'i (önizleme; gönderim yapmaz)
 *   POST ods/basvuru         herkese açık gönderim: bal küpü, doldurma süresi, IP başına sınır, tanıma göre doğrulama, kontenjan
 *   GET  ods/kayitlar        liste (kayit ≥ 1, kayit.odsliste ≥ 1; gözlemciye maskeli)
 *   POST ods/kayit/<id>      düzenle; DELETE ods/kayit/<id> sil (kayit ≥ 2, gözlemci değil, kayit.odsliste ≥ 2)
 *   POST ods/disa            dışa aktarım verisi (aynı yetki; günlüğe yazılır)
 *   POST ods/aktar           seçili kayıtları CRM adaylarına aktar (ayrıca crm ≥ 2); tekrar aktarım yeni aday açmaz
 *
 * @package SIDES
 */

defined( 'ABSPATH' ) || exit;

/* ------------------------------------------------------------------ *
 * Tanım
 * ------------------------------------------------------------------ */
function sides_odsf_tipler() {
	return array( 'kisa', 'uzun', 'liste', 'tek', 'coklu', 'telefon', 'tarih', 'bolum', 'kvkk' );
}
/* Temel alanlar: kimlik = sabit anahtar. kilit: silinemez ve her zaman zorunlu. */
function sides_odsf_sabitler() {
	return array(
		'ogrenciAd' => array( 'ad' => 'Öğrencinin adı soyadı', 'tip' => array( 'kisa' ), 'kilit' => true ),
		'sinif'     => array( 'ad' => 'Sınıfı', 'tip' => array( 'liste', 'tek' ), 'kilit' => false ),
		'oturum'    => array( 'ad' => 'Sınav tarihi / oturum', 'tip' => array( 'tek', 'liste' ), 'kilit' => false ),
		'okul'      => array( 'ad' => 'Okulu', 'tip' => array( 'liste', 'tek' ), 'kilit' => false ),
		'veliAd'    => array( 'ad' => 'Veli adı soyadı', 'tip' => array( 'kisa' ), 'kilit' => false ),
		'veliTel'   => array( 'ad' => 'Veli iletişim numarası', 'tip' => array( 'telefon' ), 'kilit' => true ),
		'kvkk'      => array( 'ad' => 'KVKK onayı', 'tip' => array( 'kvkk' ), 'kilit' => true ),
	);
}
function sides_odsf_kvkk_metin() {
	return 'Bu formda verdiğiniz öğrenci ve veli bilgileri (ad soyad, sınıf, okul, telefon), kurumumuz tarafından yalnızca Ödüllü Deneme Sınavı kaydının alınması, oturumların planlanması, sınav sonuçlarının ve sınavla ilgili bilgilendirmelerin size iletilmesi amacıyla 6698 sayılı Kişisel Verilerin Korunması Kanunu’na uygun olarak işlenir. Bilgileriniz bu amaç dışında kullanılmaz ve üçüncü kişilerle paylaşılmaz. Kanun’un 11. maddesindeki haklarınız için kurumumuza başvurabilirsiniz.';
}
function sides_odsf_kvkk_onay() {
	return 'Aydınlatma metnini okudum; bilgilerimin bu amaçla işlenmesine ve sınavla ilgili tarafıma ulaşılmasına açık rıza veriyorum.';
}
function sides_odsf_varsayilan() {
	$sinif = array();
	foreach ( array( 3, 4, 5, 6, 7 ) as $s ) {
		$sinif[] = array( 'id' => 's' . $s, 'ad' => $s . '. Sınıf', 'kontenjan' => 0 );
	}
	return array(
		'surum'     => 0,
		'baslik'    => 'Ödüllü Deneme Sınavı Kayıt Formu',
		'aciklama'  => 'Ödüllü Deneme Sınavı’na kayıt için formu doldurun. Kaydınız alındığında sınav günüyle ilgili bilgilendirme veli telefonuna iletilir.',
		'acik'      => false,
		'kapanis'   => '',
		'kontenjan' => 0,
		'basari'    => 'Teşekkür ederiz. Sınav günü ve saatinde sizi bekliyoruz.',
		'alanlar'   => array(
			array( 'id' => 'ogrenciAd', 'sabit' => 'ogrenciAd', 'tip' => 'kisa', 'etiket' => 'Öğrencinin adı soyadı', 'aciklama' => '', 'zorunlu' => true, 'max' => 80 ),
			array( 'id' => 'sinif', 'sabit' => 'sinif', 'tip' => 'liste', 'etiket' => 'Sınıfı', 'aciklama' => '', 'zorunlu' => true, 'secenekler' => $sinif, 'diger' => false ),
			array( 'id' => 'oturum', 'sabit' => 'oturum', 'tip' => 'tek', 'etiket' => 'Sınav tarihi / oturum', 'aciklama' => '', 'zorunlu' => true, 'diger' => false, 'secenekler' => array(
				array( 'id' => 'o1', 'ad' => '23 Ekim 2026 Cuma, 10:00 (1. Oturum)', 'kontenjan' => 0 ),
				array( 'id' => 'o2', 'ad' => '24 Ekim 2026 Cumartesi, 16:00 (2. Oturum)', 'kontenjan' => 0 ),
			) ),
			array( 'id' => 'okul', 'sabit' => 'okul', 'tip' => 'liste', 'etiket' => 'Okulu', 'aciklama' => '', 'zorunlu' => true, 'secenekler' => array(), 'diger' => true ),
			array( 'id' => 'veliAd', 'sabit' => 'veliAd', 'tip' => 'kisa', 'etiket' => 'Veli adı soyadı', 'aciklama' => '', 'zorunlu' => true, 'max' => 80 ),
			array( 'id' => 'veliTel', 'sabit' => 'veliTel', 'tip' => 'telefon', 'etiket' => 'Veli iletişim numarası', 'aciklama' => 'Cep telefonu: 05XX XXX XX XX', 'zorunlu' => true ),
			array( 'id' => 'kvkk', 'sabit' => 'kvkk', 'tip' => 'kvkk', 'etiket' => 'Kişisel verilerin korunması (KVKK)', 'aciklama' => sides_odsf_kvkk_metin(), 'onay' => sides_odsf_kvkk_onay(), 'zorunlu' => true ),
		),
		'silinen'   => array(),
	);
}
function sides_odsf_form( $org ) {
	$d = sides_get_doc( (int) $org, 'ods', 'form' );
	if ( ! is_array( $d ) || empty( $d['alanlar'] ) || ! is_array( $d['alanlar'] ) ) {
		return sides_odsf_varsayilan();
	}
	unset( $d['id'] );
	return array_merge( sides_odsf_varsayilan(), $d );
}
function sides_odsf_simdi() {
	return new DateTime( 'now', new DateTimeZone( 'Europe/Istanbul' ) );
}
function sides_odsf_ms() {
	return (int) round( microtime( true ) * 1000 );
}
/* Seçim türü mü */
function sides_odsf_secimli( $tip ) {
	return in_array( $tip, array( 'liste', 'tek', 'coklu' ), true );
}

/* Gönderilen tanımı temizler. $gevsek (önizleme): boş metinler yer tutucuyla doldurulur, hata yerine düzeltilir. */
function sides_odsf_temizle( $p, $gevsek = false ) {
	$hata = function ( $m ) {
		return new WP_Error( 'sides_gecersiz', $m, array( 'status' => 400 ) );
	};
	if ( ! is_array( $p ) ) {
		return $hata( 'Geçersiz form verisi.' );
	}
	$tx = function ( $x, $len, $cok = false ) {
		$s = is_scalar( $x ) ? (string) $x : '';
		$s = $cok ? sanitize_textarea_field( $s ) : sanitize_text_field( $s );
		return mb_substr( trim( $s ), 0, $len );
	};
	$g   = function ( $a, $k ) {
		return is_array( $a ) && isset( $a[ $k ] ) ? $a[ $k ] : '';
	};
	$v   = sides_odsf_varsayilan();
	$out = array();
	$out['baslik'] = $tx( $g( $p, 'baslik' ), 120 );
	if ( '' === $out['baslik'] ) {
		if ( ! $gevsek ) {
			return $hata( 'Form başlığını yazın.' );
		}
		$out['baslik'] = $v['baslik'];
	}
	$out['aciklama']  = $tx( $g( $p, 'aciklama' ), 1500, true );
	$out['basari']    = $tx( $g( $p, 'basari' ), 500, true );
	$out['acik']      = ! empty( $p['acik'] );
	$out['kontenjan'] = max( 0, min( 100000, (int) $g( $p, 'kontenjan' ) ) );
	$kp               = trim( (string) ( is_scalar( $g( $p, 'kapanis' ) ) ? $g( $p, 'kapanis' ) : '' ) );
	if ( '' !== $kp ) {
		if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})T([01]\d|2[0-3]):([0-5]\d)$/', $kp, $m ) || ! checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ) {
			if ( ! $gevsek ) {
				return $hata( 'Son kayıt zamanı geçersiz (gün, ay, yıl ve saat girin).' );
			}
			$kp = '';
		}
	}
	$out['kapanis'] = $kp;
	$tipler = sides_odsf_tipler();
	$sabit  = sides_odsf_sabitler();
	$al     = isset( $p['alanlar'] ) && is_array( $p['alanlar'] ) ? array_values( $p['alanlar'] ) : array();
	if ( count( $al ) > 60 ) {
		return $hata( 'En fazla 60 alan eklenebilir.' );
	}
	$out['alanlar'] = array();
	$gor            = array();
	foreach ( $al as $i => $a ) {
		$no = ( $i + 1 ) . '. alan';
		if ( ! is_array( $a ) ) {
			return $hata( $no . ' geçersiz.' );
		}
		$id = is_scalar( $g( $a, 'id' ) ) ? (string) $g( $a, 'id' ) : '';
		if ( ! preg_match( '/^[A-Za-z][A-Za-z0-9_]{1,23}$/', $id ) || isset( $gor[ $id ] ) ) {
			if ( ! $gevsek ) {
				return $hata( $no . ': kimlik geçersiz ya da yinelenmiş.' );
			}
			$id = 'f' . substr( md5( $i . '|' . wp_rand() ), 0, 10 );
		}
		$gor[ $id ] = 1;
		$tip        = is_scalar( $g( $a, 'tip' ) ) ? (string) $g( $a, 'tip' ) : '';
		if ( ! in_array( $tip, $tipler, true ) ) {
			return $hata( $no . ': alan türü geçersiz.' );
		}
		$sb = isset( $sabit[ $id ] ) ? $sabit[ $id ] : null;
		if ( $sb && ! in_array( $tip, $sb['tip'], true ) ) {
			$tip = $sb['tip'][0];   // temel alanların türü sınırlı
		}
		if ( ! $sb && 'kvkk' === $tip ) {
			return $hata( $no . ': KVKK onayı formda yalnızca bir kez, temel alan olarak bulunur.' );
		}
		$x  = array( 'id' => $id, 'tip' => $tip );
		$et = $tx( $g( $a, 'etiket' ), 200 );
		if ( '' === $et ) {
			if ( ! $gevsek ) {
				return $hata( $no . ': ' . ( 'bolum' === $tip ? 'bölüm başlığı' : 'soru metni' ) . ' boş.' );
			}
			$et = 'bolum' === $tip ? 'Başlıksız bölüm' : 'Başlıksız soru';
		}
		$x['etiket']   = $et;
		$x['aciklama'] = $tx( $g( $a, 'aciklama' ), 'kvkk' === $tip ? 3000 : 1000, true );
		$x['zorunlu']  = 'bolum' === $tip ? false : ( ( $sb && $sb['kilit'] ) ? true : ! empty( $a['zorunlu'] ) );
		if ( $sb ) {
			$x['sabit'] = $id;
		}
		if ( 'kisa' === $tip || 'uzun' === $tip ) {
			$mx       = (int) $g( $a, 'max' );
			$lim      = 'kisa' === $tip ? 500 : 3000;
			$x['max'] = $mx >= 1 && $mx <= $lim ? $mx : ( 'kisa' === $tip ? 150 : 1000 );
		}
		if ( 'kvkk' === $tip ) {
			$x['onay'] = $tx( $g( $a, 'onay' ), 300 );
			if ( '' === $x['onay'] ) {
				$x['onay'] = sides_odsf_kvkk_onay();
			}
			if ( '' === $x['aciklama'] ) {
				if ( ! $gevsek ) {
					return $hata( 'KVKK aydınlatma metni boş olamaz.' );
				}
				$x['aciklama'] = sides_odsf_kvkk_metin();
			}
		}
		if ( sides_odsf_secimli( $tip ) ) {
			$ss = isset( $a['secenekler'] ) && is_array( $a['secenekler'] ) ? array_values( $a['secenekler'] ) : array();
			if ( count( $ss ) > 300 ) {
				return $hata( $no . ': en fazla 300 seçenek eklenebilir.' );
			}
			$x['secenekler'] = array();
			$sg              = array();
			$adlar           = array();
			foreach ( $ss as $j => $s ) {
				if ( ! is_array( $s ) ) {
					return $hata( $no . ': seçenek geçersiz.' );
				}
				$sid = is_scalar( $g( $s, 'id' ) ) ? (string) $g( $s, 'id' ) : '';
				if ( ! preg_match( '/^[A-Za-z0-9][A-Za-z0-9_]{0,23}$/', $sid ) || isset( $sg[ $sid ] ) || '_diger' === $sid ) {
					if ( ! $gevsek ) {
						return $hata( $no . ': ' . ( $j + 1 ) . '. seçeneğin kimliği geçersiz.' );
					}
					$sid = 'x' . substr( md5( $i . '|' . $j . '|' . wp_rand() ), 0, 10 );
				}
				$ad = $tx( $g( $s, 'ad' ), 150 );
				if ( '' === $ad ) {
					if ( ! $gevsek ) {
						return $hata( $no . ' (' . $et . '): ' . ( $j + 1 ) . '. seçenek boş.' );
					}
					$ad = 'Seçenek ' . ( $j + 1 );
				}
				$ak = mb_strtolower( $ad, 'UTF-8' );
				if ( isset( $adlar[ $ak ] ) && ! $gevsek ) {
					return $hata( $no . ' (' . $et . '): “' . $ad . '” seçeneği iki kez yazılmış.' );
				}
				$adlar[ $ak ]      = 1;
				$sg[ $sid ]        = 1;
				$x['secenekler'][] = array( 'id' => $sid, 'ad' => $ad, 'kontenjan' => 'coklu' === $tip ? 0 : max( 0, min( 100000, (int) $g( $s, 'kontenjan' ) ) ) );
			}
			$x['diger'] = 'coklu' !== $tip && ! empty( $a['diger'] );
			if ( ! $x['secenekler'] && ! $x['diger'] ) {
				if ( ! $gevsek ) {
					return $hata( $no . ' (' . $et . '): en az bir seçenek ekleyin.' );
				}
				$x['secenekler'][] = array( 'id' => 'x1', 'ad' => 'Seçenek 1', 'kontenjan' => 0 );
			}
		}
		$out['alanlar'][] = $x;
	}
	if ( ! $gevsek ) {
		foreach ( $sabit as $sid => $sb ) {
			if ( $sb['kilit'] && ! isset( $gor[ $sid ] ) ) {
				return $hata( '“' . $sb['ad'] . '” alanı silinemez (tekrar kaydı denetimi ve KVKK onayı için gerekir).' );
			}
		}
	}
	return $out;
}

/* ------------------------------------------------------------------ *
 * Sayım, durum, telefon
 * ------------------------------------------------------------------ */
function sides_odsf_satirlar( $org ) {
	global $wpdb;
	$t = sides_docs();
	return $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = 'odskayit' ORDER BY id", (int) $org ) ); // phpcs:ignore
}
function sides_odsf_say( $org, $haric = '' ) {
	$n = 0;
	$s = array();
	foreach ( sides_odsf_satirlar( $org ) as $r ) {
		if ( (string) $r->id === (string) $haric ) {
			continue;
		}
		$d = json_decode( $r->data, true );
		if ( ! is_array( $d ) ) {
			continue;
		}
		$n++;
		foreach ( ( isset( $d['o'] ) && is_array( $d['o'] ) ? $d['o'] : array() ) as $fid => $ov ) {
			foreach ( (array) $ov as $oid ) {
				$oid = (string) $oid;
				if ( ! isset( $s[ $fid ] ) ) {
					$s[ $fid ] = array();
				}
				$s[ $fid ][ $oid ] = ( isset( $s[ $fid ][ $oid ] ) ? $s[ $fid ][ $oid ] : 0 ) + 1;
			}
		}
	}
	return array( 'toplam' => $n, 'secenek' => $s );
}
function sides_odsf_durum( $f, $say ) {
	$simdi   = sides_odsf_simdi()->format( 'Y-m-d\TH:i' );
	$kapandi = '' !== (string) $f['kapanis'] && $simdi >= $f['kapanis'];
	$dolu    = (int) $f['kontenjan'] > 0 && $say['toplam'] >= (int) $f['kontenjan'];
	return array(
		'acik'     => ! empty( $f['acik'] ) && ! $kapandi && ! $dolu,
		'yayinda'  => ! empty( $f['acik'] ),
		'kapandi'  => $kapandi,
		'dolu'     => $dolu,
		'toplam'   => $say['toplam'],
		'secenek'  => $say['secenek'],
	);
}
/* Türkiye cep telefonu: +90 / 90 / 0 öneki kabul edilir → "05XX XXX XX XX"; geçersizse '' */
function sides_odsf_tel( $s ) {
	$d = preg_replace( '/\D/', '', (string) $s );
	if ( 12 === strlen( $d ) && '90' === substr( $d, 0, 2 ) ) {
		$d = substr( $d, 2 );
	} elseif ( 11 === strlen( $d ) && '0' === $d[0] ) {
		$d = substr( $d, 1 );
	}
	if ( ! preg_match( '/^5\d{9}$/', $d ) ) {
		return '';
	}
	return '0' . substr( $d, 0, 3 ) . ' ' . substr( $d, 3, 3 ) . ' ' . substr( $d, 6, 2 ) . ' ' . substr( $d, 8, 2 );
}
function sides_odsf_imza( $org, $ts ) {
	return substr( hash_hmac( 'sha256', 'odsf|' . (int) $org . '|' . (int) $ts, wp_salt( 'nonce' ) ), 0, 24 );
}
function sides_odsf_tekrar_anahtar( $d ) {
	$c   = isset( $d['c'] ) && is_array( $d['c'] ) ? $d['c'] : array();
	$ad  = isset( $c['ogrenciAd'] ) && is_string( $c['ogrenciAd'] ) ? sides_odsf_ad_anahtar( $c['ogrenciAd'] ) : '';
	$tel = isset( $c['veliTel'] ) && is_string( $c['veliTel'] ) ? substr( preg_replace( '/\D/', '', $c['veliTel'] ), -10 ) : '';
	return '' !== $ad && '' !== $tel ? $ad . '|' . $tel : '';
}
/* Ad karşılaştırma anahtarı (tekrar kaydı ve aday eşleştirme) */
function sides_odsf_ad_anahtar( $s ) {
	$s = mb_strtolower( str_replace( array( 'I', 'İ' ), array( 'ı', 'i' ), trim( (string) $s ) ), 'UTF-8' );
	return preg_replace( '/\s+/u', ' ', $s );
}

/* ------------------------------------------------------------------ *
 * Başvuru doğrulama — herkese açık gönderim ve yönetici düzenlemesi aynı kuralları kullanır.
 * $c: alan → değer (seçimlerde seçenek kimliği, çoktan seçmelide kimlik dizisi, "Diğer" için "_diger")
 * $dg: alan → "Diğer" metni. $yon: yönetici düzenlemesi (kontenjan ve KVKK denetlenmez; yalnız kilitli alanlar zorunlu)
 * Döner: array( 'c' => …, 'o' => … ) ya da alan hatalarıyla WP_Error (data.alanlar)
 * ------------------------------------------------------------------ */
function sides_odsf_dogrula( $f, $c, $dg, $yon = false, $say = null ) {
	$c   = is_array( $c ) ? $c : array();
	$dg  = is_array( $dg ) ? $dg : array();
	$err = array();
	$oc  = array();
	$oo  = array();
	foreach ( $f['alanlar'] as $a ) {
		$id  = $a['id'];
		$tip = $a['tip'];
		if ( 'bolum' === $tip ) {
			continue;
		}
		$zor = ! empty( $a['zorunlu'] ) && ( ! $yon || ! empty( $a['sabit'] ) && in_array( $a['sabit'], array( 'ogrenciAd', 'veliTel' ), true ) );
		$v   = isset( $c[ $id ] ) ? $c[ $id ] : '';
		if ( 'kvkk' === $tip ) {
			if ( ! $yon && ! ( true === $v || 1 === $v || '1' === $v || 'evet' === $v ) ) {
				$err[ $id ] = 'Devam etmek için onay kutusunu işaretleyin.';
			}
			continue;
		}
		if ( 'coklu' === $tip ) {
			$ids = is_array( $v ) ? array_values( array_unique( array_map( 'strval', array_filter( $v, 'is_scalar' ) ) ) ) : ( '' === $v ? array() : null );
			if ( null === $ids || count( $ids ) > count( $a['secenekler'] ) ) {
				$err[ $id ] = 'Geçersiz seçim.';
				continue;
			}
			$L = array();
			$I = array();
			foreach ( $ids as $sid ) {
				$bul = null;
				foreach ( $a['secenekler'] as $s ) {
					if ( $s['id'] === $sid ) {
						$bul = $s;
					}
				}
				if ( ! $bul ) {
					$err[ $id ] = 'Geçersiz seçim.';
					continue 2;
				}
				$L[] = $bul['ad'];
				$I[] = $bul['id'];
			}
			if ( $zor && ! $L ) {
				$err[ $id ] = 'En az bir seçenek işaretleyin.';
				continue;
			}
			if ( $L ) {
				$oc[ $id ] = $L;
				$oo[ $id ] = $I;
			}
			continue;
		}
		if ( ! is_scalar( $v ) ) {
			$err[ $id ] = 'Geçersiz değer.';
			continue;
		}
		$v = (string) $v;
		if ( 'liste' === $tip || 'tek' === $tip ) {
			$serbest = ! $a['secenekler'] && ! empty( $a['diger'] );   // seçeneksiz "Diğer": düz metin kutusu
			if ( $serbest && '' !== trim( $v ) && '_diger' !== $v ) {
				$dg[ $id ] = $v;
				$v         = '_diger';
			}
			if ( '' === $v || ( $serbest && '_diger' === $v && '' === trim( (string) ( isset( $dg[ $id ] ) && is_scalar( $dg[ $id ] ) ? $dg[ $id ] : '' ) ) ) ) {
				if ( $zor ) {
					$err[ $id ] = $serbest ? ( 'okul' === $id ? 'Okulun adını yazın.' : 'Bu alanı doldurun.' ) : 'Bir seçenek seçin.';
				}
				continue;
			}
			if ( '_diger' === $v ) {
				if ( empty( $a['diger'] ) ) {
					$err[ $id ] = 'Geçersiz seçim.';
					continue;
				}
				$t = isset( $dg[ $id ] ) && is_scalar( $dg[ $id ] ) ? preg_replace( '/\s+/u', ' ', trim( sanitize_text_field( (string) $dg[ $id ] ) ) ) : '';
				if ( '' === $t ) {
					$err[ $id ] = 'okul' === $id ? 'Okulun adını yazın.' : 'Lütfen yazın.';
					continue;
				}
				if ( mb_strlen( $t ) > 150 ) {
					$err[ $id ] = 'En fazla 150 karakter yazabilirsiniz.';
					continue;
				}
				$oc[ $id ] = $t;
				$oo[ $id ] = '_diger';
				continue;
			}
			$bul = null;
			foreach ( $a['secenekler'] as $s ) {
				if ( $s['id'] === $v ) {
					$bul = $s;
				}
			}
			if ( ! $bul ) {
				$err[ $id ] = 'Geçersiz seçim.';
				continue;
			}
			if ( ! $yon && $say && (int) $bul['kontenjan'] > 0 ) {
				$n = isset( $say['secenek'][ $id ][ $bul['id'] ] ) ? (int) $say['secenek'][ $id ][ $bul['id'] ] : 0;
				if ( $n >= (int) $bul['kontenjan'] ) {
					$err[ $id ] = 'Bu seçeneğin kontenjanı doldu; başka bir seçenek seçin.';
					continue;
				}
			}
			$oc[ $id ] = $bul['ad'];
			$oo[ $id ] = $bul['id'];
			continue;
		}
		if ( 'telefon' === $tip ) {
			if ( '' === trim( $v ) ) {
				if ( $zor ) {
					$err[ $id ] = 'Cep telefonu numarasını yazın.';
				}
				continue;
			}
			$n = sides_odsf_tel( $v );
			if ( '' === $n ) {
				$err[ $id ] = 'Cep telefonu numarasını 05XX XXX XX XX biçiminde yazın.';
				continue;
			}
			$oc[ $id ] = $n;
			continue;
		}
		if ( 'tarih' === $tip ) {
			$v = trim( $v );
			if ( '' === $v ) {
				if ( $zor ) {
					$err[ $id ] = 'Bir tarih seçin.';
				}
				continue;
			}
			if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $v, $m ) || ! checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) || (int) $m[1] < 1900 || (int) $m[1] > 2100 ) {
				$err[ $id ] = 'Geçerli bir tarih seçin.';
				continue;
			}
			$oc[ $id ] = $v;
			continue;
		}
		// kisa, uzun
		$t = 'uzun' === $tip ? trim( sanitize_textarea_field( $v ) ) : preg_replace( '/\s+/u', ' ', trim( sanitize_text_field( $v ) ) );
		if ( '' === $t ) {
			if ( $zor ) {
				$err[ $id ] = 'Bu alanı doldurun.';
			}
			continue;
		}
		$mx = isset( $a['max'] ) ? (int) $a['max'] : ( 'uzun' === $tip ? 1000 : 150 );
		if ( mb_strlen( $t ) > $mx ) {
			$err[ $id ] = 'En fazla ' . $mx . ' karakter yazabilirsiniz.';
			continue;
		}
		if ( ! empty( $a['sabit'] ) && in_array( $a['sabit'], array( 'ogrenciAd', 'veliAd' ), true ) ) {
			if ( ! preg_match( '/\p{L}/u', $t ) || preg_match( '/[<>{}\[\]=@#$%^*\\\\|~`]/u', $v ) ) {   // ham değer: etiket ayıklanmadan önce denetlenir
				$err[ $id ] = 'Yalnızca ad ve soyadı yazın.';
				continue;
			}
			if ( count( preg_split( '/\s+/u', $t ) ) < 2 ) {
				$err[ $id ] = 'Adı ve soyadı birlikte yazın.';
				continue;
			}
		}
		$oc[ $id ] = $t;
	}
	if ( $err ) {
		return new WP_Error( 'sides_alan', 'Formda düzeltilmesi gereken alanlar var.', array( 'status' => 400, 'alanlar' => $err ) );
	}
	return array( 'c' => $oc, 'o' => $oo );
}

/* KVKK metni geçmişi: kayıt yalnızca metnin özetini taşır; metnin kendisi ods/kvkk belgesinde bir kez saklanır */
function sides_odsf_kvkk_ozet( $org, $f ) {
	foreach ( $f['alanlar'] as $a ) {
		if ( 'kvkk' === $a['tip'] ) {
			$h = substr( md5( $a['aciklama'] . '|' . $a['onay'] ), 0, 12 );
			$k = sides_get_doc( (int) $org, 'ods', 'kvkk' );
			$k = is_array( $k ) ? $k : array();
			unset( $k['id'] );
			if ( ! isset( $k[ $h ] ) ) {
				$k[ $h ] = array( 'metin' => $a['aciklama'], 'onay' => $a['onay'], 't' => sides_odsf_ms() );
				if ( count( $k ) > 50 ) {
					$k = array_slice( $k, -50, null, true );
				}
				sides_put_doc( (int) $org, 'ods', 'kvkk', $k );
			}
			return $h;
		}
	}
	return '';
}

/* ------------------------------------------------------------------ *
 * Herkese açık sayfa
 * ------------------------------------------------------------------ */
function sides_ods_sayfa( $key ) {
	$o = sides_ods_org( $key );
	header( 'X-Robots-Tag: noindex, nofollow' );
	header( 'X-Frame-Options: SAMEORIGIN' );
	header( 'Referrer-Policy: same-origin' );
	header( 'X-Content-Type-Options: nosniff' );
	if ( ! $o ) {
		status_header( 404 );
		echo '<!doctype html><html lang="tr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>Sayfa bulunamadı</title></head><body style="font-family:system-ui;padding:40px 16px;text-align:center"><h1>Sayfa bulunamadı</h1><p>Bu bağlantı geçerli bir kuruma ait değil.</p></body></html>';
		return;
	}
	if ( function_exists( 'sides_gf_ods_form' ) && ( $gf = sides_gf_ods_form( (int) $o->id ) ) ) {   // v7.9.25: ÖDS olarak işaretli Google Form gömülü açılır
		$gh = sides_gf_ods_html( $o, $gf );
		if ( $gh ) {
			echo $gh; // phpcs:ignore
			return;
		}
	}
	$f = sides_odsf_form( (int) $o->id );
	echo sides_odsf_html( $o, $f, sides_odsf_durum( $f, sides_odsf_say( (int) $o->id ) ), false ); // phpcs:ignore
}

/* Sayfanın HTML'i. $onz: önizleme (gönderim yapılmaz, durum ne olursa olsun alanlar görünür). $sayfa: kaydedilmemiş renk seçimi. */
function sides_odsf_html( $o, $f, $durum, $onz = false, $sayfa = null ) {
	$org = (int) $o->id;
	$a   = sides_ods_ayar( $org );
	if ( is_array( $sayfa ) && isset( $sayfa['renk'] ) && isset( SIDES_ODS_RENKLER[ $sayfa['renk'] ] ) ) {
		$a['renk'] = $sayfa['renk'];
	}
	if ( is_array( $sayfa ) && isset( $sayfa['logoTur'] ) && in_array( $sayfa['logoTur'], array( 'kurum', 'yok' ), true ) ) {
		$a['logoTur'] = $sayfa['logoTur'];
	}
	$set  = sides_get_doc( $org, 'settings', 'main' );
	$kur  = isset( $set['kurum'] ) && $set['kurum'] ? (string) $set['kurum'] : (string) $o->ad;
	$R    = SIDES_ODS_RENKLER[ isset( SIDES_ODS_RENKLER[ $a['renk'] ] ) ? $a['renk'] : 'lacivert' ];
	$logo = sides_ods_logo_url( $o, $a );
	$blok = sides_org_blok( $o );
	$acik = $onz || ( $durum['acik'] && ! $blok );
	$h    = function ( $s ) {
		return esc_html( (string) $s );
	};
	$ts      = time();
	$alanlar = $f['alanlar'];
	$hepsi   = true;
	foreach ( $alanlar as $x ) {
		if ( 'bolum' !== $x['tip'] && empty( $x['zorunlu'] ) ) {
			$hepsi = false;
		}
	}
	$js = array( 'o' => $o->anahtar, 'rest' => esc_url_raw( rest_url( 'optik-karne/v1/ods/basvuru' ) ), 'ts' => $ts, 'imza' => sides_odsf_imza( $org, $ts ), 'onz' => (bool) $onz, 'alanlar' => array() );
	foreach ( $alanlar as $x ) {
		if ( 'bolum' === $x['tip'] ) {
			continue;
		}
		$js['alanlar'][] = array( 'id' => $x['id'], 'tip' => $x['tip'], 'z' => ! empty( $x['zorunlu'] ), 'max' => isset( $x['max'] ) ? (int) $x['max'] : 0, 'sabit' => isset( $x['sabit'] ) ? $x['sabit'] : '', 'serbest' => sides_odsf_secimli( $x['tip'] ) && empty( $x['secenekler'] ) && ! empty( $x['diger'] ) );
	}
	$kapMetin = '';
	if ( ! $acik ) {
		if ( $blok || ! $durum['yayinda'] ) {
			$kapMetin = array( 'Kayıt formu şu anda kapalı', 'Kayıtlar açıldığında bu bağlantıdan başvurabilirsiniz.' );
		} elseif ( $durum['kapandi'] ) {
			$kapMetin = array( 'Kayıtlar kapandı', 'Bu sınav için kayıt süresi doldu. İlginiz için teşekkür ederiz.' );
		} else {
			$kapMetin = array( 'Kontenjan doldu', 'Bu sınavın kontenjanı doldu. İlginiz için teşekkür ederiz.' );
		}
	}
	$kapanisYazi = '';
	if ( $f['kapanis'] && preg_match( '/^(\d{4})-(\d{2})-(\d{2})T(\d{2}:\d{2})$/', $f['kapanis'], $km ) ) {
		$kapanisYazi = sides_ods_tarih_yaz( $km[1] . '-' . $km[2] . '-' . $km[3] ) . ', ' . $km[4];
	}
	$secSay = function ( $fid, $sid ) use ( $durum ) {
		return isset( $durum['secenek'][ $fid ][ $sid ] ) ? (int) $durum['secenek'][ $fid ][ $sid ] : 0;
	};
	ob_start();
	?><!doctype html>
<html lang="tr">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="robots" content="noindex,nofollow">
<meta name="theme-color" content="<?php echo esc_attr( $R['a'] ); ?>">
<title><?php echo $h( $f['baslik'] . ' · ' . $kur ); ?></title>
<meta property="og:type" content="website">
<meta property="og:locale" content="tr_TR">
<meta property="og:site_name" content="<?php echo esc_attr( $kur ); ?>">
<meta property="og:title" content="<?php echo esc_attr( $f['baslik'] ); ?>">
<meta property="og:description" content="<?php echo esc_attr( mb_substr( $f['aciklama'] ? $f['aciklama'] : $kur, 0, 200 ) ); ?>">
<?php if ( $logo ) : ?><meta property="og:image" content="<?php echo esc_url( $logo ); ?>">
<?php endif; ?>
<style>
:root{--a:<?php echo esc_html( $R['a'] ); ?>;--a2:<?php echo esc_html( $R['b'] ); ?>;--a3:<?php echo esc_html( $R['c'] ); ?>;--v:<?php echo esc_html( $R['v'] ); ?>;--v2:<?php echo esc_html( $R['v2'] ); ?>;--zemin:#eef1f7;--kart:#fff;--yazi:#16233b;--mut:#5a6880;--cizgi:#d5dce8;--hata:#b42318;--hata-z:#fef3f2;--ok:#127a43;color-scheme:light}
*{box-sizing:border-box}html,body{margin:0;padding:0}[hidden]{display:none!important}
body{font-family:system-ui,-apple-system,"Segoe UI",Roboto,Arial,sans-serif;color:var(--yazi);background:var(--zemin);line-height:1.5;-webkit-text-size-adjust:100%;overflow-x:hidden;font-size:16px}
.ust{background:linear-gradient(135deg,var(--a) 0%,var(--a2) 60%,var(--a3) 100%);color:#fff;padding:18px 16px 64px;position:relative}
.ust::after{content:"";position:absolute;left:0;right:0;bottom:0;height:4px;background:linear-gradient(90deg,var(--v),var(--v2))}
.ust .ic{max-width:680px;margin:0 auto;display:flex;align-items:center;gap:12px;min-width:0}
.ust img{flex:none;width:48px;height:48px;object-fit:contain;border-radius:12px;background:#fff;padding:3px}
.ust .rozet{flex:none;width:48px;height:48px;border-radius:12px;background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.35);display:grid;place-items:center;font-weight:900;font-size:14px;letter-spacing:.5px}
.ust .kurum{font-weight:800;font-size:17px;line-height:1.25;overflow-wrap:anywhere;min-width:0}
.ust .kurum small{display:block;font-weight:600;font-size:13px;opacity:.85;letter-spacing:.2px}
main{max-width:680px;margin:-48px auto 0;padding:0 12px 40px;position:relative}
.kart{background:var(--kart);border:1px solid var(--cizgi);border-radius:16px;padding:18px 16px;margin-bottom:12px;box-shadow:0 1px 2px rgba(16,24,40,.04)}
.giris{border-top:6px solid var(--v);padding:20px 16px}
h1{font-size:clamp(23px,6vw,30px);line-height:1.2;margin:0 0 8px;color:var(--a);letter-spacing:-.3px;overflow-wrap:anywhere}
.ac{margin:0;color:var(--mut);white-space:pre-line;overflow-wrap:anywhere}
.bilgi{display:flex;flex-wrap:wrap;gap:6px 12px;margin-top:12px;font-size:14px;color:var(--mut)}
.bilgi span{display:inline-flex;align-items:center;gap:6px}
.bilgi svg{width:16px;height:16px;flex:none;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.alan .et{display:block;font-weight:700;font-size:17px;line-height:1.35;margin:0 0 4px;overflow-wrap:anywhere}
.alan .et small{font-weight:500;color:var(--mut);font-size:14px}
.alan .yd{margin:0 0 10px;color:var(--mut);font-size:14px;white-space:pre-line;overflow-wrap:anywhere}
.alan fieldset{border:0;margin:0;padding:0;min-width:0}
.alan legend{padding:0;width:100%}
input[type=text],input[type=tel],input[type=date],select,textarea{display:block;width:100%;font:inherit;font-size:17px;min-height:52px;padding:12px 14px;border:1.5px solid #b9c3d3;border-radius:12px;background:#fff;color:var(--yazi);margin-top:6px;-webkit-appearance:none;appearance:none}
select{background-image:linear-gradient(45deg,transparent 50%,var(--mut) 50%),linear-gradient(135deg,var(--mut) 50%,transparent 50%);background-position:calc(100% - 20px) 50%,calc(100% - 14px) 50%;background-size:6px 6px;background-repeat:no-repeat;padding-right:40px}
textarea{min-height:110px;resize:vertical}
input:focus,select:focus,textarea:focus{outline:3px solid rgba(42,86,168,.3);outline:3px solid color-mix(in srgb,var(--a3) 35%,transparent);outline-offset:0;border-color:var(--a3)}
.secler{display:grid;gap:8px;margin-top:6px}
.sec{display:flex;align-items:center;gap:12px;min-height:52px;padding:10px 14px;border:1.5px solid var(--cizgi);border-radius:12px;background:#fff;cursor:pointer;font-size:16px;line-height:1.35;overflow-wrap:anywhere}
.sec input{flex:none;width:22px;height:22px;margin:0;accent-color:var(--a)}
.sec.secili{border-color:var(--a3);background:#f1f5fc;background:color-mix(in srgb,var(--a3) 8%,#fff);box-shadow:inset 0 0 0 1px var(--a3)}
.sec:focus-within{outline:3px solid rgba(42,86,168,.3);outline:3px solid color-mix(in srgb,var(--a3) 35%,transparent)}
.sec.dolu{cursor:not-allowed;color:var(--mut);background:#f4f6f9}
.sec .dl{margin-left:auto;flex:none;font-size:12px;font-weight:700;color:var(--hata);background:var(--hata-z);border-radius:999px;padding:3px 8px}
.kvkk .metin{font-size:14px;color:var(--mut);white-space:pre-line;max-height:220px;overflow:auto;padding:12px 14px;border:1px solid var(--cizgi);border-radius:12px;background:#f8fafc;margin:6px 0 10px;overflow-wrap:anywhere}
.kvkk .sec{align-items:flex-start;font-weight:600;font-size:15px}
.kvkk .sec input{margin-top:1px}
.bolum{border-left:6px solid var(--a);padding:16px}
.bolum h2{margin:0 0 4px;font-size:20px;color:var(--a);overflow-wrap:anywhere}
.alan.hatali{border-color:var(--hata);box-shadow:0 0 0 1px var(--hata)}
.alan.hatali input[type=text],.alan.hatali input[type=tel],.alan.hatali input[type=date],.alan.hatali select,.alan.hatali textarea{border-color:var(--hata)}
.hata{display:flex;gap:6px;align-items:flex-start;margin:8px 0 0;color:var(--hata);font-size:14px;font-weight:600}
.hata[hidden]{display:none}
.hata::before{content:"!";flex:none;width:18px;height:18px;border-radius:50%;background:var(--hata);color:#fff;font-size:12px;font-weight:900;display:grid;place-items:center;margin-top:1px}
.diger{margin-top:8px}
.hp{position:absolute!important;left:-10000px!important;width:1px;height:1px;overflow:hidden}
.gonder{position:relative}
.btn{display:flex;align-items:center;justify-content:center;gap:8px;width:100%;min-height:56px;padding:0 22px;border-radius:14px;border:0;font:inherit;font-weight:800;font-size:18px;cursor:pointer;background:var(--a);color:#fff;box-shadow:0 6px 18px rgba(15,45,92,.25);transition:transform .15s,opacity .15s}
.btn:active{transform:scale(.985)}
.btn[disabled]{opacity:.7;cursor:progress}
.btn.ikinci{background:#fff;color:var(--a);border:1.5px solid var(--a);box-shadow:none}
.ozet-h{background:var(--hata-z);border:1px solid #fecdca;color:var(--hata);border-radius:12px;padding:12px 14px;font-size:15px;font-weight:600;margin-bottom:12px}
.ozet-h[hidden]{display:none}
.not-k{font-size:13px;color:var(--mut);text-align:center;margin:12px 4px 0}
.durum{text-align:center;padding:28px 18px}
.durum .ik{width:64px;height:64px;border-radius:50%;margin:0 auto 12px;display:grid;place-items:center;background:#eef2f8;color:var(--a)}
.durum .ik svg{width:32px;height:32px;stroke:currentColor;fill:none;stroke-width:2.2;stroke-linecap:round;stroke-linejoin:round}
.durum.ok .ik{background:#e3f5ea;color:var(--ok)}
.durum h2{margin:0 0 6px;font-size:24px;color:var(--a)}
.durum.ok h2{color:var(--ok)}
.durum p{margin:0 auto;color:var(--mut);max-width:440px;white-space:pre-line}
.ozet{list-style:none;padding:0;margin:16px auto 18px;max-width:420px;text-align:left;border:1px solid var(--cizgi);border-radius:12px;overflow:hidden}
.ozet li{display:flex;justify-content:space-between;gap:12px;padding:10px 14px;border-top:1px solid var(--cizgi);font-size:15px}
.ozet li:first-child{border-top:0}
.ozet li span{color:var(--mut);flex:none}
.ozet li b{text-align:right;overflow-wrap:anywhere;min-width:0}
.onz{background:#fff8e6;border:1px dashed #e0b44a;color:#5c4300;border-radius:12px;padding:10px 14px;font-size:14px;margin-bottom:12px}
footer{max-width:680px;margin:0 auto;padding:0 16px 32px;text-align:center;font-size:13px;color:var(--mut)}
@media (min-width:640px){.kart{padding:22px 24px}.giris{padding:26px 24px}.ust{padding:22px 16px 72px}main{padding:0 16px 48px}.btn{width:auto;min-width:260px;margin:0 auto}}
@media (prefers-reduced-motion:reduce){.btn{transition:none}}
</style>
</head>
<body>
<header class="ust"><div class="ic">
<?php if ( $logo ) : ?><img src="<?php echo esc_url( $logo ); ?>" alt="" width="48" height="48"><?php else : ?><span class="rozet" aria-hidden="true">ÖDS</span><?php endif; ?>
<div class="kurum"><?php echo $h( $kur ); ?><small>Ödüllü Deneme Sınavı kaydı</small></div>
</div></header>
<main>
<?php if ( $onz ) : ?><div class="onz" role="note"><b>Önizleme.</b> Başvuranlar bu sayfayı böyle görür; önizlemede bilgiler gönderilmez.<?php echo $durum['acik'] ? '' : ' Form şu an başvuruya kapalı; başvuranlar “' . $h( $kapMetin ? $kapMetin[0] : ( ! $durum['yayinda'] ? 'Kayıt formu şu anda kapalı' : ( $durum['kapandi'] ? 'Kayıtlar kapandı' : 'Kontenjan doldu' ) ) ) . '” yazısını görür.'; ?></div><?php endif; ?>
<section class="kart giris">
<h1><?php echo $h( $f['baslik'] ); ?></h1>
<?php if ( $f['aciklama'] ) : ?><p class="ac"><?php echo $h( $f['aciklama'] ); ?></p><?php endif; ?>
<?php if ( $acik && ( $kapanisYazi || $hepsi ) ) : ?><div class="bilgi"><?php if ( $kapanisYazi ) : ?><span><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>Son kayıt: <?php echo $h( $kapanisYazi ); ?></span><?php endif; ?><?php if ( $hepsi ) : ?><span><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 11l3 3 8-8"/><path d="M20 12v7a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h9"/></svg>Tüm alanlar zorunludur</span><?php endif; ?></div><?php endif; ?>
</section>
<?php if ( ! $acik ) : ?>
<section class="kart durum" id="odsDurum"><div class="ik"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/></svg></div><h2><?php echo $h( $kapMetin[0] ); ?></h2><p><?php echo $h( $kapMetin[1] ); ?></p></section>
<?php else : ?>
<form id="odsForm" novalidate>
<?php foreach ( $alanlar as $x ) :
	$id  = $x['id'];
	$fid = 'f_' . $id;
	$opt = ! $hepsi && empty( $x['zorunlu'] ) && 'bolum' !== $x['tip'] ? ' <small>(isteğe bağlı)</small>' : '';
	$yd  = $x['aciklama'] && 'kvkk' !== $x['tip'] ? '<p class="yd" id="y_' . esc_attr( $id ) . '">' . $h( $x['aciklama'] ) . '</p>' : '';
	$by  = 'h_' . $id . ( $yd ? ' y_' . $id : '' );
	if ( 'bolum' === $x['tip'] ) :
		?><section class="kart bolum"><h2><?php echo $h( $x['etiket'] ); ?></h2><?php if ( $x['aciklama'] ) : ?><p class="ac"><?php echo $h( $x['aciklama'] ); ?></p><?php endif; ?></section>
<?php
		continue;
	endif;
	?><div class="kart alan<?php echo 'kvkk' === $x['tip'] ? ' kvkk' : ''; ?>" id="a_<?php echo esc_attr( $id ); ?>" data-id="<?php echo esc_attr( $id ); ?>">
<?php
	switch ( $x['tip'] ) {
		case 'kisa':
		case 'telefon':
		case 'tarih':
			$ty = 'telefon' === $x['tip'] ? 'tel' : ( 'tarih' === $x['tip'] ? 'date' : 'text' );
			$ac = 'ogrenciAd' === $id ? 'off' : ( 'veliAd' === $id ? 'name' : ( 'telefon' === $x['tip'] ? 'tel' : 'on' ) );
			echo '<label class="et" for="' . esc_attr( $fid ) . '">' . $h( $x['etiket'] ) . $opt . '</label>' . $yd; // phpcs:ignore
			echo '<input type="' . $ty . '" id="' . esc_attr( $fid ) . '" name="' . esc_attr( $fid ) . '" autocomplete="' . $ac . '"' . ( 'telefon' === $x['tip'] ? ' inputmode="tel" placeholder="05XX XXX XX XX" maxlength="20"' : '' ) . ( 'kisa' === $x['tip'] ? ' maxlength="' . (int) $x['max'] . '"' . ( in_array( $id, array( 'ogrenciAd', 'veliAd' ), true ) ? ' autocapitalize="words"' : '' ) : '' ) . ( ! empty( $x['zorunlu'] ) ? ' aria-required="true"' : '' ) . ' aria-describedby="' . esc_attr( $by ) . '">'; // phpcs:ignore
			break;
		case 'uzun':
			echo '<label class="et" for="' . esc_attr( $fid ) . '">' . $h( $x['etiket'] ) . $opt . '</label>' . $yd; // phpcs:ignore
			echo '<textarea id="' . esc_attr( $fid ) . '" name="' . esc_attr( $fid ) . '" maxlength="' . (int) $x['max'] . '"' . ( ! empty( $x['zorunlu'] ) ? ' aria-required="true"' : '' ) . ' aria-describedby="' . esc_attr( $by ) . '"></textarea>'; // phpcs:ignore
			break;
		case 'liste':
			echo '<label class="et" for="' . esc_attr( $fid ) . '">' . $h( $x['etiket'] ) . $opt . '</label>' . $yd; // phpcs:ignore
			if ( ! $x['secenekler'] && ! empty( $x['diger'] ) ) {
				echo '<input type="text" id="' . esc_attr( $fid ) . '" name="' . esc_attr( $fid ) . '" maxlength="150" autocomplete="off"' . ( 'okul' === $id ? ' placeholder="Okulun adını yazın"' : '' ) . ( ! empty( $x['zorunlu'] ) ? ' aria-required="true"' : '' ) . ' aria-describedby="' . esc_attr( $by ) . '">'; // phpcs:ignore
				break;
			}
			echo '<select id="' . esc_attr( $fid ) . '" name="' . esc_attr( $fid ) . '"' . ( ! empty( $x['zorunlu'] ) ? ' aria-required="true"' : '' ) . ' aria-describedby="' . esc_attr( $by ) . '"><option value="">Seçin</option>'; // phpcs:ignore
			foreach ( $x['secenekler'] as $s ) {
				$dl = (int) $s['kontenjan'] > 0 && $secSay( $id, $s['id'] ) >= (int) $s['kontenjan'];
				echo '<option value="' . esc_attr( $s['id'] ) . '"' . ( $dl && ! $onz ? ' disabled' : '' ) . '>' . $h( $s['ad'] . ( $dl ? ' (kontenjan doldu)' : '' ) ) . '</option>'; // phpcs:ignore
			}
			if ( ! empty( $x['diger'] ) ) {
				echo '<option value="_diger">Diğer (yazınız)</option>';
			}
			echo '</select>';
			if ( ! empty( $x['diger'] ) ) {
				echo '<input type="text" class="diger" id="d_' . esc_attr( $id ) . '" name="d_' . esc_attr( $id ) . '" maxlength="150" autocomplete="off" placeholder="' . ( 'okul' === $id ? 'Okulun adını yazın' : 'Yazınız' ) . '" aria-label="' . esc_attr( $x['etiket'] . ': diğer' ) . '" hidden>'; // phpcs:ignore
			}
			break;
		case 'tek':
		case 'coklu':
			$tt = 'tek' === $x['tip'] ? 'radio' : 'checkbox';
			if ( 'tek' === $x['tip'] && ! $x['secenekler'] && ! empty( $x['diger'] ) ) {
				echo '<label class="et" for="' . esc_attr( $fid ) . '">' . $h( $x['etiket'] ) . $opt . '</label>' . $yd; // phpcs:ignore
				echo '<input type="text" id="' . esc_attr( $fid ) . '" name="' . esc_attr( $fid ) . '" maxlength="150" autocomplete="off"' . ( ! empty( $x['zorunlu'] ) ? ' aria-required="true"' : '' ) . ' aria-describedby="' . esc_attr( $by ) . '">'; // phpcs:ignore
				break;
			}
			echo '<fieldset aria-describedby="' . esc_attr( $by ) . '"><legend class="et">' . $h( $x['etiket'] ) . $opt . '</legend>' . $yd . '<div class="secler">'; // phpcs:ignore
			foreach ( $x['secenekler'] as $s ) {
				$dl = 'tek' === $x['tip'] && (int) $s['kontenjan'] > 0 && $secSay( $id, $s['id'] ) >= (int) $s['kontenjan'];
				echo '<label class="sec' . ( $dl ? ' dolu' : '' ) . '"><input type="' . $tt . '" name="' . esc_attr( $fid ) . '" value="' . esc_attr( $s['id'] ) . '"' . ( $dl && ! $onz ? ' disabled' : '' ) . '><span>' . $h( $s['ad'] ) . '</span>' . ( $dl ? '<span class="dl">Kontenjan doldu</span>' : '' ) . '</label>'; // phpcs:ignore
			}
			if ( 'tek' === $x['tip'] && ! empty( $x['diger'] ) ) {
				echo '<label class="sec"><input type="radio" name="' . esc_attr( $fid ) . '" value="_diger"><span>Diğer (yazınız)</span></label>';
			}
			echo '</div></fieldset>';
			if ( 'tek' === $x['tip'] && ! empty( $x['diger'] ) ) {
				echo '<input type="text" class="diger" id="d_' . esc_attr( $id ) . '" name="d_' . esc_attr( $id ) . '" maxlength="150" autocomplete="off" placeholder="Yazınız" aria-label="' . esc_attr( $x['etiket'] . ': diğer' ) . '" hidden>'; // phpcs:ignore
			}
			break;
		case 'kvkk':
			echo '<div class="et" id="k_' . esc_attr( $id ) . '">' . $h( $x['etiket'] ) . '</div><div class="metin" tabindex="0" aria-labelledby="k_' . esc_attr( $id ) . '">' . $h( $x['aciklama'] ) . '</div>'; // phpcs:ignore
			echo '<label class="sec"><input type="checkbox" id="' . esc_attr( $fid ) . '" name="' . esc_attr( $fid ) . '" value="1" aria-required="true" aria-describedby="h_' . esc_attr( $id ) . '"><span>' . $h( $x['onay'] ) . '</span></label>'; // phpcs:ignore
			break;
	}
	?>
<p class="hata" id="h_<?php echo esc_attr( $id ); ?>" role="alert" hidden></p>
</div>
<?php endforeach; ?>
<div class="hp" aria-hidden="true"><label>Web sitesi<input type="text" name="web" tabindex="-1" autocomplete="off"></label></div>
<div class="gonder">
<div class="ozet-h" id="odsOzetH" role="alert" hidden></div>
<button class="btn" type="submit" id="odsGonder">Kaydı tamamla</button>
<p class="not-k">Bilgileriniz yalnızca sınav kaydı için kullanılır.</p>
</div>
</form>
<?php endif; ?>
</main>
<footer><?php echo $h( $kur ); ?></footer>
<?php if ( $acik ) : ?>
<script>
(function(){
  var T=<?php echo wp_json_encode( $js, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT ); ?>;
  var basari=<?php echo wp_json_encode( $f['basari'] ? $f['basari'] : 'Kaydınız alındı. Teşekkür ederiz.', JSON_HEX_TAG | JSON_HEX_AMP ); ?>;
  var F=document.getElementById('odsForm'); if(!F) return;
  var islem=function(){var s='';for(var i=0;i<20;i++)s+='abcdefghijklmnopqrstuvwxyz0123456789'.charAt(Math.floor(Math.random()*36));return s;};
  var IS=islem();
  var q=function(s,r){return (r||document).querySelector(s)};
  var qa=function(s,r){return Array.prototype.slice.call((r||document).querySelectorAll(s))};
  var telNorm=function(s){var d=String(s||'').replace(/\D/g,'');if(d.length===12&&d.slice(0,2)==='90')d=d.slice(2);else if(d.length===11&&d.charAt(0)==='0')d=d.slice(1);return /^5\d{9}$/.test(d)?d:''};
  var telBicim=function(d){return '0'+d.slice(0,3)+' '+d.slice(3,6)+' '+d.slice(6,8)+' '+d.slice(8,10)};
  var kutu=function(id){return q('#a_'+id)};
  var hataYaz=function(id,m){var k=kutu(id);if(!k)return;var p=q('#h_'+id);if(m){k.classList.add('hatali');p.textContent=m;p.hidden=false;qa('input,select,textarea',k).forEach(function(e){e.setAttribute('aria-invalid','true')})}else{k.classList.remove('hatali');p.textContent='';p.hidden=true;qa('[aria-invalid]',k).forEach(function(e){e.removeAttribute('aria-invalid')})}};
  var deger=function(a){
    var n='f_'+a.id;
    if(a.tip==='kvkk'){var c=q('#'+n);return c&&c.checked}
    if(a.tip==='coklu'){return qa('input[name="'+n+'"]:checked').map(function(e){return e.value})}
    if(a.tip==='tek'&&!a.serbest){var r=q('input[name="'+n+'"]:checked');return r?r.value:''}
    var e=F.elements[n];return e?String(e.value||''):''
  };
  var digerMetin=function(a){var d=q('#d_'+a.id);return d?String(d.value||'').trim():''};
  var denetle=function(a,v){
    var bos=function(x){return x===''||x===false||(x&&x.length===0)};
    if(a.tip==='kvkk')return v?'':'Devam etmek için onay kutusunu işaretleyin.';
    if(a.tip==='coklu')return a.z&&!v.length?'En az bir seçenek işaretleyin.':'';
    var t=typeof v==='string'?v.trim():v;
    if((a.tip==='liste'||a.tip==='tek')&&!a.serbest){
      if(bos(t))return a.z?'Bir seçenek seçin.':'';
      if(t==='_diger'){var m=digerMetin(a);if(!m)return a.id==='okul'?'Okulun adını yazın.':'Lütfen yazın.';if(m.length>150)return 'En fazla 150 karakter yazabilirsiniz.'}
      return ''
    }
    if(bos(t))return a.z?(a.tip==='telefon'?'Cep telefonu numarasını yazın.':a.tip==='tarih'?'Bir tarih seçin.':a.serbest&&a.id==='okul'?'Okulun adını yazın.':'Bu alanı doldurun.'):'';
    if(a.tip==='telefon')return telNorm(t)?'':'Cep telefonu numarasını 05XX XXX XX XX biçiminde yazın.';
    if(a.tip==='tarih')return /^\d{4}-\d{2}-\d{2}$/.test(t)?'':'Geçerli bir tarih seçin.';
    if(a.max&&t.length>a.max)return 'En fazla '+a.max+' karakter yazabilirsiniz.';
    if(a.serbest&&t.length>150)return 'En fazla 150 karakter yazabilirsiniz.';
    if(a.sabit==='ogrenciAd'||a.sabit==='veliAd'){if(/[<>{}\[\]=@#$%^*\\|~`]/.test(t)||!/[A-Za-zÇĞİÖŞÜçğıöşüÂâÎîÛû]/.test(t))return 'Yalnızca ad ve soyadı yazın.';if(t.split(/\s+/).length<2)return 'Adı ve soyadı birlikte yazın.'}
    return ''
  };
  // telefon: yazarken biçimlendir, ayrılınca düzelt
  T.alanlar.forEach(function(a){
    if(a.tip==='telefon'){var e=F.elements['f_'+a.id];if(!e)return;
      e.addEventListener('input',function(ev){if(ev&&ev.inputType&&ev.inputType.indexOf('delete')===0)return;var v=e.value;if(/^\s*(\+|9)/.test(v)||/[^\d\s()-]/.test(v))return;var d=v.replace(/\D/g,'');if(d&&d.charAt(0)!=='0')d='0'+d;d=d.slice(0,11);var p=[d.slice(0,4),d.slice(4,7),d.slice(7,9),d.slice(9,11)].filter(Boolean).join(' ');if(v!==p)e.value=p});
      e.addEventListener('blur',function(){var n=telNorm(e.value);if(n)e.value=telBicim(n)});
    }
    if((a.tip==='liste'||a.tip==='tek')&&!a.serbest){var d=q('#d_'+a.id);if(!d)return;
      var guncel=function(){var on=deger(a)==='_diger';d.hidden=!on;if(on&&document.activeElement&&document.activeElement.name!==d.name)d.focus()};
      qa('[name="f_'+a.id+'"]').forEach(function(e){e.addEventListener('change',guncel)});
    }
  });
  F.addEventListener('input',function(ev){var k=ev.target.closest&&ev.target.closest('.alan');if(k&&k.classList.contains('hatali'))hataYaz(k.getAttribute('data-id'),'')});
  var isaretle=function(){qa('.sec',F).forEach(function(l){var i=l.querySelector('input');l.classList.toggle('secili',!!(i&&i.checked))})};
  F.addEventListener('change',function(ev){isaretle();var k=ev.target.closest&&ev.target.closest('.alan');if(k&&k.classList.contains('hatali'))hataYaz(k.getAttribute('data-id'),'')});
  // kardeş kaydı: veli bilgileri bu sekmede hatırlanır
  try{var V=JSON.parse(sessionStorage.getItem('odsVeli')||'null');if(V){['veliAd','veliTel'].forEach(function(k){var e=F.elements['f_'+k];if(e&&!e.value&&V[k])e.value=V[k]})}}catch(e){}
  var B=q('#odsGonder'),OH=q('#odsOzetH');
  var hatalar=function(H){var ilk=null,n=0;T.alanlar.forEach(function(a){var m=H[a.id]||'';hataYaz(a.id,m);if(m){n++;if(!ilk)ilk=a.id}});
    if(n){OH.textContent=n===1?'Bir alanı kontrol edin.':n+' alanı kontrol edin.';OH.hidden=false;var k=kutu(ilk);if(k){k.scrollIntoView({block:'center',behavior:'smooth'});var e=q('input:not([type=hidden]):not([hidden]),select,textarea',k);if(e)setTimeout(function(){try{e.focus({preventScroll:true})}catch(x){e.focus()}},250)}}else{OH.hidden=true}
    return n};
  var bitti=function(c){
    var oz=[];var ad=c.ogrenciAd;if(ad)oz.push(['Öğrenci',ad]);
    T.alanlar.forEach(function(a){if(a.sabit==='oturum'||a.sabit==='sinif'){var e=a.tip==='tek'?q('input[name="f_'+a.id+'"]:checked'):F.elements['f_'+a.id];var t='';if(e){t=a.tip==='tek'?(e.parentNode.querySelector('span')||{}).textContent:(e.options&&e.selectedIndex>=0?e.options[e.selectedIndex].text:'')}if(t)oz.push([a.sabit==='oturum'?'Oturum':'Sınıf',t])}});
    try{sessionStorage.setItem('odsVeli',JSON.stringify({veliAd:c.veliAd||'',veliTel:c.veliTel||''}))}catch(e){}
    var s=document.createElement('section');s.className='kart durum ok';s.id='odsOk';s.setAttribute('tabindex','-1');
    s.innerHTML='<div class="ik"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg></div><h2>Kaydınız alındı</h2><p></p><ul class="ozet"></ul><button type="button" class="btn ikinci" id="odsYeni">Başka bir öğrenci kaydet</button>';
    s.querySelector('p').textContent=basari;
    var ul=s.querySelector('.ozet');oz.forEach(function(x){var li=document.createElement('li');var sp=document.createElement('span');sp.textContent=x[0];var b=document.createElement('b');b.textContent=x[1];li.appendChild(sp);li.appendChild(b);ul.appendChild(li)});if(!oz.length)ul.remove();
    F.parentNode.replaceChild(s,F);var bl=q('.giris .bilgi');if(bl)bl.hidden=true;s.focus();window.scrollTo(0,0);
    q('#odsYeni').addEventListener('click',function(){location.reload()});
  };
  F.addEventListener('submit',function(ev){
    ev.preventDefault();
    var c={},d={},H={};
    T.alanlar.forEach(function(a){var v=deger(a);var m=denetle(a,v);if(m)H[a.id]=m;
      if(a.tip==='telefon'&&typeof v==='string'){var n=telNorm(v);if(n)v=telBicim(n)}
      if(a.tip==='kvkk')v=v?'1':'';
      c[a.id]=typeof v==='string'?v.trim():v;if(v==='_diger')d[a.id]=digerMetin(a)});
    if(hatalar(H))return;
    if(T.onz){OH.textContent='Önizleme: bilgiler doğru biçimde; gerçek formda bu adımda kayıt gönderilir.';OH.hidden=false;OH.style.background='#e3f5ea';OH.style.color='#0f5132';OH.style.borderColor='#b7e4c7';return}
    B.disabled=true;B.textContent='Gönderiliyor…';OH.hidden=true;
    var x=new XMLHttpRequest();x.open('POST',T.rest);x.setRequestHeader('Content-Type','application/json');
    x.onload=function(){var j={};try{j=JSON.parse(x.responseText)}catch(e){}
      if(x.status>=200&&x.status<300){bitti(c);return}
      B.disabled=false;B.textContent='Kaydı tamamla';
      if(j&&j.data&&j.data.alanlar){hatalar(j.data.alanlar);return}
      OH.textContent=(j&&j.message)||('Kayıt gönderilemedi (sunucu hatası '+x.status+'). Lütfen tekrar deneyin.');OH.hidden=false;OH.scrollIntoView({block:'center'})};
    x.onerror=function(){B.disabled=false;B.textContent='Kaydı tamamla';OH.textContent='Bağlantı kurulamadı. İnternet bağlantınızı kontrol edip tekrar deneyin.';OH.hidden=false};
    x.send(JSON.stringify({o:T.o,ts:T.ts,imza:T.imza,islemId:IS,web:(F.elements.web||{}).value||'',c:c,d:d}));
  });
})();
</script>
<?php endif; ?>
</body>
</html>
	<?php
	return ob_get_clean();
}

/* ------------------------------------------------------------------ *
 * REST
 * ------------------------------------------------------------------ */
add_action( 'rest_api_init', function () {
	$ns      = 'optik-karne/v1';
	$sayfa   = function ( $s, $l ) {
		return ! function_exists( 'sides_sayfa_herhangi' ) || sides_sayfa_herhangi( (array) $s, $l );
	};
	$okuForm = function () use ( $sayfa ) {
		if ( ! sides_can( 'kayit', 1 ) || ! $sayfa( array( 'kayit.ods', 'kayit.odsliste' ), 1 ) ) {
			return sides_deny( 'ÖDS kayıt formunu görmek için Kayıt modülü yetkisi gerekir.' );
		}
		return true;
	};
	$yazForm = function () use ( $sayfa ) {
		if ( sides_is_observer() ) {
			return sides_deny( 'Gözlemci hesabı kayıt formunu değiştiremez.' );
		}
		if ( ! sides_can( 'kayit', 2 ) || ! $sayfa( 'kayit.ods', 2 ) ) {
			return sides_deny( 'ÖDS kayıt formunu Kayıt modülünde değişiklik yetkisi olan kullanıcılar düzenler.' );
		}
		return true;
	};
	$okuListe = function () use ( $sayfa ) {
		if ( ! sides_can( 'kayit', 1 ) || ! $sayfa( 'kayit.odsliste', 1 ) ) {
			return sides_deny( 'ÖDS aday listesini görmek için Kayıt modülü yetkisi gerekir.' );
		}
		return true;
	};
	$yazListe = function () use ( $sayfa ) {
		if ( sides_is_observer() ) {
			return sides_deny( 'Gözlemci hesabı kayıtları değiştiremez ve dışa aktaramaz.' );
		}
		if ( ! sides_can( 'kayit', 2 ) || ! $sayfa( 'kayit.odsliste', 2 ) ) {
			return sides_deny( 'Kayıtları düzenlemek ve dışa aktarmak için Kayıt modülünde değişiklik yetkisi gerekir.' );
		}
		return true;
	};
	$aktar = function () use ( $yazListe ) {
		$r = $yazListe();
		if ( true !== $r ) {
			return $r;
		}
		return sides_can( 'crm', 2 ) ? true : sides_deny( 'Adaylara aktarmak için CRM modülünde değişiklik yetkisi gerekir.' );
	};
	register_rest_route( $ns, '/ods/form', array(
		array( 'methods' => 'GET', 'callback' => 'sides_odsf_rest_form', 'permission_callback' => $okuForm ),
		array( 'methods' => 'POST', 'callback' => 'sides_odsf_rest_form_kaydet', 'permission_callback' => $yazForm ),
	) );
	register_rest_route( $ns, '/ods/onizleme', array( 'methods' => 'POST', 'callback' => 'sides_odsf_rest_onizleme', 'permission_callback' => $okuForm ) );
	register_rest_route( $ns, '/ods/basvuru', array( 'methods' => 'POST', 'callback' => 'sides_odsf_rest_basvuru', 'permission_callback' => '__return_true' ) );
	register_rest_route( $ns, '/ods/kayitlar', array( 'methods' => 'GET', 'callback' => 'sides_odsf_rest_liste', 'permission_callback' => $okuListe ) );
	register_rest_route( $ns, '/ods/kayit/(?P<id>k[a-z0-9]{6,40})', array(
		array( 'methods' => 'POST', 'callback' => 'sides_odsf_rest_duzenle', 'permission_callback' => $yazListe ),
		array( 'methods' => 'DELETE', 'callback' => 'sides_odsf_rest_sil', 'permission_callback' => $yazListe ),
	) );
	register_rest_route( $ns, '/ods/disa', array( 'methods' => 'POST', 'callback' => 'sides_odsf_rest_disa', 'permission_callback' => $yazListe ) );
	register_rest_route( $ns, '/ods/aktar', array( 'methods' => 'POST', 'callback' => 'sides_odsf_rest_aktar', 'permission_callback' => $aktar ) );
} );

function sides_odsf_yanit( $d ) {
	$r = rest_ensure_response( $d );
	$r->header( 'Cache-Control', 'no-store, private' );
	return $r;
}
function sides_odsf_cikis( $org ) {
	$o   = sides_org( $org );
	$f   = sides_odsf_form( $org );
	$a   = sides_ods_ayar( $org );
	$set = sides_get_doc( $org, 'settings', 'main' );
	$vo  = $o ? sides_ods_org( '1' ) : null;
	return array(
		'form'      => $f,
		'durum'     => sides_odsf_durum( $f, sides_odsf_say( $org ) ),
		'kurum'     => isset( $set['kurum'] ) && $set['kurum'] ? $set['kurum'] : ( $o ? $o->ad : '' ),
		'kurumLogo' => ! empty( $set['logo'] ),
		'sayfa'     => array( 'logoTur' => $a['logoTur'], 'logoG' => $a['logoG'], 'renk' => $a['renk'], 'yonlendir' => ! empty( $a['yonlendir'] ) ),
		'renkler'   => SIDES_ODS_RENKLER,
		'url'       => array( 'kisa' => sides_ods_url_kisa(), 'tam' => sides_ods_url_tam( $o ), 'logo' => $o ? sides_ods_logo_url( $o, $a ) : '' ),
		'varsayilan' => $o && $vo ? (int) $vo->id === (int) $o->id : false,
		'anaSayfa'  => sides_ana_sayfa(),
		'yaz'       => sides_can( 'kayit', 2 ) && ! sides_is_observer(),
		'yonlendirYetki' => sides_is_super(),
	);
}
function sides_odsf_rest_form() {
	return sides_odsf_yanit( sides_odsf_cikis( sides_org_id() ) );
}
function sides_odsf_rest_form_kaydet( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	$p   = is_array( $p ) ? $p : array();
	$yeni = sides_odsf_temizle( isset( $p['form'] ) ? $p['form'] : null );
	if ( is_wp_error( $yeni ) ) {
		return $yeni;
	}
	$eski = sides_odsf_form( $org );
	if ( isset( $p['form']['surum'] ) && (int) $p['form']['surum'] !== (int) $eski['surum'] ) {
		return new WP_Error( 'sides_cakisma', 'Form bu arada başka bir oturumda değiştirildi. Sayfayı yenileyip değişikliklerinizi yeniden yapın.', array( 'status' => 409 ) );
	}
	// formdan çıkarılan alanlar: eski kayıtlardaki değerleri ayrıntı ekranında adıyla gösterebilmek için
	$sil = array();
	foreach ( (array) $eski['silinen'] as $x ) {
		if ( is_array( $x ) && isset( $x['id'] ) ) {
			$sil[ $x['id'] ] = $x;
		}
	}
	$var = array();
	foreach ( $yeni['alanlar'] as $x ) {
		$var[ $x['id'] ] = 1;
		unset( $sil[ $x['id'] ] );
	}
	foreach ( $eski['alanlar'] as $x ) {
		if ( ! isset( $var[ $x['id'] ] ) && 'bolum' !== $x['tip'] ) {
			$sil[ $x['id'] ] = array( 'id' => $x['id'], 'etiket' => $x['etiket'], 'tip' => $x['tip'] );
		}
	}
	$yeni['silinen']    = array_slice( array_values( $sil ), -100 );
	$yeni['surum']      = (int) $eski['surum'] + 1;
	$yeni['guncelleme'] = sides_odsf_ms();
	if ( false === sides_put_doc( $org, 'ods', 'form', $yeni ) ) {
		return new WP_Error( 'sides_db', 'Form kaydedilemedi.', array( 'status' => 500 ) );
	}
	sides_odsf_kvkk_ozet( $org, $yeni );
	// sayfa görünümü ve kök yönlendirme (eski ods/ayar belgesinde)
	$s = isset( $p['sayfa'] ) && is_array( $p['sayfa'] ) ? $p['sayfa'] : null;
	$ne = array();
	if ( (bool) $eski['acik'] !== $yeni['acik'] ) {
		$ne[] = $yeni['acik'] ? 'form açıldı' : 'form kapatıldı';
	}
	if ( $s ) {
		$a  = sides_ods_ayar( $org );
		$a0 = $a;
		if ( isset( $s['logoTur'] ) && in_array( $s['logoTur'], array( 'kurum', 'yukle', 'yok', 'url' ), true ) ) {
			$a['logoTur'] = $s['logoTur'];
		}
		if ( isset( $s['logoG'] ) && is_string( $s['logoG'] ) && preg_match( '/^g[a-f0-9]{16,40}$/', $s['logoG'] ) ) {
			global $wpdb;
			$t = sides_docs();
			if ( $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE org = %d AND coll = 'gorsel' AND id = %s", $org, $s['logoG'] ) ) ) { // phpcs:ignore
				$a['logoG'] = $s['logoG'];
			}
		}
		if ( ( 'yukle' === $a['logoTur'] && ! $a['logoG'] ) || ( 'url' === $a['logoTur'] && ! $a['logoUrl'] ) ) {
			$a['logoTur'] = 'kurum';
		}
		if ( isset( $s['renk'] ) && is_string( $s['renk'] ) && isset( SIDES_ODS_RENKLER[ $s['renk'] ] ) ) {
			$a['renk'] = $s['renk'];
		}
		/* v7.3.1 güvenlik: sitenin kök adresini yönlendirmek tüm siteyi etkiler; yalnız site yöneticisi açıp kapatabilir */
		if ( sides_is_super() && isset( $s['yonlendir'] ) ) {
			$a['yonlendir'] = ! empty( $s['yonlendir'] );
			if ( $a['yonlendir'] ) {
				update_option( 'sides_ods_varsayilan', (int) $org, false );
			} elseif ( (int) get_option( 'sides_ods_varsayilan', 0 ) === (int) $org ) {
				delete_option( 'sides_ods_varsayilan' );
			}
			if ( (bool) $a0['yonlendir'] !== $a['yonlendir'] ) {
				$ne[] = $a['yonlendir'] ? 'ana sayfa yönlendirmesi açıldı' : 'ana sayfa yönlendirmesi kapatıldı';
			}
		}
		if ( $a !== $a0 ) {
			sides_put_doc( $org, 'ods', 'ayar', $a );
		}
	}
	sides_log( $org, 'ÖDS kayıt formu güncellendi' . ( $ne ? ': ' . implode( ', ', $ne ) : '' ) );
	return sides_odsf_yanit( sides_odsf_cikis( $org ) );
}
function sides_odsf_rest_onizleme( WP_REST_Request $req ) {
	$org = sides_org_id();
	$o   = sides_org( $org );
	$p   = $req->get_json_params();
	$p   = is_array( $p ) ? $p : array();
	$f   = sides_odsf_temizle( isset( $p['form'] ) ? $p['form'] : null, true );
	if ( is_wp_error( $f ) ) {
		return $f;
	}
	if ( ! $o ) {
		return new WP_Error( 'sides_yok', 'Kurum bulunamadı.', array( 'status' => 404 ) );
	}
	$f = array_merge( sides_odsf_varsayilan(), $f );
	return sides_odsf_yanit( array( 'html' => sides_odsf_html( $o, $f, sides_odsf_durum( $f, sides_odsf_say( $org ) ), true, isset( $p['sayfa'] ) && is_array( $p['sayfa'] ) ? $p['sayfa'] : null ) ) );
}

/* Herkese açık gönderim */
function sides_odsf_rest_basvuru( WP_REST_Request $req ) {
	$p = $req->get_json_params();
	if ( ! is_array( $p ) ) {
		return new WP_Error( 'sides_gecersiz', 'Geçersiz istek.', array( 'status' => 400 ) );
	}
	if ( ! sides_rl( 'ods_basvuru_deneme', 60, 600 ) ) {
		return new WP_Error( 'sides_limit', 'Çok fazla istek gönderildi. Birkaç dakika sonra tekrar deneyin.', array( 'status' => 429 ) );
	}
	$o = sides_org_by_key( isset( $p['o'] ) && is_string( $p['o'] ) ? $p['o'] : '' );
	if ( ! $o ) {
		return new WP_Error( 'sides_yok', 'Kurum bulunamadı.', array( 'status' => 404 ) );
	}
	$org = (int) $o->id;
	if ( function_exists( 'sides_gf_ods_form' ) && sides_gf_ods_form( $org ) ) {   // v7.9.25: ATLAS kayıt formu kapalı, başvurular Google Form'dan
		return new WP_Error( 'sides_kapali', 'Başvurular artık Google Form üzerinden alınıyor. Sayfayı yenileyin.', array( 'status' => 409 ) );
	}
	if ( ! empty( $p['web'] ) ) {
		return sides_odsf_yanit( array( 'ok' => true ) );   // bal küpü: bot gönderimi kaydedilmez, başarı gibi yanıtlanır
	}
	$ts   = isset( $p['ts'] ) ? (int) $p['ts'] : 0;
	$imza = isset( $p['imza'] ) && is_string( $p['imza'] ) ? $p['imza'] : '';
	if ( ! $ts || ! hash_equals( sides_odsf_imza( $org, $ts ), $imza ) || time() - $ts > 2 * DAY_IN_SECONDS ) {
		return new WP_Error( 'sides_sure', 'Sayfanın süresi doldu. Sayfayı yenileyip formu tekrar gönderin.', array( 'status' => 400 ) );
	}
	if ( time() - $ts < 3 ) {
		return new WP_Error( 'sides_hizli', 'Form çok hızlı gönderildi. Birkaç saniye bekleyip tekrar deneyin.', array( 'status' => 400 ) );
	}
	$f = sides_odsf_form( $org );
	if ( sides_org_blok( $o ) || empty( $f['acik'] ) ) {
		return new WP_Error( 'sides_kapali', 'Kayıt formu şu anda kapalı.', array( 'status' => 403 ) );
	}
	$islem = isset( $p['islemId'] ) && is_string( $p['islemId'] ) ? preg_replace( '/[^a-z0-9]/', '', strtolower( $p['islemId'] ) ) : '';
	if ( strlen( $islem ) < 12 ) {
		$islem = strtolower( wp_generate_password( 20, false, false ) );
	}
	$id = 'k' . substr( $islem, 0, 32 );
	if ( sides_get_doc( $org, 'odskayit', $id ) ) {
		return sides_odsf_yanit( array( 'ok' => true ) );   // aynı gönderim ikinci kez geldi (çift dokunma, ağ tekrarı): yeni kayıt açılmaz
	}
	$kilit = function_exists( 'sides_takip_kilit' ) ? sides_takip_kilit( 'odsf|' . $org ) : '';
	if ( false === $kilit ) {
		return new WP_Error( 'sides_mesgul', 'Şu anda çok sayıda kayıt alınıyor. Birkaç saniye sonra tekrar deneyin.', array( 'status' => 503 ) );
	}
	$bitir = function ( $r ) use ( $kilit ) {
		if ( $kilit && function_exists( 'sides_takip_kilit_birak' ) ) {
			sides_takip_kilit_birak( $kilit );
		}
		return $r;
	};
	$say   = sides_odsf_say( $org );
	$durum = sides_odsf_durum( $f, $say );
	if ( $durum['kapandi'] ) {
		return $bitir( new WP_Error( 'sides_kapandi', 'Kayıtlar kapandı.', array( 'status' => 403 ) ) );
	}
	if ( $durum['dolu'] ) {
		return $bitir( new WP_Error( 'sides_dolu', 'Kontenjan doldu. İlginiz için teşekkür ederiz.', array( 'status' => 403 ) ) );
	}
	$v = sides_odsf_dogrula( $f, isset( $p['c'] ) ? $p['c'] : array(), isset( $p['d'] ) ? $p['d'] : array(), false, $say );
	if ( is_wp_error( $v ) ) {
		return $bitir( $v );
	}
	if ( ! sides_rl( 'ods_basvuru', 10, 600 ) ) {   // IP başına 10 dakikada 10 kayıt (kardeş kaydına yeter)
		return $bitir( new WP_Error( 'sides_limit', 'Bu bağlantıdan kısa sürede çok fazla kayıt gönderildi. 10 dakika sonra tekrar deneyin.', array( 'status' => 429 ) ) );
	}
	$ms = sides_odsf_ms();
	$d  = array(
		'c'      => $v['c'],
		'o'      => $v['o'],
		't'      => $ms,
		'kvkk'   => array( 't' => $ms, 'h' => sides_odsf_kvkk_ozet( $org, $f ) ),
		'surum'  => (int) $f['surum'],
		'adayId' => '',
	);
	$ok = sides_put_doc( $org, 'odskayit', $id, $d );
	$bitir( null );
	if ( false === $ok ) {
		return new WP_Error( 'sides_db', 'Kayıt kaydedilemedi. Lütfen tekrar deneyin.', array( 'status' => 500 ) );
	}
	return sides_odsf_yanit( array( 'ok' => true ) );
}

/* Gözlemci: adlar kısaltılır; telefon, uzun metin ve tarihler gizlenir; formdan çıkarılmış alanlar gönderilmez */
function sides_odsf_maskele( $f, $c ) {
	$out = array();
	foreach ( $f['alanlar'] as $a ) {
		if ( ! isset( $c[ $a['id'] ] ) ) {
			continue;
		}
		$v = $c[ $a['id'] ];
		switch ( $a['tip'] ) {
			case 'kisa':
				$out[ $a['id'] ] = sides_mask_name( is_scalar( $v ) ? $v : '' );
				break;
			case 'telefon':
				$out[ $a['id'] ] = '';
				break;
			case 'uzun':
			case 'tarih':
				$out[ $a['id'] ] = '' === $v ? '' : '•••';
				break;
			default:
				$out[ $a['id'] ] = $v;
		}
	}
	return $out;
}
function sides_odsf_kayit_cikis( $id, $d, $f, $mask ) {
	$c = isset( $d['c'] ) && is_array( $d['c'] ) ? $d['c'] : array();
	return array(
		'id'     => (string) $id,
		'c'      => $mask ? sides_odsf_maskele( $f, $c ) : $c,
		'o'      => isset( $d['o'] ) && is_array( $d['o'] ) ? $d['o'] : array(),
		't'      => isset( $d['t'] ) ? (int) $d['t'] : 0,
		'kvkk'   => isset( $d['kvkk'] ) && is_array( $d['kvkk'] ) ? $d['kvkk'] : null,
		'adayId' => $mask ? '' : ( isset( $d['adayId'] ) ? (string) $d['adayId'] : '' ),
		'duz'    => isset( $d['duz'] ) && is_array( $d['duz'] ) ? array( 't' => (int) $d['duz']['t'], 'u' => $mask ? sides_mask_name( (string) $d['duz']['u'] ) : (string) $d['duz']['u'] ) : null,
	);
}
function sides_odsf_rest_liste() {
	$org  = sides_org_id();
	$mask = sides_is_observer();
	$f    = sides_odsf_form( $org );
	$out  = array();
	$ham  = array();
	$say  = array();
	foreach ( sides_odsf_satirlar( $org ) as $r ) {
		$d = json_decode( $r->data, true );
		if ( is_array( $d ) ) {
			$an          = sides_odsf_tekrar_anahtar( $d );
			$ham[]       = array( $r->id, $d, $an );
			$say[ $an ]  = ( isset( $say[ $an ] ) ? $say[ $an ] : 0 ) + 1;
		}
	}
	foreach ( $ham as $x ) {   // tk: aynı öğrenci adı + veli telefonuyla kaç kayıt var (tekrar uyarısı; maskeli görünümde de çalışır)
		$o       = sides_odsf_kayit_cikis( $x[0], $x[1], $f, $mask );
		$o['tk'] = '' !== $x[2] && $say[ $x[2] ] > 1 ? $say[ $x[2] ] : 0;
		$out[]   = $o;
	}
	$k = sides_get_doc( $org, 'ods', 'kvkk' );
	unset( $k['id'] );
	return sides_odsf_yanit( array(
		'form'     => $f,
		'kayitlar' => $out,
		'kvkk'     => $mask ? new stdClass() : ( is_array( $k ) && $k ? $k : new stdClass() ),
		'maske'    => $mask,
		'yaz'      => ! $mask && sides_can( 'kayit', 2 ) && ( ! function_exists( 'sides_sayfa_herhangi' ) || sides_sayfa_herhangi( array( 'kayit.odsliste' ), 2 ) ),
		'aktar'    => ! $mask && sides_can( 'kayit', 2 ) && sides_can( 'crm', 2 ),
	) );
}
function sides_odsf_rest_duzenle( WP_REST_Request $req ) {
	$org = sides_org_id();
	$id  = (string) $req['id'];
	$d   = sides_get_doc( $org, 'odskayit', $id );
	if ( ! $d ) {
		return new WP_Error( 'sides_yok', 'Kayıt bulunamadı; silinmiş olabilir.', array( 'status' => 404 ) );
	}
	$p = $req->get_json_params();
	$p = is_array( $p ) ? $p : array();
	$f = sides_odsf_form( $org );
	$v = sides_odsf_dogrula( $f, isset( $p['c'] ) ? $p['c'] : array(), isset( $p['d'] ) ? $p['d'] : array(), true );
	if ( is_wp_error( $v ) ) {
		return $v;
	}
	unset( $d['id'] );
	$c = isset( $d['c'] ) && is_array( $d['c'] ) ? $d['c'] : array();
	$o = isset( $d['o'] ) && is_array( $d['o'] ) ? $d['o'] : array();
	foreach ( $f['alanlar'] as $a ) {   // formdaki alanlar yeni değerle değişir; formdan çıkarılmış alanların eski değerleri korunur
		if ( 'bolum' === $a['tip'] || 'kvkk' === $a['tip'] ) {
			continue;
		}
		unset( $c[ $a['id'] ], $o[ $a['id'] ] );
		if ( isset( $v['c'][ $a['id'] ] ) ) {
			$c[ $a['id'] ] = $v['c'][ $a['id'] ];
		}
		if ( isset( $v['o'][ $a['id'] ] ) ) {
			$o[ $a['id'] ] = $v['o'][ $a['id'] ];
		}
	}
	$d['c']   = $c;
	$d['o']   = $o;
	$u        = wp_get_current_user();
	$d['duz'] = array( 't' => sides_odsf_ms(), 'u' => $u ? $u->display_name : '' );
	if ( false === sides_put_doc( $org, 'odskayit', $id, $d ) ) {
		return new WP_Error( 'sides_db', 'Kayıt güncellenemedi.', array( 'status' => 500 ) );
	}
	sides_log( $org, 'ÖDS kaydı düzenlendi: ' . sides_mask_name( isset( $c['ogrenciAd'] ) ? $c['ogrenciAd'] : '' ) );
	return sides_odsf_yanit( array( 'kayit' => sides_odsf_kayit_cikis( $id, $d, $f, false ) ) );
}
function sides_odsf_rest_sil( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$id  = (string) $req['id'];
	$d   = sides_get_doc( $org, 'odskayit', $id );
	if ( ! $d ) {
		return new WP_Error( 'sides_yok', 'Kayıt bulunamadı; silinmiş olabilir.', array( 'status' => 404 ) );
	}
	$wpdb->delete( sides_docs(), array( 'org' => $org, 'coll' => 'odskayit', 'id' => $id ) );
	sides_log( $org, 'ÖDS kaydı silindi: ' . sides_mask_name( isset( $d['c']['ogrenciAd'] ) ? $d['c']['ogrenciAd'] : '' ) );
	return sides_odsf_yanit( array( 'ok' => true ) );
}
function sides_odsf_idler( $p ) {
	$ids = isset( $p['ids'] ) && is_array( $p['ids'] ) ? $p['ids'] : null;
	if ( null === $ids ) {
		return null;
	}
	$out = array();
	foreach ( array_slice( $ids, 0, 5000 ) as $x ) {
		if ( is_string( $x ) && preg_match( '/^k[a-z0-9]{6,40}$/', $x ) ) {
			$out[ $x ] = 1;
		}
	}
	return $out;
}
function sides_odsf_rest_disa( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	$ids = sides_odsf_idler( is_array( $p ) ? $p : array() );
	$f   = sides_odsf_form( $org );
	$out = array();
	foreach ( sides_odsf_satirlar( $org ) as $r ) {
		if ( null !== $ids && ! isset( $ids[ $r->id ] ) ) {
			continue;
		}
		$d = json_decode( $r->data, true );
		if ( is_array( $d ) ) {
			$out[] = sides_odsf_kayit_cikis( $r->id, $d, $f, false );
		}
	}
	sides_log( $org, 'ÖDS aday listesi dışa aktarıldı (' . count( $out ) . ' kayıt)' );
	return sides_odsf_yanit( array( 'form' => $f, 'kayitlar' => $out ) );
}
function sides_odsf_rest_aktar( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$p   = $req->get_json_params();
	$ids = sides_odsf_idler( is_array( $p ) ? $p : array() );
	if ( ! $ids ) {
		return new WP_Error( 'sides_gecersiz', 'Aktarılacak kayıt seçin.', array( 'status' => 400 ) );
	}
	if ( count( $ids ) > 1000 ) {
		return new WP_Error( 'sides_gecersiz', 'Bir seferde en fazla 1000 kayıt aktarılabilir.', array( 'status' => 400 ) );
	}
	$t      = sides_docs();
	$adaylar = array();
	foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = 'adaylar'", $org ) ) as $r ) { // phpcs:ignore
		$a = json_decode( $r->data, true );
		if ( is_array( $a ) ) {
			$adaylar[ $r->id ] = sides_odsf_ad_anahtar( isset( $a['ad'] ) ? $a['ad'] : '' ) . '|' . substr( preg_replace( '/\D/', '', isset( $a['telefon'] ) ? (string) $a['telefon'] : '' ), -10 );
		}
	}
	$f   = sides_odsf_form( $org );
	$ot  = '';
	foreach ( $f['alanlar'] as $x ) {
		if ( 'oturum' === $x['id'] ) {
			$ot = $x['etiket'];
		}
	}
	$u   = wp_get_current_user();
	$ms  = sides_odsf_ms();
	$sonuc = array( 'yeni' => 0, 'bagli' => 0, 'zaten' => 0, 'eslesme' => array() );
	$i   = 0;
	foreach ( array_keys( $ids ) as $kid ) {
		$d = sides_get_doc( $org, 'odskayit', $kid );
		if ( ! $d ) {
			continue;
		}
		unset( $d['id'] );
		if ( ! empty( $d['adayId'] ) && isset( $adaylar[ $d['adayId'] ] ) ) {
			$sonuc['zaten']++;
			$sonuc['eslesme'][ $kid ] = $d['adayId'];
			continue;
		}
		$c   = isset( $d['c'] ) && is_array( $d['c'] ) ? $d['c'] : array();
		$ad  = isset( $c['ogrenciAd'] ) ? (string) $c['ogrenciAd'] : '';
		$tel = isset( $c['veliTel'] ) ? (string) $c['veliTel'] : '';
		if ( '' === $ad ) {
			continue;
		}
		$an  = sides_odsf_ad_anahtar( $ad ) . '|' . substr( preg_replace( '/\D/', '', $tel ), -10 );
		$aid = array_search( $an, $adaylar, true );
		if ( false !== $aid ) {
			$sonuc['bagli']++;
		} else {
			$sinif = isset( $c['sinif'] ) && preg_match( '/\b([3-8])\b/', (string) $c['sinif'], $m ) ? $m[1] : '';
			$not   = 'ÖDS kaydı' . ( isset( $c['oturum'] ) && is_string( $c['oturum'] ) ? ' · ' . ( $ot ? $ot . ': ' : '' ) . $c['oturum'] : '' ) . ' · ' . wp_date( 'd.m.Y H:i', (int) floor( ( isset( $d['t'] ) ? (int) $d['t'] : $ms ) / 1000 ) );
			$aid   = 'a' . base_convert( (string) ( $ms + $i ), 10, 36 ) . wp_rand( 100, 999 );
			$i++;
			sides_put_doc( $org, 'adaylar', $aid, array(
				'ad'        => $ad,
				'veliAd'    => isset( $c['veliAd'] ) && is_string( $c['veliAd'] ) ? $c['veliAd'] : '',
				'telefon'   => $tel,
				'sinif'     => $sinif,
				'okul'      => isset( $c['okul'] ) && is_string( $c['okul'] ) ? $c['okul'] : '',
				'durum'     => 'yeni',
				'kaynak'    => 'ÖDS kayıt formu',
				'kanal'     => 'ods',
				'notlar'    => array( array( 't' => $ms, 'm' => $not, 'u' => $u ? $u->display_name : 'ÖDS' ) ),
				'olusturma' => isset( $d['t'] ) ? (int) $d['t'] : $ms,
				'studentId' => '',
				'gorusme'   => '',
			) );
			$adaylar[ $aid ] = $an;
			$sonuc['yeni']++;
		}
		$d['adayId'] = $aid;
		sides_put_doc( $org, 'odskayit', $kid, $d );
		$sonuc['eslesme'][ $kid ] = $aid;
	}
	sides_log( $org, 'ÖDS kayıtları adaylara aktarıldı: ' . $sonuc['yeni'] . ' yeni aday, ' . $sonuc['bagli'] . ' mevcut adayla eşleşti' );
	return sides_odsf_yanit( $sonuc );
}
