<?php
/**
 * v7 · Beceri sınavı (exam.tur = 'beceri'): okutma linkine giden bölüm yapısı (cevap anahtarı ve madde cevapları olmadan)
 * ve okutulan cevap dizisinin satır satır denetimi. İstemcideki bcBolumler / bcSatirlar (src/beceri.js) ile aynı kurallar.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function sides_beceri_mi( $e ) {
	return is_array( $e ) && isset( $e['tur'] ) && 'beceri' === $e['tur'] && isset( $e['beceri']['bolumler'] ) && is_array( $e['beceri']['bolumler'] );
}

function sides_beceri_sayi( $v, $d, $a, $b ) {
	return is_numeric( $v ) ? max( $a, min( $b, (float) $v ) ) : $d;
}

/* Bölümler: en çok 8; seçmeli bölümde soru puanları, sayısal bölümde sütun adı ve madde sayısı */
function sides_beceri_bolumler( $e ) {
	$renk = array( 'mavi', 'yesil', 'turuncu', 'mor', 'kirmizi', 'turkuaz', 'pembe', 'gri' );
	$out  = array();
	foreach ( array_values( array_slice( (array) $e['beceri']['bolumler'], 0, 8 ) ) as $i => $b ) {
		if ( ! is_array( $b ) ) {
			continue;
		}
		$tur = ( isset( $b['tur'] ) && 'sayisal' === $b['tur'] ) ? 'sayisal' : 'secmeli';
		$o   = array(
			'kod'     => mb_substr( isset( $b['kod'] ) ? (string) $b['kod'] : '', 0, 3 ),
			'ad'      => mb_substr( isset( $b['ad'] ) ? (string) $b['ad'] : '', 0, 60 ),
			'renk'    => ( isset( $b['renk'] ) && in_array( $b['renk'], $renk, true ) ) ? $b['renk'] : $renk[ $i % 8 ],
			'tur'     => $tur,
			'katsayi' => sides_beceri_sayi( isset( $b['katsayi'] ) ? $b['katsayi'] : 1, 1, 0, 100 ),
		);
		if ( 'sayisal' === $tur ) {
			$o['sutunlar'] = array();
			foreach ( array_slice( isset( $b['sutunlar'] ) ? (array) $b['sutunlar'] : array(), 0, 6 ) as $s ) {
				$s               = is_array( $s ) ? $s : array();
				$o['sutunlar'][] = array(
					'ad'   => mb_substr( isset( $s['ad'] ) ? (string) $s['ad'] : '', 0, 40 ),
					'soru' => (int) round( sides_beceri_sayi( isset( $s['soru'] ) ? $s['soru'] : 20, 20, 1, 99 ) ),
					'puan' => sides_beceri_sayi( isset( $s['puan'] ) ? $s['puan'] : 1, 1, 0, 100 ),
				);
			}
		} else {
			$o['secenek'] = ( isset( $b['secenek'] ) && 5 === (int) $b['secenek'] ) ? 5 : 4;
			$o['yanlis']  = ( isset( $b['yanlis'] ) && in_array( $b['yanlis'], array( 'yok', 'y3', 'y4' ), true ) ) ? $b['yanlis'] : 'yok';
			$o['sorular'] = array();
			foreach ( array_slice( isset( $b['sorular'] ) ? (array) $b['sorular'] : array(), 0, 60 ) as $q ) {
				$o['sorular'][] = array( 'puan' => sides_beceri_sayi( is_array( $q ) && isset( $q['puan'] ) ? $q['puan'] : 1, 1, 0, 100 ) );
			}
		}
		$out[] = $o;
	}
	return $out;
}

/* Okutma linki (sides_scan_exam_public) için özet */
function sides_beceri_public( $e ) {
	return array(
		'surum'    => 1,
		'yuzluk'   => ! ( isset( $e['beceri']['yuzluk'] ) && false === $e['beceri']['yuzluk'] ),
		'bolumler' => sides_beceri_bolumler( $e ),
		'numara'   => isset( $e['beceri']['numara'] ) && 'surekli' === $e['beceri']['numara'] ? 'surekli' : 'bolum',   // v7.0.1 sürekli soru numarası (yalnız görünüm)
	);
}

/* Cevap dizisi: her optik satır kendi şık setinden bir karakter ya da '-' (boş), '*' (çift işaret) */
function sides_beceri_cevap_gecerli( $e, $cevap ) {
	$izin = array();
	foreach ( sides_beceri_bolumler( $e ) as $b ) {
		if ( 'sayisal' === $b['tur'] ) {
			foreach ( $b['sutunlar'] as $s ) {
				if ( $s['soru'] >= 10 ) {
					$izin[] = substr( '0123456789', 0, intdiv( $s['soru'], 10 ) + 1 );
					$izin[] = '0123456789';
				} else {
					$izin[] = substr( '0123456789', 0, $s['soru'] + 1 );
				}
			}
		} else {
			foreach ( $b['sorular'] as $q ) {
				$izin[] = 5 === $b['secenek'] ? 'ABCDE' : 'ABCD';
			}
		}
	}
	$cevap = (string) $cevap;
	if ( ! $izin || strlen( $cevap ) !== count( $izin ) ) {
		return false;
	}
	foreach ( $izin as $i => $h ) {
		$c = $cevap[ $i ];
		if ( '-' !== $c && '*' !== $c && false === strpos( $h, $c ) ) {
			return false;
		}
	}
	return true;
}
