<?php
/**
 * ATLAS REST uçları. Her istek, giriş yapan kullanıcının kurum alanıyla sınırlıdır.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function sides_deny( $m = 'Bu işlem için yetkiniz yok. Yöneticinizden izin isteyin.' ) {
	return new WP_Error( 'sides_yetki', $m, array( 'status' => is_user_logged_in() ? 403 : 401 ) );
}

/* Yazma yetkisi: hangi koleksiyon hangi modüle bağlı */
function sides_can_write_coll( $coll ) {
	switch ( $coll ) {
		case 'students':
			return sides_can( 'kayit', 2 ) || sides_can( 'crm', 2 ) || sides_can( 'nehari', 2 );
		case 'exams':
			return sides_can( 'sinav', 2 ) || sides_can( 'nehari', 2 );
		case 'results':
			return sides_can( 'karne', 2 ) || sides_can( 'nehari', 2 );
		case 'settings':
			return sides_can( 'sinav', 2 ) || sides_can( 'crm', 2 ) || sides_can( 'analiz', 2 ) || sides_can( 'test', 2 ) || sides_can( 'nehari', 2 );
		case 'duyurular':
			return sides_can( 'sistem', 2 );
		case 'adaylar':
			return sides_can( 'crm', 2 );
		case 'takvim':
			return sides_can( 'takvim', 2 ) || sides_can( 'sinav', 2 );
		case 'testler':
		case 'tsonuc':
			return sides_can( 'test', 2 ) || sides_can( 'nehari', 2 );
		case 'havuz':
			return sides_can( 'havuz', 2 ) || sides_can( 'nehari', 2 );
		case 'lgs':   // LGS hedefleri: Deneme modülü
			return sides_can( 'sinav', 2 );
		case 'etut':  // Takip modülü
		case 'izin':
		case 'kitap':
		case 'takviye':
		case 'seviye':
		case 'dgrup':
		case 'hedef':
		case 'hsablon':
		case 'workwin':
		case 'sgunluk':
		case 'tklink':
		case 'yoklama':
		case 'kutuphane':   // v7.9.5: kütüphane kitap listesi
		case 'odev':     // v6: ödev takibi
		case 'dplan':    // v6: haftalık ders planı
		case 'doturum':  // v6: tarihli ders oturumu
			return sides_can( 'takip', 2 );
		case 'pkriter':  // Puan sistemi ve TV
		case 'phareket':
		case 'pgun':
		case 'podul':
		case 'tv':
			return sides_can( 'puan', 2 );
		case 'rsablon':  // Yönetim raporları
		case 'rapor':
			return sides_can( 'rapor', 2 );
		case 'birlesik':  // Analiz: birleşik deneme seçimleri, veli raporu bağlantıları
		case 'velirapor':
			return sides_can( 'analiz', 2 );
	}
	return false;
}

/* Nehari bölümü: 3, 4 ve N5. sınıfların öğrencileri, sınavları, testleri, soruları ve sonuçları "nehari" yetkisine,
   diğer sınıflarınki kendi modülünün yetkisine bağlıdır. Kaydın eski ve yeni hâli ayrı ayrı denetlenir. */
/* N5: Nehari'nin 5. sınıfları (okulun diğer 5. sınıflarından ayrı) */
function sides_neh_sinif( $s ) {
	return in_array( strtoupper( trim( (string) $s ) ), array( '3', '4', 'N5' ), true );
}
function sides_kayit_sinifi( $org, $coll, $d ) {
	if ( ! is_array( $d ) ) {
		return null;
	}
	if ( in_array( $coll, array( 'exams', 'testler', 'havuz' ), true ) ) {
		return isset( $d['sinif'] ) ? (string) $d['sinif'] : '';
	}
	if ( 'results' === $coll || 'tsonuc' === $coll ) {
		$ref = 'results' === $coll ? 'examId' : 'testId';
		$e   = ! empty( $d[ $ref ] ) ? sides_get_doc( $org, 'results' === $coll ? 'exams' : 'testler', (string) $d[ $ref ] ) : null;
		if ( $e && isset( $e['sinif'] ) ) {
			return (string) $e['sinif'];
		}
		return isset( $d['ogr']['sinif'] ) ? (string) $d['ogr']['sinif'] : '';
	}
	return null;
}
function sides_bolum_yetkisi( $coll, $sinif ) {
	$mod = array( 'exams' => 'sinav', 'results' => 'karne', 'testler' => 'test', 'tsonuc' => 'test', 'havuz' => 'havuz' );
	if ( ! isset( $mod[ $coll ] ) ) {
		return null;
	}
	return sides_neh_sinif( $sinif ) ? 'nehari' : $mod[ $coll ];
}
function sides_bolum_denetimi( $org, $coll, $id, $yeni ) {
	// Öğrenciler: Nehari öğrencisini (3, 4, N5) Nehari yetkilisi de kaydeder; diğer öğrenciler yalnızca Kayıt / Aday Takip yetkisiyle
	if ( 'students' === $coll ) {
		foreach ( array( sides_get_doc( $org, 'students', $id ), $yeni ) as $d ) {
			if ( ! is_array( $d ) ) {
				continue;
			}
			$neh = sides_neh_sinif( isset( $d['sinif'] ) ? $d['sinif'] : '' );
			if ( ! ( sides_can( 'kayit', 2 ) || sides_can( 'crm', 2 ) || ( $neh && sides_can( 'nehari', 2 ) ) ) ) {
				return sides_deny( $neh ? 'Bu işlem için yetkiniz yok. Yöneticinizden izin isteyin.' : 'Nehari yetkisiyle yalnızca 3, 4 ve N5. sınıf öğrencileri kaydedilebilir.' );
			}
		}
		return null;
	}
	if ( ! in_array( $coll, array( 'exams', 'results', 'testler', 'tsonuc', 'havuz' ), true ) ) {
		return null;
	}
	foreach ( array( sides_get_doc( $org, $coll, $id ), $yeni ) as $d ) {
		$s = sides_kayit_sinifi( $org, $coll, $d );
		if ( null === $s ) {
			continue;
		}
		$gerek = sides_bolum_yetkisi( $coll, $s );
		if ( ! sides_can( $gerek, 2 ) ) {
			return sides_deny( 'nehari' === $gerek ? 'Nehari (3, 4 ve N5. sınıf) kayıtları için yetkiniz yok. Yöneticinizden izin isteyin.' : 'Bu işlem için yetkiniz yok. Yöneticinizden izin isteyin.' );
		}
	}
	return null;
}

/* Okutma bağlamı: okutma linki (token) ya da okutma yetkisi olan oturum.
   tip: 'okutucu' yalnızca okutup kaydeder (cevap, kitapçık ve elle giriş kapalı), 'yonetici' okunan cevapları da düzeltebilir. */
function sides_scan_ctx( WP_REST_Request $req ) {
	$tok = preg_replace( '/[^a-f0-9]/', '', strtolower( (string) $req->get_param( 't' ) ) );
	if ( 32 === strlen( $tok ) ) {
		return sides_okut_token( $tok );
	}
	$c = sides_ctx();
	if ( ! $c['org'] ) {
		return null;
	}
	if ( 'yonetici' === $c['rol'] || ( 'personel' === $c['rol'] && ( $c['yetki']['karne'] >= 2 || $c['yetki']['test'] >= 2 || $c['yetki']['nehari'] >= 2 ) ) ) {
		return array( 'org' => (int) $c['org'], 'exams' => null, 'tip' => 'yonetici', 'oturum' => 1 );
	}
	if ( 'ogretmen' === $c['rol'] ) {
		return array( 'org' => (int) $c['org'], 'exams' => null, 'tip' => 'okutucu', 'oturum' => 1 );
	}
	return null;
}
/* Sınav veya test satırındaki token okutucu linkidir (eski linkler de böyle çalışır); yönetici linkleri 'okutlink' satırlarında tutulur. */
function sides_okut_token( $tok ) {
	global $wpdb;
	$tok = preg_replace( '/[^a-f0-9]/', '', strtolower( (string) $tok ) );
	if ( 32 !== strlen( $tok ) ) {
		return null;
	}
	$t   = sides_docs();
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT org, coll, id, exam_id FROM $t WHERE token = %s AND coll IN ('exams','testler','okutlink') LIMIT 1", $tok ) ); // phpcs:ignore
	if ( ! $row || sides_org_blok( sides_org( (int) $row->org ) ) ) {
		return null;
	}
	$yon = 'okutlink' === $row->coll;
	/* v7.4: yönetici linkleri (kurum geneli 'kurum' satırı ve eski deneme bazlı satırlar) kurumun bütün deneme ve testlerini okutur;
	   okutucu linki yalnız kendi sınavını okutur. Okutma kapatılmış sınavlar her iki linkte de okutulamaz. */
	return array( 'org' => (int) $row->org, 'exams' => $yon ? null : array( $row->id ), 'tip' => $yon ? 'yonetici' : 'okutucu' );
}
/* v7.4: kurum geneli yönetici okutma linkini kimler oluşturup görebilir: kurum yöneticisi ya da sınıf kısıtı olmadan
   karne, test ve Nehari modüllerinde tam yetkili personel (link bütün deneme ve testleri okuttuğu için) */
function sides_okut_kurum_yetki() {
	if ( sides_is_observer() ) {
		return false;
	}
	$c = sides_ctx();
	if ( 'yonetici' === $c['rol'] ) {
		return true;
	}
	return 'personel' === $c['rol'] && null === sides_sinif_kisit() && sides_can( 'karne', 2 ) && sides_can( 'test', 2 ) && sides_can( 'nehari', 2 );
}
/* Kurumun yönetici okutma linki: 'kurum' satırı; yoksa en yeni eski (deneme bazlı) yönetici linki */
function sides_okut_kurum_token( $org ) {
	global $wpdb;
	$t = sides_docs();
	$k = $wpdb->get_var( $wpdb->prepare( "SELECT token FROM $t WHERE org = %d AND coll = 'okutlink' AND id = 'kurum' LIMIT 1", $org ) ); // phpcs:ignore
	if ( $k ) {
		return (string) $k;
	}
	$k = $wpdb->get_var( $wpdb->prepare( "SELECT token FROM $t WHERE org = %d AND coll = 'okutlink' AND token IS NOT NULL ORDER BY updated_at DESC LIMIT 1", $org ) ); // phpcs:ignore
	return $k ? (string) $k : null;
}

add_action( 'rest_api_init', function () {
	$ns    = 'optik-karne/v1';
	$panel = function () {
		return sides_is_panel() ? true : sides_deny( 'Oturum açmanız gerekiyor.' );
	};
	$write = function ( WP_REST_Request $req ) {
		if ( ! sides_is_panel() ) {
			return sides_deny( 'Oturum açmanız gerekiyor.' );
		}
		if ( sides_is_observer() ) {
			return sides_deny( 'Gözlemci hesabının işlem yetkisi yok. Yöneticinizden izin isteyin.' );
		}
		return sides_can_write_coll( $req['coll'] ) ? true : sides_deny();
	};
	$karne = function () {
		if ( sides_is_observer() ) {
			return sides_deny( 'Gözlemci hesabının işlem yetkisi yok. Yöneticinizden izin isteyin.' );
		}
		return ( sides_can( 'karne', 2 ) || sides_can( 'nehari', 2 ) ) ? true : sides_deny();
	};
	$editor = function () {
		return ( sides_is_panel() && ! sides_is_observer() ) ? true : sides_deny();
	};
	$admin = function () {
		return 'yonetici' === sides_ctx()['rol'] ? true : sides_deny( 'Kullanıcıları yalnızca yönetici düzenleyebilir.' );
	};
	$scan = function ( WP_REST_Request $req ) {
		return null !== sides_scan_ctx( $req ) ? true : sides_deny();
	};
	register_rest_route( $ns, '/all', array( 'methods' => 'GET', 'callback' => 'sides_rest_all', 'permission_callback' => $panel ) );
	register_rest_route( $ns, '/results', array( 'methods' => 'GET', 'callback' => 'sides_rest_results', 'permission_callback' => $panel ) );
	register_rest_route( $ns, '/doc/(?P<coll>students|exams|results|settings|duyurular|adaylar|takvim|testler|havuz|tsonuc|lgs|etut|izin|kitap|kutuphane|takviye|seviye|dgrup|yoklama|odev|dplan|doturum|hedef|hsablon|workwin|sgunluk|pkriter|phareket|pgun|podul|tv|rsablon|rapor|birlesik|velirapor|tklink)/(?P<id>[A-Za-z0-9_\-]{1,64})', array(
		array( 'methods' => 'PUT, POST', 'callback' => 'sides_rest_put', 'permission_callback' => $write ),
		array( 'methods' => 'DELETE', 'callback' => 'sides_rest_delete', 'permission_callback' => $write ),
	) );
	register_rest_route( $ns, '/links', array( 'methods' => 'POST', 'callback' => 'sides_rest_links', 'permission_callback' => $karne ) );
	register_rest_route( $ns, '/log', array(
		array( 'methods' => 'GET', 'callback' => 'sides_rest_log', 'permission_callback' => $panel ),
		array( 'methods' => 'POST', 'callback' => 'sides_rest_log_add', 'permission_callback' => $editor ),
	) );
	register_rest_route( $ns, '/history', array( 'methods' => 'GET', 'callback' => 'sides_rest_history', 'permission_callback' => $panel ) );
	register_rest_route( $ns, '/okut-link', array( 'methods' => 'POST', 'callback' => 'sides_rest_okut_link', 'permission_callback' => function () {
		if ( sides_is_observer() ) {
			return sides_deny( 'Gözlemci hesabının işlem yetkisi yok. Yöneticinizden izin isteyin.' );
		}
		return ( sides_can( 'karne', 2 ) || sides_can( 'test', 2 ) || sides_can( 'nehari', 2 ) ) ? true : sides_deny();
	} ) );
	register_rest_route( $ns, '/tsonuc', array( 'methods' => 'GET', 'callback' => 'sides_rest_tsonuc', 'permission_callback' => $panel ) );
	register_rest_route( $ns, '/havuz', array( 'methods' => 'GET', 'callback' => 'sides_rest_havuz', 'permission_callback' => $panel ) );
	register_rest_route( $ns, '/gorsel', array( 'methods' => 'POST', 'callback' => 'sides_rest_gorsel_add', 'permission_callback' => function () {
		if ( sides_is_observer() ) {
			return sides_deny( 'Gözlemci hesabının işlem yetkisi yok. Yöneticinizden izin isteyin.' );
		}
		return ( sides_can( 'test', 2 ) || sides_can( 'havuz', 2 ) || sides_can( 'nehari', 2 ) || sides_can( 'takip', 2 ) || sides_can( 'puan', 2 ) || sides_can( 'sosyal', 2 ) ) ? true : sides_deny();   // v7.9.15 sosyal: yarışma sorusu görseli
	} ) );
	/* Dosyadan soru yükleme: soruların görselleri ve kayıtları tek istekte (en fazla 25 soru) */
	register_rest_route( $ns, '/havuz/toplu', array( 'methods' => 'POST', 'callback' => 'sides_rest_havuz_toplu', 'permission_callback' => function () {
		if ( ! sides_is_panel() ) {
			return sides_deny( 'Oturum açmanız gerekiyor.' );
		}
		if ( sides_is_observer() ) {
			return sides_deny( 'Gözlemci hesabının işlem yetkisi yok. Yöneticinizden izin isteyin.' );
		}
		return ( sides_can( 'havuz', 2 ) || sides_can( 'nehari', 2 ) ) ? true : sides_deny();
	} ) );
	register_rest_route( $ns, '/gorsel/(?P<id>g[a-f0-9]{16,40})', array(
		array( 'methods' => 'GET', 'callback' => 'sides_rest_gorsel_get', 'permission_callback' => $panel ),
		array( 'methods' => 'DELETE', 'callback' => 'sides_rest_gorsel_del', 'permission_callback' => function () {
			return ( ! sides_is_observer() && ( sides_can( 'test', 2 ) || sides_can( 'havuz', 2 ) || sides_can( 'nehari', 2 ) || sides_can( 'takip', 2 ) || sides_can( 'puan', 2 ) || sides_can( 'sosyal', 2 ) ) ) ? true : sides_deny();
		} ),
	) );
	register_rest_route( $ns, '/users', array(
		array( 'methods' => 'GET', 'callback' => 'sides_rest_users', 'permission_callback' => $admin ),
		array( 'methods' => 'POST', 'callback' => 'sides_rest_user_add', 'permission_callback' => $admin ),
	) );
	register_rest_route( $ns, '/users/(?P<id>\d+)/guvenlik', array(
		array( 'methods' => 'GET', 'callback' => 'sides_rest_guvenlik', 'permission_callback' => $admin ),
		array( 'methods' => 'POST', 'callback' => 'sides_rest_guvenlik_islem', 'permission_callback' => $admin ),
	) );
	/* Oturum yoklaması: başka cihazda açılan oturum yüzünden kapanan oturumu uygulama hemen fark eder */
	register_rest_route( $ns, '/oturum', array( 'methods' => 'GET', 'callback' => function () {
		return array( 'ok' => true );
	}, 'permission_callback' => $panel ) );
	register_rest_route( $ns, '/users/(?P<id>\d+)', array(
		array( 'methods' => 'PUT, POST', 'callback' => 'sides_rest_user_edit', 'permission_callback' => $admin ),
		array( 'methods' => 'DELETE', 'callback' => 'sides_rest_user_remove', 'permission_callback' => $admin ),
	) );
	register_rest_route( $ns, '/profil', array( 'methods' => 'POST', 'callback' => 'sides_rest_profil', 'permission_callback' => function () {
		return sides_ctx()['org'] ? true : sides_deny( 'Oturum açmanız gerekiyor.' );
	} ) );
	register_rest_route( $ns, '/kayit-bilgi', array( 'methods' => 'GET', 'callback' => 'sides_rest_kayit_bilgi', 'permission_callback' => '__return_true' ) );
	register_rest_route( $ns, '/kayit', array( 'methods' => 'POST', 'callback' => 'sides_rest_kayit', 'permission_callback' => '__return_true' ) );
	register_rest_route( $ns, '/scan/exams', array( 'methods' => 'GET', 'callback' => 'sides_rest_scan_exams', 'permission_callback' => $scan ) );
	register_rest_route( $ns, '/scan/exam/(?P<id>[A-Za-z0-9_\-]{1,64})', array( 'methods' => 'GET', 'callback' => 'sides_rest_scan_exam', 'permission_callback' => $scan ) );
	register_rest_route( $ns, '/scan/exam/(?P<id>[A-Za-z0-9_\-]{1,64})/result', array( 'methods' => 'POST', 'callback' => 'sides_rest_scan_save', 'permission_callback' => $scan ) );
	register_rest_route( $ns, '/veli/(?P<token>[a-f0-9]{32})', array( 'methods' => 'GET', 'callback' => 'sides_rest_veli', 'permission_callback' => '__return_true' ) );
} );

function sides_rest_all( $req = null ) {
	global $wpdb;
	$org  = sides_org_id();
	$mask = sides_is_observer();
	$t    = sides_docs();
	$rows = $wpdb->get_results( $wpdb->prepare( "SELECT coll, id, token, data FROM $t WHERE org = %d AND coll IN ('students','exams','settings','duyurular','adaylar','takvim','testler','lgs') ORDER BY coll, id", $org ) ); // phpcs:ignore
	$out  = array( 'students' => array(), 'exams' => array(), 'duyurular' => array(), 'adaylar' => array(), 'takvim' => array(), 'testler' => array(), 'lgs' => array(), 'settings' => new stdClass() );
	$ykurum = ! $mask && sides_okut_kurum_yetki() ? sides_okut_kurum_token( $org ) : null;   // v7.4: tek yönetici linki (bütün deneme ve testler)
	$crm      = sides_can( 'crm', 1 );
	$sinav_ok = sides_sinav_okur();
	$test_ok  = sides_test_okur();
	$kisit    = sides_sinif_kisit();
	$lgs_izin = null;
	foreach ( $rows as $r ) {
		if ( 'students' === $r->coll && null !== $kisit && ! sides_ogrenci_izinli( json_decode( $r->data, true ), $kisit ) ) {
			continue; // sınıf yetkisi dışındaki öğrenci
		}
		if ( 'lgs' === $r->coll && null !== $kisit && 'liseler' !== (string) $r->id ) {   // v7.9.9: 'liseler' belgesi (tercih kılavuzu) herkese
			if ( null === $lgs_izin ) {
				$lgs_izin = sides_izinli_ogrenciler( $org, $kisit );
			}
			if ( ! isset( $lgs_izin[ (string) $r->id ] ) ) {
				continue; // sınıf yetkisi dışındaki öğrencinin LGS hedefi
			}
		}
		if ( 'settings' === $r->coll ) {
			if ( 'main' === $r->id ) {
				$d               = json_decode( $r->data, true );
				$out['settings'] = $d ? $d : new stdClass();
			}
		} elseif ( ( 'adaylar' !== $r->coll || $crm ) && ( 'exams' !== $r->coll || $sinav_ok ) && ( 'testler' !== $r->coll || $test_ok ) ) {   // T01: modül yetkisi
			$o = sides_row_out( $r, $mask );
			if ( 'exams' === $r->coll || 'testler' === $r->coll ) {
				$okut = ! $mask && ( 'exams' === $r->coll ? ( sides_can( 'karne', 2 ) || sides_can( 'sinav', 2 ) || sides_can( 'nehari', 2 ) ) : ( sides_can( 'test', 2 ) || sides_can( 'nehari', 2 ) ) );
				$o['yonetimToken'] = $okut ? $ykurum : null;
				if ( ! $okut ) {
					$o['okutToken'] = null;   // okutma bağlantıları yalnız okutma yetkisi olana
				}
			}
			$out[ $r->coll ][] = $o;
		}
	}
	$out['log']    = sides_log_list( $org, 40, $mask );
	$out['counts'] = array( 'results' => 0, 'tsonuc' => 0, 'havuz' => 0 );
	// son düzeltme zamanı: başka kullanıcının düzelttiği sonuçlar da uygulamada hemen yenilenir
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT coll, COUNT(*) AS n, MAX(updated_at) AS son FROM $t WHERE org = %d AND coll IN ('results','tsonuc','havuz') GROUP BY coll", $org ) ) as $r ) { // phpcs:ignore
		$out['counts'][ $r->coll ]          = (int) $r->n;
		$out['counts'][ $r->coll . 'Son' ] = (string) $r->son;
	}
	$out['counts']['genelHavuz'] = (int) $wpdb->get_var( "SELECT COUNT(*) FROM $t WHERE org = 0 AND coll = 'havuz'" ); // phpcs:ignore
	$muf           = get_option( 'sides_mufredat' );
	$out['mufredat'] = is_array( $muf ) && $muf ? $muf : new stdClass();
	$out['ai']       = sides_ai_durum( $org );
	$out['sinifKisit'] = $kisit ? $kisit : array();
	$out['bakim']      = function_exists( 'sides_bakim_ozet' ) ? sides_bakim_ozet( $org ) : null;   // v6 R09: yalnız yöneticiye, kapalıysa
	// v6 T10: istemcinin son imzası aynıysa veri yeniden gönderilmez
	$imza = md5( wp_json_encode( $out ) );
	if ( $req instanceof WP_REST_Request && preg_replace( '/[^a-f0-9]/', '', (string) $req->get_param( 'imza' ) ) === $imza ) {
		return array( 'degismedi' => true, 'imza' => $imza );
	}
	$out['imza'] = $imza;
	return $out;
}

/* T01: sınav ve test verisini okuyabilen modüller */
function sides_sinav_okur() {
	foreach ( array( 'karne', 'sinav', 'analiz', 'nehari', 'rapor' ) as $m ) {
		if ( sides_can( $m, 1 ) ) {
			return true;
		}
	}
	return false;
}
function sides_test_okur() {
	foreach ( array( 'test', 'nehari', 'analiz', 'rapor' ) as $m ) {
		if ( sides_can( $m, 1 ) ) {
			return true;
		}
	}
	return false;
}
function sides_rest_results( WP_REST_Request $req ) {
	global $wpdb;
	if ( ! sides_sinav_okur() ) {
		return array();   // T01: sınav sonucu okuma yetkisi yok
	}
	$org  = sides_org_id();
	$mask = sides_is_observer();
	$t    = sides_docs();
	if ( '*' === $req->get_param( 'exam' ) ) {
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT coll, id, token, data FROM $t WHERE org = %d AND coll = 'results' ORDER BY id", $org ) ); // phpcs:ignore
	} else {
		$exam = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $req->get_param( 'exam' ) );
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT coll, id, token, data FROM $t WHERE org = %d AND coll = 'results' AND exam_id = %s ORDER BY id", $org, $exam ) ); // phpcs:ignore
	}
	$kisit = sides_sinif_kisit();
	$izin  = null === $kisit ? null : sides_izinli_ogrenciler( $org, $kisit );
	$out   = array();
	foreach ( $rows as $r ) {
		$o = sides_row_out( $r, $mask );
		if ( sides_sonuc_izinli( $o, $izin ) ) {
			$out[] = $o;
		}
	}
	return $out;
}

function sides_rest_put( WP_REST_Request $req ) {
	global $wpdb;
	$org  = sides_org_id();
	$body = $req->get_body();
	if ( strlen( $body ) > 262144 ) {
		return new WP_Error( 'sides_buyuk', 'Kayıt çok büyük.', array( 'status' => 413 ) );
	}
	$d = json_decode( $body, true );
	if ( ! is_array( $d ) ) {
		return new WP_Error( 'sides_gecersiz', 'Geçersiz veri.', array( 'status' => 400 ) );
	}
	$coll = $req['coll'];
	$id   = $req['id'];
	$red  = sides_sinif_yazma_denetimi( $org, $coll, $id, $d );
	if ( ! $red ) {
		$red = sides_bolum_denetimi( $org, $coll, $id, $d );
	}
	if ( $red ) {
		return $red;
	}
	// T03: takip belgelerinde değerler doğrulanır; sınıf kısıtlı kullanıcı yalnız kendi öğrencilerinin hücrelerini değiştirebilir
	$d = sides_takip_doc_birlestir( $org, $coll, $id, $d );
	if ( is_wp_error( $d ) ) {
		return $d;
	}
	if ( function_exists( 'sides_v6_doc_denetim' ) ) {   // v6 modülleri (ödev, ders oturumu…): doğrulama ve sınıf kapsamı — includes/odev.php
		$d = sides_v6_doc_denetim( $org, $coll, $id, $d );
		if ( is_wp_error( $d ) ) {
			return $d;
		}
	}
	if ( 'students' === $coll && function_exists( 'sides_donem_birlestir' ) ) {   // v6 T09: sınıf/şube değişince önceki üyelik donemler'e eklenir; eski dönemler korunur (includes/yildevri.php)
		$d = sides_donem_birlestir( $org, $id, $d );
	}
	// v5.5: kitabın öğrencisi genel kayıtla değiştirilemez; ayrı ve onaylı işlem: POST /takip/kitap/<id> (islem: ogrenci)
	if ( 'kitap' === $coll ) {
		$eski_kitap = sides_get_doc( $org, 'kitap', $id );
		if ( $eski_kitap && isset( $eski_kitap['studentId'] ) && (string) ( isset( $d['studentId'] ) ? $d['studentId'] : '' ) !== (string) $eski_kitap['studentId'] ) {
			return sides_deny( 'Kitabın öğrencisi bu yolla değiştirilemez; Düzenle > Öğrenciyi değiştir bölümünü kullanın.' );
		}
	}
	if ( 'settings' === $coll && isset( $d['logo'] ) && strlen( (string) $d['logo'] ) > 120000 ) {
		return new WP_Error( 'sides_buyuk', 'Logo dosyası çok büyük.', array( 'status' => 413 ) );
	}
	/* v7.3.1 güvenlik: logo her sayfada <img src> içine yazılır; yalnız görsel veri adresi ya da düz http(s) adresi kabul edilir */
	if ( 'settings' === $coll && isset( $d['logo'] ) && '' !== $d['logo'] && ! sides_logo_gecerli( $d['logo'] ) ) {
		return new WP_Error( 'sides_gorsel', 'Logo geçersiz. Logoyu PNG, JPG ya da WEBP dosyası olarak yeniden yükleyin.', array( 'status' => 400 ) );
	}
	// v5.5: başka kurumun ortak sorusu bu kurumdan değiştirilemez; liste alanları saklanmaz
	if ( 'havuz' === $coll ) {
		if ( function_exists( 'sides_havuz_yabanci' ) && sides_havuz_yabanci( $org, $id ) ) {
			return sides_deny( 'Bu soru başka bir kurumun ortak havuzundan. Yalnızca kaynak kurum değiştirebilir veya silebilir.' );
		}
		unset( $d['ortak'], $d['kaynakKurum'] );
	}
	// Genel soru havuzu (tüm kurumlar görür) yalnızca ana hesaptan düzenlenir
	if ( 'havuz' === $coll && ( ! empty( $d['genel'] ) || sides_get_doc( 0, 'havuz', $id ) ) ) {
		if ( ! sides_is_super() ) {
			return sides_deny( 'Genel soru havuzunu yalnızca ana hesap düzenleyebilir.' );
		}
		$org        = 0;
		$d['genel'] = true;
	}
	$exam = ( 'results' === $coll && isset( $d['examId'] ) ) ? substr( preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $d['examId'] ), 0, 64 ) : '';
	if ( 'tsonuc' === $coll && isset( $d['testId'] ) ) {
		$exam = substr( preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $d['testId'] ), 0, 64 );
	}
	$res  = sides_put_doc( $org, $coll, $id, $d, $exam );
	if ( false === $res ) {
		return new WP_Error( 'sides_db', 'Kayıt yapılamadı.', array( 'status' => 500 ) );
	}
	if ( 'settings' === $coll && 'main' === $id && ! empty( $d['kurum'] ) ) {
		$wpdb->update( sides_orgs(), array( 'ad' => mb_substr( (string) $d['kurum'], 0, 190 ) ), array( 'id' => $org ) );
	}
	if ( ! $req->get_header( 'x_ok_quiet' ) ) {
		sides_log( $org, sides_log_text( $coll, $d, 'insert' === $res, false ) );
	}
	$t   = sides_docs();
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT coll, id, token, data FROM $t WHERE org = %d AND coll = %s AND id = %s", $org, $coll, $id ) ); // phpcs:ignore
	return sides_row_out( $row );
}

function sides_rest_delete( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	if ( 'havuz' === $req['coll'] && function_exists( 'sides_havuz_yabanci' ) && sides_havuz_yabanci( $org, $req['id'] ) ) {
		return sides_deny( 'Bu soru başka bir kurumun ortak havuzundan. Yalnızca kaynak kurum değiştirebilir veya silebilir.' );
	}
	if ( 'havuz' === $req['coll'] && ! sides_get_doc( $org, 'havuz', $req['id'] ) && sides_get_doc( 0, 'havuz', $req['id'] ) ) {
		if ( ! sides_is_super() ) {
			return sides_deny( 'Genel soru havuzunu yalnızca ana hesap düzenleyebilir.' );
		}
		$org = 0;
	}
	$red = sides_sinif_yazma_denetimi( $org, $req['coll'], $req['id'], null );
	if ( ! $red ) {
		$red = sides_bolum_denetimi( $org, $req['coll'], $req['id'], null );
	}
	if ( ! $red && in_array( $req['coll'], array( 'etut', 'izin', 'takviye', 'dgrup', 'yoklama' ), true ) && null !== sides_sinif_kisit() ) {
		$red = sides_deny( 'Bu kayıt başka sınıfların öğrencilerini de içeriyor; yalnızca tüm sınıflara yetkili kullanıcı silebilir.' );   // T03
	}
	if ( $red ) {
		return $red;
	}
	$old = sides_get_doc( $org, $req['coll'], $req['id'] );
	if ( false === $wpdb->delete( sides_docs(), array( 'org' => $org, 'coll' => $req['coll'], 'id' => $req['id'] ) ) ) {
		return new WP_Error( 'sides_db', 'Silinemedi (veritabanı hatası). Kayıt yerinde duruyor.', array( 'status' => 500 ) );   // T11
	}
	if ( 'exams' === $req['coll'] || 'testler' === $req['coll'] ) {
		$wpdb->delete( sides_docs(), array( 'org' => $org, 'coll' => 'okutlink', 'id' => ( 'testler' === $req['coll'] ? 't_' : 'e_' ) . $req['id'] ) );
	}
	if ( $old ) {   // T11: silme her zaman işlem günlüğüne yazılır
		sides_log( $org, sides_log_text( $req['coll'], $old, false, true ) );
	}
	return array( 'ok' => true );
}

function sides_rest_links( WP_REST_Request $req ) {
	global $wpdb;
	$org   = sides_org_id();
	$t     = sides_docs();
	$p     = $req->get_json_params();
	$items = ( isset( $p['items'] ) && is_array( $p['items'] ) ) ? array_slice( $p['items'], 0, 100 ) : array();
	$out   = array();
	$kisit = sides_sinif_kisit();
	$izin  = null === $kisit ? null : sides_izinli_ogrenciler( $org, $kisit );
	foreach ( $items as $it ) {
		if ( empty( $it['id'] ) || ! isset( $it['snapshot'] ) || ! is_array( $it['snapshot'] ) ) {
			continue;
		}
		$id   = substr( preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $it['id'] ), 0, 64 );
		$snap = wp_json_encode( $it['snapshot'] );
		if ( strlen( $snap ) > 131072 ) {
			continue;
		}
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT token, data FROM $t WHERE org = %d AND coll = 'results' AND id = %s", $org, $id ) ); // phpcs:ignore
		$rd = $row ? json_decode( $row->data, true ) : null;
		if ( ! $row || ! sides_sonuc_izinli( $rd, $izin ) || ! sides_can( sides_bolum_yetkisi( 'results', sides_kayit_sinifi( $org, 'results', $rd ) ), 2 ) ) {
			continue;
		}
		$tok = $row->token ? $row->token : bin2hex( random_bytes( 16 ) );
		$wpdb->update( $t, array( 'token' => $tok, 'snapshot' => $snap ), array( 'org' => $org, 'coll' => 'results', 'id' => $id ) );
		$out[ $id ] = $tok;
	}
	return array( 'tokens' => (object) $out );
}

function sides_rest_veli( WP_REST_Request $req ) {
	global $wpdb;
	$t   = sides_docs();
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT org, snapshot FROM $t WHERE coll = 'results' AND token = %s", $req['token'] ) ); // phpcs:ignore
	if ( ! $row || ! $row->snapshot ) {
		return new WP_Error( 'sides_yok', 'Karne bulunamadı.', array( 'status' => 404 ) );
	}
	$set = sides_get_doc( (int) $row->org, 'settings', 'main' );
	// kurum adı ve logo karnenin hazırlandığı andan değil, güncel ayarlardan gelir
	$res = rest_ensure_response( array( 'snapshot' => json_decode( $row->snapshot, true ), 'logo' => $set && ! empty( $set['logo'] ) ? $set['logo'] : '', 'kurum' => $set && ! empty( $set['kurum'] ) ? (string) $set['kurum'] : '' ) );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}

/* Okutma linkleri: 'okutucu' (yalnızca okutur ve kaydeder) sınav/test satırının token sütununda,
   'yonetici' (okunan cevapları da düzeltebilir) ayrı bir 'okutlink' satırında tutulur. */
function sides_rest_okut_link( WP_REST_Request $req ) {
	global $wpdb;
	$org   = sides_org_id();
	$p     = $req->get_json_params();
	$id    = isset( $p['exam'] ) ? substr( preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $p['exam'] ), 0, 60 ) : '';
	$hedef = ( isset( $p['hedef'] ) && 'testler' === $p['hedef'] ) ? 'testler' : 'exams';
	$t     = sides_docs();
	$doc   = sides_get_doc( $org, $hedef, $id );
	if ( ! $doc ) {
		return new WP_Error( 'sides_yok', 'testler' === $hedef ? 'Test bulunamadı.' : 'Sınav bulunamadı.', array( 'status' => 404 ) );
	}
	$gerek = sides_neh_sinif( isset( $doc['sinif'] ) ? $doc['sinif'] : '' ) ? 'nehari' : ( 'testler' === $hedef ? 'test' : 'karne' );
	if ( ! sides_can( $gerek, 2 ) ) {
		return sides_deny();
	}
	$tip = ( isset( $p['tip'] ) && 'yonetici' === $p['tip'] ) ? 'yonetici' : 'okutucu';
	$kapat = isset( $p['action'] ) && 'kapat' === $p['action'];
	if ( 'okutucu' === $tip ) {
		$tok = $kapat ? null : bin2hex( random_bytes( 16 ) );
		$wpdb->update( $t, array( 'token' => $tok ), array( 'org' => $org, 'coll' => $hedef, 'id' => $id ) );
		sides_log( $org, 'Okutucu okutma linki ' . ( $tok ? 'oluşturuldu' : 'kapatıldı' ) );
		return array( 'token' => $tok, 'tip' => $tip );
	}
	/* v7.4: yönetici linki kurum genelidir — tek link ve tek QR bütün deneme ve testleri okutur.
	   'yeni': link varsa aynısı döner (her denemede aynı QR); 'yenile': eski bütün yönetici linkleri kapanır, yenisi üretilir; 'kapat': hepsi kapanır. */
	if ( ! sides_okut_kurum_yetki() ) {
		return sides_deny( 'Yönetici okutma linki kurumun bütün deneme ve testlerini okutur; kurum yöneticisi oluşturur.' );
	}
	$yenile = ! empty( $p['yenile'] );
	if ( ! $kapat && ! $yenile ) {
		$var = sides_okut_kurum_token( $org );
		if ( $var ) {
			if ( ! $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE org = %d AND coll = 'okutlink' AND id = 'kurum'", $org ) ) ) { // phpcs:ignore
				$wpdb->update( $t, array( 'id' => 'kurum', 'exam_id' => '' ), array( 'org' => $org, 'coll' => 'okutlink', 'token' => $var ) );   // eski en yeni link kurum linki olur (basılı QR çalışmaya devam eder)
			}
			return array( 'token' => $var, 'tip' => $tip, 'kurum' => true );
		}
	}
	$wpdb->query( $wpdb->prepare( "DELETE FROM $t WHERE org = %d AND coll = 'okutlink'", $org ) ); // phpcs:ignore
	$tok = $kapat ? null : bin2hex( random_bytes( 16 ) );
	if ( $tok ) {
		$wpdb->insert( $t, array( 'org' => $org, 'coll' => 'okutlink', 'id' => 'kurum', 'exam_id' => '', 'token' => $tok, 'data' => wp_json_encode( array( 'tip' => 'yonetici', 'kapsam' => 'kurum' ) ), 'updated_at' => current_time( 'mysql', true ), 'updated_by' => get_current_user_id() ) );
	}
	sides_log( $org, 'Yönetici okutma linki (bütün denemeler) ' . ( $tok ? ( $yenile ? 'yenilendi' : 'oluşturuldu' ) : 'kapatıldı' ) );
	return array( 'token' => $tok, 'tip' => $tip, 'kurum' => true );
}

function sides_rest_history( WP_REST_Request $req ) {
	global $wpdb;
	$org  = sides_org_id();
	$mask = sides_is_observer();
	$ids  = array_filter( array_map( function ( $x ) {
		return preg_replace( '/[^A-Za-z0-9_\-]/', '', $x );
	}, explode( ',', (string) $req->get_param( 'students' ) ) ) );
	$ids  = array_flip( array_slice( $ids, 0, 500 ) );
	$t    = sides_docs();
	$out  = array();
	if ( ! sides_sinav_okur() ) {
		return $out;   // T01
	}
	$kisit = sides_sinif_kisit();   // T02: sınıf kapsamı
	if ( null !== $kisit ) {
		$ids = array_intersect_key( $ids, sides_izinli_ogrenciler( $org, $kisit ) );
	}
	foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT coll, id, token, data FROM $t WHERE org = %d AND coll = 'results'", $org ) ) as $r ) { // phpcs:ignore
		$d = json_decode( $r->data, true );
		if ( isset( $d['studentId'] ) && isset( $ids[ $d['studentId'] ] ) ) {
			$out[] = sides_row_out( $r, $mask );
		}
	}
	return $out;
}

function sides_rest_log() {
	return sides_log_list( sides_org_id(), 300, sides_is_observer() );
}

function sides_rest_log_add( WP_REST_Request $req ) {
	$p = $req->get_json_params();
	sides_log( sides_org_id(), isset( $p['m'] ) ? sanitize_text_field( (string) $p['m'] ) : '' );
	return array( 'ok' => true );
}

/* ------------------------------------------------------------------ *
 * Okutma (link veya okutma yetkili oturum): denemeler ve testler
 * ------------------------------------------------------------------ */
function sides_scan_exam_public( $e ) {
	$dersler = array();
	foreach ( (array) ( isset( $e['dersler'] ) ? $e['dersler'] : array() ) as $d ) {
		$dersler[] = array( 'ad' => isset( $d['ad'] ) ? (string) $d['ad'] : '', 'soru' => isset( $d['soru'] ) ? (int) $d['soru'] : 0 );
	}
	return array(
		'id'      => $e['id'],
		'ad'      => isset( $e['ad'] ) ? $e['ad'] : '',
		'tarih'   => isset( $e['tarih'] ) ? $e['tarih'] : '',
		'sinif'   => isset( $e['sinif'] ) ? (string) $e['sinif'] : '',
		'secenek' => isset( $e['secenek'] ) ? (int) $e['secenek'] : 4,
		'dersler' => $dersler,
	) + ( function_exists( 'sides_beceri_mi' ) && sides_beceri_mi( $e ) ? array( 'tur' => 'beceri', 'beceri' => sides_beceri_public( $e ) ) : array() );   // v7: beceri formunun yerleşimi (anahtarsız)
}
/* Test, okutma ekranında tek dersli bir sınav gibi görünür (optik form yerleşimi istemcideki testExam ile aynı) */
function sides_test_soru_sayisi( $e ) {
	return isset( $e['sorular'] ) && is_array( $e['sorular'] ) ? count( $e['sorular'] ) : 0;
}
function sides_test_exam_public( $e ) {
	return array(
		'id'      => $e['id'],
		'tip'     => 'test',
		'ad'      => isset( $e['ad'] ) ? $e['ad'] : '',
		'tarih'   => isset( $e['tarih'] ) ? $e['tarih'] : '',
		'sinif'   => isset( $e['sinif'] ) ? (string) $e['sinif'] : '',
		'secenek' => isset( $e['secenek'] ) ? (int) $e['secenek'] : 4,
		'dersler' => array( array( 'ad' => isset( $e['ders'] ) && $e['ders'] ? (string) $e['ders'] : 'Test', 'soru' => sides_test_soru_sayisi( $e ) ) ),
	);
}

function sides_rest_scan_exams( WP_REST_Request $req ) {
	global $wpdb;
	$sc   = sides_scan_ctx( $req );
	$t    = sides_docs();
	$rows = $wpdb->get_results( $wpdb->prepare( "SELECT coll, id, token, data FROM $t WHERE org = %d AND coll IN ('exams','testler')", $sc['org'] ) ); // phpcs:ignore
	$out  = array();
	foreach ( $rows as $r ) {
		$e = sides_row_out( $r );
		if ( ! empty( $e['okutmaKapali'] ) ) {
			continue;
		}
		if ( null !== $sc['exams'] && ! in_array( $e['id'], $sc['exams'], true ) ) {
			continue;
		}
		if ( 'testler' === $r->coll ) {
			if ( sides_test_soru_sayisi( $e ) ) {
				$out[] = sides_test_exam_public( $e );
			}
		} else {
			$out[] = sides_scan_exam_public( $e );
		}
	}
	$set = sides_get_doc( $sc['org'], 'settings', 'main' );
	return array( 'exams' => $out, 'tip' => $sc['tip'], 'settings' => array( 'kurum' => $set && isset( $set['kurum'] ) ? $set['kurum'] : '' ) );
}

/* Okutulacak deneme veya test; dönen dizide _coll (exams|testler), _org ve _tip bulunur */
function sides_scan_exam_or_error( WP_REST_Request $req ) {
	$sc = sides_scan_ctx( $req );
	$id = $req['id'];
	if ( null !== $sc['exams'] && ! in_array( $id, $sc['exams'], true ) ) {
		return new WP_Error( 'sides_yetki', 'Bu bağlantıyla bu sınav okutulamaz.', array( 'status' => 403 ) );
	}
	$coll = 'exams';
	$e    = sides_get_doc( $sc['org'], 'exams', $id );
	if ( ! $e ) {
		$coll = 'testler';
		$e    = sides_get_doc( $sc['org'], 'testler', $id );
	}
	if ( ! $e ) {
		return new WP_Error( 'sides_yok', 'Sınav bulunamadı.', array( 'status' => 404 ) );
	}
	if ( ! empty( $e['okutmaKapali'] ) ) {
		return new WP_Error( 'sides_kapali', 'Bu sınav için okutma kapatıldı.', array( 'status' => 403 ) );
	}
	// Oturumla okutmada modül yetkisi: deneme için Karne, test için Test modülü
	if ( ! empty( $sc['oturum'] ) && 'ogretmen' !== sides_ctx()['rol'] && ! sides_can( sides_neh_sinif( isset( $e['sinif'] ) ? $e['sinif'] : '' ) ? 'nehari' : ( 'testler' === $coll ? 'test' : 'karne' ), 2 ) ) {
		return sides_deny();
	}
	$e['_org']  = $sc['org'];
	$e['_coll'] = $coll;
	$e['_tip']  = $sc['tip'];
	return $e;
}

function sides_rest_scan_exam( WP_REST_Request $req ) {
	global $wpdb;
	$e = sides_scan_exam_or_error( $req );
	if ( is_wp_error( $e ) ) {
		return $e;
	}
	$org      = $e['_org'];
	$t        = sides_docs();
	$students = array();
	foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT coll, id, token, data FROM $t WHERE org = %d AND coll = 'students'", $org ) ) as $r ) { // phpcs:ignore
		$s = sides_row_out( $r );
		if ( isset( $s['sinif'] ) && (string) $s['sinif'] === (string) $e['sinif'] ) {
			$students[] = array( 'id' => $s['id'], 'ad' => isset( $s['ad'] ) ? $s['ad'] : '', 'no' => isset( $s['no'] ) ? $s['no'] : '', 'sinif' => $s['sinif'], 'sube' => isset( $s['sube'] ) ? $s['sube'] : '' );
		}
	}
	$done = array();
	$rc   = 'testler' === $e['_coll'] ? 'tsonuc' : 'results';
	foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT data FROM $t WHERE org = %d AND coll = %s AND exam_id = %s", $org, $rc, $e['id'] ) ) as $r ) { // phpcs:ignore
		$d = json_decode( $r->data, true );
		if ( ! empty( $d['studentId'] ) ) {
			$done[] = $d['studentId'];
		}
	}
	return array( 'exam' => 'testler' === $e['_coll'] ? sides_test_exam_public( $e ) : sides_scan_exam_public( $e ), 'students' => $students, 'done' => $done, 'tip' => $e['_tip'] );
}

function sides_rest_scan_save( WP_REST_Request $req ) {
	$e = sides_scan_exam_or_error( $req );
	if ( is_wp_error( $e ) ) {
		return $e;
	}
	$org  = $e['_org'];
	$test = 'testler' === $e['_coll'];
	$p    = $req->get_json_params();
	$sid  = isset( $p['studentId'] ) ? preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $p['studentId'] ) : '';
	$s    = $sid ? sides_get_doc( $org, 'students', $sid ) : null;
	if ( ! $s || (string) ( isset( $s['sinif'] ) ? $s['sinif'] : '' ) !== (string) $e['sinif'] ) {
		return new WP_Error( 'sides_ogrenci', 'Öğrenci bulunamadı.', array( 'status' => 400 ) );
	}
	$kaynak = in_array( isset( $p['kaynak'] ) ? $p['kaynak'] : '', array( 'foto', 'kamera', 'elle' ), true ) ? $p['kaynak'] : 'foto';
	if ( 'okutucu' === $e['_tip'] && 'elle' === $kaynak ) {
		return new WP_Error( 'sides_okutucu', 'Okutucu bağlantısıyla elle cevap girilemez. Formu okutun.', array( 'status' => 403 ) );
	}
	$total = 0;
	if ( $test ) {
		$total = sides_test_soru_sayisi( $e );
	} else {
		foreach ( (array) $e['dersler'] as $d ) {
			$total += (int) $d['soru'];
		}
	}
	$cevap = isset( $p['cevap'] ) ? strtoupper( (string) $p['cevap'] ) : '';
	$harf  = $test ? ( isset( $e['secenek'] ) && 4 === (int) $e['secenek'] ? 'A-D' : 'A-E' ) : ( isset( $e['secenek'] ) && 5 === (int) $e['secenek'] ? 'A-E' : 'A-D' );   // T03: 4 seçenekli sınavda E yok
	if ( ( ! $test && function_exists( 'sides_beceri_mi' ) && sides_beceri_mi( $e ) ) ? ! sides_beceri_cevap_gecerli( $e, $cevap ) : ( strlen( $cevap ) !== $total || ! preg_match( '/^[' . $harf . '\-\*]*$/', $cevap ) ) ) {   // v7: beceri satırları rakam da içerir
		return new WP_Error( 'sides_cevap', 'Cevaplar geçersiz.', array( 'status' => 400 ) );
	}
	$id = substr( $e['id'] . '_' . $sid, 0, 64 );
	$d  = array(
		$test ? 'testId' : 'examId' => $e['id'],
		'studentId' => $sid,
		'kitapcik'  => ( ! $test && isset( $p['kitapcik'] ) && 'B' === $p['kitapcik'] ) ? 'B' : 'A',
		'cevap'     => $cevap,
		'ogr'       => array(
			'ad'      => isset( $s['ad'] ) ? $s['ad'] : '',
			'no'      => isset( $s['no'] ) ? $s['no'] : '',
			'sinif'   => isset( $s['sinif'] ) ? $s['sinif'] : '',
			'sube'    => isset( $s['sube'] ) ? $s['sube'] : '',
			'veliTel' => isset( $s['veliTel'] ) ? $s['veliTel'] : '',
			'misafir' => ! empty( $s['misafir'] ) ? 1 : 0,   /* v7.9 misafir öğrenci (öğrenci silinse de karne bireysel kalır) */
		),
		'kaynak'    => $kaynak,
		'kontrol'   => isset( $p['kontrol'] ) ? (int) $p['kontrol'] : 0,
		'okutan'    => isset( $p['okutan'] ) ? mb_substr( sanitize_text_field( (string) $p['okutan'] ), 0, 60 ) : '',
		'link'      => $e['_tip'],
		'tarih'     => (int) round( microtime( true ) * 1000 ),
	);
	if ( false === sides_put_doc( $org, $test ? 'tsonuc' : 'results', $id, $d, $e['id'] ) ) {
		return new WP_Error( 'sides_db', 'Kayıt yapılamadı.', array( 'status' => 500 ) );
	}
	sides_log( $org, ( $test ? 'Test formu okutuldu: ' : 'Form okutuldu: ' ) . $d['ogr']['ad'] . ' · ' . ( isset( $e['ad'] ) ? $e['ad'] : '' ) . ( $d['okutan'] ? ' (' . $d['okutan'] . ')' : '' ), $d['okutan'] ? $d['okutan'] : ( is_user_logged_in() ? null : 'Okutma linki' ) );
	return array( 'id' => $id, 'studentId' => $sid );
}

/* ------------------------------------------------------------------ *
 * Test modülü: test sonuçları, soru havuzu, soru görselleri
 * ------------------------------------------------------------------ */
function sides_rest_tsonuc( WP_REST_Request $req ) {
	global $wpdb;
	$org  = sides_org_id();
	$mask = sides_is_observer();
	$t    = sides_docs();
	$test = preg_replace( '/[^A-Za-z0-9_\-\*]/', '', (string) $req->get_param( 'test' ) );
	$ogr  = preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $req->get_param( 'ogrenci' ) );
	if ( $test && '*' !== $test ) {
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT coll, id, token, data FROM $t WHERE org = %d AND coll = 'tsonuc' AND exam_id = %s ORDER BY id", $org, $test ) ); // phpcs:ignore
	} else {
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT coll, id, token, data FROM $t WHERE org = %d AND coll = 'tsonuc' ORDER BY id", $org ) ); // phpcs:ignore
	}
	$out   = array();
	$kisit = sides_sinif_kisit();
	$izin  = null === $kisit ? null : sides_izinli_ogrenciler( $org, $kisit );
	foreach ( $rows as $r ) {
		$o = sides_row_out( $r, $mask );
		if ( $ogr && ( ! isset( $o['studentId'] ) || $o['studentId'] !== $ogr ) ) {
			continue;
		}
		if ( ! sides_sonuc_izinli( $o, $izin ) ) {
			continue;
		}
		$out[] = $o;
	}
	return $out;
}

/* Soru havuzu: kurumun kendi soruları + ana hesabın tüm kurumlara açtığı genel havuz */
function sides_rest_havuz() {
	global $wpdb;
	$org = sides_org_id();
	$t   = sides_docs();
	$out = array();
	foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT org, coll, id, token, data FROM $t WHERE coll = 'havuz' AND org IN (%d, 0) ORDER BY id", $org ) ) as $r ) { // phpcs:ignore
		$o          = sides_row_out( $r );
		$o['genel'] = 0 === (int) $r->org;
		$out[]      = $o;
	}
	// v5.5: paylaşımı açık kurumların ortak soruları (salt okunur)
	if ( function_exists( 'sides_havuz_ortak' ) ) {
		$out = array_merge( $out, sides_havuz_ortak( $org ) );
	}
	return $out;
}

/* data:image/...;base64 görseli doğrulayıp kaydeder; { id, w, h } ya da WP_Error döner */
function sides_gorsel_kaydet( $url, $org ) {
	global $wpdb;
	if ( ! preg_match( '#^data:image/(jpeg|png|webp);base64,([A-Za-z0-9+/=]+)$#', (string) $url, $m ) ) {
		return new WP_Error( 'sides_gorsel', 'Görsel biçimi desteklenmiyor.', array( 'status' => 400 ) );
	}
	$bin = base64_decode( $m[2], true );
	if ( false === $bin || strlen( $bin ) > 1600000 ) {
		return new WP_Error( 'sides_gorsel', 'Görsel çok büyük (en fazla 1,5 MB).', array( 'status' => 413 ) );
	}
	$info = function_exists( 'getimagesizefromstring' ) ? @getimagesizefromstring( $bin ) : array( 1, 1, 'mime' => 'image/' . $m[1] ); // phpcs:ignore
	if ( ! $info || ! in_array( $info['mime'], array( 'image/jpeg', 'image/png', 'image/webp' ), true ) ) {
		return new WP_Error( 'sides_gorsel', 'Dosya bir görsel değil.', array( 'status' => 400 ) );
	}
	$id = 'g' . bin2hex( random_bytes( 10 ) );
	$ok = $wpdb->insert( sides_docs(), array( 'org' => (int) $org, 'coll' => 'gorsel', 'id' => $id, 'exam_id' => '', 'data' => wp_json_encode( array( 'm' => $info['mime'], 'b' => base64_encode( $bin ), 'w' => (int) $info[0], 'h' => (int) $info[1] ) ), 'updated_at' => current_time( 'mysql', true ), 'updated_by' => get_current_user_id() ) );
	if ( ! $ok ) {
		return new WP_Error( 'sides_db', 'Görsel kaydedilemedi.', array( 'status' => 500 ) );
	}
	return array( 'id' => $id, 'w' => (int) $info[0], 'h' => (int) $info[1] );
}

function sides_rest_gorsel_add( WP_REST_Request $req ) {
	$p   = $req->get_json_params();
	$org = sides_org_id();
	if ( ! empty( $p['genel'] ) ) {
		if ( ! sides_is_super() ) {
			return sides_deny( 'Genel soru havuzunu yalnızca ana hesap düzenleyebilir.' );
		}
		$org = 0;
	}
	return sides_gorsel_kaydet( isset( $p['data'] ) ? (string) $p['data'] : '', $org );
}

/* Dosyadan soru yükleme. Gövde: { genel, sorular: [ { id, gorsel: data-url, data: { ders, sinif, konu, ... } } ] } */
function sides_rest_havuz_toplu( WP_REST_Request $req ) {
	$body = $req->get_body();
	if ( strlen( $body ) > 12 * 1048576 ) {
		return new WP_Error( 'sides_buyuk', 'Gönderilen soru paketi çok büyük.', array( 'status' => 413 ) );
	}
	$p     = json_decode( $body, true );
	$liste = is_array( $p ) && isset( $p['sorular'] ) && is_array( $p['sorular'] ) ? $p['sorular'] : null;
	if ( null === $liste || count( $liste ) > 25 ) {
		return new WP_Error( 'sides_gecersiz', 'Geçersiz soru paketi (en fazla 25 soru).', array( 'status' => 400 ) );
	}
	$genel = ! empty( $p['genel'] );
	if ( $genel && ! sides_is_super() ) {
		return sides_deny( 'Genel soru havuzunu yalnızca ana hesap düzenleyebilir.' );
	}
	foreach ( $liste as $s ) {
		$sn = isset( $s['data']['sinif'] ) ? (string) $s['data']['sinif'] : '';
		if ( ! sides_can( sides_neh_sinif( $sn ) ? 'nehari' : 'havuz', 2 ) ) {
			return sides_deny( sides_neh_sinif( $sn ) ? 'Nehari (3, 4 ve N5. sınıf) soru havuzuna ekleme yetkiniz yok.' : 'Soru havuzuna ekleme yetkiniz yok. Yöneticinizden izin isteyin.' );
		}
	}
	$org   = $genel ? 0 : sides_org_id();
	$ids   = array();
	$hata  = array();
	foreach ( $liste as $k => $s ) {
		$id = isset( $s['id'] ) ? preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $s['id'] ) : '';
		$d  = isset( $s['data'] ) && is_array( $s['data'] ) ? $s['data'] : null;
		if ( '' === $id || strlen( $id ) > 64 || ! $d || strlen( wp_json_encode( $d ) ) > 262144 ) {
			$hata[] = $k;
			continue;
		}
		if ( sides_get_doc( $genel ? sides_org_id() : 0, 'havuz', $id ) ) {   // kimlik öteki havuzda kullanılıyorsa atla
			$hata[] = $k;
			continue;
		}
		$g = sides_gorsel_kaydet( isset( $s['gorsel'] ) ? $s['gorsel'] : '', $org );
		if ( is_wp_error( $g ) ) {
			$hata[] = $k;
			continue;
		}
		$d['g']     = $g['id'];
		$d['genel'] = $genel;
		if ( false === sides_put_doc( $org, 'havuz', $id, $d ) ) {
			$hata[] = $k;
			continue;
		}
		$ids[] = $id;
	}
	return array( 'eklenen' => count( $ids ), 'ids' => $ids, 'hatalar' => $hata );
}

function sides_rest_gorsel_get( WP_REST_Request $req ) {
	global $wpdb;
	$t   = sides_docs();
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT data FROM $t WHERE coll = 'gorsel' AND id = %s AND org IN (%d, 0)", $req['id'], sides_org_id() ) ); // phpcs:ignore
	// v5.5: paylaşılan veya daha önce teste alınmış başka kurum görseli
	if ( ! $row && function_exists( 'sides_gorsel_ortak_org' ) && ( $src = sides_gorsel_ortak_org( $req['id'], sides_org_id() ) ) ) {
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT data FROM $t WHERE coll = 'gorsel' AND id = %s AND org = %d", $req['id'], $src ) ); // phpcs:ignore
	}
	$d   = $row ? json_decode( $row->data, true ) : null;
	if ( ! $d || empty( $d['b'] ) ) {
		return new WP_Error( 'sides_yok', 'Görsel bulunamadı.', array( 'status' => 404 ) );
	}
	$bin = base64_decode( $d['b'] );
	sides_gorsel_basliklar( $d, $bin );   // v7.9.27: tür beyaz listesi + nosniff + sandbox
	header( 'Cache-Control: private, max-age=31536000, immutable' );
	header_remove( 'Expires' );
	header_remove( 'Pragma' );
	echo $bin; // phpcs:ignore
	exit;
}

function sides_rest_gorsel_del( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$t   = sides_docs();
	// Başka bir testte, denemede veya havuzda kullanılan görsel silinmez (v5.5: ortak sorudan kopya alan kurumlar dâhil)
	$like = '%' . $wpdb->esc_like( $req['id'] ) . '%';
	$kul  = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE coll IN ('testler','havuz','exams') AND data LIKE %s", $like ) ); // phpcs:ignore
	if ( $kul ) {
		return array( 'ok' => true, 'kullaniliyor' => $kul );
	}
	$wpdb->delete( $t, array( 'org' => $org, 'coll' => 'gorsel', 'id' => $req['id'] ) );
	if ( sides_is_super() ) {
		$wpdb->delete( $t, array( 'org' => 0, 'coll' => 'gorsel', 'id' => $req['id'] ) );
	}
	return array( 'ok' => true );
}

/* Kullanıcının kendi profil resmi (192 px JPEG veri adresi) */
function sides_rest_profil( WP_REST_Request $req ) {
	$p   = $req->get_json_params();
	$a   = isset( $p['avatar'] ) ? (string) $p['avatar'] : '';
	$uid = get_current_user_id();
	if ( '' === $a ) {
		delete_user_meta( $uid, 'sides_avatar' );
		return array( 'avatar' => '' );
	}
	if ( strlen( $a ) > 90000 || ! preg_match( '#^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$#', $a ) ) {
		return new WP_Error( 'sides_gorsel', 'Görsel geçersiz ya da çok büyük.', array( 'status' => 400 ) );
	}
	update_user_meta( $uid, 'sides_avatar', $a );
	return array( 'avatar' => $a );
}

/* ------------------------------------------------------------------ *
 * Herkese açık ön kayıt (aday) formu: ?kayit=<kurum anahtarı>
 * ------------------------------------------------------------------ */
function sides_rest_kayit_bilgi( WP_REST_Request $req ) {
	$o = sides_org_by_key( $req->get_param( 'o' ) );
	if ( ! $o ) {
		return array( 'acik' => false, 'kurum' => '', 'logo' => '' );
	}
	$set = sides_get_doc( (int) $o->id, 'settings', 'main' );
	return array(
		'acik'  => ! empty( $set['kayitAcik'] ) && ! sides_org_blok( $o ),
		'kurum' => isset( $set['kurum'] ) ? $set['kurum'] : $o->ad,
		'logo'  => isset( $set['logo'] ) ? $set['logo'] : '',
	);
}

function sides_rest_kayit( WP_REST_Request $req ) {
	global $wpdb;
	$p = $req->get_json_params();
	$o = sides_org_by_key( isset( $p['o'] ) ? $p['o'] : '' );
	if ( ! $o ) {
		return new WP_Error( 'sides_yok', 'Kurum bulunamadı.', array( 'status' => 404 ) );
	}
	$org = (int) $o->id;
	$set = sides_get_doc( $org, 'settings', 'main' );
	if ( empty( $set['kayitAcik'] ) || sides_org_blok( $o ) ) {
		return new WP_Error( 'sides_kapali', 'Ön kayıt formu şu anda kapalı.', array( 'status' => 403 ) );
	}
	if ( ! empty( $p['web'] ) ) {
		return array( 'ok' => true ); // bot tuzağı
	}
	if ( ! sides_rl( 'kayit', 5, HOUR_IN_SECONDS ) ) {
		return new WP_Error( 'sides_limit', 'Çok fazla başvuru gönderildi. Lütfen daha sonra tekrar deneyin.', array( 'status' => 429 ) );
	}
	$f   = function ( $k, $len ) use ( $p ) {
		return isset( $p[ $k ] ) ? mb_substr( sanitize_text_field( (string) $p[ $k ] ), 0, $len ) : '';
	};
	$ad  = $f( 'ad', 80 );
	$tel = $f( 'telefon', 30 );
	if ( ! $ad || strlen( preg_replace( '/\D/', '', $tel ) ) < 10 ) {
		return new WP_Error( 'sides_eksik', 'Öğrencinin adını ve geçerli bir telefon numarası yazın.', array( 'status' => 400 ) );
	}
	$sinif = in_array( $f( 'sinif', 2 ), array( '3', '4', '5', '6', '7', '8' ), true ) ? $f( 'sinif', 2 ) : '';
	$ms    = (int) round( microtime( true ) * 1000 );
	$not   = $f( 'not', 500 );
	$d     = array(
		'ad'        => $ad,
		'veliAd'    => $f( 'veliAd', 80 ),
		'telefon'   => $tel,
		'sinif'     => $sinif,
		'okul'      => $f( 'okul', 120 ),
		'durum'     => 'yeni',
		'kaynak'    => 'Kayıt linki',
		'kanal'     => isset( $p['kanal'] ) && 'ods' === $p['kanal'] ? 'ods' : '',   // ÖDS tanıtım sayfasındaki gömülü formdan gelen başvuru (includes/ods.php)
		'notlar'    => $not ? array( array( 't' => $ms, 'm' => 'Başvuru notu: ' . $not, 'u' => 'Kayıt formu' ) ) : array(),
		'olusturma' => $ms,
		'studentId' => '',
		'gorusme'   => '',
	);
	sides_put_doc( $org, 'adaylar', 'a' . base_convert( (string) $ms, 10, 36 ) . wp_rand( 100, 999 ), $d );
	sides_log( $org, 'Yeni aday başvurusu: ' . $ad . ( $sinif ? ' (' . $sinif . '. sınıf)' : '' ), 'Kayıt formu' );
	return array( 'ok' => true );
}

/* ------------------------------------------------------------------ *
 * Kurum kullanıcıları (yalnızca yönetici)
 * ------------------------------------------------------------------ */
function sides_user_row( $u, $org ) {
	$c = sides_ctx( $u->ID );
	return array(
		'id'       => $u->ID,
		'ad'       => $u->display_name,
		'email'    => $u->user_email,
		'login'    => $u->user_login,
		'rol'      => $c['rol'],
		'yetki'    => $c['yetki'],
		'sayfa'    => (object) ( in_array( $c['rol'], array( 'personel', 'gozlemci' ), true ) && is_array( get_user_meta( $u->ID, 'sides_sayfa', true ) ) ? get_user_meta( $u->ID, 'sides_sayfa', true ) : array() ),
		'sonGiris' => (int) get_user_meta( $u->ID, 'sides_son_giris', true ),
		'siniflar' => sides_user_siniflar( $u->ID ),
		'cihazSay' => count( sides_cihaz_listesi( $u->ID ) ),
		'avatar'   => (string) get_user_meta( $u->ID, 'sides_avatar', true ),
		'kilitli'  => user_can( $u, 'manage_options' ) || get_current_user_id() === $u->ID,
		'sahip'    => ( $o = sides_org( $org ) ) && (int) $o->sahip === (int) $u->ID,
	);
}

function sides_org_users( $org ) {
	$out  = array();
	$seen = array();
	foreach ( get_users( array( 'meta_key' => 'sides_org', 'meta_value' => (string) $org ) ) as $u ) {
		$out[]            = sides_user_row( $u, $org );
		$seen[ $u->ID ] = 1;
	}
	if ( 1 === (int) $org ) { // eski sürümden kalan site yöneticileri ve öğretmenler
		foreach ( get_users( array( 'role__in' => array( 'administrator', 'editor', 'ogretmen' ) ) ) as $u ) {
			if ( ! isset( $seen[ $u->ID ] ) && ! get_user_meta( $u->ID, 'sides_org', true ) ) {
				$out[] = sides_user_row( $u, $org );
			}
		}
	}
	return $out;
}

function sides_rest_users() {
	return sides_org_users( sides_org_id() );
}

function sides_logo_gecerli( $v ) {
	return is_string( $v ) && ( preg_match( '#^data:image/(png|jpe?g|gif|webp);base64,[A-Za-z0-9+/=]+$#', $v ) || preg_match( '#^https?://[^\s"\'<>`]+$#', $v ) );
}

function sides_clean_yetki( $y ) {
	$out = array();
	foreach ( SIDES_MODS as $m ) {
		$out[ $m ] = isset( $y[ $m ] ) ? max( 0, min( 2, (int) $y[ $m ] ) ) : 2;
	}
	return $out;
}

function sides_rest_user_add( WP_REST_Request $req ) {
	$org   = sides_org_id();
	$p     = $req->get_json_params();
	$email = isset( $p['email'] ) ? sanitize_email( (string) $p['email'] ) : '';
	$ad    = isset( $p['ad'] ) ? mb_substr( sanitize_text_field( (string) $p['ad'] ), 0, 80 ) : '';
	$rol   = isset( $p['rol'] ) && in_array( $p['rol'], SIDES_ROLLER, true ) ? $p['rol'] : 'personel';
	$pass  = isset( $p['sifre'] ) ? (string) $p['sifre'] : '';
	if ( ! is_email( $email ) || ! $ad ) {
		return new WP_Error( 'sides_eksik', 'Ad soyad ve geçerli bir e-posta yazın.', array( 'status' => 400 ) );
	}
	$u = get_user_by( 'email', $email );
	if ( $u ) {
		$c = sides_ctx( $u->ID );
		if ( $c['org'] && (int) $c['org'] !== $org ) {
			/* Ana hesap hangi kurumda olduğunu görür; kurum yöneticisine başka kurumun adı gösterilmez */
			$diger = sides_is_super() ? sides_org( (int) $c['org'] ) : null;
			return new WP_Error( 'sides_var', $diger
				? 'Bu e-posta «' . $diger->ad . '» kurumunda kayıtlı. Önce o kurumun Kullanıcılar sayfasından silin (ya da Ana Yönetim › Kurumlar\'dan o kurumu silin), sonra tekrar ekleyin.'
				: 'Bu e-posta başka bir kurumda kayıtlı. Farklı bir e-posta yazın ya da kişinin o kurumdan silinmesini isteyin.', array( 'status' => 409 ) );
		}
		if ( $c['org'] ) {
			return new WP_Error( 'sides_var', 'Bu kullanıcı zaten kurumunuzda.', array( 'status' => 409 ) );
		}
		/* v7.3.1 güvenlik: yalnız kurumsuz kalmış ATLAS üyesi bağlanır. Sitenin diğer hesapları (yönetici, yazar, müşteri…)
		   ve askıya alınmış başka kurumun üyeleri kuruma alınamaz; aksi hâlde şifreleri buradan değiştirilebilirdi. */
		$ozel = (int) get_user_meta( $u->ID, 'sides_org', true );
		if ( ! sides_salt_atlas_uyesi( $u ) || ( $ozel && $ozel !== $org ) ) {
			return new WP_Error( 'sides_var', 'Bu e-posta sitede başka bir hesapta kullanılıyor. Farklı bir e-posta yazın.', array( 'status' => 409 ) );
		}
		$uid = $u->ID;
	} else {
		if ( strlen( $pass ) < 8 ) {
			return new WP_Error( 'sides_sifre', 'Şifre en az 8 karakter olmalı.', array( 'status' => 400 ) );
		}
		$uid = sides_new_wp_user( $email, $ad, $pass );
		if ( is_wp_error( $uid ) ) {
			return $uid;
		}
		if ( ! empty( $p['bildir'] ) ) {
			wp_mail( $email, 'ATLAS hesabınız açıldı', "Merhaba $ad,\n\n" . ( ( $o = sides_org( $org ) ) ? $o->ad : '' ) . " kurumu size ATLAS hesabı açtı.\n\nGiriş adresi: " . optik_karne_url() . "\nE-posta: $email\nŞifrenizi yöneticinizden öğrenebilir veya giriş sayfasındaki \"Şifremi unuttum\" bağlantısıyla yenileyebilirsiniz.\n\nATLAS · Akademik Takip ve Analiz Sistemi" );
		}
	}
	update_user_meta( $uid, 'sides_org', $org );
	update_user_meta( $uid, 'sides_rol', $rol );
	update_user_meta( $uid, 'sides_yetki', sides_clean_yetki( isset( $p['yetki'] ) ? (array) $p['yetki'] : array() ) );
	update_user_meta( $uid, 'sides_siniflar', sides_clean_siniflar( isset( $p['siniflar'] ) ? (array) $p['siniflar'] : array() ) );
	if ( function_exists( 'sides_sayfa_temizle' ) ) {
		update_user_meta( $uid, 'sides_sayfa', sides_sayfa_temizle( isset( $p['sayfa'] ) ? (array) $p['sayfa'] : array() ) );
	}
	sides_log( $org, 'Kullanıcı eklendi: ' . $ad . ' (' . sides_rol_ad( $rol ) . ')' );
	return sides_user_row( get_userdata( $uid ), $org );
}

/* v7.3.1: hesabın WordPress rolleri yalnız ATLAS rolleri mi (sides_uye; eski sürümden ogretmen) */
function sides_salt_atlas_uyesi( $u ) {
	$r = array_values( (array) $u->roles );
	return ! user_can( $u, 'manage_options' ) && ! array_diff( $r, array( 'sides_uye', 'ogretmen' ) );
}

function sides_target_user( WP_REST_Request $req ) {
	$org = sides_org_id();
	$u   = get_userdata( (int) $req['id'] );
	if ( ! $u || (int) sides_ctx( $u->ID )['org'] !== $org ) {
		return new WP_Error( 'sides_yok', 'Kullanıcı bulunamadı.', array( 'status' => 404 ) );
	}
	if ( get_current_user_id() === $u->ID ) {
		return new WP_Error( 'sides_kendi', 'Kendi rolünüzü değiştiremezsiniz.', array( 'status' => 400 ) );
	}
	if ( user_can( $u, 'manage_options' ) ) {
		return new WP_Error( 'sides_kilit', 'Site yöneticisinin rolü buradan değiştirilemez.', array( 'status' => 400 ) );
	}
	return $u;
}

function sides_rest_user_edit( WP_REST_Request $req ) {
	$u = sides_target_user( $req );
	if ( is_wp_error( $u ) ) {
		return $u;
	}
	$org = sides_org_id();
	$p   = $req->get_json_params();
	if ( isset( $p['rol'] ) && in_array( $p['rol'], SIDES_ROLLER, true ) ) {
		update_user_meta( $u->ID, 'sides_rol', $p['rol'] );
		update_user_meta( $u->ID, 'sides_org', $org );
	}
	if ( isset( $p['yetki'] ) ) {
		update_user_meta( $u->ID, 'sides_yetki', sides_clean_yetki( (array) $p['yetki'] ) );
	}
	if ( isset( $p['siniflar'] ) ) {
		update_user_meta( $u->ID, 'sides_siniflar', sides_clean_siniflar( (array) $p['siniflar'] ) );
	}
	if ( isset( $p['sayfa'] ) && function_exists( 'sides_sayfa_temizle' ) ) {
		update_user_meta( $u->ID, 'sides_sayfa', sides_sayfa_temizle( (array) $p['sayfa'] ) );
	}
	if ( ! empty( $p['ad'] ) ) {
		wp_update_user( array( 'ID' => $u->ID, 'display_name' => mb_substr( sanitize_text_field( (string) $p['ad'] ), 0, 80 ) ) );
	}
	if ( ! empty( $p['sifre'] ) ) {
		if ( ! sides_salt_atlas_uyesi( $u ) ) {
			return new WP_Error( 'sides_kilit', 'Bu hesabın şifresi ATLAS’tan değiştirilemez; kişi kendi hesabından ya da “Şifremi unuttum” ile yenilemeli.', array( 'status' => 403 ) );
		}
		if ( strlen( (string) $p['sifre'] ) < 8 ) {
			return new WP_Error( 'sides_sifre', 'Şifre en az 8 karakter olmalı.', array( 'status' => 400 ) );
		}
		wp_set_password( (string) $p['sifre'], $u->ID );
	}
	sides_log( $org, 'Kullanıcı yetkisi güncellendi: ' . $u->display_name );
	return sides_user_row( get_userdata( $u->ID ), $org );
}

function sides_rest_user_remove( WP_REST_Request $req ) {
	$u = sides_target_user( $req );
	if ( is_wp_error( $u ) ) {
		return $u;
	}
	global $wpdb;
	$org = sides_org_id();
	delete_user_meta( $u->ID, 'sides_org' );
	delete_user_meta( $u->ID, 'sides_rol' );
	delete_user_meta( $u->ID, 'sides_yetki' );
	delete_user_meta( $u->ID, 'sides_siniflar' );
	if ( in_array( 'ogretmen', (array) $u->roles, true ) ) {
		$u->set_role( 'sides_uye' );
	}
	$o = sides_org( $org );
	if ( $o && (int) $o->sahip === (int) $u->ID ) {
		$wpdb->update( sides_orgs(), array( 'sahip' => 0 ), array( 'id' => $org ) );
	}
	/* Yalnızca ATLAS için açılmış hesap tamamen silinir; böylece e-posta adresi yeniden kullanılabilir.
	   Sitede başka bir rolü olan WordPress hesabına dokunulmaz, yalnızca ATLAS erişimi kaldırılır. */
	$ad      = $u->display_name;
	$u       = get_userdata( $u->ID );
	$silindi = false;
	if ( $u && array_values( (array) $u->roles ) === array( 'sides_uye' ) ) {
		require_once ABSPATH . 'wp-admin/includes/user.php';
		$silindi = (bool) wp_delete_user( $u->ID );
	}
	sides_log( $org, ( $silindi ? 'Kullanıcı silindi: ' : 'Kullanıcının erişimi kaldırıldı: ' ) . $ad );
	return array( 'ok' => true, 'silindi' => $silindi );
}

function sides_rol_ad( $r ) {
	$a = array( 'yonetici' => 'Yönetici', 'personel' => 'Personel', 'gozlemci' => 'Gözlemci', 'ogretmen' => 'Öğretmen (okutma)' );
	return isset( $a[ $r ] ) ? $a[ $r ] : $r;
}

/* E-posta ile yeni WordPress kullanıcısı (ATLAS kullanıcısı rolüyle) */
function sides_new_wp_user( $email, $ad, $pass, $is_hash = false ) {
	global $wpdb;
	$base  = sanitize_user( strtolower( strstr( $email, '@', true ) ), true );
	$base  = $base ? substr( $base, 0, 40 ) : 'kullanici';
	$login = $base;
	$i     = 1;
	while ( username_exists( $login ) ) {
		$login = $base . ( ++$i );
	}
	$uid = wp_insert_user( array(
		'user_login'   => $login,
		'user_email'   => $email,
		'user_pass'    => $is_hash ? wp_generate_password( 32 ) : $pass,
		'display_name' => $ad,
		'first_name'   => $ad,
		'role'         => 'sides_uye',
	) );
	if ( is_wp_error( $uid ) ) {
		if ( 'empty_data' === $uid->get_error_code() ) {
			sides_kayit_engeli( $email );
			return new WP_Error( 'sides_kullanici', 'Bu e-posta adresiyle hesap açılamadı. Sitedeki bir güvenlik veya istenmeyen kayıt (spam) koruması kaydı durdurdu. Geçici (tek kullanımlık) e-posta adresleri genellikle engellenir; kalıcı bir e-posta adresiyle tekrar deneyin. Sorun sürerse bizimle iletişime geçin.', array( 'status' => 400 ) );
		}
		return new WP_Error( 'sides_kullanici', 'Kullanıcı oluşturulamadı: ' . $uid->get_error_message(), array( 'status' => 400 ) );
	}
	if ( $is_hash ) {
		$wpdb->update( $wpdb->users, array( 'user_pass' => $pass ), array( 'ID' => $uid ) );
		clean_user_cache( $uid );
	}
	return $uid;
}

/* WordPress, kullanıcı oluşturmayı "wp_pre_insert_user_data" süzgecine bağlı bir eklenti durdurunca
   "Bu kullanıcıyı oluşturmak için yeterli veri bulunmuyor" hatası verir. Hangi eklentinin durdurduğu bulunur,
   Ana Hesap > Kayıt Ayarları'nda gösterilir ve site sahibine (en fazla 6 saatte bir) e-postayla bildirilir. */
function sides_filtre_eklentileri( $hook ) {
	global $wp_filter;
	$out = array();
	if ( empty( $wp_filter[ $hook ] ) || ! is_object( $wp_filter[ $hook ] ) ) {
		return $out;
	}
	$pd   = trailingslashit( wp_normalize_path( WP_PLUGIN_DIR ) );
	$mu   = trailingslashit( wp_normalize_path( WPMU_PLUGIN_DIR ) );
	$td   = trailingslashit( wp_normalize_path( get_theme_root() ) );
	$ben  = basename( dirname( __DIR__ ) );
	foreach ( $wp_filter[ $hook ]->callbacks as $cbs ) {
		foreach ( $cbs as $cb ) {
			$f = $cb['function'];
			try {
				if ( $f instanceof Closure || ( is_string( $f ) && false === strpos( $f, '::' ) && function_exists( $f ) ) ) {
					$r = new ReflectionFunction( $f );
				} elseif ( is_array( $f ) && 2 === count( $f ) ) {
					$r = new ReflectionMethod( is_object( $f[0] ) ? get_class( $f[0] ) : $f[0], $f[1] );
				} elseif ( is_string( $f ) && false !== strpos( $f, '::' ) ) {
					$r = new ReflectionMethod( $f );
				} elseif ( is_object( $f ) && method_exists( $f, '__invoke' ) ) {
					$r = new ReflectionMethod( $f, '__invoke' );
				} else {
					continue;
				}
				$file = wp_normalize_path( (string) $r->getFileName() );
			} catch ( Exception $e ) {
				continue;
			}
			if ( 0 === strpos( $file, $pd ) ) {
				$slug = strtok( substr( $file, strlen( $pd ) ), '/' );
				if ( $slug === $ben ) {
					continue;
				}
				$out[ $slug ] = sides_eklenti_adi( $slug );
			} elseif ( 0 === strpos( $file, $mu ) ) {
				$out[ 'mu:' . $file ] = 'Zorunlu eklenti (mu-plugins): ' . basename( $file );
			} elseif ( 0 === strpos( $file, $td ) ) {
				$out[ 'tema:' . $file ] = 'Tema: ' . strtok( substr( $file, strlen( $td ) ), '/' );
			}
		}
	}
	return array_values( $out );
}
function sides_eklenti_adi( $slug ) {
	if ( ! function_exists( 'get_plugins' ) ) {
		require_once ABSPATH . 'wp-admin/includes/plugin.php';
	}
	foreach ( get_plugins() as $file => $p ) {
		if ( 0 === strpos( $file, $slug . '/' ) || $file === $slug ) {
			return $p['Name'];
		}
	}
	return $slug;
}
function sides_kayit_engeli( $email ) {
	$ek   = sides_filtre_eklentileri( 'wp_pre_insert_user_data' );
	$alan = strtolower( (string) substr( strrchr( (string) $email, '@' ), 1 ) );
	update_option( 'sides_kayit_engel', array( 't' => time(), 'eklenti' => $ek, 'alan' => $alan ), false );
	if ( false === get_transient( 'sides_kayit_engel_mail' ) ) {
		set_transient( 'sides_kayit_engel_mail', 1, 6 * HOUR_IN_SECONDS );
		sides_mail_sahip( 'ATLAS: bir kurum kaydı engellendi', "Bir kurum kayıt olmaya çalıştı, ancak hesap oluşturma sitenizdeki başka bir eklenti tarafından durduruldu.\n\nE-posta alanı: @$alan\nDurduran eklenti: " . ( $ek ? implode( ', ', $ek ) : 'bulunamadı' ) . "\n\nGeçici (tek kullanımlık) e-posta adresleri genellikle bu şekilde engellenir; bu beklenen bir durumdur. Gerçek kurumların kaydı da engelleniyorsa ilgili eklentinin ayarlarında ATLAS kayıt sayfasını veya bu e-posta alanını izinli listeye ekleyin." );
	}
}
