<?php
/**
 * Günün Kelimeleri — yerleşik İngilizce kelime listesi (özgün; ATLAS için yazıldı, hiçbir yayınevi ya da site listesi kopyalanmadı).
 *
 * Biçim (includes/kelime.php sides_kelime_yerlesik() çözer):
 *   ## <sinif>|<konu>          bölüm başlığı: sinif 5 | 6 | 7 | 8 | genel, konu Türkçe tema adı
 *   en|tr|tur|ornek|ornekTr   tur: i isim, f fiil, s sıfat, z zarf, e edat, x ifade; ornek ve ornekTr isteğe bağlı (≤ 60 karakter)
 *   # …                        açıklama satırı
 * Yerleşik kimlik: <sinif>:<en küçük harf, boşluk yerine _>; aynı bölümde aynı İngilizce ikinci kez geçerse ~2 eklenir.
 * Kurum, yerleşik kelimeyi gizleyebilir ya da Türkçesini değiştirebilir (kelime/yerlesik belgesi); kendi kelimelerini ekleyebilir.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function sides_kelime_ham() {
	return <<<'VERI'
## 5|Selamlaşma
hello|merhaba|x|Hello! My name is Ali.|Merhaba! Benim adım Ali.
good morning|günaydın|x|Good morning, teacher!|Günaydın öğretmenim!
good night|iyi geceler|x|Good night, see you tomorrow.|İyi geceler, yarın görüşürüz.
goodbye|hoşça kal|x|Goodbye, have a nice day!|Hoşça kal, iyi günler!
please|lütfen|z|Open the window, please.|Pencereyi aç lütfen.
thank you|teşekkür ederim|x|Thank you for your help.|Yardımın için teşekkür ederim.
sorry|özür dilerim|x|Sorry, I am late.|Özür dilerim, geç kaldım.
name|ad, isim|i|What is your name?|Adın ne?
country|ülke|i|Türkiye is a beautiful country.|Türkiye güzel bir ülkedir.
nationality|milliyet, uyruk|i|What is your nationality?|Milliyetin nedir?
language|dil|i|English is a world language.|İngilizce bir dünya dilidir.
classmate|sınıf arkadaşı|i|Zeynep is my classmate.|Zeynep benim sınıf arkadaşım.
teacher|öğretmen|i|Our teacher is very kind.|Öğretmenimiz çok nazik.
student|öğrenci|i|I am a student at this school.|Bu okulda öğrenciyim.
spell|hecelemek, harf harf söylemek|f|Can you spell your name?|Adını heceleyebilir misin?
## 5|Şehrim
town|kasaba, şehir|i|I live in a small town.|Küçük bir kasabada yaşıyorum.
street|sokak, cadde|i|Our school is on this street.|Okulumuz bu sokakta.
bank|banka|i|The bank is next to the post office.|Banka postanenin yanında.
hospital|hastane|i|The hospital is near the park.|Hastane parkın yakınında.
library|kütüphane|i|I read books in the library.|Kütüphanede kitap okurum.
museum|müze|i|The museum opens at nine.|Müze dokuzda açılır.
pharmacy|eczane|i|There is a pharmacy on the corner.|Köşede bir eczane var.
post office|postane|i|I send letters from the post office.|Postaneden mektup gönderirim.
bus stop|otobüs durağı|i|Wait for me at the bus stop.|Beni otobüs durağında bekle.
mosque|cami|i|The mosque is behind the market.|Cami pazarın arkasında.
between|arasında|e|The café is between two shops.|Kafe iki dükkânın arasında.
opposite|karşısında|e|The bakery is opposite the school.|Fırın okulun karşısında.
turn left|sola dönmek|x|Turn left at the traffic lights.|Trafik ışıklarında sola dön.
turn right|sağa dönmek|x|Turn right and go straight.|Sağa dön ve düz git.
go straight|düz gitmek|x|Go straight for two blocks.|İki blok düz git.
map|harita|i|Look at the map of our town.|Şehrimizin haritasına bak.
## 5|Oyunlar ve Hobiler
hobby|hobi, uğraş|i|My hobby is painting.|Hobim resim yapmak.
hide and seek|saklambaç|i|We play hide and seek in the garden.|Bahçede saklambaç oynarız.
hopscotch|seksek|i|The girls are playing hopscotch.|Kızlar seksek oynuyor.
chess|satranç|i|Chess is a game for two players.|Satranç iki kişilik bir oyundur.
marbles|misket|i|My grandfather played marbles.|Dedem misket oynarmış.
skipping rope|ip atlama|i|Skipping rope is good exercise.|İp atlamak iyi bir egzersizdir.
blind man's buff|körebe|i|Let's play blind man's buff!|Hadi körebe oynayalım!
dodgeball|yakar top|i|We played dodgeball at break time.|Teneffüste yakar top oynadık.
collect|toplamak, biriktirmek|f|I collect stamps and coins.|Pul ve madenî para biriktiriyorum.
origami|origami, kâğıt katlama|i|She makes birds with origami.|Origamiyle kuşlar yapıyor.
puzzle|yapboz, bulmaca|i|This puzzle has 500 pieces.|Bu yapboz 500 parçalı.
camping|kamp yapma|i|We go camping every summer.|Her yaz kampa gideriz.
cycling|bisiklete binme|i|Cycling is my favourite hobby.|Bisiklete binmek en sevdiğim hobi.
fishing|balık tutma|i|My uncle loves fishing.|Amcam balık tutmayı çok sever.
board game|kutu oyunu, masa oyunu|i|We play board games on rainy days.|Yağmurlu günlerde kutu oyunu oynarız.
team|takım|i|Our team won the game.|Takımımız oyunu kazandı.
## 5|Günlük Rutin
wake up|uyanmak|f|I wake up at seven o'clock.|Saat yedide uyanırım.
get up|kalkmak|f|Get up, it is late!|Kalk, geç oldu!
get dressed|giyinmek|f|I get dressed quickly.|Hızlıca giyinirim.
brush|fırçalamak|f|Brush your teeth twice a day.|Dişlerini günde iki kez fırçala.
have breakfast|kahvaltı yapmak|f|We have breakfast together.|Birlikte kahvaltı yaparız.
go to school|okula gitmek|f|I go to school by bus.|Okula otobüsle giderim.
homework|ödev|i|I do my homework after dinner.|Ödevimi akşam yemeğinden sonra yaparım.
go to bed|yatmak, yatağa gitmek|f|I go to bed at ten.|Onda yatarım.
early|erken|z|My father gets up early.|Babam erken kalkar.
late|geç|z|Don't be late for school.|Okula geç kalma.
always|her zaman, daima|z|I always do my homework.|Ödevimi her zaman yaparım.
usually|genellikle|z|I usually walk to school.|Okula genellikle yürürüm.
sometimes|bazen|z|Sometimes I play chess.|Bazen satranç oynarım.
never|asla, hiç|z|I never skip breakfast.|Kahvaltıyı asla atlamam.
half past|buçuk|x|It is half past eight.|Saat sekiz buçuk.
quarter|çeyrek|i|It is a quarter to nine.|Saat dokuza çeyrek var.
timetable|ders programı|i|Check the timetable for Monday.|Pazartesi için ders programına bak.
## 5|Sağlık
headache|baş ağrısı|i|I have a terrible headache.|Korkunç bir baş ağrım var.
stomachache|karın ağrısı|i|He has a stomachache today.|Bugün karnı ağrıyor.
toothache|diş ağrısı|i|Go to the dentist for your toothache.|Diş ağrın için dişçiye git.
sore throat|boğaz ağrısı|i|I have a sore throat and a cough.|Boğaz ağrım ve öksürüğüm var.
cold|soğuk algınlığı, soğuk|i|She has a bad cold.|Kötü bir soğuk algınlığı var.
flu|grip|i|Many students have the flu.|Birçok öğrenci grip oldu.
fever|ateş|i|The baby has a high fever.|Bebeğin ateşi yüksek.
cough|öksürük|i|Drink warm water for your cough.|Öksürüğün için ılık su iç.
doctor|doktor|i|You should see a doctor.|Bir doktora görünmelisin.
dentist|diş hekimi|i|I visit the dentist twice a year.|Yılda iki kez diş hekimine giderim.
medicine|ilaç|i|Take your medicine after meals.|İlacını yemeklerden sonra al.
rest|dinlenmek|f|You should rest in bed.|Yatakta dinlenmelisin.
hurt|acımak, incitmek|f|My leg hurts a lot.|Bacağım çok acıyor.
should|-meli, -malı|x|You should drink more water.|Daha çok su içmelisin.
healthy|sağlıklı|s|Vegetables are healthy food.|Sebzeler sağlıklı yiyeceklerdir.
ill|hasta|s|I feel ill today.|Bugün kendimi hasta hissediyorum.
## 5|Filmler
film|film|i|We watched a funny film.|Komik bir film izledik.
cartoon|çizgi film|i|My little brother loves cartoons.|Küçük kardeşim çizgi filmleri çok sever.
comedy|komedi|i|Comedies make me laugh.|Komediler beni güldürür.
horror|korku|i|I don't like horror films.|Korku filmlerini sevmem.
animation|animasyon|i|This animation is for children.|Bu animasyon çocuklar için.
science fiction|bilim kurgu|i|Science fiction films show the future.|Bilim kurgu filmleri geleceği gösterir.
documentary|belgesel|i|We watched a documentary about whales.|Balinalar hakkında bir belgesel izledik.
actor|oyuncu, aktör|i|He is a famous actor.|O ünlü bir oyuncu.
character|karakter|i|Who is your favourite character?|En sevdiğin karakter kim?
funny|komik, eğlenceli|s|The film was very funny.|Film çok komikti.
scary|korkutucu, ürkütücü|s|That film is too scary for me.|O film benim için fazla korkutucu.
boring|sıkıcı|s|The documentary was boring.|Belgesel sıkıcıydı.
exciting|heyecan verici|s|The adventure film was exciting.|Macera filmi heyecan vericiydi.
cinema|sinema|i|Let's go to the cinema on Saturday.|Cumartesi sinemaya gidelim.
ticket|bilet|i|I bought two tickets.|İki bilet aldım.
popcorn|patlamış mısır|i|We eat popcorn at the cinema.|Sinemada patlamış mısır yeriz.
## 5|Parti
party|parti, eğlence|i|My birthday party is on Friday.|Doğum günü partim cuma günü.
invitation|davetiye, davet|i|I got an invitation card.|Bir davetiye aldım.
invite|davet etmek|f|I want to invite all my friends.|Bütün arkadaşlarımı davet etmek istiyorum.
balloon|balon|i|We need colourful balloons.|Renkli balonlara ihtiyacımız var.
candle|mum|i|There are eleven candles on the cake.|Pastanın üzerinde on bir mum var.
cake|pasta, kek|i|Mum made a chocolate cake.|Annem çikolatalı pasta yaptı.
present|hediye, armağan|i|Thank you for the present!|Hediye için teşekkürler!
decorate|süslemek|f|Let's decorate the room.|Hadi odayı süsleyelim.
guest|misafir, konuk|i|Twenty guests are coming.|Yirmi misafir geliyor.
celebrate|kutlamak|f|We celebrate my birthday at home.|Doğum günümü evde kutlarız.
music|müzik|i|Turn on the music, please.|Lütfen müziği aç.
dance|dans etmek|f|Everybody dances at the party.|Partide herkes dans eder.
lemonade|limonata|i|Would you like some lemonade?|Biraz limonata ister misin?
would you like|ister misin|x|Would you like a piece of cake?|Bir dilim pasta ister misin?
wear|giymek|f|I will wear my new dress.|Yeni elbisemi giyeceğim.
costume|kostüm|i|She wears a cat costume.|Kedi kostümü giyiyor.
## 5|Spor ve Zindelik
exercise|egzersiz|i|Exercise keeps you healthy.|Egzersiz seni sağlıklı tutar.
push-up|şınav|i|I can do twenty push-ups.|Yirmi şınav çekebilirim.
sit-up|mekik|i|Do ten sit-ups every morning.|Her sabah on mekik çek.
jump|zıplamak, atlamak|f|Jump as high as you can.|Zıplayabildiğin kadar yükseğe zıpla.
run|koşmak|f|I run in the park on Sundays.|Pazarları parkta koşarım.
swim|yüzmek|f|Can you swim?|Yüzebiliyor musun?
stretch|esnemek, germek|f|Stretch your arms before running.|Koşmadan önce kollarını ger.
warm up|ısınmak|f|Always warm up before sports.|Spordan önce her zaman ısın.
strong|güçlü, kuvvetli|s|Sports make us strong.|Spor bizi güçlü yapar.
fit|formda, zinde|s|My uncle is very fit.|Amcam çok formda.
sports hall|spor salonu|i|We play basketball in the sports hall.|Spor salonunda basketbol oynarız.
football|futbol|i|Football is popular in Türkiye.|Futbol Türkiye'de popülerdir.
basketball|basketbol|i|Tall players are good at basketball.|Uzun oyuncular basketbolda iyidir.
volleyball|voleybol|i|Our volleyball team is great.|Voleybol takımımız harika.
tennis|tenis|i|She plays tennis on Mondays.|Pazartesileri tenis oynar.
racket|raket|i|I need a new tennis racket.|Yeni bir tenis raketine ihtiyacım var.
## 5|Hayvanlar
animal|hayvan|i|What is your favourite animal?|En sevdiğin hayvan hangisi?
pet|evcil hayvan|i|Do you have a pet?|Evcil hayvanın var mı?
cat|kedi|i|Our cat sleeps all day.|Kedimiz bütün gün uyur.
dog|köpek|i|The dog is barking.|Köpek havlıyor.
rabbit|tavşan|i|Rabbits eat carrots.|Tavşanlar havuç yer.
turtle|kaplumbağa|i|Turtles move slowly.|Kaplumbağalar yavaş hareket eder.
parrot|papağan|i|A parrot can talk.|Papağan konuşabilir.
hamster|hamster|i|My hamster runs in its wheel.|Hamsterim çarkında koşuyor.
goldfish|japon balığı|i|Goldfish live in a bowl.|Japon balıkları fanusta yaşar.
feed|beslemek|f|I feed my cat every morning.|Kedimi her sabah beslerim.
shelter|barınak|i|We visited the animal shelter.|Hayvan barınağını ziyaret ettik.
adopt|sahiplenmek|f|We adopted a puppy from the shelter.|Barınaktan bir yavru köpek sahiplendik.
cage|kafes|i|The bird is in a cage.|Kuş kafeste.
fur|kürk, tüy|i|The cat has soft fur.|Kedinin tüyleri yumuşak.
tail|kuyruk|i|The dog wags its tail.|Köpek kuyruğunu sallıyor.
wing|kanat|i|Birds have two wings.|Kuşların iki kanadı vardır.
veterinarian|veteriner|i|The veterinarian helps sick animals.|Veteriner hasta hayvanlara yardım eder.
## 5|Festivaller
festival|festival, şenlik|i|There is a music festival in May.|Mayısta bir müzik festivali var.
holiday|tatil, bayram|i|Children's Day is a national holiday.|Çocuk Bayramı ulusal bir bayramdır.
tradition|gelenek|i|It is a tradition to visit relatives.|Akrabaları ziyaret etmek bir gelenektir.
fireworks|havai fişek|i|We watched fireworks at night.|Gece havai fişek izledik.
parade|geçit töreni|i|There was a parade in the street.|Sokakta bir geçit töreni vardı.
mask|maske|i|People wear masks at the carnival.|İnsanlar karnavalda maske takar.
greeting card|tebrik kartı|i|I sent a greeting card to my aunt.|Teyzeme tebrik kartı gönderdim.
special|özel|s|Today is a special day.|Bugün özel bir gün.
national|ulusal, millî|s|We sing the national anthem.|Millî marşı söyleriz.
flag|bayrak|i|Our flag is red and white.|Bayrağımız kırmızı ve beyazdır.
visit|ziyaret etmek|f|We visit our grandparents on holidays.|Bayramlarda büyüklerimizi ziyaret ederiz.
kiss|öpmek|f|Children kiss the hands of elders.|Çocuklar büyüklerin ellerini öper.
sweet|şeker, tatlı|i|We give sweets to children.|Çocuklara şeker veririz.
gift|hediye|i|Everyone gets a small gift.|Herkes küçük bir hediye alır.
lantern|fener|i|The lanterns light up the street.|Fenerler sokağı aydınlatıyor.
joy|neşe, sevinç|i|The festival brings joy to everyone.|Festival herkese neşe getirir.
## 6|Günlük Hayat
chore|ev işi|i|I help with the chores at home.|Evde ev işlerine yardım ederim.
tidy|toplamak, düzenlemek|f|Tidy your room before dinner.|Akşam yemeğinden önce odanı topla.
take out the rubbish|çöpü dışarı çıkarmak|x|I take out the rubbish on Mondays.|Pazartesileri çöpü dışarı çıkarırım.
wash the dishes|bulaşık yıkamak|x|My sister washes the dishes.|Kız kardeşim bulaşıkları yıkar.
water the plants|çiçekleri sulamak|x|Water the plants twice a week.|Çiçekleri haftada iki kez sula.
make the bed|yatağı toplamak|x|I make my bed every morning.|Her sabah yatağımı toplarım.
weekday|hafta içi günü|i|I get up early on weekdays.|Hafta içi erken kalkarım.
weekend|hafta sonu|i|We go to the park at the weekend.|Hafta sonu parka gideriz.
free time|boş zaman|i|What do you do in your free time?|Boş zamanında ne yaparsın?
hang out|takılmak, vakit geçirmek|f|I hang out with my friends.|Arkadaşlarımla takılırım.
practise|alıştırma yapmak, çalışmak|f|I practise the guitar every day.|Her gün gitar çalışırım.
attend|katılmak|f|She attends a drama course.|Tiyatro kursuna katılıyor.
once|bir kez|z|I swim once a week.|Haftada bir kez yüzerim.
twice|iki kez|z|We visit grandma twice a month.|Büyükannemi ayda iki kez ziyaret ederiz.
rarely|nadiren|z|He rarely watches TV.|Nadiren televizyon izler.
often|sık sık|z|I often read before bed.|Yatmadan önce sık sık okurum.
## 6|Kahvaltı ve Yiyecek
breakfast|kahvaltı|i|Breakfast is the first meal of the day.|Kahvaltı günün ilk öğünüdür.
cheese|peynir|i|I eat cheese and olives.|Peynir ve zeytin yerim.
olive|zeytin|i|Black olives are my favourite.|Siyah zeytin en sevdiğim.
honey|bal|i|Honey is sweet and healthy.|Bal tatlı ve sağlıklıdır.
jam|reçel|i|Strawberry jam is delicious.|Çilek reçeli çok lezzetli.
butter|tereyağı|i|Spread butter on the bread.|Ekmeğe tereyağı sür.
egg|yumurta|i|I like boiled eggs.|Haşlanmış yumurta severim.
sausage|sosis|i|We had sausages for breakfast.|Kahvaltıda sosis yedik.
pastry|börek, hamur işi|i|My grandmother makes great pastry.|Büyükannem harika börek yapar.
cereal|mısır gevreği|i|He eats cereal with milk.|Mısır gevreğini sütle yer.
delicious|lezzetli|s|This soup is delicious!|Bu çorba çok lezzetli!
sour|ekşi|s|Lemons are sour.|Limonlar ekşidir.
salty|tuzlu|s|The cheese is too salty.|Peynir çok tuzlu.
bitter|acı|s|Black coffee is bitter.|Sade kahve acıdır.
spicy|baharatlı, acılı|s|I love spicy food.|Baharatlı yemekleri çok severim.
yummy|çok lezzetli|s|These pancakes are yummy!|Bu pankekler çok lezzetli!
prefer|tercih etmek|f|I prefer tea to coffee.|Kahve yerine çayı tercih ederim.
## 6|Şehir Merkezi
downtown|şehir merkezi|i|We went downtown by tram.|Şehir merkezine tramvayla gittik.
crowded|kalabalık|s|The market is very crowded today.|Pazar bugün çok kalabalık.
quiet|sessiz, sakin|s|The village is quiet at night.|Köy geceleri sessizdir.
modern|modern, çağdaş|s|It is a modern shopping centre.|Modern bir alışveriş merkezi.
polluted|kirli, kirlenmiş|s|The air is polluted in big cities.|Büyük şehirlerde hava kirlidir.
traffic|trafik|i|There is heavy traffic in the morning.|Sabahları yoğun trafik var.
skyscraper|gökdelen|i|There are many skyscrapers in Istanbul.|İstanbul'da çok sayıda gökdelen var.
shopping centre|alışveriş merkezi|i|The shopping centre is open until ten.|Alışveriş merkezi ona kadar açık.
stadium|stadyum|i|The stadium is full of fans.|Stadyum taraftarlarla dolu.
underground|metro|i|Take the underground to the centre.|Merkeze metroyla git.
noisy|gürültülü|s|The street is noisy and busy.|Sokak gürültülü ve hareketli.
peaceful|huzurlu, sakin|s|Our neighbourhood is peaceful.|Mahallemiz huzurlu.
fountain|çeşme, fıskiye|i|There is a fountain in the square.|Meydanda bir çeşme var.
bridge|köprü|i|The bridge connects the two sides.|Köprü iki yakayı birleştirir.
square|meydan|i|People meet in the main square.|İnsanlar ana meydanda buluşur.
historical|tarihî|s|Istanbul has many historical places.|İstanbul'da birçok tarihî yer var.
## 6|Hava ve Duygular
weather|hava, hava durumu|i|What is the weather like today?|Bugün hava nasıl?
sunny|güneşli|s|It is sunny and warm.|Hava güneşli ve ılık.
rainy|yağmurlu|s|Take an umbrella, it is rainy.|Şemsiye al, hava yağmurlu.
snowy|karlı|s|The mountains are snowy in winter.|Dağlar kışın karlıdır.
windy|rüzgârlı|s|It is too windy to fly a kite.|Uçurtma uçurmak için fazla rüzgârlı.
foggy|sisli|s|Drive slowly, it is foggy.|Yavaş sür, hava sisli.
stormy|fırtınalı|s|It was a stormy night.|Fırtınalı bir geceydi.
freezing|dondurucu, buz gibi|s|It is freezing outside!|Dışarısı buz gibi!
temperature|sıcaklık|i|The temperature is 25 degrees.|Sıcaklık 25 derece.
happy|mutlu|s|I feel happy on sunny days.|Güneşli günlerde mutlu hissederim.
sad|üzgün|s|Rainy days make him sad.|Yağmurlu günler onu üzer.
angry|kızgın, öfkeli|s|Why are you angry?|Neden kızgınsın?
scared|korkmuş|s|I am scared of thunder.|Gök gürültüsünden korkarım.
moody|huysuz, karamsar|s|He is moody in cold weather.|Soğuk havada huysuz olur.
energetic|enerjik|s|I feel energetic in the morning.|Sabahları enerjik hissederim.
anxious|endişeli, kaygılı|s|She is anxious about the exam.|Sınav için endişeli.
thunder|gök gürültüsü|i|The thunder was very loud.|Gök gürültüsü çok yüksekti.
## 6|Lunapark
fair|lunapark, panayır|i|The fair comes to town in June.|Lunapark haziranda kasabaya gelir.
roller coaster|hız treni|i|The roller coaster was so fast!|Hız treni çok hızlıydı!
Ferris wheel|dönme dolap|i|You can see the city from the Ferris wheel.|Şehri dönme dolaptan görebilirsin.
bumper car|çarpışan araba|i|Bumper cars are fun!|Çarpışan arabalar eğlenceli!
carousel|atlıkarınca|i|Little children love the carousel.|Küçük çocuklar atlıkarıncayı çok sever.
ghost train|korku treni|i|I was scared on the ghost train.|Korku treninde korktum.
ride|binmek|f|Let's ride the big wheel.|Hadi dönme dolaba binelim.
candy floss|pamuk şeker|i|Pink candy floss is sweet.|Pembe pamuk şeker tatlıdır.
frightening|korkutucu|s|The ghost train is frightening.|Korku treni korkutucu.
thrilling|heyecan verici|s|The ride was thrilling.|Yolculuk heyecan vericiydi.
dull|sıkıcı, donuk|s|The show was a bit dull.|Gösteri biraz sıkıcıydı.
queue|kuyruk, sıra|i|There is a long queue for tickets.|Biletler için uzun bir kuyruk var.
scream|çığlık atmak|f|Everybody screamed on the ride.|Hız treninde herkes çığlık attı.
fun|eğlence|i|We had a lot of fun at the fair.|Lunaparkta çok eğlendik.
must|-meli (zorunluluk)|x|You must be ten to ride this.|Buna binmek için on yaşında olmalısın.
amazing|şaşırtıcı, harika|s|The view was amazing.|Manzara harikaydı.
horrible|korkunç, berbat|s|The weather was horrible.|Hava berbattı.
## 6|Meslekler
job|iş, meslek|i|What is your mother's job?|Annenin mesleği ne?
nurse|hemşire|i|The nurse gave me an injection.|Hemşire bana iğne yaptı.
engineer|mühendis|i|My father is an engineer.|Babam mühendis.
farmer|çiftçi|i|Farmers grow vegetables.|Çiftçiler sebze yetiştirir.
pilot|pilot|i|A pilot flies planes.|Pilot uçak uçurur.
firefighter|itfaiyeci|i|Firefighters put out fires.|İtfaiyeciler yangınları söndürür.
police officer|polis memuru|i|The police officer stopped the car.|Polis memuru arabayı durdurdu.
lawyer|avukat|i|My aunt is a lawyer.|Teyzem avukat.
chef|aşçı, şef|i|The chef cooks in a restaurant.|Aşçı restoranda yemek pişirir.
waiter|garson|i|The waiter brought the menu.|Garson menüyü getirdi.
architect|mimar|i|An architect designs buildings.|Mimar binalar tasarlar.
mechanic|tamirci|i|The mechanic fixed our car.|Tamirci arabamızı tamir etti.
hairdresser|kuaför|i|The hairdresser cut my hair.|Kuaför saçımı kesti.
journalist|gazeteci|i|A journalist writes news.|Gazeteci haber yazar.
work|çalışmak|f|My mum works in a hospital.|Annem bir hastanede çalışır.
earn|kazanmak (para)|f|He earns money by selling bread.|Ekmek satarak para kazanır.
uniform|üniforma|i|Nurses wear white uniforms.|Hemşireler beyaz üniforma giyer.
## 6|Tatiller
vacation|tatil|i|We spent our vacation by the sea.|Tatilimizi deniz kenarında geçirdik.
beach|plaj, kumsal|i|We built sandcastles on the beach.|Plajda kumdan kale yaptık.
sunbathe|güneşlenmek|f|My mum likes to sunbathe.|Annem güneşlenmeyi sever.
suitcase|bavul, valiz|i|Pack your suitcase tonight.|Bavulunu bu gece hazırla.
passport|pasaport|i|Don't forget your passport.|Pasaportunu unutma.
hotel|otel|i|We stayed at a small hotel.|Küçük bir otelde kaldık.
tent|çadır|i|We slept in a tent.|Çadırda uyuduk.
sightseeing|gezip görme|i|We went sightseeing in Rome.|Roma'da şehri gezdik.
souvenir|hediyelik eşya|i|I bought souvenirs for my friends.|Arkadaşlarıma hediyelik eşya aldım.
journey|yolculuk|i|It was a long journey by train.|Trenle uzun bir yolculuktu.
abroad|yurt dışında|z|My cousin lives abroad.|Kuzenim yurt dışında yaşıyor.
sunscreen|güneş kremi|i|Put on sunscreen at the beach.|Plajda güneş kremi sür.
sunglasses|güneş gözlüğü|i|I lost my sunglasses.|Güneş gözlüğümü kaybettim.
travel|seyahat etmek|f|I want to travel the world.|Dünyayı gezmek istiyorum.
stay|kalmak|f|How long did you stay there?|Orada ne kadar kaldın?
arrive|varmak|f|We arrived at the hotel at noon.|Otele öğlen vardık.
last|geçen, son|s|Last summer we went to Antalya.|Geçen yaz Antalya'ya gittik.
## 6|Kitaplar
bookworm|kitap kurdu|i|My sister is a real bookworm.|Kız kardeşim tam bir kitap kurdu.
novel|roman|i|I am reading a long novel.|Uzun bir roman okuyorum.
poem|şiir|i|She wrote a poem for her mother.|Annesi için bir şiir yazdı.
fairy tale|peri masalı|i|Children love fairy tales.|Çocuklar peri masallarını çok sever.
author|yazar|i|Who is the author of this book?|Bu kitabın yazarı kim?
page|sayfa|i|Open your books to page ten.|Kitaplarınızın onuncu sayfasını açın.
chapter|bölüm (kitap)|i|I read two chapters last night.|Dün gece iki bölüm okudum.
borrow|ödünç almak|f|You can borrow books from the library.|Kütüphaneden kitap ödünç alabilirsin.
return|geri vermek, dönmek|f|Return the book in two weeks.|Kitabı iki hafta içinde geri ver.
bookshop|kitapçı|i|There is a new bookshop near here.|Yakında yeni bir kitapçı var.
dictionary|sözlük|i|Look up the word in a dictionary.|Kelimeye sözlükten bak.
magazine|dergi|i|I read a science magazine.|Bir bilim dergisi okuyorum.
comic|çizgi roman|i|Comics are fun to read.|Çizgi romanlar okumak için eğlenceli.
encyclopedia|ansiklopedi|i|The encyclopedia has many facts.|Ansiklopedide pek çok bilgi var.
adventure|macera|i|It is an adventure story.|Bu bir macera hikâyesi.
legend|efsane|i|This legend is very old.|Bu efsane çok eski.
interesting|ilginç|s|The story is very interesting.|Hikâye çok ilginç.
## 6|Gezegeni Korumak
planet|gezegen|i|We must protect our planet.|Gezegenimizi korumalıyız.
recycle|geri dönüştürmek|f|We recycle paper and glass.|Kâğıt ve camı geri dönüştürürüz.
reuse|yeniden kullanmak|f|Reuse your shopping bags.|Alışveriş torbalarını yeniden kullan.
reduce|azaltmak|f|Reduce the use of plastic.|Plastik kullanımını azalt.
rubbish|çöp|i|Don't throw rubbish on the ground.|Yere çöp atma.
pollution|kirlilik|i|Air pollution is a big problem.|Hava kirliliği büyük bir sorun.
save|korumak, tasarruf etmek|f|Save water and energy.|Su ve enerjiyi tasarruflu kullan.
waste|israf etmek|f|Don't waste food.|Yiyecek israf etme.
energy|enerji|i|Turn off the lights to save energy.|Enerji tasarrufu için ışıkları kapat.
plant a tree|ağaç dikmek|x|We planted trees in the schoolyard.|Okul bahçesine ağaç diktik.
environment|çevre|i|Keep the environment clean.|Çevreyi temiz tut.
bin|çöp kutusu|i|Put the paper in the blue bin.|Kâğıdı mavi çöp kutusuna at.
unplug|fişten çekmek|f|Unplug the charger after use.|Kullandıktan sonra şarj aletini fişten çek.
harmful|zararlı|s|Plastic bags are harmful to nature.|Plastik torbalar doğaya zararlıdır.
nature|doğa|i|We love walking in nature.|Doğada yürümeyi severiz.
tap|musluk|i|Turn off the tap while brushing.|Diş fırçalarken musluğu kapat.
litter|çöp atmak|f|Don't litter in the park.|Parka çöp atma.
## 6|Demokrasi
democracy|demokrasi|i|Democracy means people choose.|Demokrasi halkın seçmesi demektir.
election|seçim|i|The class election is on Friday.|Sınıf seçimi cuma günü.
vote|oy vermek|f|Everyone votes for a president.|Herkes bir başkan için oy verir.
candidate|aday|i|There are three candidates.|Üç aday var.
president|başkan|i|Ayşe is our class president.|Ayşe sınıf başkanımız.
campaign|kampanya|i|He made posters for his campaign.|Kampanyası için afişler yaptı.
right|hak|i|Everyone has the right to speak.|Herkesin konuşma hakkı vardır.
responsibility|sorumluluk|i|Voting is a responsibility.|Oy vermek bir sorumluluktur.
fair|adil|s|The election was fair.|Seçim adildi.
equal|eşit|s|All people are equal.|Bütün insanlar eşittir.
respect|saygı|i|Show respect to others.|Başkalarına saygı göster.
freedom|özgürlük|i|Freedom of speech is important.|İfade özgürlüğü önemlidir.
rule|kural|i|We follow the class rules.|Sınıf kurallarına uyarız.
decide|karar vermek|f|We decide together.|Birlikte karar veririz.
agree|aynı fikirde olmak, katılmak|f|I agree with you.|Sana katılıyorum.
disagree|aynı fikirde olmamak|f|It is OK to disagree politely.|Nazikçe karşı çıkmak sorun değil.
ballot box|oy sandığı|i|Put your paper in the ballot box.|Kâğıdını oy sandığına at.
speech|konuşma|i|She gave a short speech.|Kısa bir konuşma yaptı.
## 7|Görünüş ve Kişilik
appearance|görünüş, dış görünüm|i|Don't judge people by their appearance.|İnsanları görünüşüyle yargılama.
personality|kişilik|i|She has a warm personality.|Sıcak bir kişiliği var.
tall|uzun boylu|s|My brother is tall and thin.|Ağabeyim uzun boylu ve zayıf.
slim|ince, zayıf|s|She is slim and sporty.|İnce ve sportif.
plump|tombul|s|The baby is plump and cute.|Bebek tombul ve sevimli.
curly|kıvırcık|s|I have curly hair.|Kıvırcık saçlarım var.
straight|düz|s|Her hair is long and straight.|Saçları uzun ve düz.
wavy|dalgalı|s|He has wavy brown hair.|Dalgalı kahverengi saçları var.
beard|sakal|i|My uncle has a grey beard.|Amcamın gri sakalı var.
freckles|çiller|i|She has freckles on her nose.|Burnunda çilleri var.
generous|cömert|s|My grandmother is very generous.|Büyükannem çok cömert.
stubborn|inatçı|s|Don't be so stubborn!|Bu kadar inatçı olma!
honest|dürüst|s|An honest person tells the truth.|Dürüst bir insan doğruyu söyler.
shy|utangaç|s|He is shy with new people.|Yeni insanlara karşı utangaç.
outgoing|dışa dönük, girişken|s|She is outgoing and friendly.|Dışa dönük ve arkadaş canlısı.
selfish|bencil|s|Selfish people think only of themselves.|Bencil insanlar yalnızca kendini düşünür.
punctual|dakik|s|Our teacher is always punctual.|Öğretmenimiz her zaman dakiktir.
cheerful|neşeli|s|He is a cheerful boy.|Neşeli bir çocuk.
## 7|Spor
athlete|sporcu, atlet|i|The athlete trains every day.|Sporcu her gün antrenman yapar.
coach|antrenör|i|Our coach is very strict.|Antrenörümüz çok sıkı.
championship|şampiyona|i|They won the championship.|Şampiyonayı kazandılar.
medal|madalya|i|She got a gold medal.|Altın madalya aldı.
score|skor, sayı|i|What is the score?|Skor ne?
goal|gol|i|He scored two goals.|İki gol attı.
referee|hakem|i|The referee blew the whistle.|Hakem düdük çaldı.
opponent|rakip|i|Our opponent was very strong.|Rakibimiz çok güçlüydü.
train|antrenman yapmak|f|We train three times a week.|Haftada üç kez antrenman yaparız.
compete|yarışmak|f|Ten schools compete in the race.|Yarışta on okul yarışıyor.
win|kazanmak|f|I hope our team wins.|Umarım takımımız kazanır.
lose|kaybetmek|f|We lost the match 2-1.|Maçı 2-1 kaybettik.
draw|berabere kalmak|f|The match ended in a draw.|Maç berabere bitti.
equipment|donanım, malzeme|i|Bring your sports equipment.|Spor malzemelerini getir.
helmet|kask|i|Wear a helmet when cycling.|Bisiklet sürerken kask tak.
archery|okçuluk|i|Archery is a traditional Turkish sport.|Okçuluk geleneksel bir Türk sporudur.
wrestling|güreş|i|Oil wrestling is famous in Edirne.|Yağlı güreş Edirne'de ünlüdür.
individual|bireysel|s|Tennis is an individual sport.|Tenis bireysel bir spordur.
## 7|Biyografiler
biography|biyografi, yaşam öyküsü|i|I read a biography of Atatürk.|Atatürk'ün bir biyografisini okudum.
be born|doğmak|f|She was born in 1990.|1990'da doğdu.
grow up|büyümek|f|He grew up in a small village.|Küçük bir köyde büyüdü.
graduate|mezun olmak|f|My sister graduated last year.|Kız kardeşim geçen yıl mezun oldu.
get married|evlenmek|f|They got married in June.|Haziranda evlendiler.
die|ölmek|f|The poet died in 1963.|Şair 1963'te öldü.
childhood|çocukluk|i|I had a happy childhood.|Mutlu bir çocukluğum oldu.
scientist|bilim insanı|i|Marie Curie was a great scientist.|Marie Curie büyük bir bilim insanıydı.
inventor|mucit|i|The inventor made a new machine.|Mucit yeni bir makine yaptı.
discover|keşfetmek|f|Who discovered penicillin?|Penisilini kim keşfetti?
invent|icat etmek|f|Edison invented the light bulb.|Edison ampulü icat etti.
award|ödül|i|She received an award for her work.|Çalışması için bir ödül aldı.
famous|ünlü|s|He became famous at twenty.|Yirmi yaşında ünlü oldu.
successful|başarılı|s|She is a successful writer.|Başarılı bir yazar.
achievement|başarı|i|It was a great achievement.|Büyük bir başarıydı.
career|kariyer, meslek hayatı|i|He had a long career in music.|Müzikte uzun bir kariyeri oldu.
move|taşınmak|f|They moved to Ankara in 2010.|2010'da Ankara'ya taşındılar.
century|yüzyıl|i|He lived in the 19th century.|19. yüzyılda yaşadı.
poet|şair|i|Yunus Emre is a famous Turkish poet.|Yunus Emre ünlü bir Türk şairidir.
## 7|Vahşi Hayvanlar
wild|vahşi, yabani|s|Wild animals live in nature.|Vahşi hayvanlar doğada yaşar.
lion|aslan|i|The lion is the king of the jungle.|Aslan ormanların kralıdır.
elephant|fil|i|Elephants have long trunks.|Fillerin uzun hortumları vardır.
giraffe|zürafa|i|A giraffe has a very long neck.|Zürafanın çok uzun bir boynu vardır.
crocodile|timsah|i|Crocodiles live in rivers.|Timsahlar nehirlerde yaşar.
eagle|kartal|i|The eagle flies very high.|Kartal çok yükseğe uçar.
whale|balina|i|The blue whale is the largest animal.|Mavi balina en büyük hayvandır.
wolf|kurt|i|Wolves live in packs.|Kurtlar sürü hâlinde yaşar.
bear|ayı|i|Bears sleep in winter.|Ayılar kışın uyur.
cheetah|çita|i|The cheetah is the fastest animal.|Çita en hızlı hayvandır.
habitat|yaşam alanı, doğal ortam|i|Forests are the habitat of deer.|Ormanlar geyiklerin yaşam alanıdır.
endangered|nesli tükenmekte olan|s|Pandas are endangered animals.|Pandalar nesli tükenmekte olan hayvanlardır.
extinct|nesli tükenmiş|s|Dinosaurs are extinct.|Dinozorların nesli tükenmiştir.
hunt|avlamak|f|Lions hunt at night.|Aslanlar gece avlanır.
prey|av|i|The eagle caught its prey.|Kartal avını yakaladı.
poisonous|zehirli|s|Some snakes are poisonous.|Bazı yılanlar zehirlidir.
feather|kuş tüyü|i|Peacock feathers are colourful.|Tavus kuşu tüyleri renklidir.
protect|korumak|f|We must protect wild animals.|Vahşi hayvanları korumalıyız.
species|tür|i|Many species live in the rainforest.|Yağmur ormanında birçok tür yaşar.
## 7|Televizyon
channel|kanal|i|Change the channel, please.|Lütfen kanalı değiştir.
remote control|uzaktan kumanda|i|Where is the remote control?|Uzaktan kumanda nerede?
series|dizi|i|I watch a series every evening.|Her akşam bir dizi izlerim.
news|haberler|i|My father watches the news at eight.|Babam sekizde haberleri izler.
quiz show|bilgi yarışması|i|Quiz shows are educational.|Bilgi yarışmaları eğiticidir.
talk show|sohbet programı|i|There is a talk show at nine.|Dokuzda bir sohbet programı var.
soap opera|pembe dizi|i|My grandma loves soap operas.|Büyükannem pembe dizileri çok sever.
commercial|reklam|i|There are too many commercials.|Çok fazla reklam var.
host|sunucu|i|The host asked funny questions.|Sunucu komik sorular sordu.
audience|izleyici, seyirci|i|The audience clapped loudly.|İzleyiciler yüksek sesle alkışladı.
episode|bölüm (dizi)|i|Did you watch the last episode?|Son bölümü izledin mi?
broadcast|yayın|i|The match is a live broadcast.|Maç canlı yayın.
educational|eğitici|s|Documentaries are educational.|Belgeseller eğiticidir.
entertaining|eğlendirici|s|The show was very entertaining.|Program çok eğlendiriciydi.
turn on|açmak (cihaz)|f|Turn on the TV, the match starts.|Televizyonu aç, maç başlıyor.
turn off|kapatmak (cihaz)|f|Turn off the TV and go to bed.|Televizyonu kapat ve yat.
couch potato|televizyon bağımlısı|i|Don't be a couch potato!|Televizyon bağımlısı olma!
screen|ekran|i|Don't sit too close to the screen.|Ekrana çok yakın oturma.
## 7|Kutlamalar
celebration|kutlama|i|The celebration lasted all night.|Kutlama bütün gece sürdü.
anniversary|yıl dönümü|i|It is my parents' wedding anniversary.|Annemle babamın evlilik yıl dönümü.
wedding|düğün|i|We danced at the wedding.|Düğünde dans ettik.
graduation|mezuniyet|i|Her graduation is next week.|Mezuniyeti gelecek hafta.
ceremony|tören|i|The ceremony starts at ten.|Tören onda başlıyor.
organise|düzenlemek, organize etmek|f|We organised a surprise party.|Sürpriz bir parti düzenledik.
prepare|hazırlamak|f|Mum prepared a big dinner.|Annem büyük bir akşam yemeği hazırladı.
beverage|içecek|i|Hot and cold beverages are ready.|Sıcak ve soğuk içecekler hazır.
snack|atıştırmalık|i|We served snacks to the guests.|Misafirlere atıştırmalık ikram ettik.
treat|ikram|i|Ice cream is a nice treat.|Dondurma güzel bir ikramdır.
theme|tema|i|The party theme was the ocean.|Partinin teması okyanustu.
decoration|süsleme, süs|i|The decorations were colourful.|Süsler renkliydi.
confetti|konfeti|i|We threw confetti in the air.|Havaya konfeti attık.
surprise|sürpriz|i|It was a big surprise for her.|Onun için büyük bir sürprizdi.
take photos|fotoğraf çekmek|x|We took photos with the guests.|Misafirlerle fotoğraf çektik.
make a wish|dilek tutmak|x|Make a wish and blow the candles.|Dilek tut ve mumları üfle.
nationwide|ülke çapında|z|People celebrate it nationwide.|İnsanlar bunu ülke çapında kutlar.
## 7|Hayaller
dream|hayal, rüya|i|My dream is to be a pilot.|Hayalim pilot olmak.
future|gelecek|i|What will you do in the future?|Gelecekte ne yapacaksın?
prediction|tahmin|i|Make a prediction about the future.|Gelecek hakkında bir tahmin yap.
wish|dilek|i|I have a wish for the new year.|Yeni yıl için bir dileğim var.
imagine|hayal etmek|f|Imagine a world without cars.|Arabasız bir dünya hayal et.
believe|inanmak|f|I believe in my dreams.|Hayallerime inanırım.
hope|ummak|f|I hope to travel to space.|Uzaya gitmeyi umuyorum.
probably|muhtemelen|z|Robots will probably do housework.|Robotlar muhtemelen ev işi yapacak.
definitely|kesinlikle|z|I will definitely study hard.|Kesinlikle çok çalışacağım.
maybe|belki|z|Maybe people will live on Mars.|Belki insanlar Mars'ta yaşayacak.
robot|robot|i|Robots will help doctors.|Robotlar doktorlara yardım edecek.
flying car|uçan araba|i|Will there be flying cars?|Uçan arabalar olacak mı?
spaceship|uzay gemisi|i|A spaceship travels to the moon.|Uzay gemisi Ay'a gider.
technology|teknoloji|i|Technology changes very fast.|Teknoloji çok hızlı değişiyor.
become|olmak, hâline gelmek|f|I want to become a doctor.|Doktor olmak istiyorum.
aim|amaç, hedef|i|My aim is to learn English well.|Amacım İngilizceyi iyi öğrenmek.
fortune teller|falcı|i|The fortune teller looked at the cards.|Falcı kartlara baktı.
possible|mümkün|s|Everything is possible with hard work.|Çok çalışmayla her şey mümkün.
## 7|Kamu Binaları
public|halka açık, kamu|s|The library is a public building.|Kütüphane halka açık bir binadır.
town hall|belediye binası|i|The town hall is in the centre.|Belediye binası merkezde.
police station|karakol|i|Go to the police station for help.|Yardım için karakola git.
fire station|itfaiye|i|The fire station is near the bridge.|İtfaiye köprünün yakınında.
courthouse|adliye|i|Lawyers work at the courthouse.|Avukatlar adliyede çalışır.
embassy|büyükelçilik|i|The embassy is in Ankara.|Büyükelçilik Ankara'da.
art gallery|sanat galerisi|i|We visited an art gallery.|Bir sanat galerisi ziyaret ettik.
concert hall|konser salonu|i|The concert hall was full.|Konser salonu doluydu.
theatre|tiyatro|i|We saw a play at the theatre.|Tiyatroda bir oyun izledik.
railway station|tren istasyonu|i|Meet me at the railway station.|Benimle tren istasyonunda buluş.
airport|havalimanı|i|The airport is far from the city.|Havalimanı şehre uzak.
university|üniversite|i|My cousin studies at university.|Kuzenim üniversitede okuyor.
clinic|klinik|i|There is a dental clinic here.|Burada bir diş kliniği var.
service|hizmet|i|Public services are free.|Kamu hizmetleri ücretsizdir.
citizen|vatandaş|i|Every citizen can use the library.|Her vatandaş kütüphaneyi kullanabilir.
pay a fine|ceza ödemek|x|You pay a fine for late books.|Geç kitaplar için ceza ödersin.
## 7|Çevre
environmental|çevresel, çevreyle ilgili|s|Environmental problems are growing.|Çevre sorunları büyüyor.
global warming|küresel ısınma|i|Global warming melts the ice.|Küresel ısınma buzları eritiyor.
climate|iklim|i|The climate is changing.|İklim değişiyor.
greenhouse effect|sera etkisi|i|The greenhouse effect warms the Earth.|Sera etkisi Dünya'yı ısıtır.
deforestation|ormansızlaşma|i|Deforestation harms animals.|Ormansızlaşma hayvanlara zarar verir.
drought|kuraklık|i|Drought dries up the rivers.|Kuraklık nehirleri kurutur.
flood|sel|i|Heavy rain caused a flood.|Şiddetli yağmur sele yol açtı.
melt|erimek|f|The ice is melting fast.|Buzlar hızla eriyor.
fossil fuel|fosil yakıt|i|Fossil fuels pollute the air.|Fosil yakıtlar havayı kirletir.
renewable|yenilenebilir|s|Wind is a renewable energy source.|Rüzgâr yenilenebilir bir enerji kaynağıdır.
solar energy|güneş enerjisi|i|Solar energy is clean.|Güneş enerjisi temizdir.
exhaust|egzoz|i|Exhaust gases are harmful.|Egzoz gazları zararlıdır.
destroy|yok etmek, tahrip etmek|f|Fires destroy the forests.|Yangınlar ormanları yok eder.
damage|zarar vermek|f|Pollution damages the sea.|Kirlilik denize zarar verir.
raise awareness|farkındalık yaratmak|x|We raise awareness about recycling.|Geri dönüşüm için farkındalık yaratıyoruz.
volunteer|gönüllü|i|Volunteers cleaned the beach.|Gönüllüler plajı temizledi.
public transport|toplu taşıma|i|Use public transport in the city.|Şehirde toplu taşıma kullan.
soil|toprak|i|Healthy soil grows healthy plants.|Sağlıklı toprak sağlıklı bitki yetiştirir.
## 7|Gezegenler
solar system|güneş sistemi|i|There are eight planets in the solar system.|Güneş sisteminde sekiz gezegen var.
sun|güneş|i|The sun is a star.|Güneş bir yıldızdır.
moon|ay (gök cismi)|i|The moon goes around the Earth.|Ay, Dünya'nın etrafında döner.
star|yıldız|i|Stars shine at night.|Yıldızlar gece parlar.
Earth|Dünya|i|The Earth is the third planet.|Dünya üçüncü gezegendir.
Mars|Mars|i|Mars is called the red planet.|Mars'a kızıl gezegen denir.
Jupiter|Jüpiter|i|Jupiter is the biggest planet.|Jüpiter en büyük gezegendir.
Saturn|Satürn|i|Saturn has beautiful rings.|Satürn'ün güzel halkaları vardır.
orbit|yörünge|i|The Earth's orbit takes a year.|Dünya'nın yörüngesi bir yıl sürer.
gravity|yer çekimi|i|Gravity pulls things down.|Yer çekimi nesneleri aşağı çeker.
astronaut|astronot|i|The astronaut walked on the moon.|Astronot Ay'da yürüdü.
telescope|teleskop|i|We watched Saturn with a telescope.|Satürn'ü teleskopla izledik.
galaxy|galaksi, gök ada|i|Our galaxy is the Milky Way.|Galaksimiz Samanyolu'dur.
comet|kuyruklu yıldız|i|A comet has a bright tail.|Kuyruklu yıldızın parlak bir kuyruğu vardır.
space|uzay|i|I want to travel to space.|Uzaya gitmek istiyorum.
satellite|uydu|i|Satellites send TV signals.|Uydular TV sinyalleri gönderir.
rotate|dönmek (kendi ekseninde)|f|The Earth rotates once a day.|Dünya günde bir kez döner.
oxygen|oksijen|i|There is no oxygen on the moon.|Ay'da oksijen yok.
## 8|Arkadaşlık
friendship|arkadaşlık, dostluk|i|Friendship is very valuable.|Dostluk çok değerlidir.
get on well|iyi geçinmek|x|I get on well with my classmates.|Sınıf arkadaşlarımla iyi geçinirim.
count on|güvenmek, bel bağlamak|f|You can always count on me.|Bana her zaman güvenebilirsin.
back up|desteklemek, arkasında durmak|f|True friends back you up.|Gerçek arkadaşlar seni destekler.
trust|güvenmek|f|I trust my best friend.|En iyi arkadaşıma güvenirim.
loyal|sadık|s|A loyal friend never lies.|Sadık bir dost asla yalan söylemez.
supportive|destekleyici|s|My friends are very supportive.|Arkadaşlarım çok destekleyici.
reliable|güvenilir|s|She is a reliable person.|Güvenilir bir insan.
jealous|kıskanç|s|Don't be jealous of your friends.|Arkadaşlarını kıskanma.
argue|tartışmak|f|We sometimes argue but we make up.|Bazen tartışırız ama barışırız.
apologise|özür dilemek|f|He apologised for being late.|Geç kaldığı için özür diledi.
forgive|affetmek|f|Good friends forgive each other.|İyi arkadaşlar birbirini affeder.
accept|kabul etmek|f|I accept your invitation.|Davetini kabul ediyorum.
refuse|reddetmek|f|She refused to come to the party.|Partiye gelmeyi reddetti.
keep a secret|sır tutmak|x|Can you keep a secret?|Sır tutabilir misin?
share|paylaşmak|f|We share everything.|Her şeyi paylaşırız.
buddy|kanka, ahbap|i|He is my best buddy.|O benim en iyi kankam.
## 8|Genç Hayatı
teenager|genç, ergen|i|Teenagers like loud music.|Gençler yüksek sesli müziği sever.
trendy|moda, şık|s|She wears trendy clothes.|Moda kıyafetler giyer.
fancy|süslü, gösterişli|s|That is a fancy restaurant.|O gösterişli bir restoran.
ridiculous|saçma, gülünç|s|That idea is ridiculous!|Bu fikir çok saçma!
unbearable|dayanılmaz, çekilmez|s|The noise was unbearable.|Gürültü dayanılmazdı.
terrific|müthiş, harika|s|The concert was terrific!|Konser müthişti!
regular|düzenli|s|I have a regular sleep schedule.|Düzenli bir uyku programım var.
chat|sohbet etmek|f|We chat online every evening.|Her akşam internette sohbet ederiz.
texting|mesajlaşma|i|Texting in class is not allowed.|Derste mesajlaşmak yasak.
pocket money|harçlık|i|I save my pocket money.|Harçlığımı biriktiriyorum.
fashion|moda|i|She follows fashion closely.|Modayı yakından takip eder.
brand|marka|i|Which brand do you prefer?|Hangi markayı tercih edersin?
concert|konser|i|We went to a rock concert.|Bir rock konserine gittik.
trend|eğilim, akım|i|Short videos are a new trend.|Kısa videolar yeni bir akım.
spend time|zaman geçirmek|x|I spend time with my family.|Ailemle zaman geçiririm.
can't stand|dayanamamak, katlanamamak|x|I can't stand loud music.|Yüksek sesli müziğe dayanamıyorum.
be fond of|düşkün olmak, çok sevmek|x|I am fond of comic books.|Çizgi romanlara düşkünüm.
look forward to|dört gözle beklemek|x|I look forward to the summer holiday.|Yaz tatilini dört gözle bekliyorum.
## 8|Mutfak
recipe|tarif, yemek tarifi|i|This recipe is very easy.|Bu tarif çok kolay.
ingredient|malzeme|i|Mix all the ingredients.|Bütün malzemeleri karıştır.
flour|un|i|Add two cups of flour.|İki bardak un ekle.
dough|hamur|i|Knead the dough for ten minutes.|Hamuru on dakika yoğur.
boil|kaynatmak, haşlamak|f|Boil the eggs for eight minutes.|Yumurtaları sekiz dakika haşla.
fry|kızartmak|f|Fry the potatoes in hot oil.|Patatesleri kızgın yağda kızart.
bake|fırında pişirmek|f|Bake the cake for forty minutes.|Keki kırk dakika fırında pişir.
grill|ızgara yapmak|f|We grilled fish on the beach.|Plajda balık ızgara yaptık.
chop|doğramak|f|Chop the onions finely.|Soğanları ince ince doğra.
slice|dilimlemek|f|Slice the tomatoes.|Domatesleri dilimle.
peel|soymak|f|Peel the potatoes first.|Önce patatesleri soy.
stir|karıştırmak|f|Stir the soup slowly.|Çorbayı yavaşça karıştır.
pour|dökmek|f|Pour the milk into the bowl.|Sütü kâseye dök.
add|eklemek|f|Add a pinch of salt.|Bir tutam tuz ekle.
mash|ezmek|f|Mash the potatoes with butter.|Patatesleri tereyağıyla ez.
oven|fırın|i|Heat the oven to 180 degrees.|Fırını 180 dereceye ısıt.
saucepan|tencere|i|Put the rice in a saucepan.|Pirinci tencereye koy.
tablespoon|yemek kaşığı|i|Add a tablespoon of oil.|Bir yemek kaşığı yağ ekle.
## 8|Telefon
phone call|telefon görüşmesi|i|I got a phone call from Ali.|Ali'den bir telefon aldım.
make a call|aramak, telefon etmek|x|Can I make a call?|Bir arama yapabilir miyim?
hang up|telefonu kapatmak|f|Don't hang up, please!|Lütfen kapatma!
hold on|hatta beklemek|x|Hold on a second, please.|Lütfen bir saniye bekleyin.
call back|geri aramak|f|I will call you back later.|Seni sonra geri ararım.
leave a message|mesaj bırakmak|x|Can I leave a message?|Mesaj bırakabilir miyim?
take a message|not almak|x|Can I take a message for him?|Onun için not alabilir miyim?
speaking|ben (telefonda)|x|Hello, this is Ayşe speaking.|Alo, ben Ayşe.
wrong number|yanlış numara|x|Sorry, you have the wrong number.|Üzgünüm, yanlış numara.
dial|numara çevirmek|f|Dial the number carefully.|Numarayı dikkatlice çevir.
ring|çalmak (telefon)|f|The phone is ringing.|Telefon çalıyor.
available|müsait|s|Is Mr Kaya available?|Kaya Bey müsait mi?
urgent|acil|s|It is urgent, please hurry.|Acil, lütfen acele et.
voicemail|sesli mesaj|i|Leave a voicemail after the tone.|Sinyal sesinden sonra sesli mesaj bırakın.
charger|şarj aleti|i|My phone charger is broken.|Telefonumun şarj aleti bozuk.
battery|pil, batarya|i|The battery is low.|Pil zayıf.
put through|bağlamak (telefonda)|f|I will put you through to the manager.|Sizi müdüre bağlıyorum.
## 8|İnternet
internet|internet|i|I use the internet for homework.|İnterneti ödev için kullanırım.
connect|bağlanmak|f|I can't connect to the wifi.|Wifi'a bağlanamıyorum.
download|indirmek|f|Download the file to your computer.|Dosyayı bilgisayarına indir.
upload|yüklemek|f|Upload your photos to the cloud.|Fotoğraflarını buluta yükle.
search|aramak|f|Search for information online.|İnternette bilgi ara.
browse|göz atmak, gezinmek|f|I browse the web in the evening.|Akşamları internette gezinirim.
website|web sitesi|i|This website is useful for students.|Bu web sitesi öğrenciler için yararlı.
password|şifre, parola|i|Never share your password.|Şifreni asla paylaşma.
username|kullanıcı adı|i|Type your username here.|Kullanıcı adını buraya yaz.
account|hesap|i|Create a new account.|Yeni bir hesap oluştur.
social media|sosyal medya|i|Teens spend hours on social media.|Gençler sosyal medyada saatler geçirir.
online|çevrim içi|s|My friends are online now.|Arkadaşlarım şu an çevrim içi.
offline|çevrim dışı|s|The printer is offline.|Yazıcı çevrim dışı.
attachment|ek dosya|i|Open the attachment in the email.|E-postadaki ek dosyayı aç.
privacy|gizlilik, mahremiyet|i|Protect your privacy online.|İnternette gizliliğini koru.
confirm|onaylamak|f|Confirm your email address.|E-posta adresini onayla.
log in|oturum açmak|f|Log in with your password.|Şifrenle oturum aç.
log out|oturumu kapatmak|f|Always log out on shared computers.|Ortak bilgisayarlarda hep oturumu kapat.
## 8|Maceralar
adventurous|maceracı|s|My brother is very adventurous.|Ağabeyim çok maceracı.
rafting|rafting|i|We went rafting on the river.|Nehirde rafting yaptık.
paragliding|yamaç paraşütü|i|Paragliding is popular in Fethiye.|Yamaç paraşütü Fethiye'de popülerdir.
caving|mağaracılık|i|Caving needs a strong torch.|Mağaracılık güçlü bir fener gerektirir.
hiking|doğa yürüyüşü|i|We went hiking in the mountains.|Dağlarda doğa yürüyüşü yaptık.
climbing|tırmanış|i|Rock climbing needs strong arms.|Kaya tırmanışı güçlü kollar ister.
diving|dalış|i|Diving shows us sea life.|Dalış bize deniz yaşamını gösterir.
risky|riskli|s|Some sports are risky.|Bazı sporlar risklidir.
dangerous|tehlikeli|s|Don't do dangerous things alone.|Tehlikeli şeyleri yalnız yapma.
safe|güvenli|s|Wear a helmet to be safe.|Güvende olmak için kask tak.
challenging|zorlu|s|The climb was challenging.|Tırmanış zorluydu.
brave|cesur|s|You must be brave to try it.|Bunu denemek için cesur olmalısın.
breathtaking|nefes kesici|s|The view was breathtaking.|Manzara nefes kesiciydi.
would rather|tercih etmek, yeğlemek|x|I would rather go hiking.|Doğa yürüyüşüne gitmeyi yeğlerim.
rope|halat, ip|i|Hold the rope tightly.|Halatı sıkıca tut.
torch|el feneri|i|Take a torch for the cave.|Mağara için el feneri al.
compass|pusula|i|A compass shows the north.|Pusula kuzeyi gösterir.
backpack|sırt çantası|i|My backpack is heavy.|Sırt çantam ağır.
## 8|Turizm
tourist|turist|i|Many tourists visit Cappadocia.|Birçok turist Kapadokya'yı ziyaret eder.
tourism|turizm|i|Tourism is important for Antalya.|Turizm Antalya için önemlidir.
destination|gidilecek yer, varış yeri|i|Our destination is Trabzon.|Gideceğimiz yer Trabzon.
accommodation|konaklama|i|The accommodation was cheap.|Konaklama ucuzdu.
resort|tatil köyü|i|We stayed at a seaside resort.|Deniz kenarında bir tatil köyünde kaldık.
guide|rehber|i|The guide told us the history.|Rehber bize tarihi anlattı.
brochure|broşür|i|Take a brochure from the desk.|Masadan bir broşür al.
book|rezervasyon yapmak|f|I booked a room online.|İnternetten oda rezervasyonu yaptım.
landmark|simge yapı|i|Galata Tower is a famous landmark.|Galata Kulesi ünlü bir simge yapıdır.
ancient|antik, eski|s|Ephesus is an ancient city.|Efes antik bir şehirdir.
ruins|kalıntılar, harabe|i|We walked among the ruins.|Kalıntıların arasında yürüdük.
scenery|manzara|i|The scenery was wonderful.|Manzara harikaydı.
cruise|gemi yolculuğu|i|We took a cruise on the Bosphorus.|Boğaz'da gemi turu yaptık.
cable car|teleferik|i|The cable car goes up the mountain.|Teleferik dağa çıkıyor.
local|yerel, yöresel|s|Try the local food.|Yöresel yemekleri dene.
heritage|miras|i|Troy is a world heritage site.|Truva bir dünya mirası alanıdır.
check in|giriş yapmak (otel)|f|We checked in at the hotel.|Otele giriş yaptık.
fascinating|büyüleyici|s|The museum was fascinating.|Müze büyüleyiciydi.
## 8|Ev İşleri
housework|ev işleri|i|Housework takes a lot of time.|Ev işleri çok zaman alır.
do the laundry|çamaşır yıkamak|x|I do the laundry on Saturdays.|Cumartesileri çamaşır yıkarım.
iron|ütülemek|f|Dad irons his shirts.|Babam gömleklerini ütüler.
vacuum|süpürge ile süpürmek|f|I vacuum the carpet every week.|Halıyı her hafta süpürürüm.
sweep|süpürmek|f|Sweep the floor, please.|Lütfen yeri süpür.
mop|paspas yapmak|f|Mop the kitchen floor.|Mutfağın zeminini paspasla.
dust|tozunu almak|f|Dust the shelves carefully.|Rafların tozunu dikkatlice al.
fold|katlamak|f|Fold the clean clothes.|Temiz kıyafetleri katla.
set the table|sofrayı kurmak|x|Set the table for dinner.|Akşam yemeği için sofrayı kur.
clear the table|sofrayı toplamak|x|Clear the table after dinner.|Yemekten sonra sofrayı topla.
load the dishwasher|bulaşık makinesini doldurmak|x|Load the dishwasher after lunch.|Öğle yemeğinden sonra makineyi doldur.
mow the lawn|çimleri biçmek|x|Grandpa mows the lawn on Sundays.|Dedem pazarları çimleri biçer.
responsible|sorumlu|s|I am responsible for the dishes.|Bulaşıklardan ben sorumluyum.
in charge of|-den sorumlu|x|Mum is in charge of the shopping.|Alışverişten annem sorumlu.
obligation|zorunluluk, yükümlülük|i|Chores are an obligation at home.|Ev işleri evde bir zorunluluktur.
share the housework|ev işlerini paylaşmak|x|We share the housework fairly.|Ev işlerini adilce paylaşırız.
pile|yığın|i|There is a pile of dirty clothes.|Bir yığın kirli çamaşır var.
## 8|Bilim
science|bilim|i|Science explains the world.|Bilim dünyayı açıklar.
experiment|deney|i|We did an experiment in the lab.|Laboratuvarda bir deney yaptık.
laboratory|laboratuvar|i|The laboratory has many tools.|Laboratuvarda birçok araç var.
microscope|mikroskop|i|We looked at cells under a microscope.|Hücrelere mikroskopla baktık.
observe|gözlemlemek|f|Observe the plant for a week.|Bitkiyi bir hafta gözlemle.
measure|ölçmek|f|Measure the temperature of the water.|Suyun sıcaklığını ölç.
research|araştırma|i|Scientists do research every day.|Bilim insanları her gün araştırma yapar.
theory|teori, kuram|i|Newton explained the theory of gravity.|Newton yer çekimi teorisini açıkladı.
evidence|kanıt|i|We need evidence for this idea.|Bu fikir için kanıta ihtiyacımız var.
cell|hücre|i|All living things have cells.|Bütün canlılar hücrelerden oluşur.
chemistry|kimya|i|Chemistry is about matter.|Kimya maddeyle ilgilidir.
physics|fizik|i|Physics explains how things move.|Fizik nesnelerin nasıl hareket ettiğini açıklar.
biology|biyoloji|i|Biology is the study of life.|Biyoloji yaşamın bilimidir.
atom|atom|i|Everything is made of atoms.|Her şey atomlardan oluşur.
vaccine|aşı|i|Vaccines protect us from diseases.|Aşılar bizi hastalıklardan korur.
develop|geliştirmek|f|Scientists develop new medicines.|Bilim insanları yeni ilaçlar geliştirir.
mixture|karışım|i|Stir the mixture well.|Karışımı iyice karıştır.
magnet|mıknatıs|i|A magnet attracts iron.|Mıknatıs demiri çeker.
## 8|Doğa Olayları
earthquake|deprem|i|An earthquake shook the city.|Bir deprem şehri salladı.
volcano|yanardağ|i|The volcano erupted last year.|Yanardağ geçen yıl patladı.
erupt|patlamak (yanardağ)|f|Volcanoes erupt with lava.|Yanardağlar lavla patlar.
tsunami|tsunami|i|A tsunami is a giant wave.|Tsunami dev bir dalgadır.
hurricane|kasırga|i|The hurricane destroyed houses.|Kasırga evleri yıktı.
tornado|hortum|i|A tornado spins very fast.|Hortum çok hızlı döner.
avalanche|çığ|i|An avalanche covered the road.|Çığ yolu kapattı.
landslide|heyelan, toprak kayması|i|Heavy rain caused a landslide.|Şiddetli yağmur heyelana yol açtı.
lightning|şimşek, yıldırım|i|Lightning hit the old tree.|Yıldırım yaşlı ağaca düştü.
hail|dolu (yağış)|i|Hail damaged the cars.|Dolu arabalara zarar verdi.
blizzard|kar fırtınası|i|The blizzard closed the schools.|Kar fırtınası okulları kapattı.
wildfire|orman yangını|i|Wildfires spread quickly in summer.|Orman yangınları yazın hızla yayılır.
disaster|afet, felaket|i|Earthquakes are natural disasters.|Depremler doğal afetlerdir.
rescue|kurtarmak|f|Teams rescued people from the flood.|Ekipler insanları selden kurtardı.
emergency|acil durum|i|Call 112 in an emergency.|Acil durumda 112'yi ara.
warning|uyarı|i|There is a storm warning today.|Bugün fırtına uyarısı var.
evacuate|tahliye etmek|f|They evacuated the village.|Köyü tahliye ettiler.
survive|hayatta kalmak|f|Everyone survived the earthquake.|Herkes depremden sağ kurtuldu.
## genel|Tanımlık ve Zamirler
the|(belirli tanımlık)|x
a|bir (belirsiz tanımlık)|x
I|ben|x
you|sen, siz|x
he|o (erkek)|x
she|o (kadın)|x
it|o (cansız, hayvan)|x
we|biz|x
they|onlar|x
me|beni, bana|x
him|onu, ona (erkek)|x
her|onu, ona; onun (kadın)|x
us|bizi, bize|x
them|onları, onlara|x
my|benim|x
your|senin, sizin|x
his|onun (erkek)|x
our|bizim|x
their|onların|x
this|bu|x
that|şu, o|x
these|bunlar|x
those|şunlar, onlar|x
someone|birisi|x
something|bir şey|x
everyone|herkes|x
everything|her şey|x
nothing|hiçbir şey|x
## genel|Soru Kelimeleri
who|kim|x
what|ne|x
where|nerede, nereye|x
when|ne zaman|x
why|neden, niçin|x
how|nasıl|x
which|hangi|x
whose|kimin|x
how many|kaç tane|x
how much|ne kadar|x
how old|kaç yaşında|x
## genel|Miktar ve Belirteçler
some|biraz, bazı|x
any|hiç, herhangi|x
many|çok sayıda, birçok|x
much|çok (sayılamayan)|x
few|az, birkaç|x
all|hepsi, bütün|x
every|her|x
each|her biri|x
other|diğer, başka|x
another|başka bir|x
both|her ikisi|x
same|aynı|s
different|farklı|s
own|kendi|s
yes|evet|x
no|hayır|x
not|değil|z
## genel|Yardımcı Fiiller
be|olmak|f
am|-im (be fiili, I ile)|f
is|-dir (be fiili, tekil)|f
are|-dir (be fiili, çoğul)|f
was|-di (be fiili, geçmiş tekil)|f
were|-di (be fiili, geçmiş çoğul)|f
have|sahip olmak|f
has|sahip olmak (tekil)|f
had|sahip oldu|f
do|yapmak|f
does|yapmak (tekil)|f
did|yaptı|f
can|-ebilmek|f
could|-ebilirdi, -ebilir miydi|f
will|-ecek, -acak|f
would|-erdi, -ardı|f
may|-ebilir (izin, olasılık)|f
might|belki -ebilir|f
## genel|Temel Fiiller
go|gitmek|f
come|gelmek|f
get|almak, elde etmek|f
make|yapmak, üretmek|f
know|bilmek, tanımak|f
think|düşünmek|f
take|almak, götürmek|f
see|görmek|f
look|bakmak|f
want|istemek|f
give|vermek|f
use|kullanmak|f
find|bulmak|f
tell|söylemek, anlatmak|f
ask|sormak, istemek|f
feel|hissetmek|f
try|denemek|f
leave|ayrılmak, bırakmak|f
call|aramak, çağırmak|f
say|demek, söylemek|f
speak|konuşmak|f
talk|konuşmak, sohbet etmek|f
need|ihtiyacı olmak|f
put|koymak|f
mean|anlamına gelmek|f
keep|tutmak, saklamak|f
let|izin vermek|f
begin|başlamak|f
start|başlamak, başlatmak|f
help|yardım etmek|f
show|göstermek|f
hear|duymak|f
play|oynamak, çalmak|f
live|yaşamak|f
bring|getirmek|f
happen|olmak, meydana gelmek|f
write|yazmak|f
read|okumak|f
sit|oturmak|f
stand|ayakta durmak|f
pay|ödemek|f
meet|buluşmak, tanışmak|f
learn|öğrenmek|f
change|değiştirmek, değişmek|f
understand|anlamak|f
watch|izlemek|f
follow|takip etmek|f
stop|durmak, durdurmak|f
open|açmak|f
close|kapatmak|f
walk|yürümek|f
remember|hatırlamak|f
forget|unutmak|f
love|sevmek|f
like|hoşlanmak, sevmek|f
wait|beklemek|f
send|göndermek|f
build|inşa etmek|f
fall|düşmek|f
cut|kesmek|f
buy|satın almak|f
sell|satmak|f
eat|yemek yemek|f
drink|içmek|f
sleep|uyumak|f
listen|dinlemek|f
carry|taşımak|f
choose|seçmek|f
teach|öğretmek|f
study|ders çalışmak|f
answer|cevaplamak|f
draw|çizmek|f
drive|araba sürmek|f
fly|uçmak|f
grow|büyümek, yetiştirmek|f
hold|tutmak|f
break|kırmak|f
catch|yakalamak|f
cook|yemek pişirmek|f
clean|temizlemek|f
wash|yıkamak|f
finish|bitirmek|f
enjoy|keyif almak, hoşlanmak|f
hate|nefret etmek|f
miss|özlemek, kaçırmak|f
spend|harcamak, geçirmek|f
sing|şarkı söylemek|f
smile|gülümsemek|f
laugh|gülmek|f
cry|ağlamak|f
turn|dönmek, çevirmek|f
fix|tamir etmek, düzeltmek|f
## genel|Temel İsimler
time|zaman, vakit|i
year|yıl|i
people|insanlar|i
way|yol, yöntem|i
day|gün|i
man|adam, erkek|i
woman|kadın|i
child|çocuk|i
world|dünya|i
life|hayat, yaşam|i
hand|el|i
part|parça, kısım|i
place|yer|i
week|hafta|i
group|grup|i
number|sayı, numara|i
problem|sorun, problem|i
thing|şey|i
night|gece|i
home|ev, yuva|i
water|su|i
room|oda|i
mother|anne|i
father|baba|i
money|para|i
story|hikâye, öykü|i
month|ay (takvim)|i
eye|göz|i
word|kelime, sözcük|i
head|baş, kafa|i
house|ev|i
friend|arkadaş|i
hour|saat (süre)|i
game|oyun|i
end|son, bitiş|i
car|araba|i
city|şehir|i
minute|dakika|i
idea|fikir|i
body|vücut|i
information|bilgi|i
parent|ebeveyn, anne ya da baba|i
face|yüz|i
door|kapı|i
health|sağlık|i
person|kişi|i
art|sanat|i
history|tarih|i
result|sonuç|i
morning|sabah|i
reason|sebep, neden|i
girl|kız|i
boy|erkek çocuk, oğlan|i
moment|an|i
air|hava|i
education|eğitim|i
foot|ayak|i
age|yaş|i
market|pazar, market|i
plan|plan|i
class|sınıf|i
heart|kalp|i
light|ışık|i
voice|ses (insan)|i
mind|zihin, akıl|i
price|fiyat|i
decision|karar|i
son|oğul|i
daughter|kız evlat|i
view|manzara, görüş|i
road|yol|i
arm|kol|i
difference|fark|i
value|değer|i
building|bina|i
season|mevsim|i
paper|kâğıt|i
event|olay, etkinlik|i
couple|çift|i
table|masa|i
situation|durum|i
picture|resim|i
piece|parça|i
land|kara, toprak|i
wall|duvar|i
test|test, sınav|i
love|sevgi, aşk|i
step|adım|i
baby|bebek|i
computer|bilgisayar|i
tree|ağaç|i
cup|fincan, bardak|i
window|pencere|i
letter|mektup, harf|i
bed|yatak|i
box|kutu|i
flower|çiçek|i
food|yiyecek, yemek|i
fish|balık|i
bird|kuş|i
sea|deniz|i
river|nehir|i
mountain|dağ|i
sky|gökyüzü|i
rain|yağmur|i
snow|kar|i
fire|ateş, yangın|i
colour|renk|i
school|okul|i
lesson|ders|i
question|soru|i
family|aile|i
brother|erkek kardeş|i
sister|kız kardeş|i
bread|ekmek|i
milk|süt|i
apple|elma|i
chair|sandalye|i
pen|kalem|i
bag|çanta|i
shoe|ayakkabı|i
clothes|giysiler, kıyafet|i
hair|saç|i
nose|burun|i
mouth|ağız|i
ear|kulak|i
leg|bacak|i
finger|parmak|i
## genel|Temel Sıfatlar
good|iyi|s
bad|kötü|s
new|yeni|s
old|eski, yaşlı|s
first|ilk, birinci|s
long|uzun|s
short|kısa|s
great|harika, büyük|s
big|büyük|s
small|küçük|s
large|geniş, büyük|s
high|yüksek|s
low|alçak, düşük|s
next|sonraki, gelecek|s
young|genç|s
important|önemli|s
easy|kolay|s
difficult|zor|s
hard|zor, sert|s
hot|sıcak|s
warm|ılık, sıcak|s
cool|serin|s
beautiful|güzel|s
pretty|güzel, hoş|s
ugly|çirkin|s
fast|hızlı|s
slow|yavaş|s
quick|çabuk, hızlı|s
dirty|kirli|s
full|dolu|s
empty|boş|s
heavy|ağır|s
rich|zengin|s
poor|fakir, yoksul|s
cheap|ucuz|s
expensive|pahalı|s
free|özgür, ücretsiz|s
busy|meşgul, yoğun|s
ready|hazır|s
sure|emin|s
true|doğru, gerçek|s
wrong|yanlış|s
real|gerçek|s
whole|bütün, tüm|s
tired|yorgun|s
hungry|aç|s
thirsty|susamış|s
near|yakın|s
far|uzak|s
nice|hoş, güzel|s
kind|nazik|s
wonderful|harika|s
simple|basit|s
clear|açık, net|s
dark|karanlık, koyu|s
bright|parlak|s
deep|derin|s
wide|geniş|s
weak|zayıf, güçsüz|s
favourite|en sevilen, favori|s
wet|ıslak|s
dry|kuru|s
soft|yumuşak|s
loud|yüksek sesli, gürültülü|s
## genel|Zaman ve Zarflar
now|şimdi|z
today|bugün|z
tomorrow|yarın|z
yesterday|dün|z
tonight|bu gece|z
soon|yakında|z
again|tekrar, yine|z
already|çoktan, zaten|z
still|hâlâ|z
yet|henüz|z
just|sadece, az önce|z
only|yalnızca, sadece|z
also|ayrıca, de|z
too|de, da; çok fazla|z
very|çok|z
really|gerçekten|z
quite|oldukça|z
almost|neredeyse|z
here|burada|z
there|orada|z
everywhere|her yerde|z
together|birlikte|z
well|iyi (bir şekilde)|z
away|uzakta, uzağa|z
ever|hiç, şimdiye kadar|z
perhaps|belki|z
then|sonra, o zaman|z
so|bu yüzden, çok|z
even|hatta, bile|z
later|daha sonra|z
ago|önce (geçmişte)|z
## genel|Edatlar ve Bağlaçlar
in|içinde, -de|e
on|üstünde, -de|e
at|-de, -da (yer, zaman)|e
to|-e, -a|e
of|-in, -nin|e
for|için|e
with|ile, -le|e
from|-den, -dan|e
by|tarafından, ile|e
about|hakkında|e
into|içine|e
through|içinden, boyunca|e
over|üzerinde, üstünden|e
under|altında|e
among|arasında (çok şey)|e
behind|arkasında|e
in front of|önünde|e
next to|yanında|e
above|yukarısında|e
below|aşağısında|e
without|-sız, olmadan|e
against|karşı|e
around|etrafında|e
across|karşıya, karşısında|e
along|boyunca|e
up|yukarı|e
down|aşağı|e
out|dışarı|e
before|önce|e
after|sonra|e
during|sırasında|e
until|-e kadar|e
since|-den beri|e
and|ve|x
but|ama, fakat|x
or|veya, ya da|x
because|çünkü|x
if|eğer|x
while|-iken|x
than|-den (karşılaştırma)|x
as|gibi, olarak|x
## genel|Sayılar ve Günler
one|bir|i
two|iki|i
three|üç|i
four|dört|i
five|beş|i
six|altı|i
seven|yedi|i
eight|sekiz|i
nine|dokuz|i
ten|on|i
hundred|yüz (sayı)|i
thousand|bin (sayı)|i
Monday|Pazartesi|i
Tuesday|Salı|i
Wednesday|Çarşamba|i
Thursday|Perşembe|i
Friday|Cuma|i
Saturday|Cumartesi|i
Sunday|Pazar|i
## 5|Vücudumuz ve Hareket
shoulder|omuz|i|My shoulders are tired after swimming.|Yüzdükten sonra omuzlarım yoruldu.
knee|diz|i|He hurt his knee in the garden.|Bahçede dizini incitti.
tooth|diş|i|Brush your teeth twice a day.|Dişlerini günde iki kez fırçala.
stomach|mide, karın|i|My stomach hurts after lunch.|Öğle yemeğinden sonra karnım ağrıyor.
clap|alkışlamak|f|Everyone clapped at the end of the show.|Gösterinin sonunda herkes alkışladı.
whisper|fısıldamak|f|Please whisper in the library.|Lütfen kütüphanede fısılda.
## 5|Renkler ve Şekiller
circle|daire|i|Draw a big circle on the paper.|Kâğıda büyük bir daire çiz.
triangle|üçgen|i|A triangle has three sides.|Bir üçgenin üç kenarı vardır.
rectangle|dikdörtgen|i|The door is a rectangle.|Kapı bir dikdörtgendir.
purple|mor|s|She has a purple pencil case.|Onun mor bir kalem kutusu var.
pink|pembe|s|My little sister loves pink.|Küçük kız kardeşim pembeyi çok sever.
grey|gri|s|The sky is grey today.|Bugün gökyüzü gri.
striped|çizgili|s|I like your striped T-shirt.|Çizgili tişörtünü beğendim.
round|yuvarlak|s|The table in the kitchen is round.|Mutfaktaki masa yuvarlak.
## 6|Ulaşım
ferry|vapur, feribot|i|We cross the sea by ferry.|Denizi vapurla geçeriz.
tram|tramvay|i|The tram stops near our school.|Tramvay okulumuzun yakınında durur.
platform|peron|i|Wait on platform two.|İki numaralı peronda bekle.
passenger|yolcu|i|The passengers got on the plane.|Yolcular uçağa bindi.
seat belt|emniyet kemeri|i|Fasten your seat belt, please.|Lütfen emniyet kemerini tak.
crossing|yaya geçidi|i|Use the crossing to cross the road.|Yolu geçmek için yaya geçidini kullan.
depart|kalkmak, ayrılmak|f|Our bus departs in ten minutes.|Otobüsümüz on dakika sonra kalkıyor.
## 6|Alışveriş
customer|müşteri|i|The customer paid at the counter.|Müşteri kasada ödeme yaptı.
receipt|fiş, makbuz|i|Keep the receipt for the shoes.|Ayakkabıların fişini sakla.
discount|indirim|i|There is a discount on books this week.|Bu hafta kitaplarda indirim var.
cashier|kasiyer|i|The cashier gave me the change.|Kasiyer bana para üstünü verdi.
trolley|alışveriş arabası|i|Put the bags in the trolley.|Poşetleri arabaya koy.
size|beden, boyut|i|Do you have this jacket in a smaller size?|Bu ceketin daha küçük bedeni var mı?
try on|denemek (giysi)|f|Can I try on this dress?|Bu elbiseyi deneyebilir miyim?
afford|parası yetmek|f|I can't afford a new phone.|Yeni bir telefona param yetmez.
bargain|kelepir, ucuz alışveriş|i|These boots were a real bargain.|Bu botlar gerçekten kelepirdi.
## 7|Teknoloji
device|cihaz|i|Turn off your devices before bed.|Yatmadan önce cihazlarını kapat.
headphones|kulaklık|i|She listens to music with headphones.|Kulaklıkla müzik dinler.
keyboard|klavye|i|The keyboard has a broken key.|Klavyenin bir tuşu bozuk.
update|güncellemek, güncelleme|f|Update the game to fix the bug.|Hatayı düzeltmek için oyunu güncelle.
wireless|kablosuz|s|We use wireless headphones in class.|Sınıfta kablosuz kulaklık kullanırız.
invention|buluş, icat|i|The wheel is a great invention.|Tekerlek harika bir buluştur.
## 7|Sağlıklı Yaşam
balanced|dengeli|s|Eat a balanced breakfast every day.|Her gün dengeli bir kahvaltı yap.
habit|alışkanlık|i|Reading is a good habit.|Okumak iyi bir alışkanlıktır.
protein|protein|i|Eggs are full of protein.|Yumurta protein doludur.
sugar|şeker|i|Too much sugar is bad for your teeth.|Çok fazla şeker dişlerine zararlıdır.
avoid|kaçınmak|f|Avoid fast food on school days.|Okul günlerinde hazır yiyeceklerden kaçın.
## 8|Duygular ve Düşünceler
confident|kendine güvenen|s|She feels confident before the exam.|Sınavdan önce kendine güveniyor.
nervous|gergin, heyecanlı|s|I was nervous on the first day.|İlk gün gergindim.
disappointed|hayal kırıklığına uğramış|s|He was disappointed with the result.|Sonuçtan hayal kırıklığına uğradı.
grateful|minnettar|s|I am grateful for your help.|Yardımın için minnettarım.
curious|meraklı|s|Curious students ask many questions.|Meraklı öğrenciler çok soru sorar.
patient|sabırlı|s|Be patient, the results come tomorrow.|Sabırlı ol, sonuçlar yarın geliyor.
opinion|fikir, görüş|i|In my opinion, the film was great.|Bence film harikaydı.
## 8|Gelecek ve Kariyer
experience|deneyim|i|He has experience in sports.|Sporda deneyimi var.
interview|mülakat, görüşme|i|The interview lasted ten minutes.|Mülakat on dakika sürdü.
skill|beceri|i|Typing is a useful skill.|Klavyede yazmak faydalı bir beceridir.
apply|başvurmak|f|You can apply for the course online.|Kursa internetten başvurabilirsin.
achieve|başarmak, ulaşmak|f|Work hard to achieve your dreams.|Hayallerine ulaşmak için çok çalış.
salary|maaş|i|Engineers earn a good salary.|Mühendisler iyi maaş alır.
## genel|Fiil Öbekleri
put on|giymek|f|Put on your coat, it's cold.|Paltonu giy, hava soğuk.
take off|çıkarmak (giysi); havalanmak|f|Take off your shoes at the door.|Ayakkabılarını kapıda çıkar.
look after|bakmak, ilgilenmek|f|She looks after her little brother.|Küçük kardeşine bakıyor.
give up|vazgeçmek|f|Never give up on your goals.|Hedeflerinden asla vazgeçme.
find out|öğrenmek, keşfetmek|f|Let's find out the answer together.|Cevabı birlikte öğrenelim.
hurry up|acele etmek|f|Hurry up, the bus is coming!|Acele et, otobüs geliyor!
## genel|Zıt Anlamlılar
narrow|dar|s|The street is too narrow for buses.|Sokak otobüsler için çok dar.
shallow|sığ|s|Children swim in the shallow water.|Çocuklar sığ suda yüzer.
VERI;
}
