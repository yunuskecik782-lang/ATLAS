<?php
/**
 * ATLAS — Ödüllü Deneme Sınavı (ÖDS): herkese açık adres, yönlendirme, logo ve eski tanıtım sayfası ayarları.
 *
 * v7.8: tanıtım sitesi kaldırıldı; /ods/ (kalıcı bağlantı varsa), /?ods=1 (varsayılan kurum) ve /?ods=<kurum anahtarı>
 *   artık ÖDS kayıt formunu gösterir (includes/odsform.php → sides_ods_sayfa). Eski tanıtım sayfası kodu includes/ods-tanitim.php
 *   dosyasında (yüklenmez), ayarları sides_docs ods/ayar kaydında saklı durur; logo, renk ve kök yönlendirme hâlâ bu kayıttan okunur.
 * Yönetim: Kayıt Modülü › ÖDS Kayıt Formu (kayit.ods) ve ÖDS Aday Listesi (kayit.odsliste) — src/ods.js.
 * REST (optik-karne/v1):
 *   GET  ods/ayar                 eski ayarlar + adresler (kayit ≥ 1)
 *   POST ods/ayar                 kaydet (kayit ≥ 2; gözlemci yazamaz); beyaz liste + uzunluk sınırı, hatalı değer 400
 *   POST ods/logo { data }        logo yükle (kayit ≥ 2) → { id }
 *   GET  ods/logo/<anahtar>       etkin logo (herkese açık, hız sınırlı) — form sayfası ve og:image için
 * "Ana sayfaya yönlendir" (yalnız site yöneticisi) açıkken ve form başvuruya açıkken sitenin kök adresi (yalnızca / ve sorgusuz)
 *   302 ile kayıt formuna gider; wp-admin, REST ve ATLAS etkilenmez.
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SIDES_ODS_RENKLER', array(
	'lacivert' => array( 'ad' => 'Lacivert · Altın', 'a' => '#0f2d5c', 'b' => '#163d7a', 'c' => '#2a56a8', 'v' => '#d4a017', 'v2' => '#f2c14e' ),
	'bordo'    => array( 'ad' => 'Bordo · Altın', 'a' => '#5c0f1e', 'b' => '#7a1630', 'c' => '#a8263f', 'v' => '#d4a017', 'v2' => '#f2c14e' ),
	'yesil'    => array( 'ad' => 'Koyu Yeşil · Altın', 'a' => '#0f4a2e', 'b' => '#166a44', 'c' => '#2a8f5e', 'v' => '#d4a017', 'v2' => '#f2c14e' ),
	'antrasit' => array( 'ad' => 'Antrasit · Turuncu', 'a' => '#1f2933', 'b' => '#323f4b', 'c' => '#52606d', 'v' => '#e8772e', 'v2' => '#f59e52' ),
) );

function sides_ods_varsayilan() {
	return array(
		'aktif'      => false,
		'baslik'     => 'Ödüllü Deneme Sınavı',
		'altYazi'    => '5, 6, 7 ve 8. sınıf öğrencileri için ücretsiz deneme sınavı. Sınava gir, sıralamaya göre ödülünü kazan.',
		'sinavTarih' => '',
		'sinavSaat'  => '10:00',
		'saatYazi'   => '',
		'sonBasvuru' => '',
		'yer'        => '',
		'adres'      => '',
		'siniflar'   => '5 · 6 · 7 · 8',
		'ucret'      => 'Ücretsiz',
		'odulAlt'    => 'Sınav sonucuna göre dereceye giren öğrencilere verilir.',
		'oduller'    => array(),
		'dersler'    => array( 'Türkçe', 'Matematik', 'Fen Bilimleri', 'Sosyal Bilgiler', 'İngilizce', 'Din Kültürü' ),
		'sinavAlt'   => 'Sorular öğrencinin bulunduğu sınıfın müfredatına göre hazırlanır.',
		'sinavNot'   => 'Sorular çoktan seçmelidir; yanlış cevap doğruyu götürmez.',
		'sss'        => array(
			array( 's' => 'Sınava kimler katılabilir?', 'c' => '5, 6, 7 ve 8. sınıf öğrencileri katılabilir. Başka bir okulda okuyor olmak engel değildir.' ),
			array( 's' => 'Sınav ücretli mi?', 'c' => 'Hayır, katılım ücretsizdir.' ),
			array( 's' => 'Sonuçları nasıl öğreneceğiz?', 'c' => 'Sınavdan sonra her öğrencinin karnesi veli telefonuna gönderilir; dereceye girenler ayrıca aranır.' ),
			array( 's' => 'Yanımda ne getirmeliyim?', 'c' => 'Kurşun kalem, silgi ve varsa okul kimliği yeterlidir.' ),
		),
		'telefon'    => '',
		'whatsapp'   => '',
		'eposta'     => '',
		'footer'     => 'Bu sayfa kurumun ödüllü deneme sınavı başvurusu içindir.',
		'logoTur'    => 'kurum',
		'logoG'      => '',
		'logoUrl'    => '',
		'renk'       => 'lacivert',
		'form'       => 'gomulu',
		'yonlendir'  => false,
	);
}

function sides_ods_ayar( $org ) {
	$d = sides_get_doc( (int) $org, 'ods', 'ayar' );
	$a = array_merge( sides_ods_varsayilan(), is_array( $d ) ? $d : array() );
	unset( $a['id'] );
	return $a;
}

/* Gönderilen ayarları temizler; hatalı değerde WP_Error (400) döner. Metinler kırpılır, listeler ve seçimler beyaz listeyle denetlenir. */
function sides_ods_temizle( $p ) {
	if ( ! is_array( $p ) ) {
		return new WP_Error( 'sides_gecersiz', 'Geçersiz ayar verisi.', array( 'status' => 400 ) );
	}
	$v   = sides_ods_varsayilan();
	$out = array();
	$yz  = function ( $k, $len ) use ( $p, $v ) {
		$s = isset( $p[ $k ] ) ? sanitize_text_field( (string) $p[ $k ] ) : $v[ $k ];
		return mb_substr( trim( $s ), 0, $len );
	};
	$coklu = function ( $k, $len ) use ( $p, $v ) {   // çok satırlı metin
		$s = isset( $p[ $k ] ) ? sanitize_textarea_field( (string) $p[ $k ] ) : $v[ $k ];
		return mb_substr( trim( $s ), 0, $len );
	};
	$out['aktif']     = ! empty( $p['aktif'] );
	$out['yonlendir'] = ! empty( $p['yonlendir'] );
	$out['baslik']    = $yz( 'baslik', 80 );
	if ( '' === $out['baslik'] ) {
		$out['baslik'] = $v['baslik'];
	}
	$out['altYazi']  = $coklu( 'altYazi', 300 );
	$out['saatYazi'] = $yz( 'saatYazi', 60 );
	$out['yer']      = $yz( 'yer', 80 );
	$out['adres']    = $yz( 'adres', 160 );
	$out['siniflar'] = $yz( 'siniflar', 40 );
	$out['ucret']    = $yz( 'ucret', 40 );
	$out['odulAlt']  = $yz( 'odulAlt', 160 );
	$out['sinavAlt'] = $yz( 'sinavAlt', 160 );
	$out['sinavNot'] = $coklu( 'sinavNot', 300 );
	$out['footer']   = $yz( 'footer', 200 );
	foreach ( array( 'sinavTarih', 'sonBasvuru' ) as $k ) {
		$t = isset( $p[ $k ] ) ? trim( (string) $p[ $k ] ) : '';
		if ( '' !== $t && ! ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $t ) && checkdate( (int) substr( $t, 5, 2 ), (int) substr( $t, 8, 2 ), (int) substr( $t, 0, 4 ) ) ) ) {
			return new WP_Error( 'sides_gecersiz', ( 'sinavTarih' === $k ? 'Sınav tarihi' : 'Son başvuru günü' ) . ' geçersiz (Yıl-Ay-Gün olmalı).', array( 'status' => 400 ) );
		}
		$out[ $k ] = $t;
	}
	$s = isset( $p['sinavSaat'] ) ? trim( (string) $p['sinavSaat'] ) : $v['sinavSaat'];
	if ( '' !== $s && ! preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $s ) ) {
		return new WP_Error( 'sides_gecersiz', 'Sınav saati geçersiz (SS:DD olmalı).', array( 'status' => 400 ) );
	}
	$out['sinavSaat'] = '' === $s ? '10:00' : $s;
	if ( $out['sinavTarih'] && $out['sonBasvuru'] && $out['sonBasvuru'] > $out['sinavTarih'] ) {
		return new WP_Error( 'sides_gecersiz', 'Son başvuru günü sınav tarihinden sonra olamaz.', array( 'status' => 400 ) );
	}
	// ödüller
	$od = isset( $p['oduller'] ) ? $p['oduller'] : array();
	if ( ! is_array( $od ) || count( $od ) > 10 ) {
		return new WP_Error( 'sides_gecersiz', 'En fazla 10 ödül girilebilir.', array( 'status' => 400 ) );
	}
	$out['oduller'] = array();
	foreach ( $od as $x ) {
		if ( ! is_array( $x ) ) {
			return new WP_Error( 'sides_gecersiz', 'Ödül satırı geçersiz.', array( 'status' => 400 ) );
		}
		$ad = mb_substr( sanitize_text_field( isset( $x['ad'] ) ? (string) $x['ad'] : '' ), 0, 60 );
		if ( '' === trim( $ad ) ) {
			continue;   // boş satır atlanır
		}
		$out['oduller'][] = array( 'sira' => mb_substr( sanitize_text_field( isset( $x['sira'] ) ? (string) $x['sira'] : '' ), 0, 10 ), 'ad' => $ad, 'aciklama' => mb_substr( sanitize_text_field( isset( $x['aciklama'] ) ? (string) $x['aciklama'] : '' ), 0, 120 ) );
	}
	// dersler
	$dl = isset( $p['dersler'] ) ? $p['dersler'] : $v['dersler'];
	if ( ! is_array( $dl ) || count( $dl ) > 12 ) {
		return new WP_Error( 'sides_gecersiz', 'En fazla 12 ders girilebilir.', array( 'status' => 400 ) );
	}
	$out['dersler'] = array();
	foreach ( $dl as $x ) {
		$x = mb_substr( sanitize_text_field( (string) $x ), 0, 30 );
		if ( '' !== trim( $x ) ) {
			$out['dersler'][] = $x;
		}
	}
	// SSS
	$ss = isset( $p['sss'] ) ? $p['sss'] : array();
	if ( ! is_array( $ss ) || count( $ss ) > 10 ) {
		return new WP_Error( 'sides_gecersiz', 'En fazla 10 soru girilebilir.', array( 'status' => 400 ) );
	}
	$out['sss'] = array();
	foreach ( $ss as $x ) {
		if ( ! is_array( $x ) ) {
			return new WP_Error( 'sides_gecersiz', 'SSS satırı geçersiz.', array( 'status' => 400 ) );
		}
		$q = mb_substr( sanitize_text_field( isset( $x['s'] ) ? (string) $x['s'] : '' ), 0, 120 );
		$c = mb_substr( sanitize_textarea_field( isset( $x['c'] ) ? (string) $x['c'] : '' ), 0, 400 );
		if ( '' === trim( $q ) && '' === trim( $c ) ) {
			continue;
		}
		$out['sss'][] = array( 's' => $q, 'c' => $c );
	}
	// iletişim
	$tel = $yz( 'telefon', 30 );
	if ( '' !== $tel && ! preg_match( '/^\+?[\d\s().-]{7,30}$/', $tel ) ) {
		return new WP_Error( 'sides_gecersiz', 'Telefon numarası geçersiz.', array( 'status' => 400 ) );
	}
	$out['telefon'] = $tel;
	$wa = preg_replace( '/\D/', '', isset( $p['whatsapp'] ) ? (string) $p['whatsapp'] : '' );
	if ( '' !== $wa && ( strlen( $wa ) < 10 || strlen( $wa ) > 15 ) ) {
		return new WP_Error( 'sides_gecersiz', 'WhatsApp numarası ülke koduyla, boşluksuz 10–15 rakam olmalı (örn. 905xxxxxxxxx).', array( 'status' => 400 ) );
	}
	$out['whatsapp'] = $wa;
	$ep = $yz( 'eposta', 80 );
	if ( '' !== $ep && ! is_email( $ep ) ) {
		return new WP_Error( 'sides_gecersiz', 'E-posta adresi geçersiz.', array( 'status' => 400 ) );
	}
	$out['eposta'] = $ep;
	// logo, renk, form
	$lt = isset( $p['logoTur'] ) ? (string) $p['logoTur'] : 'kurum';
	if ( ! in_array( $lt, array( 'kurum', 'yukle', 'url', 'yok' ), true ) ) {
		return new WP_Error( 'sides_gecersiz', 'Logo seçimi geçersiz.', array( 'status' => 400 ) );
	}
	$out['logoTur'] = $lt;
	$lg             = isset( $p['logoG'] ) ? (string) $p['logoG'] : '';
	if ( '' !== $lg && ! preg_match( '/^g[a-f0-9]{16,40}$/', $lg ) ) {
		return new WP_Error( 'sides_gecersiz', 'Yüklenen logo kimliği geçersiz.', array( 'status' => 400 ) );
	}
	$out['logoG'] = $lg;
	$lu           = isset( $p['logoUrl'] ) ? trim( (string) $p['logoUrl'] ) : '';
	if ( '' !== $lu && ( strlen( $lu ) > 300 || ! preg_match( '#^https://[^\s"\'<>]+$#i', $lu ) ) ) {
		return new WP_Error( 'sides_gecersiz', 'Logo adresi https:// ile başlayan geçerli bir adres olmalı.', array( 'status' => 400 ) );
	}
	$out['logoUrl'] = $lu;
	$r              = isset( $p['renk'] ) ? (string) $p['renk'] : 'lacivert';
	if ( ! isset( SIDES_ODS_RENKLER[ $r ] ) ) {
		return new WP_Error( 'sides_gecersiz', 'Renk seçimi geçersiz.', array( 'status' => 400 ) );
	}
	$out['renk'] = $r;
	$f           = isset( $p['form'] ) ? (string) $p['form'] : 'gomulu';
	if ( ! in_array( $f, array( 'gomulu', 'link' ), true ) ) {
		return new WP_Error( 'sides_gecersiz', 'Kayıt formu seçimi geçersiz.', array( 'status' => 400 ) );
	}
	$out['form'] = $f;
	return $out;
}

/* ------------------------------------------------------------------ *
 * Kurum ve adresler
 * ------------------------------------------------------------------ */
/* ?ods=1 ya da /ods/ → varsayılan kurum: ÖDS ayarı olan kurumlardan aktif olan (en düşük kimlik), yoksa ilk kurum. ?ods=<anahtar> → o kurum. */
function sides_ods_org( $key ) {
	global $wpdb;
	$key = substr( preg_replace( '/[^a-z0-9]/', '', strtolower( (string) $key ) ), 0, 32 );
	if ( '' !== $key ) {
		$o = sides_org_by_key( $key );
		if ( $o || '1' !== $key ) {
			return $o;   // anahtar verilmişse yalnızca o kurum; "1" anahtarı yoksa varsayılan kurum
		}
	}
	/* v7.3.1 güvenlik: site yöneticisinin seçtiği kurum (ana sayfa yönlendirmesini açan) varsayılandır; bir kurum kendini sitenin varsayılan sayfası yapamaz */
	$vs = (int) get_option( 'sides_ods_varsayilan', 0 );
	if ( $vs && ( $vo = sides_org( $vs ) ) ) {
		return $vo;
	}
	$t    = sides_docs();
	$rows = $wpdb->get_results( "SELECT org, id, data FROM $t WHERE coll = 'ods' AND id IN ('form','ayar') ORDER BY org" ); // phpcs:ignore
	$ilk  = 0;
	foreach ( array( 'form', 'ayar' ) as $tur ) {   // v7.8: önce kayıt formu açık olan kurum, yoksa eski tanıtım sayfası yayında olan
		foreach ( $rows as $r ) {
			$d = json_decode( $r->data, true );
			if ( ! $ilk ) {
				$ilk = (int) $r->org;
			}
			if ( $r->id === $tur && ! empty( $d[ 'form' === $tur ? 'acik' : 'aktif' ] ) ) {
				return sides_org( (int) $r->org );
			}
		}
	}
	if ( ! $ilk ) {
		$ilk = (int) $wpdb->get_var( 'SELECT MIN(id) FROM ' . sides_orgs() ); // phpcs:ignore
	}
	return $ilk ? sides_org( $ilk ) : null;
}

function sides_ods_url_kisa() {
	return get_option( 'permalink_structure' ) ? home_url( '/ods/' ) : add_query_arg( 'ods', '1', home_url( '/' ) );
}
function sides_ods_url_tam( $o ) {
	return add_query_arg( 'ods', $o ? $o->anahtar : '1', home_url( '/' ) );
}
function sides_ods_logo_url( $o, $a ) {
	if ( 'yok' === $a['logoTur'] ) {
		return '';
	}
	if ( 'url' === $a['logoTur'] ) {
		return $a['logoUrl'];
	}
	if ( 'yukle' === $a['logoTur'] && ! $a['logoG'] ) {
		return '';
	}
	if ( 'kurum' === $a['logoTur'] ) {
		$set = sides_get_doc( (int) $o->id, 'settings', 'main' );
		if ( empty( $set['logo'] ) ) {
			return '';
		}
	}
	return add_query_arg( 'v', substr( md5( $a['logoTur'] . $a['logoG'] ), 0, 8 ), rest_url( 'optik-karne/v1/ods/logo/' . $o->anahtar ) );
}

/* ------------------------------------------------------------------ *
 * Yeniden yazma (/ods/) ve yönlendirme
 * ------------------------------------------------------------------ */
add_action( 'init', function () {
	add_rewrite_rule( '^ods/?$', 'index.php?sides_ods=1', 'top' );
	if ( '2' !== (string) get_option( 'sides_ods_rw' ) ) {   // kural bir kez kaydedilir (eklenti güncellemesinde etkinleştirme çalışmayabilir); seçenek önce yazılır ki eş zamanlı istekler yeniden tazelemesin
		update_option( 'sides_ods_rw', '2' );
		flush_rewrite_rules();
	}
}, 11 );
add_filter( 'query_vars', function ( $vars ) {
	$vars[] = 'sides_ods';
	return $vars;
} );
add_action( 'template_redirect', function () {
	if ( is_admin() || ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
		return;
	}
	if ( isset( $_GET['ods'] ) || get_query_var( 'sides_ods' ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		$k = isset( $_GET['ods'] ) && is_string( $_GET['ods'] ) ? wp_unslash( $_GET['ods'] ) : '1'; // phpcs:ignore
		sides_render_app( 'ods', substr( preg_replace( '/[^a-z0-9]/', '', strtolower( $k ) ), 0, 32 ) );
		exit;
	}
	// Ana sayfaya yönlendir: yalnızca kök adres (sorgusuz), ATLAS ana sayfada değilse ve sayfa yayındaysa
	if ( sides_ana_sayfa() || get_query_var( 'optik_karne' ) || ! ( is_front_page() || is_home() ) || is_customize_preview() ) {
		return;
	}
	if ( ! empty( $_SERVER['QUERY_STRING'] ) ) {
		return;
	}
	$yol  = rawurldecode( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '/', PHP_URL_PATH ) ); // phpcs:ignore
	$kok  = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
	if ( untrailingslashit( $yol ) !== untrailingslashit( $kok ) ) {
		return;
	}
	$o = sides_ods_org( '1' );
	if ( ! $o || (int) $o->id !== (int) get_option( 'sides_ods_varsayilan', 0 ) ) {   // v7.3.1: yalnız site yöneticisinin açtığı yönlendirme
		return;
	}
	$a = sides_ods_ayar( (int) $o->id );
	$f = function_exists( 'sides_odsf_form' ) ? sides_odsf_form( (int) $o->id ) : null;   // v7.8: yönlendirme kayıt formuna; form başvuruya açıkken
	$acik = $f ? sides_odsf_durum( $f, sides_odsf_say( (int) $o->id ) )['acik'] : ! empty( $a['aktif'] );
	if ( $acik && ! empty( $a['yonlendir'] ) && ! sides_org_blok( $o ) ) {
		wp_safe_redirect( sides_ods_url_kisa(), 302 );
		exit;
	}
}, 5 );

/* ------------------------------------------------------------------ *
 * REST
 * ------------------------------------------------------------------ */
add_action( 'rest_api_init', function () {
	$ns  = 'optik-karne/v1';
	$oku = function () {
		return sides_can( 'kayit', 1 ) ? true : sides_deny( 'Tanıtım sayfası ayarlarını görmek için Kayıt modülü yetkisi gerekir.' );
	};
	$yaz = function () {
		if ( sides_is_observer() ) {
			return sides_deny( 'Gözlemci hesabı tanıtım sayfasını değiştiremez.' );
		}
		if ( ! sides_can( 'kayit', 2 ) ) {
			return sides_deny( 'Tanıtım sayfasını Kayıt modülünde değişiklik yetkisi olan kullanıcılar düzenler.' );
		}
		if ( function_exists( 'sides_sayfa_herhangi' ) && ! sides_sayfa_herhangi( array( 'kayit.ods' ), 2 ) ) {
			return sides_deny( 'ÖDS Kayıt Formu sayfasında değişiklik yetkiniz yok. Yöneticinizden izin isteyin.' );
		}
		return true;
	};
	register_rest_route( $ns, '/ods/ayar', array(
		array( 'methods' => 'GET', 'callback' => 'sides_ods_rest_oku', 'permission_callback' => $oku ),
		array( 'methods' => 'POST', 'callback' => 'sides_ods_rest_kaydet', 'permission_callback' => $yaz ),
	) );
	register_rest_route( $ns, '/ods/logo', array( 'methods' => 'POST', 'callback' => 'sides_ods_rest_logo_yukle', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/ods/logo/(?P<key>[a-z0-9]{1,32})', array( 'methods' => 'GET', 'callback' => 'sides_ods_rest_logo', 'permission_callback' => '__return_true' ) );
} );

function sides_ods_rest_cikis( $org ) {
	$o   = sides_org( $org );
	$a   = sides_ods_ayar( $org );
	$set = sides_get_doc( $org, 'settings', 'main' );
	return array(
		'ayar'      => $a,
		'kurum'     => isset( $set['kurum'] ) && $set['kurum'] ? $set['kurum'] : ( $o ? $o->ad : '' ),
		'kurumLogo' => ! empty( $set['logo'] ),
		'kayitAcik' => ! empty( $set['kayitAcik'] ),
		'anaSayfa'  => sides_ana_sayfa(),
		'url'       => array( 'kisa' => sides_ods_url_kisa(), 'tam' => sides_ods_url_tam( $o ), 'kayit' => optik_karne_url( array( 'kayit' => $o ? $o->anahtar : '1' ) ), 'logo' => $o ? sides_ods_logo_url( $o, $a ) : '' ),
		'varsayilan' => $o && ( $vo = sides_ods_org( '1' ) ) ? (int) $vo->id === (int) $o->id : false,   // /ods/ bu kurumu açar mı?
		'renkler'   => SIDES_ODS_RENKLER,
		'yaz'       => sides_can( 'kayit', 2 ) && ! sides_is_observer(),
		'yonlendirYetki' => sides_is_super(),
	);
}
function sides_ods_rest_oku() {
	return sides_ods_rest_cikis( sides_org_id() );
}
function sides_ods_rest_kaydet( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	$a   = sides_ods_temizle( isset( $p['ayar'] ) && is_array( $p['ayar'] ) ? $p['ayar'] : $p );
	if ( is_wp_error( $a ) ) {
		return $a;
	}
	if ( 'yukle' === $a['logoTur'] && $a['logoG'] ) {   // yüklenen logo bu kurumun görseli olmalı
		global $wpdb;
		$t = sides_docs();
		if ( ! $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE org = %d AND coll = 'gorsel' AND id = %s", $org, $a['logoG'] ) ) ) { // phpcs:ignore
			return new WP_Error( 'sides_gecersiz', 'Yüklenen logo bulunamadı; yeniden yükleyin.', array( 'status' => 400 ) );
		}
	}
	$eski = sides_ods_ayar( $org );
	/* v7.3.1 güvenlik: sitenin kök adresini yönlendirmek tüm siteyi etkiler; yalnız site yöneticisi açıp kapatabilir */
	if ( ! sides_is_super() ) {
		$a['yonlendir'] = ! empty( $eski['yonlendir'] );
	} elseif ( $a['yonlendir'] ) {
		update_option( 'sides_ods_varsayilan', (int) $org, false );
	} elseif ( (int) get_option( 'sides_ods_varsayilan', 0 ) === (int) $org ) {
		delete_option( 'sides_ods_varsayilan' );
	}
	if ( false === sides_put_doc( $org, 'ods', 'ayar', $a ) ) {
		return new WP_Error( 'sides_db', 'Ayarlar kaydedilemedi.', array( 'status' => 500 ) );
	}
	$ne = array();
	if ( (bool) $eski['aktif'] !== $a['aktif'] ) {
		$ne[] = $a['aktif'] ? 'sayfa yayına alındı' : 'sayfa yayından kaldırıldı';
	}
	if ( (bool) $eski['yonlendir'] !== $a['yonlendir'] ) {
		$ne[] = $a['yonlendir'] ? 'ana sayfa yönlendirmesi açıldı' : 'ana sayfa yönlendirmesi kapatıldı';
	}
	sides_log( $org, 'ÖDS tanıtım sayfası güncellendi' . ( $ne ? ': ' . implode( ', ', $ne ) : '' ) );
	return sides_ods_rest_cikis( $org );
}
function sides_ods_rest_logo_yukle( WP_REST_Request $req ) {
	if ( ! sides_rl( 'ods_logo_yukle_' . sides_org_id(), 30, 3600 ) ) {   // v7.3.1: her yükleme yeni görsel kaydı açar; sınırsız yükleme veritabanını doldurmasın
		return new WP_Error( 'sides_rl', 'Çok sık logo yüklendi. Bir saat sonra tekrar deneyin.', array( 'status' => 429 ) );
	}
	$p = $req->get_json_params();
	$g = sides_gorsel_kaydet( isset( $p['data'] ) ? (string) $p['data'] : '', sides_org_id() );
	return is_wp_error( $g ) ? $g : array( 'id' => $g['id'] );
}
/* Herkese açık logo: kurum logosu (ayarlardaki veri adresi) ya da yüklenen görsel. Yalnızca ÖDS ayarının gösterdiği görsel sunulur. */
function sides_ods_rest_logo( WP_REST_Request $req ) {
	global $wpdb;
	if ( ! sides_rl( 'ods_logo', 300, 600 ) ) {
		return new WP_Error( 'sides_rl', 'Çok fazla istek.', array( 'status' => 429 ) );
	}
	$o = sides_ods_org( (string) $req['key'] );
	if ( ! $o ) {
		return new WP_Error( 'sides_yok', 'Kurum bulunamadı.', array( 'status' => 404 ) );
	}
	$a   = sides_ods_ayar( (int) $o->id );
	$bin = '';
	$mim = 'image/png';
	if ( 'kurum' === $a['logoTur'] ) {
		$set = sides_get_doc( (int) $o->id, 'settings', 'main' );
		if ( ! empty( $set['logo'] ) && preg_match( '#^data:(image/(?:png|jpeg|webp|gif));base64,([A-Za-z0-9+/=]+)$#', (string) $set['logo'], $m ) ) {
			$mim = $m[1];
			$bin = base64_decode( $m[2], true );
		}
	} elseif ( 'yukle' === $a['logoTur'] && $a['logoG'] ) {
		$t   = sides_docs();
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT data FROM $t WHERE coll = 'gorsel' AND id = %s AND org = %d", $a['logoG'], (int) $o->id ) ); // phpcs:ignore
		$d   = $row ? json_decode( $row->data, true ) : null;
		if ( $d && ! empty( $d['b'] ) ) {
			$mim = isset( $d['m'] ) && in_array( $d['m'], array( 'image/jpeg', 'image/png', 'image/webp' ), true ) ? $d['m'] : 'image/jpeg';
			$bin = base64_decode( $d['b'] );
		}
	}
	if ( ! $bin ) {
		return new WP_Error( 'sides_yok', 'Logo bulunamadı.', array( 'status' => 404 ) );
	}
	header( 'Content-Type: ' . $mim );
	header( 'Content-Length: ' . strlen( $bin ) );
	header( 'Cache-Control: public, max-age=3600' );
	header( 'X-Content-Type-Options: nosniff' );
	/* v7.3.1 güvenlik: SVG ve betik içeren dosyalar sunulmaz; yanlış türde içerik gelse bile tarayıcı çalıştırmaz */
	header( "Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; sandbox" );
	header( 'Content-Disposition: inline; filename="logo"' );
	header_remove( 'Expires' );
	header_remove( 'Pragma' );
	echo $bin; // phpcs:ignore
	exit;
}

/* ------------------------------------------------------------------ *
 * Herkese açık sayfa
 * ------------------------------------------------------------------ */
function sides_ods_tarih_yaz( $iso ) {
	if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', (string) $iso, $m ) ) {
		return '';
	}
	$ay  = array( 1 => 'Ocak', 'Şubat', 'Mart', 'Nisan', 'Mayıs', 'Haziran', 'Temmuz', 'Ağustos', 'Eylül', 'Ekim', 'Kasım', 'Aralık' );
	$gun = array( 'Pazar', 'Pazartesi', 'Salı', 'Çarşamba', 'Perşembe', 'Cuma', 'Cumartesi' );
	$ts  = gmmktime( 12, 0, 0, (int) $m[2], (int) $m[3], (int) $m[1] );
	return (int) $m[3] . ' ' . $ay[ (int) $m[2] ] . ' ' . $m[1] . ' ' . $gun[ (int) gmdate( 'w', $ts ) ];
}
function sides_ods_bugun() {
	return ( new DateTime( 'now', new DateTimeZone( 'Europe/Istanbul' ) ) )->format( 'Y-m-d' );
}
