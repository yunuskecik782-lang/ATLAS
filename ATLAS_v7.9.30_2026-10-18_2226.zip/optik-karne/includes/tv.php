<?php
/**
 * TV Panosu (Puan Sistemi modülü): yalnızca gösterim amaçlı, iptal edilebilir bağlantı ile açılan televizyon ekranı.
 *
 * Belgeler (coll: tv):
 *   tv/ayar            ekran ayarları (tema, paneller, gizlilik, şerit, namaz vakti konumu…)
 *   tv/program         günlük program: { gunler: { 1: [ {id, bas, bit, ad, kat} ], … 7: [] } }  (1 = Pazartesi)
 *   tv/duyuru_<id>     duyuru kartı: { baslik, aciklama, tip: metin|gorsel|video, g (görsel kimliği), video (url), bas, bit, oncelik, sure, aktif }
 *   tv/vakit_<YYYY-MM> aylık namaz vakti çizelgesi: { ay, kaynak, kaynakTip?, veriTarihi, gunler: { 'YYYY-MM-DD': {imsak, sabah?, gunes, ogle, ikindi, aksam, yatsi} } }
 *   (Vakitler yönetim ekranında yapıştırılan/yüklenen tablodan gelir. v7 R05: yönetici açarsa includes/fazilet.php, Fazilet Takvimi web
 *    istemcisinin kamuya açık günlük veri yolundan — belgelenmiş/sürüm garantili bir API değildir — günde bir kez çekip doğrular ve bu
 *    belgelere gün gün birleştirir; TV ekranları dış siteye hiç bağlanmaz.)
 *   tv/link            ekran bağlantısı; 32 karakterlik belirteç satırın token sütunundadır (yenile = yeni belirteç, iptal = null)
 *
 * GET  tv/<token>            herkese açık, hız sınırlı, no-store. Yanıtta yalnızca gösterim için gereken alanlar bulunur:
 *                            gerekçe, not, veli/telefon bilgisi ve öğrenci bazlı ibadet ayrıntısı hiçbir zaman gönderilmez.
 *                            ?imza=<son imza> gönderilirse ve veri değişmediyse { degismedi: true } döner.
 *                            v7.8 yönetim önizlemesi: ?oniz=1 + geçerli oturum (X-WP-Nonce) + TV yönetim yetkisi (puan ≥ 2, gözlemci ve
 *                            sınıf kısıtlı değil, belirtecin kurumu) varsa TV beklemedeyken de gerçek pano döner ve { onizBekleme } taşır;
 *                            belirteç tek başına (oturumsuz ya da nonce'suz) beklemeyi asla aşamaz (sides_tv_oniz_yetki).
 * GET  tv/<token>/gorsel/<id> duyuru görseli (kurumun görsel kaydı)
 * POST tv/link  (yetki: puan ≥ 2) bağlantı oluştur/yenile · DELETE tv/link bağlantıyı iptal et
 * POST tv/hedef-oniz (yetki: puan ≥ 2, gözlemci değil) { hedef: taslak Hedefler bölümü ayarı } → panoya gidecek hedef listesinin aynısı
 *                            (kaydedilmemiş taslağın önizlemesi ve ayar ekranındaki öğrenci sayısı için; kayıtlı gizlilik ve fotoğraf ayarıyla)
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SIDES_TV_KATEGORI', array( 'namaz', 'ders', 'etut', 'yemek', 'teneffus', 'diger' ) );
define( 'SIDES_TV_VAKIT_ALAN', array( 'imsak', 'sabah', 'gunes', 'ogle', 'ikindi', 'aksam', 'yatsi' ) );   // sabah: Fazilet Takvimi'nin ayrı sütunu (yoksa boş)

add_action( 'rest_api_init', function () {
	$ns  = 'optik-karne/v1';
	$yaz = function () {
		if ( function_exists( 'sides_is_observer' ) && sides_is_observer() ) {
			return sides_deny( 'Gözlemci hesabının işlem yetkisi yok. Yöneticinizden izin isteyin.' );
		}
		if ( function_exists( 'sides_sinif_kisit' ) && null !== sides_sinif_kisit() ) {   // v7.3.1: TV kurum geneli bir ayardır; sınıf kısıtlı kullanıcı linki yenileyip kapatamaz
			return sides_deny( 'TV bağlantısı kurum geneli bir ayardır; kurum yöneticisi ya da sınıf kısıtı olmayan bir kullanıcı yönetebilir.' );
		}
		return sides_can( 'puan', 2 ) ? true : sides_deny( 'TV bağlantısı için Puan Sistemi düzenleme yetkisi gerekir.' );
	};
	register_rest_route( $ns, '/tv/link', array(
		array( 'methods' => 'POST', 'callback' => 'sides_tv_link_olustur', 'permission_callback' => $yaz ),
		array( 'methods' => 'DELETE', 'callback' => 'sides_tv_link_sil', 'permission_callback' => $yaz ),
	) );
	register_rest_route( $ns, '/tv/hedef-oniz', array( 'methods' => 'POST', 'callback' => 'sides_tv_hedef_oniz', 'permission_callback' => $yaz ) );   // Ekran Ayarları › Hedefler: kaydetmeden önizleme
	register_rest_route( $ns, '/tv/(?P<token>[a-f0-9]{32})', array( 'methods' => 'GET', 'callback' => 'sides_tv_oku', 'permission_callback' => '__return_true' ) );
	register_rest_route( $ns, '/tv/(?P<token>[a-f0-9]{32})/surum', array( 'methods' => 'GET', 'callback' => 'sides_tv_surum_oku', 'permission_callback' => '__return_true' ) );
	register_rest_route( $ns, '/tv/(?P<token>[a-f0-9]{32})/gorsel/(?P<id>g[a-f0-9]{16,40})', array( 'methods' => 'GET', 'callback' => 'sides_tv_gorsel', 'permission_callback' => '__return_true' ) );
} );

/* ------------------------------------------------------------------ *
 * Bağlantı (belirteç)
 * ------------------------------------------------------------------ */
function sides_tv_link_olustur() {
	global $wpdb;
	$org = sides_org_id();
	$d   = sides_get_doc( $org, 'tv', 'link' );
	$u   = wp_get_current_user();
	$yeni = ! $d;
	$d    = array( 'olusturma' => current_time( 'mysql' ), 'olusturan' => $u ? $u->display_name : '' );
	if ( false === sides_put_doc( $org, 'tv', 'link', $d ) ) {
		return new WP_Error( 'sides_db', 'Kaydedilemedi.', array( 'status' => 500 ) );
	}
	$tok = bin2hex( random_bytes( 16 ) );
	$wpdb->update( sides_docs(), array( 'token' => $tok ), array( 'org' => $org, 'coll' => 'tv', 'id' => 'link' ) );
	sides_log( $org, $yeni ? 'TV ekranı bağlantısı oluşturuldu' : 'TV ekranı bağlantısı yenilendi (eski bağlantı geçersiz)' );
	return array( 'token' => $tok, 'olusturma' => $d['olusturma'], 'olusturan' => $d['olusturan'] );
}
function sides_tv_link_sil() {
	global $wpdb;
	$org = sides_org_id();
	$wpdb->update( sides_docs(), array( 'token' => null ), array( 'org' => $org, 'coll' => 'tv', 'id' => 'link' ) );
	sides_log( $org, 'TV ekranı bağlantısı iptal edildi' );
	return array( 'ok' => true );
}

/* Belirteçten kurum: modül kapalıysa ya da kurum engelliyse null */
function sides_tv_bul( $token ) {
	global $wpdb;
	$t = sides_docs();
	$r = $wpdb->get_row( $wpdb->prepare( "SELECT org FROM $t WHERE coll = 'tv' AND id = 'link' AND token = %s", $token ) ); // phpcs:ignore
	if ( ! $r || in_array( 'puan', sides_kapali_moduller( (int) $r->org ), true ) ) {
		return 0;
	}
	$o = sides_org( (int) $r->org );
	if ( ! $o || sides_org_blok( $o ) ) {
		return 0;
	}
	return (int) $r->org;
}

/* ------------------------------------------------------------------ *
 * Yardımcılar
 * ------------------------------------------------------------------ */
function sides_tv_ayar_varsayilan() {
	return array(
		'tema' => 'acik', 'yon' => 'yatay', 'fontOlcek' => 1, 'logoBoyut' => 1, 'kenar' => 24, 'saniye' => 1, 'salise' => 1, 'hicri' => 1, 'hicriDuzelt' => 0, 'desen' => 1,
		'paneller' => array( 'siralama' => 1, 'program' => 1, 'duyuru' => 1, 'vakit' => 1, 'serit' => 1 ),
		'oran' => 'dengeli', 'gizlilik' => 'adsoyad', 'foto' => 0, 'ilkN' => 0, 'siraSigdir' => 1, 'siraMod' => 'sayfa', 'siraGecis' => 'solma', 'vakitBoyut' => 'orta', 'markaYazi' => 'el', 'markaUst' => '', 'markaAlt' => '', 'markaRenk' => 'lacivert', 'renkProfil' => 'lacivert', 'markaBoyut' => 1, 'markaLogo' => 'kurum', 'markaLogoG' => '', 'sayfaSure' => 12, 'donem' => '1h', 'ozel' => array( 'bas' => '', 'bit' => '' ),
		'yenile' => 15, 'duyuruSure' => 12, 'sistemDuyuru' => 0, 'slogan' => '',
		'ustStil' => 'kart', 'ustZemin' => 'panel', 'ustRenk' => '#0f2d5c', 'ustEfekt' => 'yok', 'ustCizgi' => 'oto',   // v7.9.8 üst şerit biçimi, zemini, efekti (sides_tv_gorunum_temiz)
		'arkaplan' => 'sade', 'arkaplanYog' => 'orta', 'arkaplanHiz' => 'normal',   // v7.2 canlı arka plan, yoğunluğu ve hızı (sides_tv_gorunum_temiz)
		'lgsTarihi' => '2027-06-12', 'lgsKart' => 1, 'lgsUst' => 0,   // v7.2 LGS geri sayımı: lgsTarihi tahminî varsayılan (MEB henüz açıklamadı; ayarda "tahmini" etiketli, değiştirilebilir; '' = kapalı). LGS Modülü'nde tarih girilmişse o geçerlidir (sides_tv_lgs_tarih). lgsKart: 8. sınıf kartları, lgsUst: üst şerit rozeti
		'serit' => array( 'acik' => 1, 'hiz' => 90, 'yon' => 'sol', 'boyut' => 1, 'renk' => '', 'duraklat' => 0, 'akici' => 1, 'metinler' => array(), 'yazi' => 'modern', 'zemin' => '', 'rozet' => 'profil', 'akis' => 'kayan', 'anim' => 'karisik', 'bekle' => 6, 'kenar' => 1, 'kenarGen' => 'orta', 'ayirici' => 'nokta', 'manim' => 'yok' ),   // akici: hız ekranın yenileme hızına uydurulur (±%15; src/tv.js tvSrtHiz); v7.2: yazı stili, zemin, rozet rengi, akış türü, animasyon, bekleme, kenar solması (+ genişlik), ayırıcı, kayan metin animasyonu
		'vakit' => array( 'il' => 'İstanbul', 'ilce' => 'Fatih', 'tz' => 'Europe/Istanbul', 'sabahAlan' => 'sabah', 'kaynakTip' => 'fazilet' ),
		'duzen' => null, 'basliklar' => array(), 'ozelBolumler' => array(), 'hadisKonular' => array(), 'hadisDongu' => 15,   // v7.1 Sayfa düzeni; dönen konular (panoya bu ve gelecek haftanın kayıtları gider: sides_tv_konu_pano)
		'gerisayim' => sides_tv_gs_vars(),   // v7.6 sınav geri sayımı (tam ekran; sides_tv_gs_temiz)
		'hedef' => sides_tv_hedef_vars(),   // Hedefler bölümü: öğrenci hedefleri slaytları (sides_tv_hedef_veri)
	);
}
/* v7.6 Sınav geri sayımı: pano belirtilen gün ve saat aralığında tam ekran geri sayıma geçer.
   tarih YYYY-AA-GG · bas SS:DD · sure dk (1–300) · erken: başladıktan kaç dk sonra çıkılabilir (0 = gösterme; saat olarak yazılır)
   once: başlamadan kaç dk önce "başlamasına kalan" gösterilir (0–180) · sonra: bitince kaç dk "süre doldu" kalır (0–30)
   stil: dijital | halka | kart · baslik ≤ 60 · alt ≤ 80 (ör. salon/oturum) · acik 0/1 */
function sides_tv_gs_vars() {
	return array( 'acik' => 0, 'baslik' => 'Deneme Sınavı', 'alt' => '', 'tarih' => '', 'bas' => '09:30', 'sure' => 120, 'erken' => 30, 'once' => 30, 'sonra' => 5, 'stil' => 'dijital' );
}
function sides_tv_gs_temiz( $g, &$hata ) {
	$v = sides_tv_gs_vars();
	$g = is_array( $g ) ? $g : array();
	$o = array();
	$o['acik']   = ! empty( $g['acik'] ) && '0' !== $g['acik'] ? 1 : 0;
	$o['baslik'] = mb_substr( trim( sanitize_text_field( isset( $g['baslik'] ) && is_scalar( $g['baslik'] ) ? (string) $g['baslik'] : $v['baslik'] ) ), 0, 60 );
	$o['alt']    = mb_substr( trim( sanitize_text_field( isset( $g['alt'] ) && is_scalar( $g['alt'] ) ? (string) $g['alt'] : '' ) ), 0, 80 );
	$t           = isset( $g['tarih'] ) && is_string( $g['tarih'] ) ? trim( $g['tarih'] ) : '';
	if ( '' !== $t && ! ( preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $t, $m ) && checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ) ) {
		$hata[] = 'Geri sayım tarihi YYYY-AA-GG biçiminde olmalı.';
		$t      = '';
	}
	$o['tarih'] = $t;
	$b          = isset( $g['bas'] ) && is_string( $g['bas'] ) ? trim( $g['bas'] ) : $v['bas'];
	if ( ! preg_match( '/^([01]\d|2[0-3]):[0-5]\d$/', $b ) ) {
		$hata[] = 'Geri sayım başlangıç saati SS:DD biçiminde olmalı.';
		$b      = $v['bas'];
	}
	$o['bas'] = $b;
	foreach ( array( 'sure' => array( 1, 300 ), 'erken' => array( 0, 300 ), 'once' => array( 0, 180 ), 'sonra' => array( 0, 30 ) ) as $k => $ar ) {
		$n = isset( $g[ $k ] ) && is_numeric( $g[ $k ] ) ? (int) $g[ $k ] : null;
		if ( null === $n || $n < $ar[0] || $n > $ar[1] ) {
			if ( isset( $g[ $k ] ) ) {
				$hata[] = 'Geri sayım: ' . array( 'sure' => 'süre', 'erken' => 'en erken çıkış', 'once' => 'önceden gösterme', 'sonra' => 'bitiş sonrası gösterme' )[ $k ] . ' ' . $ar[0] . '–' . $ar[1] . ' dakika olmalı.';
			}
			$n = $v[ $k ];
		}
		$o[ $k ] = $n;
	}
	if ( $o['erken'] >= $o['sure'] && $o['erken'] > 0 ) {
		$hata[]     = 'En erken çıkış, sınav süresinden kısa olmalı.';
		$o['erken'] = min( $v['erken'], max( 0, $o['sure'] - 1 ) );
	}
	$o['stil'] = isset( $g['stil'] ) && in_array( $g['stil'], array( 'dijital', 'halka', 'kart' ), true ) ? $g['stil'] : 'dijital';
	if ( isset( $g['stil'] ) && $o['stil'] !== $g['stil'] ) {
		$hata[] = 'Geri sayım stili geçersiz.';
	}
	if ( $o['acik'] && '' === $o['tarih'] ) {
		$hata[] = 'Panoda göstermek için geri sayımın tarihini seçin.';
	}
	return $o;
}
/* Ekrana giden ayar: yalnızca gösterimle ilgili alanlar (varsayılanlarla birleştirilmiş) */
function sides_tv_ayar_disari( $a ) {
	$v = sides_tv_ayar_varsayilan();
	$a = sides_tv_goc( is_array( $a ) ? $a : array() );   // eski kayıtlar: hedef bölümü ve konular (kalıcı yazmaz; ilk kayıtta saklanır)
	$o = array();
	foreach ( $v as $k => $d ) {
		if ( is_array( $d ) && ! isset( $d[0] ) ) {
			$o[ $k ] = array_merge( $d, isset( $a[ $k ] ) && is_array( $a[ $k ] ) ? $a[ $k ] : array() );
		} else {
			$o[ $k ] = isset( $a[ $k ] ) ? $a[ $k ] : $d;
		}
	}
	$o['yon']       = in_array( $o['yon'], array( 'yatay', 'otomatik', 'dikey' ), true ) ? $o['yon'] : 'yatay';
	$o['gizlilik']  = in_array( $o['gizlilik'], array( 'adsoyad', 'adbas', 'takma' ), true ) ? $o['gizlilik'] : 'adsoyad';
	$o['ilkN']      = max( 0, min( 500, (int) $o['ilkN'] ) );   // 0 = bütün öğrenciler
	$o['siraSigdir'] = 0 === (int) $o['siraSigdir'] ? 0 : 1;
	$o['siraMod']    = 'sigdir' === $o['siraMod'] ? 'sigdir' : 'sayfa';
	$o['siraGecis']  = in_array( $o['siraGecis'], array( 'solma', 'kaydir', 'dalga', 'yok' ), true ) ? $o['siraGecis'] : 'solma';   // v7.9.7 Zirvedekiler sayfa geçişi
	$o['vakitBoyut'] = in_array( $o['vakitBoyut'], array( 'kucuk', 'orta', 'buyuk' ), true ) ? $o['vakitBoyut'] : 'orta';   // v7.0.6 namaz vakti yazı boyutu   // v7: Zirvedekiler varsayılanı sayfalara bölmek
	$o['markaYazi']  = in_array( $o['markaYazi'], array( 'el', 'zarif', 'yuvarlak', 'klasik', 'modern', 'duz' ), true ) ? $o['markaYazi'] : 'el';
	$o['markaUst']   = mb_substr( trim( (string) $o['markaUst'] ), 0, 40 );
	$o['markaAlt']   = mb_substr( trim( (string) $o['markaAlt'] ), 0, 60 );
	$o['markaRenk']  = in_array( $o['markaRenk'], array( 'lacivert', 'altin', 'bordo', 'yesil', 'siyah' ), true ) ? $o['markaRenk'] : 'lacivert';
	$o['markaBoyut'] = max( 0.6, min( 1.8, (float) $o['markaBoyut'] ) );
	$o['renkProfil'] = in_array( $o['renkProfil'], SIDES_TV_RPROFIL, true ) ? $o['renkProfil'] : 'lacivert';   // v6 R04 hazır renk profilleri (v7.2: 17 profil)
	$o['markaLogo']  = in_array( $o['markaLogo'], array( 'kurum', 'ozel', 'yok' ), true ) ? $o['markaLogo'] : 'kurum';
	$o['markaLogoG'] = preg_match( '/^g[a-f0-9]{16,40}$/', (string) $o['markaLogoG'] ) ? (string) $o['markaLogoG'] : '';
	$o['yenile']    = max( 5, min( 600, (int) $o['yenile'] ) );
	$gs_h           = array();
	$o['gerisayim'] = sides_tv_gs_temiz( $o['gerisayim'], $gs_h );   // v7.6: eski/bozuk kayıt da güvenli biçimde
	$o['sayfaSure'] = max( 4, min( 120, (int) $o['sayfaSure'] ) );
	$o['vakit']['sabahAlan'] = in_array( $o['vakit']['sabahAlan'], array( 'sabah', 'imsak', 'gunes' ), true ) ? $o['vakit']['sabahAlan'] : 'sabah';
	$o['vakit']['kaynakTip'] = 'diger' === $o['vakit']['kaynakTip'] ? 'diger' : 'fazilet';
	$o['vakit']['il']        = mb_substr( trim( (string) $o['vakit']['il'] ), 0, 40 );
	$o['vakit']['ilce']      = mb_substr( trim( (string) $o['vakit']['ilce'] ), 0, 40 );
	$o['serit']['metinler'] = array_values( array_filter( array_map( 'strval', (array) $o['serit']['metinler'] ), 'strlen' ) );
	$o['serit']['akici']    = empty( $o['serit']['akici'] ) ? 0 : 1;
	$h                 = array();
	$o                 = sides_tv_gorunum_temiz( $o, $h );   // v7.2 arka plan, LGS seçenekleri, şerit seçenekleri (ekrana giderken sınırlanır)   // v7.1: ekrana giderken kural dışı değerler sınırlanır ya da atılır (kayıtta 400: sides_tv_ayar_denetim)
	$o['ozelBolumler'] = sides_tv_ozel_temiz( isset( $a['ozelBolumler'] ) ? $a['ozelBolumler'] : null, $h );
	$o['basliklar']    = (object) sides_tv_basliklar_temiz( isset( $a['basliklar'] ) ? $a['basliklar'] : null, $h );
	$o['duzen']        = sides_tv_duzen_temiz( isset( $a['duzen'] ) ? $a['duzen'] : null, $o['ozelBolumler'], $h );
	if ( null === $o['duzen'] ) {   // bozuk kayıt: eski paneller/oran'dan
		$o['duzen'] = sides_tv_duzen_temiz( array( 's' => 2 ) + sides_tv_duzen_eski( $a ), array(), $h );
	}
	$o['hedef']        = sides_tv_hedef_ayar_temiz( isset( $a['hedef'] ) ? $a['hedef'] : null, $h );
	$o['hadisKonular'] = sides_tv_konular_temiz( isset( $a['hadisKonular'] ) ? $a['hadisKonular'] : null, 'Hadis-i şerif bölümü', $h );
	$o['hadisDongu']   = sides_tv_dongu( isset( $a['hadisDongu'] ) ? $a['hadisDongu'] : null, $h );
	unset( $o['hadis'] );
	return $o;
}

/* ------------------------------------------------------------------ *
 * v7.1 Sayfa düzeni, bölüm başlıkları, özel bölümler, dönen konular (haftanın hadis-i şerifi, özlü söz …) ve Hedefler bölümü
 *   duzen        { kolonlar: [ { w: 1–6, bolumler: [ { id, h: 1–6 } ] } ] (1–4 sütun, sütunda ≤ 6 bölüm), bosluk 0–3, kenar 0–3, kose 0–2, ust 0|1, serit 0|1, s: 2 }
 *                bölüm kimlikleri: sira prog hadis vakit duy hedef, özel bölümler oz_<id> (her bölüm bir kez); s = 2: hedef göçü yapıldı
 *   basliklar    { sira, prog, hadis, vakit, duy, serit, hedef } ≤ 40 karakter (hedef: Hedefler bölümünün başlığı, boşsa "Hedeflerimiz")
 *   hadisKonular [ konu ] ≤ 6, hadisDongu 5–300 sn (varsayılan 15): hadis-i şerif bölümünde içeriği olan konular sırayla döner
 *   ozelBolumler [ { id, baslik ≤ 40, dongu 5–300, konular: [ konu ] ≤ 6 } ] ≤ 6
 *   konu         { id, baslik ≤ 40, girdiler: [ { id, hafta: pazartesi 'YYYY-MM-DD' ya da '' (sabit), tur: metin|gorsel, metin ≤ 600, kaynak ≤ 120, gorsel } ] ≤ 60 }
 *                bir bölümde en çok 120 kayıt; kayıt içeriği boş olamaz; kayıt kimliği bölümde tektir
 * Aynı temizleyiciler iki kipte çalışır: $hata'ya ileti eklenirse kayıt 400 ile reddedilir; ekran çıktısında iletiler yok sayılır.
 * Göç (sides_tv_goc, istemcide tvAyarBirlestir aynı kuralla; ikisi de tekrar uygulanınca değişmez):
 *   - düzen s < 2 ise: düzende 'prog' varsa ve (eski Duyurular › Hedefler açıksa ya da prog başlığında "hedef" geçiyorsa)
 *     'prog' aynı sütun, sıra ve yükseklikte 'hedef' olur (prog kullanılmayanlara düşer); başlıkta "hedef" geçiyorsa başlık hedefe taşınır.
 *     Aksi hâlde hedef kullanılmayan bölümlerde başlar. Eski hedef ayarları (kapsam, dönem, kişi, süre, sıra, slogan) korunur; acik/yer/aralik atılır.
 *   - hadisKonular yoksa: 1. konu "Haftanın Hadis-i Şerifi" (eski hadis kayıtları olduğu gibi), 2. konu "Haftanın Özlü Sözü" (boş).
 *   - konuları olmayan eski özel bölüm: tek içeriği 1. konunun sabit kaydı olur.
 * ------------------------------------------------------------------ */
define( 'SIDES_TV_BOLUM', array( 'sira', 'prog', 'hadis', 'vakit', 'duy', 'hedef', 'kelime' ) );   // kelime: Günün Kelimeleri (includes/kelime.php), ayrı bölüm olarak yerleştirilebilir
define( 'SIDES_TV_BASLIK', array( 'sira', 'prog', 'hadis', 'vakit', 'duy', 'serit', 'hedef', 'kelime' ) );
function sides_tv_liste_mi( $L ) {
	return is_array( $L ) && ( ! $L || array_keys( $L ) === range( 0, count( $L ) - 1 ) );
}
function sides_tv_say( $v, $min, $max, $ad, &$hata ) {
	if ( ! is_int( $v ) && ! is_float( $v ) && ! ( is_string( $v ) && is_numeric( $v ) ) ) {
		$hata[] = $ad . ' sayı olmalı.';
		return null;
	}
	$v = (float) $v;
	if ( $v < $min - 0.0001 || $v > $max + 0.0001 ) {
		$hata[] = $ad . ' ' . $min . '–' . $max . ' aralığında olmalı.';
		$v = max( $min, min( $max, $v ) );
	}
	return round( $v * 20 ) / 20;
}
function sides_tv_yazi( $v, $max, $ad, &$hata, $cok_satir = false ) {
	if ( null === $v || '' === $v ) {
		return '';
	}
	if ( ! is_string( $v ) || ! mb_check_encoding( $v, 'UTF-8' ) ) {
		$hata[] = $ad . ' metin olmalı.';
		return '';
	}
	$v = trim( (string) preg_replace( $cok_satir ? '/[\x00-\x09\x0B-\x1F\x7F]/u' : '/[\x00-\x1F\x7F]/u', '', str_replace( "\r", '', $v ) ) );
	if ( mb_strlen( $v ) > $max ) {
		$hata[] = $ad . ' en çok ' . $max . ' karakter olabilir.';
		$v = rtrim( mb_substr( $v, 0, $max ) );
	}
	return $v;
}
function sides_tv_gorsel_ok( $g ) {
	return is_string( $g ) && preg_match( '/^g[a-f0-9]{16,40}$/', $g );
}
function sides_tv_pazartesi( $s ) {
	if ( ! is_string( $s ) || ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $s, $m ) || ! checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ) {
		return false;
	}
	return '1' === gmdate( 'N', gmmktime( 12, 0, 0, (int) $m[2], (int) $m[3], (int) $m[1] ) );
}
function sides_tv_basliklar_temiz( $b, &$hata ) {
	$o = array();
	if ( null === $b ) {
		return $o;
	}
	if ( ! is_array( $b ) ) {
		$hata[] = 'Bölüm başlıkları geçersiz.';
		return $o;
	}
	foreach ( $b as $k => $v ) {
		if ( ! in_array( (string) $k, SIDES_TV_BASLIK, true ) ) {
			$hata[] = 'Bilinmeyen bölüm başlığı.';
			continue;
		}
		$t = sides_tv_yazi( $v, 40, 'Bölüm başlığı', $hata );
		if ( '' !== $t ) {
			$o[ (string) $k ] = $t;
		}
	}
	return $o;
}
function sides_tv_ozel_temiz( $L, &$hata ) {
	$o   = array();
	$ids = array();
	if ( null === $L ) {
		return $o;
	}
	if ( ! sides_tv_liste_mi( $L ) ) {
		$hata[] = 'Özel bölümler liste olmalı.';
		return $o;
	}
	if ( count( $L ) > 6 ) {
		$hata[] = 'En çok 6 özel bölüm eklenebilir.';
		$L      = array_slice( $L, 0, 6 );
	}
	foreach ( $L as $x ) {
		$id = is_array( $x ) && isset( $x['id'] ) && is_string( $x['id'] ) ? $x['id'] : '';
		if ( ! preg_match( '/^[a-z0-9]{3,24}$/', $id ) || isset( $ids[ $id ] ) ) {
			$hata[] = 'Özel bölüm kimliği geçersiz.';
			continue;
		}
		$ids[ $id ] = 1;
		$o[]        = array(
			'id'      => $id,
			'baslik'  => sides_tv_yazi( isset( $x['baslik'] ) ? $x['baslik'] : '', 40, 'Bölüm başlığı', $hata ),
			'dongu'   => sides_tv_dongu( isset( $x['dongu'] ) ? $x['dongu'] : null, $hata ),
			'konular' => sides_tv_konular_temiz( isset( $x['konular'] ) ? $x['konular'] : array(), 'Özel bölüm', $hata ),
		);
	}
	return $o;
}
function sides_tv_duzen_temiz( $d, $oz, &$hata ) {
	if ( null === $d ) {
		return null;
	}
	if ( ! is_array( $d ) || ! isset( $d['kolonlar'] ) || ! sides_tv_liste_mi( $d['kolonlar'] ) || ! $d['kolonlar'] ) {
		$hata[] = 'Sayfa düzeni geçersiz.';
		return null;
	}
	$K = $d['kolonlar'];
	if ( count( $K ) > 4 ) {
		$hata[] = 'Sayfa düzeninde en çok 4 sütun olabilir.';
		$K      = array_slice( $K, 0, 4 );
	}
	$ozv = array();
	foreach ( (array) $oz as $x ) {
		$ozv[ 'oz_' . $x['id'] ] = 1;
	}
	$gor = array();
	$o   = array();
	foreach ( $K as $k ) {
		if ( ! is_array( $k ) ) {
			$hata[] = 'Sütun geçersiz.';
			continue;
		}
		$w = sides_tv_say( isset( $k['w'] ) ? $k['w'] : null, 1, 6, 'Sütun genişliği', $hata );
		$B = isset( $k['bolumler'] ) ? $k['bolumler'] : array();
		if ( ! sides_tv_liste_mi( $B ) ) {
			$hata[] = 'Sütunun bölümleri liste olmalı.';
			$B      = array();
		}
		if ( count( $B ) > 6 ) {
			$hata[] = 'Bir sütunda en çok 6 bölüm olabilir.';
			$B      = array_slice( $B, 0, 6 );
		}
		$bo = array();
		foreach ( $B as $b ) {
			$id = is_array( $b ) && isset( $b['id'] ) && is_string( $b['id'] ) ? $b['id'] : '';
			if ( ! in_array( $id, SIDES_TV_BOLUM, true ) && ! isset( $ozv[ $id ] ) ) {
				$hata[] = 'Bilinmeyen bölüm.';
				continue;
			}
			if ( isset( $gor[ $id ] ) ) {
				$hata[] = 'Bir bölüm sayfada yalnızca bir kez yer alabilir.';
				continue;
			}
			$gor[ $id ] = 1;
			$h          = sides_tv_say( isset( $b['h'] ) ? $b['h'] : null, 1, 6, 'Bölüm yüksekliği', $hata );
			$bo[]       = array( 'id' => $id, 'h' => null === $h ? 1 : $h );
		}
		$o[] = array( 'w' => null === $w ? 1 : $w, 'bolumler' => $bo );
	}
	if ( ! $o ) {
		return null;
	}
	$sy  = function ( $k, $max, $vars, $ad ) use ( $d, &$hata ) {
		if ( ! array_key_exists( $k, $d ) ) {
			return $vars;
		}
		$v = sides_tv_say( $d[ $k ], 0, $max, $ad, $hata );
		return null === $v ? $vars : $v;
	};
	$bay = function ( $k ) use ( $d, &$hata ) {
		if ( ! array_key_exists( $k, $d ) ) {
			return 1;
		}
		if ( in_array( $d[ $k ], array( 0, 1, '0', '1', true, false ), true ) ) {
			return (int) $d[ $k ];
		}
		$hata[] = 'Şerit seçimi 0 ya da 1 olmalı.';
		return 1;
	};
	$r = array( 'kolonlar' => $o, 'bosluk' => $sy( 'bosluk', 3, 0.65, 'Bölümler arası boşluk' ), 'kenar' => $sy( 'kenar', 3, 1.2, 'Kenar boşluğu' ), 'kose' => $sy( 'kose', 2, 0.7, 'Köşe yuvarlaklığı' ), 'ust' => $bay( 'ust' ), 'serit' => $bay( 'serit' ), 'cerceve' => sides_tv_cerceve_temiz( array_key_exists( 'cerceve', $d ) ? $d['cerceve'] : null, $hata ) );
	if ( array_key_exists( 's', $d ) ) {   // göç işareti (sides_tv_goc)
		if ( in_array( $d['s'], array( 1, 2, '1', '2' ), true ) ) {
			if ( 2 === (int) $d['s'] ) {
				$r['s'] = 2;
			}
		} else {
			$hata[] = 'Sayfa düzeni sürümü geçersiz.';
		}
	}
	return $r;
}
/* v7.2 Renk profilleri (src/tv.js TV_RPROFIL ile aynı anahtarlar; ilk sekizi değişmedi) */
define( 'SIDES_TV_RPROFIL', array( 'lacivert', 'gece', 'zumrut', 'bordo', 'deniz', 'mor', 'kum', 'zeytin', 'bakir', 'turkuaz', 'grafit', 'lavanta', 'cam', 'mercan', 'gul', 'kahve', 'kontrast' ) );
/* v7.2 Bölüm çerçevesi: { stil: yok|duz|noktali|kesik|cift|isik, px: 1–4, renk: profil|altin|lacivert|beyaz|gri|ozel, hex: #rrggbb, hepsi: 0|1 } (src/tv.js tvCerceveNorm ile aynı) */
function sides_tv_cerceve_temiz( $c, &$hata ) {
	$v = array( 'stil' => 'duz', 'px' => 1, 'renk' => 'profil', 'hex' => '#d4a017', 'hepsi' => 0 );
	if ( null === $c ) {
		return $v;
	}
	if ( ! is_array( $c ) || ( $c && sides_tv_liste_mi( $c ) ) ) {
		$hata[] = 'Bölüm çerçevesi ayarı geçersiz.';
		return $v;
	}
	$o = $v;
	if ( array_key_exists( 'stil', $c ) ) {
		if ( in_array( $c['stil'], array( 'yok', 'duz', 'noktali', 'kesik', 'cift', 'isik' ), true ) ) {
			$o['stil'] = $c['stil'];
		} else {
			$hata[] = 'Çerçeve stili geçersiz.';
		}
	}
	if ( array_key_exists( 'px', $c ) ) {
		if ( is_numeric( $c['px'] ) && (float) $c['px'] >= 1 && (float) $c['px'] <= 6 && (float) (int) $c['px'] === (float) $c['px'] ) {
			$o['px'] = (int) $c['px'];
		} else {
			$hata[] = 'Çerçeve kalınlığı 1–6 piksel olmalı.';
		}
	}
	if ( array_key_exists( 'renk', $c ) ) {
		if ( in_array( $c['renk'], array( 'profil', 'altin', 'lacivert', 'beyaz', 'gri', 'ozel' ), true ) ) {
			$o['renk'] = $c['renk'];
		} else {
			$hata[] = 'Çerçeve rengi geçersiz.';
		}
	}
	if ( array_key_exists( 'hex', $c ) ) {
		if ( is_string( $c['hex'] ) && preg_match( '/^#[0-9a-fA-F]{6}$/', $c['hex'] ) ) {
			$o['hex'] = strtolower( $c['hex'] );
		} else {
			$hata[] = 'Özel çerçeve rengi #rrggbb biçiminde olmalı.';
		}
	}
	if ( array_key_exists( 'hepsi', $c ) ) {
		if ( in_array( $c['hepsi'], array( 0, 1, '0', '1', true, false ), true ) ) {
			$o['hepsi'] = ( true === $c['hepsi'] || 1 === $c['hepsi'] || '1' === $c['hepsi'] ) ? 1 : 0;
		} else {
			$hata[] = 'Çerçeve "başlık ve şeride de uygula" değeri 0 ya da 1 olmalı.';
		}
	}
	return $o;
}
/* v7.2 Görünüm ve şerit seçenekleri: arka plan (tür, yoğunluk, hız), LGS geri sayımı (kart satırı, üst rozet), şerit yazı stili, renkleri, rozet, akış, animasyon,
   bekleme, kenar solması ve genişliği, ayırıcı, kayan metin animasyonu.
   $yalniz_varsa: kayıt denetiminde yalnız gönderilen alanlar incelenir (eski istemci kayıtları bozulmaz); ekran çıktısında eksikler varsayılana çekilir. */
function sides_tv_gorunum_temiz( $o, &$hata, $yalniz_varsa = false ) {
	$sec = array(
		'arkaplan'    => array( array( 'sade', 'gradyan', 'bokeh', 'geo', 'dalga', 'yildiz', 'supurme' ), 'sade', 'Arka plan seçimi geçersiz.' ),
		'arkaplanYog' => array( array( 'hafif', 'orta' ), 'orta', 'Arka plan yoğunluğu geçersiz.' ),
		'arkaplanHiz' => array( array( 'yavas', 'normal' ), 'normal', 'Arka plan hızı geçersiz.' ),
		'ustStil'     => array( array( 'kart', 'cizgi' ), 'kart', 'Üst şerit biçimi geçersiz.' ),   // v7.9.8
		'ustZemin'    => array( array( 'panel', 'lacivert', 'altin', 'koyu', 'seffaf', 'ozel' ), 'panel', 'Üst şerit zemin rengi geçersiz.' ),
		'ustEfekt'    => array( array( 'yok', 'parilti', 'gradyan', 'cam' ), 'yok', 'Üst şerit efekti geçersiz.' ),
		'ustCizgi'    => array( array( 'oto', 'altin', 'beyaz', 'lacivert' ), 'oto', 'Üst şerit çizgi rengi geçersiz.' ),
	);
	if ( array_key_exists( 'ustRenk', $o ) ) {   // v7.9.8 özel zemin rengi: #rrggbb
		if ( is_string( $o['ustRenk'] ) && preg_match( '/^#[0-9a-f]{6}$/i', $o['ustRenk'] ) ) {
			$o['ustRenk'] = strtolower( $o['ustRenk'] );
		} else {
			$hata[]        = 'Üst şerit özel rengi #rrggbb biçiminde olmalı.';
			$o['ustRenk'] = '#0f2d5c';
		}
	} elseif ( ! $yalniz_varsa ) {
		$o['ustRenk'] = '#0f2d5c';
	}
	foreach ( $sec as $k => $S ) {
		if ( array_key_exists( $k, $o ) ) {
			if ( ! in_array( $o[ $k ], $S[0], true ) ) {
				$hata[] = $S[2];
				$o[ $k ] = $S[1];
			}
		} elseif ( ! $yalniz_varsa ) {
			$o[ $k ] = $S[1];
		}
	}
	if ( array_key_exists( 'lgsTarihi', $o ) ) {   // '' = geri sayım kapalı
		$t = is_string( $o['lgsTarihi'] ) ? trim( $o['lgsTarihi'] ) : null;
		if ( null === $o['lgsTarihi'] || '' === $t ) {
			$o['lgsTarihi'] = '';
		} elseif ( null !== $t && preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $t, $m ) && checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) && (int) $m[1] >= 2024 && (int) $m[1] <= 2100 ) {
			$o['lgsTarihi'] = $t;
		} else {
			$hata[]          = 'LGS tarihi YYYY-AA-GG biçiminde geçerli bir gün olmalı.';
			$o['lgsTarihi'] = '2027-06-12';
		}
	} elseif ( ! $yalniz_varsa ) {
		$o['lgsTarihi'] = '2027-06-12';
	}
	foreach ( array( 'lgsKart' => 1, 'lgsUst' => 0 ) as $k => $vars ) {
		if ( array_key_exists( $k, $o ) ) {
			if ( in_array( $o[ $k ], array( 0, 1, '0', '1', true, false ), true ) ) {
				$o[ $k ] = ( true === $o[ $k ] || 1 === $o[ $k ] || '1' === $o[ $k ] ) ? 1 : 0;
			} else {
				$hata[]   = 'lgsKart' === $k ? 'LGS kart satırı seçimi 0 ya da 1 olmalı.' : 'LGS rozeti seçimi 0 ya da 1 olmalı.';
				$o[ $k ] = $vars;
			}
		} elseif ( ! $yalniz_varsa ) {
			$o[ $k ] = $vars;
		}
	}
	if ( ! array_key_exists( 'serit', $o ) || ! is_array( $o['serit'] ) ) {
		return $o;
	}
	$s   = &$o['serit'];
	$ssec = array(
		'yazi'     => array( 'modern', 'el', 'zarif', 'yuvarlak', 'klasik', 'duz' ),
		'rozet'    => array( 'profil', 'altin', 'lacivert', 'beyaz', 'kirmizi', 'yesil' ),
		'akis'     => array( 'kayan', 'metin' ),
		'anim'     => array( 'karisik', 'soluk', 'kay', 'yazici', 'zipla' ),
		'kenarGen' => array( 'orta', 'dar', 'genis' ),
		'ayirici'  => array( 'nokta', 'cizgi', 'yildiz', 'bosluk' ),
		'manim'    => array( 'yok', 'solarak', 'vurgulu' ),
	);
	foreach ( $ssec as $k => $L ) {
		if ( array_key_exists( $k, $s ) ) {
			if ( ! in_array( $s[ $k ], $L, true ) ) {
				$hata[]  = 'Şerit ' . $k . ' seçimi geçersiz.';
				$s[ $k ] = $L[0];
			}
		} elseif ( ! $yalniz_varsa ) {
			$s[ $k ] = $L[0];
		}
	}
	foreach ( array( 'renk', 'zemin' ) as $k ) {
		if ( array_key_exists( $k, $s ) ) {
			if ( null === $s[ $k ] || '' === $s[ $k ] ) {
				$s[ $k ] = '';
			} elseif ( is_string( $s[ $k ] ) && preg_match( '/^#[0-9a-fA-F]{6}$/', $s[ $k ] ) ) {
				$s[ $k ] = strtolower( $s[ $k ] );
			} else {
				$hata[]  = 'Şerit ' . ( 'renk' === $k ? 'yazı' : 'zemin' ) . ' rengi #rrggbb biçiminde olmalı.';
				$s[ $k ] = '';
			}
		} elseif ( ! $yalniz_varsa ) {
			$s[ $k ] = '';
		}
	}
	if ( array_key_exists( 'bekle', $s ) ) {
		if ( is_numeric( $s['bekle'] ) && (float) $s['bekle'] >= 3 && (float) $s['bekle'] <= 60 ) {
			$s['bekle'] = (int) round( (float) $s['bekle'] );
		} else {
			$hata[]     = 'Şerit bekleme süresi 3–60 saniye olmalı.';
			$s['bekle'] = 6;
		}
	} elseif ( ! $yalniz_varsa ) {
		$s['bekle'] = 6;
	}
	if ( array_key_exists( 'kenar', $s ) ) {
		if ( in_array( $s['kenar'], array( 0, 1, '0', '1', true, false ), true ) ) {
			$s['kenar'] = ( true === $s['kenar'] || 1 === $s['kenar'] || '1' === $s['kenar'] ) ? 1 : 0;
		} else {
			$hata[]     = 'Şerit kenar solması 0 ya da 1 olmalı.';
			$s['kenar'] = 1;
		}
	} elseif ( ! $yalniz_varsa ) {
		$s['kenar'] = 1;
	}
	unset( $s );
	return $o;
}
/* Bir bölüm (ör. 'hedef') temizlenmiş düzende var mı */
function sides_tv_bolum_var( $duzen, $id ) {
	foreach ( is_array( $duzen ) && isset( $duzen['kolonlar'] ) ? $duzen['kolonlar'] : array() as $k ) {
		foreach ( isset( $k['bolumler'] ) && is_array( $k['bolumler'] ) ? $k['bolumler'] : array() as $b ) {
			if ( is_array( $b ) && isset( $b['id'] ) && $id === $b['id'] ) {
				return true;
			}
		}
	}
	return false;
}
/* Sayfa düzeni olmayan eski ayar: paneller + oran + kenar (istemcide tvDuzenEski ile aynı):
   Zirvedekiler | Günlük Program (2) + Hadis-i Şerif (1) + Namaz Vakitleri (1) | Duyurular */
function sides_tv_duzen_eski( $a ) {
	$p   = array_merge( array( 'siralama' => 1, 'program' => 1, 'duyuru' => 1, 'vakit' => 1, 'serit' => 1 ), isset( $a['paneller'] ) && is_array( $a['paneller'] ) ? $a['paneller'] : array() );
	$on  = function ( $v ) {
		return is_numeric( $v ) ? (float) $v != 0 : ( true === $v );
	};
	$G   = array( 'dengeli' => array( 21, 21 ), 'siralama' => array( 28, 19 ), 'program' => array( 19, 28 ), 'duyuru' => array( 17, 17 ) );
	$gen = isset( $a['oran'] ) && is_string( $a['oran'] ) && isset( $G[ $a['oran'] ] ) ? $G[ $a['oran'] ] : $G['dengeli'];
	$snr = function ( $v, $min, $max ) {
		return round( max( $min, min( $max, $v ) ) * 20 ) / 20;
	};
	$K = array();
	if ( $on( $p['siralama'] ) ) {
		$K[] = array( 'y' => $gen[0], 'bolumler' => array( array( 'id' => 'sira', 'h' => 1 ) ) );
	}
	if ( $on( $p['program'] ) || $on( $p['vakit'] ) ) {
		$b = array();
		if ( $on( $p['program'] ) ) {
			$b[] = array( 'id' => 'prog', 'h' => 2 );
		}
		$b[] = array( 'id' => 'hadis', 'h' => 1 );
		if ( $on( $p['vakit'] ) ) {
			$b[] = array( 'id' => 'vakit', 'h' => 1 );
		}
		$K[] = array( 'y' => $gen[1], 'bolumler' => $b );
	}
	if ( $on( $p['duyuru'] ) ) {
		$K[] = array( 'y' => 0, 'bolumler' => array( array( 'id' => 'duy', 'h' => 1 ) ) );
	}
	if ( $K ) {
		$n = count( $K );
		$t = 0;
		for ( $i = 0; $i < $n - 1; $i++ ) {
			$t += $K[ $i ]['y'];
		}
		$K[ $n - 1 ]['y'] = max( 10, 100 - $t );
		$m = min( array_column( $K, 'y' ) );
		foreach ( $K as $i => $k ) {
			$K[ $i ] = array( 'w' => $snr( $k['y'] / $m, 1, 6 ), 'bolumler' => $k['bolumler'] );
		}
	}
	$kenar = isset( $a['kenar'] ) && is_numeric( $a['kenar'] ) ? (float) $a['kenar'] : 24;
	$bos = array();
	return array( 'kolonlar' => $K ? $K : array( array( 'w' => 1, 'bolumler' => array() ) ), 'bosluk' => 0.65, 'kenar' => $snr( $kenar / 20.16, 0, 3 ), 'kose' => 0.7, 'ust' => 1, 'serit' => $on( $p['serit'] ) ? 1 : 0, 'cerceve' => sides_tv_cerceve_temiz( null, $bos ) );
}
/* "hedef" geçiyor mu (Türkçe büyük/küçük harf duyarsız) */
function sides_tv_hedef_baslikli( $s ) {
	$s = str_replace( array( 'İ', 'I' ), array( 'i', 'ı' ), (string) $s );
	return false !== mb_strpos( mb_strtolower( $s, 'UTF-8' ), 'hedef' );
}
/* Göç: eski kayıtları hedef bölümüne ve konulara taşır (kurallar yukarıda). Tekrar uygulanınca sonuç değişmez. */
function sides_tv_goc( $a ) {
	if ( ! is_array( $a ) ) {
		return $a;
	}
	if ( ! array_key_exists( 'duzen', $a ) || null === $a['duzen'] ) {
		$a['duzen'] = sides_tv_duzen_eski( $a );
	}
	$d = $a['duzen'];
	if ( is_array( $d ) && isset( $d['kolonlar'] ) && is_array( $d['kolonlar'] ) && ( ! isset( $d['s'] ) || in_array( $d['s'], array( 1, '1' ), true ) ) ) {   // geçersiz işaret göçle düzeltilmez: kayıtta 400
		$h   = isset( $a['hedef'] ) && is_array( $a['hedef'] ) ? $a['hedef'] : array();
		$b   = isset( $a['basliklar'] ) && is_array( $a['basliklar'] ) ? $a['basliklar'] : array();
		$pb  = isset( $b['prog'] ) && is_string( $b['prog'] ) ? trim( $b['prog'] ) : '';
		$bh  = '' !== $pb && sides_tv_hedef_baslikli( $pb );
		$ack = isset( $h['acik'] ) && in_array( $h['acik'], array( 1, true, '1' ), true );
		if ( ( $ack || $bh ) && ! sides_tv_bolum_var( $d, 'hedef' ) ) {
			foreach ( $d['kolonlar'] as $ki => $k ) {
				foreach ( is_array( $k ) && isset( $k['bolumler'] ) && is_array( $k['bolumler'] ) ? $k['bolumler'] : array() as $bi => $x ) {
					if ( is_array( $x ) && isset( $x['id'] ) && 'prog' === $x['id'] ) {
						$d['kolonlar'][ $ki ]['bolumler'][ $bi ]['id'] = 'hedef';
						if ( $bh ) {
							$b['hedef'] = $pb;
							unset( $b['prog'] );
							$a['basliklar'] = $b;
						}
						break 2;
					}
				}
			}
		}
		$d['s']     = 2;
		$a['duzen'] = $d;
	}
	if ( isset( $a['hedef'] ) && is_array( $a['hedef'] ) ) {
		unset( $a['hedef']['acik'], $a['hedef']['yer'], $a['hedef']['aralik'] );   // Duyurular › Hedefler'den kalan seçenekler
	}
	if ( ! array_key_exists( 'hadisKonular', $a ) ) {
		$b1 = isset( $a['basliklar']['hadis'] ) && is_string( $a['basliklar']['hadis'] ) && '' !== trim( $a['basliklar']['hadis'] ) ? mb_substr( trim( $a['basliklar']['hadis'] ), 0, 40 ) : 'Haftanın Hadis-i Şerifi';
		$a['hadisKonular'] = array(
			array( 'id' => 'khadis', 'baslik' => $b1, 'girdiler' => isset( $a['hadis'] ) && is_array( $a['hadis'] ) ? $a['hadis'] : array() ),
			array( 'id' => 'kozlu', 'baslik' => 'Haftanın Özlü Sözü', 'girdiler' => array() ),
		);
	}
	unset( $a['hadis'] );
	if ( isset( $a['ozelBolumler'] ) && sides_tv_liste_mi( $a['ozelBolumler'] ) ) {
		foreach ( $a['ozelBolumler'] as $i => $x ) {
			if ( ! is_array( $x ) || array_key_exists( 'konular', $x ) ) {
				continue;
			}
			$tur  = isset( $x['tur'] ) ? $x['tur'] : 'metin';
			$g    = isset( $x['gorsel'] ) ? $x['gorsel'] : '';
			$m    = isset( $x['metin'] ) ? $x['metin'] : '';
			$dolu = 'gorsel' === $tur ? sides_tv_gorsel_ok( $g ) : ( is_string( $m ) && '' !== trim( $m ) );
			$x['konular'] = array( array( 'id' => 'kn1', 'baslik' => '', 'girdiler' => $dolu ? array( array( 'id' => 'gn1', 'hafta' => '', 'tur' => $tur, 'metin' => $m, 'kaynak' => '', 'gorsel' => $g ) ) : array() ) );
			unset( $x['tur'], $x['metin'], $x['gorsel'] );
			$a['ozelBolumler'][ $i ] = $x;
		}
	}
	return $a;
}
function sides_tv_dongu( $v, &$hata ) {
	if ( null === $v ) {
		return 15;
	}
	$n = sides_tv_say( $v, 5, 300, 'Konu dönme süresi (saniye)', $hata );
	return null === $n ? 15 : (int) round( $n );
}
/* Bir konunun kayıtları ($ids: bölüm genelinde kimlik tekliği) */
function sides_tv_girdiler_temiz( $L, $ad, &$hata, &$ids ) {
	$o = array();
	if ( null === $L ) {
		return $o;
	}
	if ( ! sides_tv_liste_mi( $L ) ) {
		$hata[] = $ad . ': kayıtlar liste olmalı.';
		return $o;
	}
	if ( count( $L ) > 60 ) {
		$hata[] = $ad . ': bir konuda en çok 60 kayıt tutulabilir.';
		$L      = array_slice( $L, 0, 60 );
	}
	foreach ( $L as $i => $x ) {
		$n  = $ad . ', ' . ( $i + 1 ) . '. kayıt';
		$id = is_array( $x ) && isset( $x['id'] ) && is_string( $x['id'] ) ? $x['id'] : '';
		if ( ! preg_match( '/^[a-z0-9]{3,24}$/', $id ) || isset( $ids[ $id ] ) ) {
			$hata[] = $n . ': kimlik geçersiz.';
			continue;
		}
		$hafta = isset( $x['hafta'] ) && null !== $x['hafta'] ? $x['hafta'] : '';
		if ( '' !== $hafta && ! sides_tv_pazartesi( $hafta ) ) {
			$hata[] = $n . ': hafta, bir pazartesi tarihi (YYYY-AA-GG) ya da boş (her hafta) olmalı.';
			continue;
		}
		$tur = isset( $x['tur'] ) ? $x['tur'] : 'metin';
		if ( ! in_array( $tur, array( 'metin', 'gorsel' ), true ) ) {
			$hata[] = $n . ': tür yazı ya da görsel olmalı.';
			continue;
		}
		$g = isset( $x['gorsel'] ) ? $x['gorsel'] : '';
		if ( '' !== $g && null !== $g && ! sides_tv_gorsel_ok( $g ) ) {
			$hata[] = $n . ': görsel kimliği geçersiz.';
			$g      = '';
		}
		$m = sides_tv_yazi( isset( $x['metin'] ) ? $x['metin'] : '', 600, $n . ' metni', $hata, true );
		if ( ( 'gorsel' === $tur && ! sides_tv_gorsel_ok( $g ) ) || ( 'metin' === $tur && '' === $m ) ) {
			$hata[] = $n . ': içerik boş.';
			continue;
		}
		$ids[ $id ] = 1;
		$olcek = isset( $x['olcek'] ) && is_numeric( $x['olcek'] ) ? max( 100, min( 300, (int) round( (float) $x['olcek'] ) ) ) : 100;   // v7.9.12 görsel büyütme, sığdırma, odak
		$kirp  = isset( $x['kirp'] ) && 'doldur' === $x['kirp'] ? 'doldur' : 'sigdir';
		$odak  = isset( $x['odak'] ) && in_array( $x['odak'], array( 'orta', 'ust', 'alt', 'sol', 'sag' ), true ) ? $x['odak'] : 'orta';
		$o[]        = array( 'id' => $id, 'hafta' => $hafta, 'tur' => $tur, 'metin' => $m, 'kaynak' => sides_tv_yazi( isset( $x['kaynak'] ) ? $x['kaynak'] : '', 120, $n . ' kaynağı', $hata ), 'gorsel' => sides_tv_gorsel_ok( $g ) ? $g : '', 'olcek' => $olcek, 'kirp' => $kirp, 'odak' => $odak );
	}
	return $o;
}
/* Bir bölümün konuları: ≤ 6 konu, konu başına ≤ 60, bölümde ≤ 120 kayıt */
function sides_tv_konular_temiz( $L, $ad, &$hata ) {
	$o   = array();
	$ids = array();
	$gid = array();
	$top = 0;
	if ( null === $L ) {
		return $o;
	}
	if ( ! sides_tv_liste_mi( $L ) ) {
		$hata[] = $ad . ': konular liste olmalı.';
		return $o;
	}
	if ( count( $L ) > 6 ) {
		$hata[] = $ad . ': en çok 6 konu eklenebilir.';
		$L      = array_slice( $L, 0, 6 );
	}
	foreach ( $L as $i => $k ) {
		$n  = $ad . ' › ' . ( $i + 1 ) . '. konu';
		$id = is_array( $k ) && isset( $k['id'] ) && is_string( $k['id'] ) ? $k['id'] : '';
		if ( ! preg_match( '/^[a-z0-9]{3,24}$/', $id ) || isset( $ids[ $id ] ) ) {
			$hata[] = $n . ': kimlik geçersiz.';
			continue;
		}
		$ids[ $id ] = 1;
		$G          = sides_tv_girdiler_temiz( isset( $k['girdiler'] ) ? $k['girdiler'] : array(), $n, $hata, $gid );
		$top       += count( $G );
		$o[]        = array( 'id' => $id, 'baslik' => sides_tv_yazi( isset( $k['baslik'] ) ? $k['baslik'] : '', 40, $n . ' başlığı', $hata ), 'girdiler' => $G );
	}
	if ( $top > 120 ) {
		$hata[] = $ad . ': bir bölümde en çok 120 kayıt tutulabilir.';
	}
	return $o;
}
/* Panoya giden kayıtlar (konu başına): sabit kayıtlar + bu haftanın en son tarihli kaydından gelecek haftaya kadar olanlar.
   İstemcideki seçim (tvHadisSec) bu altkümeyle bu hafta ve gelecek hafta için tam listeyle aynı sonucu verir. */
function sides_tv_hafta_suz( $L, DateTime $now ) {
	$pzt   = ( clone $now )->modify( '-' . ( (int) $now->format( 'N' ) - 1 ) . ' days' )->format( 'Y-m-d' );
	$ileri = ( clone $now )->modify( '+' . ( 8 - (int) $now->format( 'N' ) ) . ' days' )->format( 'Y-m-d' );
	$son   = '';
	foreach ( $L as $x ) {
		if ( '' !== $x['hafta'] && $x['hafta'] <= $pzt && $x['hafta'] > $son ) {
			$son = $x['hafta'];
		}
	}
	$alt = $son ? $son : $pzt;
	return array_values( array_filter( $L, function ( $x ) use ( $alt, $ileri ) {
		return '' === $x['hafta'] || ( $x['hafta'] >= $alt && $x['hafta'] <= $ileri );
	} ) );
}
function sides_tv_konu_pano( $K, DateTime $now ) {
	return array_map( function ( $k ) use ( $now ) {
		$k['girdiler'] = sides_tv_hafta_suz( $k['girdiler'], $now );
		return $k;
	}, is_array( $K ) ? $K : array() );
}
/* Kayıt (PUT /doc/tv/ayar): yeni alanlar sıkı denetlenir; kural dışı değer 400 ile reddedilir, geçerli olanlar biçimlendirilerek saklanır. */
function sides_tv_ayar_denetim( $org, $d ) {
	$hata = array();
	$d    = sides_tv_goc( $d );   // eski biçimde gelen kayıt (eski sekme) da yeni biçimde saklanır
	$oz   = sides_tv_ozel_temiz( array_key_exists( 'ozelBolumler', $d ) ? $d['ozelBolumler'] : null, $hata );
	if ( array_key_exists( 'ozelBolumler', $d ) ) {
		$d['ozelBolumler'] = $oz;
	}
	if ( array_key_exists( 'basliklar', $d ) ) {
		$d['basliklar'] = (object) sides_tv_basliklar_temiz( $d['basliklar'], $hata );
	}
	$d['hadisKonular'] = sides_tv_konular_temiz( $d['hadisKonular'], 'Hadis-i şerif bölümü', $hata );
	if ( array_key_exists( 'hadisDongu', $d ) ) {
		$d['hadisDongu'] = sides_tv_dongu( $d['hadisDongu'], $hata );
	}
	$d['duzen'] = sides_tv_duzen_temiz( $d['duzen'], $oz, $hata );
	$d          = sides_tv_gorunum_temiz( $d, $hata, true );   // v7.2: yalnız gönderilen alanlar denetlenir; kural dışı değer 400
	if ( array_key_exists( 'gerisayim', $d ) ) {   // v7.6
		$d['gerisayim'] = sides_tv_gs_temiz( $d['gerisayim'], $hata );
	}
	if ( array_key_exists( 'hedef', $d ) ) {
		$d['hedef'] = sides_tv_hedef_ayar_temiz( $d['hedef'], $hata );
		if ( 'secili' === $d['hedef']['kapsam'] && ! $d['hedef']['siniflar'] && sides_tv_bolum_var( $d['duzen'], 'hedef' ) ) {
			$hata[] = 'Hedefler bölümü için en az bir sınıf ya da şube seçin.';
		}
	}
	if ( ! $hata ) {   // görseller bu kurumun görsel kayıtlarından olmalı (duyuru görselleri gibi tv/<token>/gorsel/<id> ile sunulur)
		$gs = array();
		$KK = array( $d['hadisKonular'] );
		foreach ( $oz as $x ) {
			$KK[] = $x['konular'];
		}
		foreach ( $KK as $K ) {
			foreach ( $K as $k ) {
				foreach ( $k['girdiler'] as $x ) {
					if ( ! empty( $x['gorsel'] ) ) {
						$gs[ $x['gorsel'] ] = 1;
					}
				}
			}
		}
		if ( $gs ) {
			global $wpdb;
			$t   = sides_docs();
			$ids = array_keys( $gs );
			$var = $wpdb->get_col( $wpdb->prepare( "SELECT id FROM $t WHERE org = %d AND coll = 'gorsel' AND id IN (" . implode( ',', array_fill( 0, count( $ids ), '%s' ) ) . ')', array_merge( array( (int) $org ), $ids ) ) ); // phpcs:ignore
			if ( count( array_unique( $var ) ) !== count( $ids ) ) {
				$hata[] = 'Seçilen görsel bulunamadı; görseli yeniden yükleyin.';
			}
		}
	}
	if ( $hata ) {
		return new WP_Error( 'sides_gecersiz', 'Ekran ayarları kaydedilemedi: ' . implode( ' ', array_slice( array_values( array_unique( $hata ) ), 0, 3 ) ), array( 'status' => 400 ) );
	}
	return $d;
}
add_filter( 'rest_request_before_callbacks', function ( $res, $handler, $req ) {
	/* v7.3.1: ekran ayarları kurum genelidir; sınıf kısıtlı kullanıcı değiştiremez ya da silemez */
	if ( ! is_wp_error( $res ) && in_array( $req->get_method(), array( 'PUT', 'POST', 'DELETE' ), true ) && '/optik-karne/v1/doc/tv/ayar' === (string) $req->get_route() && function_exists( 'sides_sinif_kisit' ) && null !== sides_sinif_kisit() ) {
		return sides_deny( 'TV ekran ayarları kurum genelidir; sınıf kısıtlı hesap değiştiremez.' );
	}
	if ( is_wp_error( $res ) || ! in_array( $req->get_method(), array( 'PUT', 'POST' ), true ) || '/optik-karne/v1/doc/tv/ayar' !== (string) $req->get_route() ) {
		return $res;
	}
	if ( ( function_exists( 'sides_is_observer' ) && sides_is_observer() ) || ! sides_can( 'puan', 2 ) ) {
		return $res;   // yetkisizlik rotanın kendi izin denetiminde (403) yanıtlanır
	}
	$d = json_decode( $req->get_body(), true );
	if ( ! is_array( $d ) ) {
		return $res;
	}
	$d = sides_tv_ayar_denetim( sides_org_id(), $d );
	if ( is_wp_error( $d ) ) {
		return $d;
	}
	$req->set_body( wp_json_encode( $d, JSON_UNESCAPED_UNICODE ) );
	return $res;
}, 10, 3 );
/* Puan dönemi aralığı (istemcideki puanAralik ile aynı kurallar; hafta Pazartesi–Pazar, Europe/Istanbul) */
function sides_tv_aralik( $tip, $ozel, $tz ) {
	if ( 'gun' === $tip ) {
		$tip = '1h';   // v6.0.4: TV'de günlük puan gösterilmez; eski 'Bugün' ayarı bu haftaya döner
	}
	try {
		$zone = new DateTimeZone( $tz ? $tz : 'Europe/Istanbul' );
	} catch ( Exception $e ) {
		$zone = new DateTimeZone( 'Europe/Istanbul' );
	}
	$now  = new DateTime( 'now', $zone );
	$ref  = $now->format( 'Y-m-d' );
	$gun  = function ( $n, $taban ) use ( $zone ) {
		$d = new DateTime( $taban . ' 12:00:00', $zone );
		$d->modify( ( $n >= 0 ? '+' : '' ) . $n . ' days' );
		return $d->format( 'Y-m-d' );
	};
	$hb   = $gun( -( ( (int) $now->format( 'N' ) ) - 1 ), $ref );   // Pazartesi
	$hs   = $gun( 6, $hb );
	$ayB  = substr( $ref, 0, 7 ) . '-01';
	$ayS  = $now->format( 'Y-m-t' );
	$ayGeri = function ( $n ) use ( $now, $zone ) {
		$d = new DateTime( $now->format( 'Y-m-01' ) . ' 12:00:00', $zone );
		$d->modify( '-' . $n . ' months' );
		return $d->format( 'Y-m-01' );
	};
	switch ( $tip ) {
		case 'gun':   return array( 'bas' => $ref, 'bit' => $ref, 'ad' => date( 'd.m.Y', strtotime( $ref ) ) );
		case '2h':    return array( 'bas' => $gun( -7, $hb ), 'bit' => $hs, 'ad' => 'Son 2 hafta' );
		case '3h':    return array( 'bas' => $gun( -14, $hb ), 'bit' => $hs, 'ad' => 'Son 3 hafta' );
		case '1a':    return array( 'bas' => $ayB, 'bit' => $ayS, 'ad' => 'Bu ay' );
		case '2a':    return array( 'bas' => $ayGeri( 1 ), 'bit' => $ayS, 'ad' => 'Son 2 ay' );
		case '3a':    return array( 'bas' => $ayGeri( 2 ), 'bit' => $ayS, 'ad' => 'Son 3 ay' );
		case 'son14': return array( 'bas' => $gun( -13, $ref ), 'bit' => $ref, 'ad' => 'Son 14 gün' );
		case 'son30': return array( 'bas' => $gun( -29, $ref ), 'bit' => $ref, 'ad' => 'Son 30 gün' );
		case 'son60': return array( 'bas' => $gun( -59, $ref ), 'bit' => $ref, 'ad' => 'Son 60 gün' );
		case 'son90': return array( 'bas' => $gun( -89, $ref ), 'bit' => $ref, 'ad' => 'Son 90 gün' );
		case 'ozel':
			$b = isset( $ozel['bas'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $ozel['bas'] ) ? $ozel['bas'] : $ref;
			$e = isset( $ozel['bit'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', $ozel['bit'] ) ? $ozel['bit'] : $ref;
			return array( 'bas' => $b, 'bit' => $e, 'ad' => date( 'd.m.Y', strtotime( $b ) ) . ' – ' . date( 'd.m.Y', strtotime( $e ) ) );
		default:      return array( 'bas' => $hb, 'bit' => $hs, 'ad' => 'Bu hafta' );
	}
}
/* Gizlilik biçimine göre görünen ad */
function sides_tv_ad( $s, $bicim ) {
	$ad = trim( (string) ( isset( $s['ad'] ) ? $s['ad'] : '' ) );
	$w  = preg_split( '/\s+/u', $ad );
	$w  = array_values( array_filter( $w, 'strlen' ) );
	if ( 'takma' === $bicim ) {
		$t = isset( $s['takma'] ) ? trim( (string) $s['takma'] ) : '';
		if ( '' !== $t ) {
			return $t;
		}
		$o = '';
		foreach ( $w as $x ) {
			$o .= mb_strtoupper( mb_substr( $x, 0, 1 ), 'UTF-8' ) . '.';
		}
		return $o;
	}
	if ( 'adbas' === $bicim && count( $w ) > 1 ) {
		$son = array_pop( $w );
		return implode( ' ', $w ) . ' ' . mb_strtoupper( mb_substr( $son, 0, 1 ), 'UTF-8' ) . '.';
	}
	return $ad;
}
function sides_tv_saat( $v ) {
	$v = trim( (string) $v );
	return preg_match( '/^([01]?\d|2[0-3]):[0-5]\d$/', $v ) ? ( strlen( $v ) === 4 ? '0' . $v : $v ) : '';
}

/* v6.0.2 Anlık yenileme: TV birkaç saniyede bir yalnızca bu küçük "sürüm" değerini sorar; panoyu etkileyen bir kayıt
   eklendiğinde, değiştiğinde ya da silindiğinde değer değişir ve TV tam veriyi hemen yeniden ister (sayfa yenilenmez). */
function sides_tv_surum( $org ) {
	global $wpdb;
	$t = sides_docs();
	$r = $wpdb->get_row( $wpdb->prepare( "SELECT COUNT(*) AS n, MAX(updated_at) AS m FROM $t WHERE org = %d AND coll IN ('tv','settings','students','pgun','phareket','pkriter','podul','animasyon','gorsel','sistem','hedef','lgs','hsablon','kelime')", $org ) ); // phpcs:ignore
	$b = get_option( 'sides_bakim_orgs' );
	return substr( md5( ( $r ? $r->n . '|' . $r->m : '' ) . '|' . wp_json_encode( is_array( $b ) && isset( $b[ $org ] ) ? $b[ $org ] : null ) . '|' . OPTIK_KARNE_VER ), 0, 16 );
}
/* Hiçbir önbellek (tarayıcı, LiteSpeed, Cloudflare vb.) pano yanıtlarını saklamasın */
function sides_tv_onbelleksiz( $res ) {
	if ( function_exists( 'nocache_headers' ) ) {
		nocache_headers();
	}
	do_action( 'litespeed_control_set_nocache', 'ATLAS TV panosu canlı veri' );
	foreach ( array( 'Cache-Control' => 'no-store, no-cache, must-revalidate, max-age=0', 'Pragma' => 'no-cache', 'Expires' => '0', 'X-LiteSpeed-Cache-Control' => 'no-cache', 'CDN-Cache-Control' => 'no-store', 'Surrogate-Control' => 'no-store' ) as $h => $v ) {
		$res->header( $h, $v );
	}
	return $res;
}
function sides_tv_surum_oku( WP_REST_Request $req ) {
	if ( function_exists( 'sides_tko_rl' ) && ! sides_tko_rl( 'tvs|' . ( isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '' ), 6000, 600 ) ) {
		return sides_tv_onbelleksiz( rest_convert_error_to_response( new WP_Error( 'sides_rl', 'Çok fazla istek.', array( 'status' => 429 ) ) ) );
	}
	$org = sides_tv_bul( (string) $req['token'] );
	if ( ! $org ) {
		return sides_tv_onbelleksiz( rest_convert_error_to_response( new WP_Error( 'sides_yok', 'Bağlantı geçersiz ya da iptal edilmiş.', array( 'status' => 404 ) ) ) );
	}
	return sides_tv_onbelleksiz( rest_ensure_response( array( 's' => sides_tv_surum( $org ) ) ) );
}

/* ------------------------------------------------------------------ *
 * Ekran verisi
 * ------------------------------------------------------------------ */
/* v7.8 Yönetim önizlemesi (Puan › TV Ekranı ve Ekran Ayarları içindeki çerçeve): TV beklemedeyken de gerçek pano.
   Hepsi gerekir: ?oniz=1, WordPress oturumu (REST çerez doğrulaması yalnız geçerli X-WP-Nonce ile kullanıcıyı tanır; nonce'suz istekte
   kullanıcı 0'dır), belirtecin kurumu = kullanıcının kurumu, TV yönetim yetkisi (tv/link ile aynı: puan ≥ 2, gözlemci ve sınıf kısıtlı değil).
   Sistem kapalıysa yalnız kurum yöneticisi / ana hesap (diğerleri zaten çalışamaz). Belirteç tek başına beklemeyi aşamaz. */
function sides_tv_oniz_yetki( WP_REST_Request $req, $org ) {
	if ( '1' !== (string) $req->get_param( 'oniz' ) || ! is_user_logged_in() || ! function_exists( 'sides_ctx' ) ) {
		return false;
	}
	$c = sides_ctx();
	if ( ! $c['org'] || (int) $c['org'] !== (int) $org || 'gozlemci' === $c['rol'] || ! sides_can( 'puan', 2 ) ) {
		return false;
	}
	if ( function_exists( 'sides_sinif_kisit' ) && null !== sides_sinif_kisit() ) {
		return false;
	}
	if ( function_exists( 'sides_bakim_kapali' ) && sides_bakim_kapali( $org ) && 'yonetici' !== $c['rol'] && ! ( function_exists( 'sides_is_super' ) && sides_is_super() ) ) {
		return false;
	}
	return true;
}
function sides_tv_oku( WP_REST_Request $req ) {
	global $wpdb;
	if ( ! sides_rl( 'tv_oku', 900, 600 ) ) {
		return sides_tv_onbelleksiz( rest_convert_error_to_response( new WP_Error( 'sides_rl', 'Çok fazla istek. Biraz sonra tekrar deneyin.', array( 'status' => 429 ) ) ) );
	}
	$org = sides_tv_bul( (string) $req['token'] );
	if ( ! $org ) {
		return sides_tv_onbelleksiz( rest_convert_error_to_response( new WP_Error( 'sides_yok', 'Bağlantı geçersiz ya da iptal edilmiş.', array( 'status' => 404 ) ) ) );
	}
	$oniz = sides_tv_oniz_yetki( $req, $org );   // v7.8: yetkili yönetim önizlemesi beklemede de gerçek panoyu görür
	if ( ! $oniz && function_exists( 'sides_bakim_tv_yanit' ) && ( $bk = sides_bakim_tv_yanit( $org ) ) ) {
		return sides_tv_onbelleksiz( $bk );   // v6 R09: TV bekleme ekranı — yalnızca mesaj, kurum adı/logosu ve saat bilgisi gider (includes/bakim.php); v7.1.3: LiteSpeed/CDN de saklamasın
	}
	$t     = sides_docs();
	$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = 'tv' AND id <> 'link' ORDER BY id", $org ) ); // phpcs:ignore
	$ayarH = null;
	$prog  = null;
	$duy   = array();
	$vakit = array();
	$tz    = 'Europe/Istanbul';
	foreach ( $rows as $r ) {
		$d = json_decode( $r->data, true );
		if ( ! is_array( $d ) ) {
			continue;
		}
		if ( 'ayar' === $r->id ) {
			$ayarH = $d;
		} elseif ( 'program' === $r->id ) {
			$prog = $d;
		} elseif ( 0 === strpos( $r->id, 'duyuru_' ) ) {
			$d['id'] = substr( $r->id, 7 );
			$duy[]   = $d;
		} elseif ( preg_match( '/^vakit_(\d{4}-\d{2})$/', $r->id, $m ) ) {
			$vakit[ $m[1] ] = $d;
		}
	}
	$ayar = sides_tv_ayar_disari( $ayarH );
	try {
		$zone = new DateTimeZone( $ayar['vakit']['tz'] );
		$tz   = $ayar['vakit']['tz'];
	} catch ( Exception $e ) {
		$zone = new DateTimeZone( 'Europe/Istanbul' );
		$ayar['vakit']['tz'] = 'Europe/Istanbul';
	}
	$now   = new DateTime( 'now', $zone );
	/* Dönen konular: her konunun yalnızca bu ve gelecek haftayı belirleyen kayıtları gider */
	$ayar['hadisKonular'] = sides_tv_konu_pano( $ayar['hadisKonular'], $now );
	foreach ( $ayar['ozelBolumler'] as $i => $x ) {
		$ayar['ozelBolumler'][ $i ]['konular'] = sides_tv_konu_pano( $x['konular'], $now );
	}
	$simdi = $now->format( 'Y-m-d\TH:i:s' );

	/* Program: yalnızca doğrulanmış alanlar */
	$gunler = array();
	for ( $g = 1; $g <= 7; $g++ ) {
		$l = $prog && isset( $prog['gunler'][ $g ] ) && is_array( $prog['gunler'][ $g ] ) ? $prog['gunler'][ $g ] : array();
		$o = array();
		foreach ( $l as $x ) {
			if ( ! is_array( $x ) ) {
				continue;
			}
			$bas = sides_tv_saat( isset( $x['bas'] ) ? $x['bas'] : '' );
			$bit = sides_tv_saat( isset( $x['bit'] ) ? $x['bit'] : '' );
			if ( ! $bas ) {
				continue;
			}
			$kat = isset( $x['kat'] ) && in_array( $x['kat'], SIDES_TV_KATEGORI, true ) ? $x['kat'] : 'diger';
			$o[] = array( 'bas' => $bas, 'bit' => $bit, 'ad' => mb_substr( (string) ( isset( $x['ad'] ) ? $x['ad'] : '' ), 0, 80 ), 'kat' => $kat );
		}
		usort( $o, function ( $a, $b ) { return strcmp( $a['bas'], $b['bas'] ); } );
		$gunler[ (string) $g ] = $o;
	}

	/* Duyurular: yalnızca şu an yayında olanlar */
	$aktif = array();
	foreach ( $duy as $d ) {
		if ( isset( $d['aktif'] ) && ! $d['aktif'] ) {
			continue;
		}
		$bas = isset( $d['bas'] ) ? (string) $d['bas'] : '';
		$bit = isset( $d['bit'] ) ? (string) $d['bit'] : '';
		if ( ( $bas && $bas > $simdi ) || ( $bit && $bit < $simdi ) ) {
			continue;
		}
		$tip = isset( $d['tip'] ) && in_array( $d['tip'], array( 'metin', 'gorsel', 'video' ), true ) ? $d['tip'] : 'metin';
		$vid = 'video' === $tip && isset( $d['video'] ) && preg_match( '#^https?://#i', (string) $d['video'] ) ? esc_url_raw( (string) $d['video'] ) : '';
		$aktif[] = array(
			'id' => (string) $d['id'], 'tip' => $tip,
			'baslik' => mb_substr( (string) ( isset( $d['baslik'] ) ? $d['baslik'] : '' ), 0, 120 ),
			'aciklama' => mb_substr( (string) ( isset( $d['aciklama'] ) ? $d['aciklama'] : '' ), 0, 2000 ),
			'g' => 'gorsel' === $tip && isset( $d['g'] ) && preg_match( '/^g[a-f0-9]{16,40}$/', (string) $d['g'] ) ? (string) $d['g'] : '',
			'video' => $vid,
			'oncelik' => max( 1, min( 5, (int) ( isset( $d['oncelik'] ) ? $d['oncelik'] : 3 ) ) ),
			'sure' => max( 4, min( 300, (int) ( isset( $d['sure'] ) ? $d['sure'] : $ayar['duyuruSure'] ) ) ),
			'bit' => $bit,
			'takvim' => ! empty( $d['takvim'] ) ? 1 : 0,   /* v7.9.3 günlük takvim yaprağı (yalnız görsel) */
		);
	}
	if ( ! empty( $ayar['sistemDuyuru'] ) ) {   // sistem duyuruları (kontrol paneli): metin kartı olarak
		$sr = $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = 'duyurular' ORDER BY updated_at DESC LIMIT 10", $org ) ); // phpcs:ignore
		foreach ( $sr as $r ) {
			$d = json_decode( $r->data, true );
			if ( is_array( $d ) && ! empty( $d['baslik'] ) ) {
				// v5.5: pasif, henüz başlamamış ya da süresi bitmiş duyurular panoda gösterilmez (kontrol paneliyle aynı kural)
				$bugun = $now->format( 'Y-m-d' );
				if ( ( isset( $d['aktif'] ) && false === $d['aktif'] ) || ( ! empty( $d['bas'] ) && (string) $d['bas'] > $bugun ) || ( ! empty( $d['bit'] ) && (string) $d['bit'] < $bugun ) ) {
					continue;
				}
				$aktif[] = array( 'id' => 's_' . $r->id, 'tip' => 'metin', 'baslik' => mb_substr( (string) $d['baslik'], 0, 120 ), 'aciklama' => mb_substr( (string) ( isset( $d['metin'] ) ? $d['metin'] : '' ), 0, 2000 ), 'g' => '', 'video' => '', 'oncelik' => 2, 'sure' => (int) $ayar['duyuruSure'], 'bit' => '' );
			}
		}
	}
	usort( $aktif, function ( $a, $b ) { return ( $b['oncelik'] - $a['oncelik'] ) ?: strcmp( $a['id'], $b['id'] ); } );

	/* Namaz vakitleri: bu ay ve gelecek ay; alanlar HH:MM olarak doğrulanır */
	$aylar = array( $now->format( 'Y-m' ), ( clone $now )->modify( 'first day of next month' )->format( 'Y-m' ) );
	$vk    = array();
	foreach ( $aylar as $ay ) {
		if ( ! isset( $vakit[ $ay ] ) ) {
			continue;
		}
		$v = $vakit[ $ay ];
		$g = array();
		foreach ( isset( $v['gunler'] ) && is_array( $v['gunler'] ) ? $v['gunler'] : array() as $tarih => $x ) {
			if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $tarih ) || ! is_array( $x ) ) {
				continue;
			}
			$s = array();
			foreach ( SIDES_TV_VAKIT_ALAN as $k ) {
				$s[ $k ] = sides_tv_saat( isset( $x[ $k ] ) ? $x[ $k ] : '' );
			}
			$g[ $tarih ] = $s;
		}
		$vk[ $ay ] = array( 'kaynak' => mb_substr( (string) ( isset( $v['kaynak'] ) ? $v['kaynak'] : '' ), 0, 80 ), 'veriTarihi' => isset( $v['veriTarihi'] ) ? (string) $v['veriTarihi'] : '', 'gunler' => (object) $g );
	}

	/* Sıralama: puan motoru (includes/puan.php) varsa gün kayıtları; ad yalnızca seçili gizlilik biçimiyle */
	$set    = sides_get_doc( $org, 'settings', 'main' );
	$pa     = function_exists( 'sides_puan_ayar' ) ? sides_puan_ayar( $org ) : ( $set && isset( $set['puan'] ) && is_array( $set['puan'] ) ? $set['puan'] : array() );
	$puanAyar = array(
		'baslangic' => isset( $pa['baslangic'] ) ? (float) $pa['baslangic'] : 100,
		'yontem'    => 'haftalik',   // v6.0.4: ekrana yansıyan puan her zaman haftalık (700 üzerinden ÷ 7)
		'ondalik'   => isset( $pa['ondalik'] ) ? max( 0, min( 3, (int) $pa['ondalik'] ) ) : 2,
	);
	$donem  = sides_tv_aralik( $ayar['donem'], $ayar['ozel'], $tz );
	$gun    = array();
	if ( function_exists( 'sides_puan_gunler' ) ) {
		$ham = sides_puan_gunler( $org, $donem['bas'], $donem['bit'] );
		foreach ( is_array( $ham ) ? $ham : array() as $x ) {
			$x = (array) $x;
			$sid = isset( $x['sid'] ) ? (string) $x['sid'] : ( isset( $x['studentId'] ) ? (string) $x['studentId'] : '' );
			if ( ! $sid ) {
				continue;
			}
			$gun[] = array( 'sid' => $sid, 'tarih' => isset( $x['tarih'] ) ? substr( (string) $x['tarih'], 0, 10 ) : '', 'durum' => isset( $x['durum'] ) ? (string) $x['durum'] : 'taslak', 'etki' => isset( $x['etki'] ) ? (float) $x['etki'] : 0 );
		}
	}
	$ogr   = array();
	$ids   = array();
	foreach ( $gun as $x ) {
		$ids[ $x['sid'] ] = 1;
	}
	if ( $ids ) {
		$neh_ayri = function_exists( 'sides_nehari_ayri' ) ? sides_nehari_ayri( $org ) : false;
		$srows = $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = 'students'", $org ) ); // phpcs:ignore
		foreach ( $srows as $r ) {
			if ( ! isset( $ids[ $r->id ] ) ) {
				continue;
			}
			$s = json_decode( $r->data, true );
			if ( ! is_array( $s ) ) {
				continue;
			}
			if ( $neh_ayri && sides_nehari_sinifi( isset( $s['sinif'] ) ? $s['sinif'] : '' ) ) {
				continue;   // Nehari öğrencileri panoda listelenmez (Parametreler'den açılabilir)
			}
			$o = array( 'id' => (string) $r->id, 'ad' => sides_tv_ad( $s, $ayar['gizlilik'] ), 'sinif' => (string) ( isset( $s['sinif'] ) ? $s['sinif'] : '' ), 'sube' => (string) ( isset( $s['sube'] ) ? $s['sube'] : '' ) );
			if ( ! empty( $ayar['foto'] ) && isset( $s['foto'] ) && preg_match( '/^g[a-f0-9]{16,40}$/', (string) $s['foto'] ) ) {
				$o['foto'] = (string) $s['foto'];
			}
			$ogr[] = $o;
		}
	}
	/* Yalnızca listelenen öğrencilerin gün kayıtları gider: Nehari (ya da silinmiş) öğrencinin günleri panoda adsız satır oluşturmasın, kimliği de dışarı çıkmasın */
	$izinli = array_flip( array_column( $ogr, 'id' ) );
	$gun    = array_values( array_filter( $gun, function ( $x ) use ( $izinli ) { return isset( $izinli[ $x['sid'] ] ); } ) );

	$out = array(
		'kurum'     => array( 'ad' => $set && isset( $set['kurum'] ) ? (string) $set['kurum'] : '', 'logo' => $set && isset( $set['logo'] ) ? (string) $set['logo'] : '', 'slogan' => (string) $ayar['slogan'] ),
		'ayar'      => $ayar,
		'program'   => $gunler,
		'duyurular' => $aktif,
		'vakitler'  => (object) $vk,
		'siralama'  => array( 'ogrenciler' => $ogr, 'gunler' => $gun ),
		'puanAyar'  => $puanAyar,
		'donem'     => $donem,
		'motor'     => function_exists( 'sides_puan_gunler' ),
		'hayvan'    => sides_tv_hayvan( $org ),
	);
	$lm               = sides_tv_lgs_tarih( $set );   // v7.2 geçerli LGS tarihi: LGS Modülü önce, yoksa pano ayarı (kartlar ve üst rozet)
	$out['lgsKaynak'] = '' !== $lm ? 'modul' : 'ayar';
	$out['lgsTarih']  = '' !== $lm ? $lm : (string) $ayar['lgsTarihi'];
	if ( sides_tv_bolum_var( $ayar['duzen'], 'hedef' ) ) {   // Hedefler bölümü: yalnızca düzendeyken; ad gizlilik biçimiyle, öğrenci kimliği ve iç notlar gönderilmez
		$out['hedefler'] = sides_tv_hedef_veri( $org, $ayar['hedef'], $ayar['gizlilik'], ! empty( $ayar['foto'] ), $set );
	}
	if ( function_exists( 'sides_kelime_pano' ) && ( $kl = sides_kelime_pano( $org, $ayarH, $now ) ) ) {   // Günün Kelimeleri: yalnızca ayar açıkken (includes/kelime.php)
		$out['kelime'] = $kl;
	}
	if ( $oniz && function_exists( 'sides_bakim_tv_durum' ) && ( $bd = sides_bakim_tv_durum( $org ) ) ) {
		$out['onizBekleme'] = $bd;   // v7.8: önizleme "Bekletmede" etiketi; imzaya girer (bekleme bitince pano etiketi kaldırır)
	}
	$imza = md5( wp_json_encode( $out ) );
	$son  = preg_replace( '/[^a-f0-9]/', '', (string) $req['imza'] );
	if ( $son && $son === $imza ) {
		$res = rest_ensure_response( array( 'degismedi' => true, 'simdi' => $simdi, 'imza' => $imza ) );
	} else {
		$out['simdi'] = $simdi;
		$out['imza']  = $imza;
		$res = rest_ensure_response( $out );
	}
	return sides_tv_onbelleksiz( $res );
}

/* v5.7 Pano hayvanları: Site Animasyonları › TV panosu hayvanları (kurum geneli kapatmaya da uyulur) */
function sides_tv_hayvan( $org ) {
	$d   = sides_get_doc( (int) $org, 'animasyon', 'kurum' );
	$tv  = is_array( $d ) && isset( $d['tv'] ) && is_array( $d['tv'] ) ? $d['tv'] : array();
	$out = array();
	foreach ( array( 'tavsan', 'kus', 'ari', 'horoz', 'aslan', 'leopar', 'araba' ) as $k ) {
		$x = isset( $tv[ $k ] ) && is_array( $tv[ $k ] ) ? $tv[ $k ] : array();
		if ( 'tavsan' === $k && isset( $tv['tavsan'] ) && ! is_array( $tv['tavsan'] ) ) {
			$x = array( 'a' => ! empty( $tv['tavsan'] ), 'h' => isset( $tv['h'] ) ? $tv['h'] : 'normal', 'sik' => isset( $tv['sik'] ) ? $tv['sik'] : 5 );
		}
		$out[ $k ] = array(
			'a'   => is_array( $d ) && empty( $d['kapali'] ) && ! empty( $x['a'] ),
			'h'   => isset( $x['h'] ) && in_array( $x['h'], array( 'yavas', 'normal', 'hizli' ), true ) ? $x['h'] : 'normal',
			'sik' => isset( $x['sik'] ) && in_array( (int) $x['sik'], array( 1, 3, 5, 10, 15 ), true ) ? (int) $x['sik'] : 5,
		);
		if ( 'tavsan' === $k && defined( 'SIDES_TAV_CINS' ) ) {   // v7 cins ve sahne (eski kayıtta yoksa karışık)
			$out[ $k ]['cins']  = isset( $x['cins'] ) && in_array( $x['cins'], SIDES_TAV_CINS, true ) ? $x['cins'] : 'karisik';
			$out[ $k ]['sahne'] = isset( $x['sahne'] ) && in_array( $x['sahne'], SIDES_TAV_SAHNE, true ) ? $x['sahne'] : 'karisik';
		}
		if ( 'araba' === $k && defined( 'SIDES_ARABA_SENARYO' ) ) {   /* v7.9 senaryo */
			$out[ $k ]['senaryo'] = isset( $x['senaryo'] ) && in_array( $x['senaryo'], SIDES_ARABA_SENARYO, true ) ? $x['senaryo'] : 'karisik';
		}
	}
	return $out;
}
/* Duyuru görseli (kurumun görsel kaydı; bağlantı geçerliyse) */
function sides_tv_gorsel( WP_REST_Request $req ) {
	global $wpdb;
	if ( ! sides_rl( 'tv_gorsel', 600, 600 ) ) {
		return new WP_Error( 'sides_rl', 'Çok fazla istek.', array( 'status' => 429 ) );
	}
	$org = sides_tv_bul( (string) $req['token'] );
	if ( ! $org ) {
		return new WP_Error( 'sides_yok', 'Bağlantı geçersiz.', array( 'status' => 404 ) );
	}
	$t   = sides_docs();
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT data FROM $t WHERE coll = 'gorsel' AND id = %s AND org = %d", $req['id'], $org ) ); // phpcs:ignore
	$d   = $row ? json_decode( $row->data, true ) : null;
	if ( ! $d || empty( $d['b'] ) ) {
		return new WP_Error( 'sides_yok', 'Görsel bulunamadı.', array( 'status' => 404 ) );
	}
	$bin = base64_decode( $d['b'] );
	sides_gorsel_basliklar( $d, $bin );   // v7.9.27: tür beyaz listesi + nosniff + sandbox
	header( 'Cache-Control: private, max-age=3600' );
	header_remove( 'Expires' );
	header_remove( 'Pragma' );
	echo $bin; // phpcs:ignore
	exit;
}

/* ------------------------------------------------------------------ *
 * Hedefler bölümü ('hedef', Sayfa düzeninde yerleştirilir): öğrencilerin girilmiş hedefleri kendi bölümünde dönen tek şablonlu slaytlar olarak
 *   ayar.hedef = { kapsam tum|secili, siniflar ['7', '8/A' …] (≤ 80), donem guncel|1|2, kisi 1|2|4|6, sure 4–120 sn, sira sinif|rastgele, slogan 0|1,
 *                  gecis karisik|kay|yukari|yakin|cevir|deste|pop (öğrenciler arası geçiş; src/tv.js TV_HD_GECIS),
 *                  desen sade|nokta|cizgi|geo|yildiz|dalga, zemin krem|beyaz|mavi|yesil|lila|kagit (kart şablonu), bolumZemin krem|tema|beyaz|gri|lacivert (kartların arkası),
 *                  cerceve metal|defne|kalkan|kristal|sade (çerçeve şablonu), esik [4 kesim noktası] 0–100 tam sayı, kesin artan
 *                  (varsayılan 70, 80, 90, 95; eski 3 eşikli kayıt 4.sü eklenerek kabul edilir), adlar [5 seviye adı ≤ 20],
 *                  v7.7: cerceve ayrıca madalyon|rozet|sekizgen|kep; zirve 0|1 (karne hedefi 100 → 6. seviye 'zirve', varsayılan 1),
 *                  zirveAd (≤ 20, < > ve denetim karakteri yok; varsayılan "Zirve"), zirveStil isik|zumrut|muhur|kristal (varsayılan isik) }
 *   (v7.1'deki Duyurular › Hedefler seçenekleri acik/yer/aralik göçte atılır: sides_tv_goc.) Veri yalnızca bölüm düzendeyken gönderilir.
 *   Başlık ayar.basliklar.hedef (≤ 40, boşsa "Hedeflerimiz").
 *   Karne hedefi: includes/hedef.php sides_hedef_karne( $org, $hedefDoc, $sinif ) varsa onun sonucu (otomatik karne hedefi), yoksa kayıtlı değer.
 *   Veri: hedef/h_<öğrenci>_<yıl>_<dönem> (Takip › Hedefler: ders/yazılı hedefleri, karne hedefi, ek rozet) ve
 *         lgs/<öğrenci> (LGS hedefi: okul, puan, net). Gerçekleşen notlar, çalışma notları, LGS notu ve planı gönderilmez.
 *   Dönem kuralı Hedefler modülüyle aynı: eğitim yılı sides_egitim_yili(), dönem Şubat–Ağustos 2, diğer aylar 1 (src/hedef.js hdDonemVars).
 * ------------------------------------------------------------------ */
define( 'SIDES_TV_HD_SLOGAN', 'Başaracağına bir defa inanırsan, inanılmaz işler başarırsın.' );   // src/hedef.js HD_SLOGAN (yerleşik şablonların motivasyon cümlesi)
function sides_tv_hedef_vars() {
	return array( 'kapsam' => 'tum', 'siniflar' => array(), 'donem' => 'guncel', 'kisi' => 2, 'sure' => 12, 'sira' => 'sinif', 'slogan' => 1, 'gecis' => 'karisik', 'desen' => 'sade', 'zemin' => 'krem', 'bolumZemin' => 'krem', 'cerceve' => 'metal', 'esik' => array( 70, 80, 90, 95 ), 'adlar' => array( 'Bronz', 'Gümüş', 'Altın', 'Platin', 'Elmas' ), 'seviyeAd' => 0, 'zirve' => 1, 'zirveAd' => 'Zirve', 'zirveStil' => 'isik' );   // seviyeAd: eski sürümden kalan, kullanılmıyor; bolumZemin (v7.1.3): kartların arkasındaki bölüm zemini; zirve* (v7.7): karne hedefi 100 için ayrı rütbe
}
/* İki kipte: $hata'ya ileti eklenirse kayıt 400 ile reddedilir; ekran çıktısında iletiler yok sayılır, değerler sınırlanır */
function sides_tv_hedef_ayar_temiz( $x, &$hata ) {
	$v = sides_tv_hedef_vars();
	if ( null === $x ) {
		return $v;
	}
	if ( ! is_array( $x ) || ( $x && sides_tv_liste_mi( $x ) ) ) {
		$hata[] = 'Hedef slaytı ayarları geçersiz.';
		return $v;
	}
	foreach ( array_keys( $x ) as $k ) {
		if ( ! array_key_exists( (string) $k, $v ) ) {
			$hata[] = 'Bilinmeyen hedef slaytı ayarı.';
			break;
		}
	}
	$o = $v;
	foreach ( array( 'slogan', 'seviyeAd', 'zirve' ) as $k ) {
		if ( array_key_exists( $k, $x ) ) {
			$b = $x[ $k ];
			if ( in_array( $b, array( 0, 1, true, false, '0', '1' ), true ) ) {
				$o[ $k ] = ( true === $b || 1 === $b || '1' === $b ) ? 1 : 0;
			} else {
				$hata[] = 'Hedef slaytı açık/kapalı değeri geçersiz.';
			}
		}
	}
	$sec = array( 'kapsam' => array( 'tum', 'secili' ), 'donem' => array( 'guncel', '1', '2' ), 'sira' => array( 'sinif', 'rastgele' ), 'gecis' => array( 'karisik', 'kay', 'yukari', 'yakin', 'cevir', 'deste', 'pop' ), 'desen' => array( 'sade', 'nokta', 'cizgi', 'geo', 'yildiz', 'dalga' ), 'zemin' => array( 'krem', 'beyaz', 'mavi', 'yesil', 'lila', 'kagit' ), 'bolumZemin' => array( 'krem', 'tema', 'beyaz', 'gri', 'lacivert' ), 'cerceve' => array( 'metal', 'defne', 'kalkan', 'kristal', 'sade', 'madalyon', 'rozet', 'sekizgen', 'kep' ), 'zirveStil' => array( 'isik', 'zumrut', 'muhur', 'kristal' ) );
	foreach ( $sec as $k => $L ) {
		if ( array_key_exists( $k, $x ) ) {
			$d = is_int( $x[ $k ] ) ? (string) $x[ $k ] : $x[ $k ];
			if ( is_string( $d ) && in_array( $d, $L, true ) ) {
				$o[ $k ] = $d;
			} else {
				$hata[] = 'Hedef slaytı seçeneği geçersiz.';
			}
		}
	}
	if ( array_key_exists( 'esik', $x ) ) {   // karne hedefi seviyelerinin 4 kesim noktası: 0–100 tam sayı, kesin artan (eski 3 eşik: 4.sü eklenir)
		$e  = $x['esik'];
		$ok = is_array( $e ) && sides_tv_liste_mi( $e ) && in_array( count( $e ), array( 3, 4 ), true );
		$n  = array();
		if ( $ok ) {
			foreach ( $e as $v ) {
				if ( ! ( is_int( $v ) || ( is_float( $v ) && floor( $v ) === $v ) || ( is_string( $v ) && preg_match( '/^\d{1,3}$/', $v ) ) ) || (int) $v < 0 || (int) $v > 100 ) {
					$ok = false;
					break;
				}
				$n[] = (int) $v;
			}
		}
		if ( $ok && 3 === count( $n ) ) {
			$n[] = $n[2] + max( 1, (int) round( ( 100 - $n[2] ) / 2 ) );
		}
		for ( $i = 1; $ok && $i < count( $n ); $i++ ) {
			$ok = $n[ $i - 1 ] < $n[ $i ];
		}
		if ( $ok && 4 === count( $n ) && $n[3] <= 100 ) {
			$o['esik'] = $n;
		} else {
			$hata[] = 'Karne seviyelerinin kesim noktaları 0–100 arasında tam sayı ve artan sırada olmalı.';
		}
	}
	if ( array_key_exists( 'adlar', $x ) ) {   // 5 seviye adı: boş olmayan, en çok 20 karakter, işaretleme yok
		$a  = $x['adlar'];
		$ok = is_array( $a ) && sides_tv_liste_mi( $a ) && 5 === count( $a );
		$n  = array();
		if ( $ok ) {
			foreach ( $a as $v ) {
				$t = is_string( $v ) && mb_check_encoding( $v, 'UTF-8' ) ? trim( $v ) : '';
				if ( '' === $t || mb_strlen( $t, 'UTF-8' ) > 20 || preg_match( '/[<>\x00-\x1F\x7F]/u', $t ) ) {
					$ok = false;
					break;
				}
				$n[] = $t;
			}
		}
		if ( $ok ) {
			$o['adlar'] = $n;
		} else {
			$hata[] = 'Seviye adları 5 tane olmalı; her biri boş olmayan, en çok 20 karakterlik bir ad.';
		}
	}
	if ( array_key_exists( 'zirveAd', $x ) ) {   // v7.7 Zirve rütbesinin adı (karne hedefi 100): seviye adlarıyla aynı kural
		$t = is_string( $x['zirveAd'] ) && mb_check_encoding( $x['zirveAd'], 'UTF-8' ) ? trim( $x['zirveAd'] ) : '';
		if ( '' === $t || mb_strlen( $t, 'UTF-8' ) > 20 || preg_match( '/[<>\x00-\x1F\x7F]/u', $t ) ) {
			$hata[] = 'Zirve rütbesinin adı boş olmayan, en çok 20 karakterlik bir ad olmalı.';
		} else {
			$o['zirveAd'] = $t;
		}
	}
	if ( array_key_exists( 'kisi', $x ) ) {
		$n = is_numeric( $x['kisi'] ) ? (int) $x['kisi'] : 0;
		if ( in_array( $n, array( 1, 2, 4, 6 ), true ) && (float) $x['kisi'] === (float) $n ) {
			$o['kisi'] = $n;
		} else {
			$hata[] = 'Slayt başına öğrenci 1, 2, 4 ya da 6 olabilir.';
		}
	}
	foreach ( array( 'sure' => array( 4, 120, 'Hedef slaytı süresi' ) ) as $k => $s ) {
		if ( array_key_exists( $k, $x ) ) {
			$n = sides_tv_say( $x[ $k ], $s[0], $s[1], $s[2], $hata );
			if ( null !== $n ) {
				$o[ $k ] = (int) round( $n );
			}
		}
	}
	if ( array_key_exists( 'siniflar', $x ) ) {
		$L = $x['siniflar'];
		if ( ! sides_tv_liste_mi( $L ) || count( $L ) > 80 ) {
			$hata[] = 'Sınıf listesi geçersiz (en çok 80 seçim).';
			$L = is_array( $L ) ? array_slice( array_values( $L ), 0, 80 ) : array();
		}
		$gor = array();
		foreach ( $L as $s ) {
			if ( ! is_string( $s ) || ! mb_check_encoding( $s, 'UTF-8' ) || ! preg_match( '/^[^\/\x00-\x1F\x7F<>]{1,20}(\/[^\/\x00-\x1F\x7F<>]{1,20})?$/u', trim( $s ) ) ) {
				$hata[] = 'Sınıf/şube değeri geçersiz.';
				continue;
			}
			$n = sides_sinif_norm( $s );
			if ( '' !== $n && ! isset( $gor[ $n ] ) ) {
				$gor[ $n ] = 1;
			}
		}
		$o['siniflar'] = array_keys( $gor );
		$o['siniflar'] = array_map( 'strval', $o['siniflar'] );
	}
	return $o;
}
/* Kurumun hedef afişlerindeki motivasyon cümlesi (varsayılan şablondan; yerleşik şablonlarda HD_SLOGAN). Kurum kapattıysa boş. */
/* v7.2 LGS tarihi: kurum ayarlarındaki settings.lgs.tarih (LGS Modülü › öğrenci profili › LGS tarihi); girilmemişse ''.
   Panoda geçerli tarih: bu varsa o (lgsKaynak 'modul'), yoksa pano ayarındaki lgsTarihi (varsayılanı tahminî; 'ayar'). */
function sides_tv_lgs_tarih( $set ) {
	$t = is_array( $set ) && isset( $set['lgs'] ) && is_array( $set['lgs'] ) && isset( $set['lgs']['tarih'] ) ? trim( (string) $set['lgs']['tarih'] ) : '';
	return preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $t, $m ) && checkdate( (int) $m[2], (int) $m[3], (int) $m[1] ) ? $t : '';
}
function sides_tv_hedef_slogan( $org, $set ) {
	$vid = is_array( $set ) && ! empty( $set['hedefVarsayilan'] ) ? (string) $set['hedefVarsayilan'] : 'y-tablo';
	$sab = 0 === strpos( $vid, 'y-' ) ? null : sides_get_doc( $org, 'hsablon', $vid );
	if ( ! is_array( $sab ) || ! empty( $sab['arsiv'] ) ) {
		return SIDES_TV_HD_SLOGAN;   // yerleşik ya da bulunamayan/arşivlenmiş şablon: Hedefler modülü de yerleşik tabloya döner
	}
	$a = isset( $sab['ayar'] ) && is_array( $sab['ayar'] ) ? $sab['ayar'] : array();
	if ( array_key_exists( 'motivAcik', $a ) && ! $a['motivAcik'] && ( ! isset( $a['tasarim'] ) || 'afis' !== $a['tasarim'] ) ) {
		return '';
	}
	$s = array_key_exists( 'slogan', $a ) ? (string) $a['slogan'] : SIDES_TV_HD_SLOGAN;
	return mb_substr( trim( wp_strip_all_tags( $s ) ), 0, 140 );
}
function sides_tv_hd_sayi( $v, $min, $max, $ondalik ) {
	if ( null === $v || '' === $v || is_bool( $v ) || ! is_numeric( $v ) ) {
		return null;
	}
	$v = (float) $v;
	return $v < $min || $v > $max ? null : round( $v, $ondalik );
}
function sides_tv_hd_yazi( $v, $max ) {
	if ( ! is_string( $v ) && ! is_numeric( $v ) ) {
		return '';
	}
	$v = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( (string) $v ) ) );
	return mb_strlen( $v ) > $max ? rtrim( mb_substr( $v, 0, $max - 1 ) ) . '…' : $v;
}
/* Panoya giden hedef listesi: kapsamdaki, gösterilecek en az bir hedefi olan öğrenciler; sınıf, şube, ad sırasıyla (en çok 400) */
function sides_tv_hedef_veri( $org, $h, $gizlilik, $foto, $set = null, $kullanici_kisit = null ) {
	global $wpdb;
	$t      = sides_docs();
	$kapali = function_exists( 'sides_kapali_moduller' ) ? sides_kapali_moduller( $org ) : array();
	$yil    = (int) sides_egitim_yili( $org );
	$ay     = (int) current_time( 'n' );
	$donem  = 'guncel' === $h['donem'] ? ( $ay >= 2 && $ay <= 8 ? 2 : 1 ) : (int) $h['donem'];
	if ( null === $set ) {
		$set = sides_get_doc( $org, 'settings', 'main' );
	}
	$out = array( 'yil' => $yil, 'donem' => $donem, 'slogan' => $h['slogan'] ? sides_tv_hedef_slogan( $org, $set ) : '', 'lgsTarih' => sides_tv_lgs_tarih( $set ), 'ogr' => array() );   // lgsTarih: LGS Modülü'nde girilmiş tarih ('' = girilmemiş; o zaman pano ayarındaki tarih geçerlidir)
	$kisit    = 'secili' === $h['kapsam'] ? $h['siniflar'] : null;
	$neh_ayri = function_exists( 'sides_nehari_ayri' ) ? sides_nehari_ayri( $org ) : false;
	$ogr      = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = 'students'", $org ) ) as $r ) { // phpcs:ignore
		$s = json_decode( $r->data, true );
		if ( ! is_array( $s ) ) {
			continue;
		}
		if ( $neh_ayri && sides_nehari_sinifi( isset( $s['sinif'] ) ? $s['sinif'] : '' ) ) {
			continue;   // Nehari öğrencileri panoda listelenmez (sıralamayla aynı kural)
		}
		if ( null !== $kisit && ( ! $kisit || ! sides_ogrenci_izinli( $s, $kisit ) ) ) {
			continue;
		}
		if ( null !== $kullanici_kisit && ! sides_ogrenci_izinli( $s, $kullanici_kisit ) ) {
			continue;   // önizleme: sınıf yetkisi kısıtlı kullanıcı yalnızca kendi sınıflarının hedeflerini görür
		}
		$ogr[ (string) $r->id ] = $s;
	}
	if ( ! $ogr ) {
		return $out;
	}
	$hd = array();
	if ( ! in_array( 'takip', $kapali, true ) ) {
		/* kaba süzgeç (alt çizgi joker; MySQL ve SQLite'ta aynı davranır), kesin eşleşme aşağıda kimlikle denetlenir */
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = 'hedef' AND id LIKE %s", $org, 'h_%_' . $yil . '_' . $donem ) ) as $r ) { // phpcs:ignore
			$d = json_decode( $r->data, true );
			$sid = is_array( $d ) && isset( $d['studentId'] ) ? (string) $d['studentId'] : '';
			if ( $sid && isset( $ogr[ $sid ] ) && (string) $r->id === 'h_' . $sid . '_' . $yil . '_' . $donem ) {
				$hd[ $sid ] = $d;
			}
		}
	}
	$lgs = array();
	if ( ! in_array( 'sinav', $kapali, true ) ) {
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = 'lgs'", $org ) ) as $r ) { // phpcs:ignore
			if ( isset( $ogr[ (string) $r->id ] ) ) {
				$d = json_decode( $r->data, true );
				if ( is_array( $d ) ) {
					$lgs[ (string) $r->id ] = $d;
				}
			}
		}
	}
	$L = array();
	foreach ( $ogr as $sid => $s ) {
		$e = array();
		if ( isset( $lgs[ $sid ] ) ) {   // LGS hedefi: okul, puan, net (not ve çalışma planı gönderilmez)
			$x  = $lgs[ $sid ];
			$lg = array_filter( array(
				'okul' => sides_tv_hd_yazi( isset( $x['okul'] ) ? $x['okul'] : '', 80 ),
				'puan' => sides_tv_hd_sayi( isset( $x['puan'] ) ? $x['puan'] : null, 100, 500, 2 ),
				'net'  => sides_tv_hd_sayi( isset( $x['net'] ) ? $x['net'] : null, 0.01, 90, 2 ),
			), function ( $v ) { return null !== $v && '' !== $v; } );
			if ( $lg ) {
				$e['lgs'] = $lg;
			}
		}
		if ( isset( $hd[ $sid ] ) ) {   // Takip › Hedefler: karne hedefi, ek rozet, ders/yazılı hedefleri (gerçekleşen notlar ve çalışma notları gönderilmez)
			$d = $hd[ $sid ];
			$kv = function_exists( 'sides_hedef_karne' ) ? sides_hedef_karne( $org, $d, isset( $s['sinif'] ) ? (string) $s['sinif'] : '' ) : ( isset( $d['karne'] ) ? $d['karne'] : null );   // otomatik karne hedefi (includes/hedef.php) ya da kayıtlı değer
			$k  = sides_tv_hd_sayi( $kv, 0, 100, 1 );
			if ( null !== $k ) {
				$e['karne'] = (int) ceil( $k - 1e-9 );   // v7.0.9: panoda karne hedefi tam sayı, küsurat yukarı tamamlanır (91,2 → 92); yönetim ekranlarında ondalıklı kalır
			}
			$ek = isset( $d['ek'] ) && is_array( $d['ek'] ) ? $d['ek'] : array();
			if ( ! empty( $ek['acik'] ) && '' !== sides_tv_hd_yazi( isset( $ek['deger'] ) ? $ek['deger'] : '', 12 ) ) {
				$e['ek'] = array( 'et' => sides_tv_hd_yazi( isset( $ek['etiket'] ) && '' !== trim( (string) $ek['etiket'] ) ? $ek['etiket'] : 'Ek hedef', 30 ), 'v' => sides_tv_hd_yazi( $ek['deger'], 12 ) );
			}
			$dl  = array();
			$kol = array();
			foreach ( array_slice( isset( $d['dersler'] ) && is_array( $d['dersler'] ) ? array_values( $d['dersler'] ) : array(), 0, 16 ) as $x ) {
				$ad = is_array( $x ) ? sides_tv_hd_yazi( isset( $x['ad'] ) ? $x['ad'] : '', 40 ) : '';
				if ( '' === $ad ) {
					continue;
				}
				$hh = array();
				for ( $i = 1; $i <= 4; $i++ ) {
					$hh[ $i ] = sides_tv_hd_sayi( isset( $x[ 'h' . $i ] ) ? $x[ 'h' . $i ] : null, 0, 100, 1 );
					if ( null !== $hh[ $i ] ) {
						$hh[ $i ] = (int) ceil( $hh[ $i ] - 1e-9 );   // v7.0.9: ders hedefleri de panoda tam sayı (yukarı)
					}
					if ( null !== $hh[ $i ] ) {
						$kol[ $i ] = 1;
					}
				}
				if ( array_filter( $hh, function ( $v ) { return null !== $v; } ) ) {
					$dl[] = array( 'ad' => $ad, 'h' => $hh );
				}
			}
			if ( $dl ) {
				ksort( $kol );
				$yz = array_keys( $kol );
				$e['yz'] = $yz;
				$e['dersler'] = array_map( function ( $x ) use ( $yz ) {
					return array( 'ad' => $x['ad'], 'h' => array_map( function ( $i ) use ( $x ) { return $x['h'][ $i ]; }, $yz ) );
				}, $dl );
			}
		}
		if ( ! $e ) {
			continue;   // gösterilecek hedefi olmayan öğrenci atlanır
		}
		$sinif = trim( (string) ( isset( $s['sinif'] ) ? $s['sinif'] : '' ) );
		$sube  = trim( (string) ( isset( $s['sube'] ) ? $s['sube'] : '' ) );
		$o     = array( 'ad' => sides_tv_ad( $s, $gizlilik ), 'sinif' => mb_substr( $sinif, 0, 20 ), 'sube' => mb_substr( $sube, 0, 20 ) );
		if ( $foto ) {
			$g = isset( $s['foto'] ) ? (string) $s['foto'] : '';
			if ( ! sides_tv_gorsel_ok( $g ) && isset( $hd[ $sid ]['foto']['id'] ) ) {
				$g = (string) $hd[ $sid ]['foto']['id'];   // öğrenci kaydında fotoğraf yoksa hedef afişindeki fotoğraf
			}
			if ( sides_tv_gorsel_ok( $g ) ) {
				$o['foto'] = $g;
			}
		}
		$L[] = array( 'k' => array( $sinif, mb_strtoupper( $sube, 'UTF-8' ), (string) ( isset( $s['ad'] ) ? $s['ad'] : '' ) ), 'o' => $o + $e );
	}
	$tr = class_exists( 'Collator' ) ? new Collator( 'tr_TR' ) : null;
	$sira = array( '3', '4', 'N5', '5', '6', '7', '8' );   // src/app.js TUM_SINIF
	usort( $L, function ( $a, $b ) use ( $tr, $sira ) {
		$ia = array_search( $a['k'][0], $sira, true );
		$ib = array_search( $b['k'][0], $sira, true );
		$c  = ( false === $ia ? 99 : $ia ) - ( false === $ib ? 99 : $ib );
		if ( ! $c ) {
			$c = strnatcasecmp( $a['k'][0], $b['k'][0] );
		}
		for ( $i = 1; ! $c && $i <= 2; $i++ ) {
			$c = $tr ? $tr->compare( $a['k'][ $i ], $b['k'][ $i ] ) : strcmp( mb_strtolower( $a['k'][ $i ], 'UTF-8' ), mb_strtolower( $b['k'][ $i ], 'UTF-8' ) );
		}
		return $c;
	} );
	$out['ogr'] = array_map( function ( $x ) { return $x['o']; }, array_slice( $L, 0, 400 ) );
	return $out;
}
/* Ekran Ayarları › Hedefler: taslak ayarla panoya gidecek listenin aynısı (hiçbir şey kaydedilmez) */
function sides_tv_hedef_oniz( WP_REST_Request $req ) {
	if ( ! sides_rl( 'tv_hedef_oniz', 120, 60 ) ) {
		return new WP_Error( 'sides_rl', 'Çok fazla istek. Biraz sonra tekrar deneyin.', array( 'status' => 429 ) );
	}
	$org  = sides_org_id();
	$p    = $req->get_json_params();
	$hata = array();
	$h    = sides_tv_hedef_ayar_temiz( is_array( $p ) && array_key_exists( 'hedef', $p ) ? $p['hedef'] : null, $hata );
	if ( $hata ) {
		return new WP_Error( 'sides_gecersiz', implode( ' ', array_slice( array_values( array_unique( $hata ) ), 0, 3 ) ), array( 'status' => 400 ) );
	}
	$a   = sides_tv_ayar_disari( sides_get_doc( $org, 'tv', 'ayar' ) );
	$res = rest_ensure_response( sides_tv_hedef_veri( $org, $h, $a['gizlilik'], ! empty( $a['foto'] ), null, function_exists( 'sides_sinif_kisit' ) ? sides_sinif_kisit() : null ) );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}
