<?php
/**
 * Yönetim Raporları (v5.3): rapor verisi, rapor anlık görüntüleri ve dışa aktarma günlüğü.
 *
 * GET  /rapor/veri?bas=&bit=&sinif=&sube=&ogr=   Seçilen aralığın TAMAMI için takip türü belgeler (etut, izin, kitap, takviye,
 *      sgunluk, hedef, workwin, dgrup, seviye) tek yanıtta; içeride LIMIT/OFFSET ile sayfalanarak okunur. Sınıf yetkisi uygulanır.
 * POST /rapor/kaydet {baslik, filtreler, ozet, html}   'rapor' anlık görüntü belgesi oluşturur (html ≤ 400 KB) ve günlüğe yazar.
 * GET  /rapor/liste                                   anlık görüntülerin listesi (html olmadan)
 * GET  /rapor/ac/<id>                                 tek anlık görüntü (html dahil)
 * POST /rapor/disa {tip, baslik}                      dışa aktarma günlük kaydı (PDF / CSV)
 * Silme: DELETE /doc/rapor/<id> (rest.php) ile yapılır.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SIDES_RAPOR_COLL', array( 'etut', 'izin', 'kitap', 'takviye', 'sgunluk', 'hedef', 'workwin', 'dgrup', 'seviye' ) );
define( 'SIDES_RAPOR_HTML_MAX', 400 * 1024 );
define( 'SIDES_RAPOR_OZET_MAX', 200 * 1024 );
define( 'SIDES_RAPOR_SAYFA', 400 );

add_action( 'rest_api_init', function () {
	$ns  = 'optik-karne/v1';
	$oku = function () {
		return sides_can( 'rapor', 1 ) ? true : sides_deny( 'Raporlar modülünü görme yetkiniz yok.' );
	};
	$yaz = function () {
		return sides_can( 'rapor', 2 ) ? true : sides_deny( 'Rapor oluşturma yetkiniz yok.' );
	};
	register_rest_route( $ns, '/rapor/veri', array( 'methods' => 'GET', 'callback' => 'sides_rapor_veri', 'permission_callback' => $oku ) );
	register_rest_route( $ns, '/rapor/kaydet', array( 'methods' => 'POST', 'callback' => 'sides_rapor_kaydet', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/rapor/liste', array( 'methods' => 'GET', 'callback' => 'sides_rapor_liste', 'permission_callback' => $oku ) );
	register_rest_route( $ns, '/rapor/ac/(?P<id>[A-Za-z0-9_\-]{1,64})', array( 'methods' => 'GET', 'callback' => 'sides_rapor_ac', 'permission_callback' => $oku ) );
	register_rest_route( $ns, '/rapor/disa', array( 'methods' => 'POST', 'callback' => 'sides_rapor_disa', 'permission_callback' => $oku ) );
} );
/* v7.9.27 güvenlik: rapor arşivi (coll 'rapor') yalnız /rapor/kaydet ucundan yazılır; HTML denetimi orada. Genel /doc ucu yalnız silebilir
   (arayüz silmeyi oradan yapar). Adres harf denetimi optik-karne.php'de olduğu için burada birebir karşılaştırma yeterli. */
add_filter( 'rest_pre_dispatch', function ( $result, $server, $req ) {
	if ( null === $result && in_array( $req->get_method(), array( 'PUT', 'POST', 'PATCH' ), true ) && preg_match( '#^/optik-karne/v1/doc/rapor/#', (string) $req->get_route() ) ) {
		return new WP_Error( 'sides_rapor', 'Raporlar yalnız rapor ekranından kaydedilir.', array( 'status' => 403 ) );
	}
	return $result;
}, 10, 3 );

/* ------------------------------------------------------------------ *
 * Kapsam: sınıf/şube/öğrenci seçimi ile kullanıcının sınıf yetkisinin kesişimi (id => true; null = kurumun tamamı)
 * ------------------------------------------------------------------ */
function sides_rapor_kapsam( $org, $sinif, $sube, $ogr ) {
	global $wpdb;
	$kisit = sides_sinif_kisit();
	$izin  = null === $kisit ? null : sides_izinli_ogrenciler( $org, $kisit );
	if ( $ogr ) {
		if ( null !== $izin && ! isset( $izin[ $ogr ] ) ) {
			return new WP_Error( 'sides_yetki', 'Bu öğrenci, yetkili olduğunuz sınıfların dışında.', array( 'status' => 403 ) );
		}
		return array( $ogr => true );
	}
	if ( '' === $sinif ) {
		return $izin;
	}
	$t   = sides_docs();
	$out = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = 'students'", $org ) ) as $r ) { // phpcs:ignore
		$d = json_decode( $r->data, true );
		if ( ! is_array( $d ) ) {
			continue;
		}
		$g = trim( (string) ( isset( $d['sinif'] ) ? $d['sinif'] : '' ) );
		$b = mb_strtoupper( trim( (string) ( isset( $d['sube'] ) ? $d['sube'] : '' ) ), 'UTF-8' );
		if ( $g !== $sinif || ( '' !== $sube && $b !== $sube ) ) {
			continue;
		}
		if ( null !== $izin && ! isset( $izin[ (string) $r->id ] ) ) {
			continue;
		}
		$out[ (string) $r->id ] = true;
	}
	return $out;
}

/* Bir haritayı (sid => değer ya da 'sid|...' => değer) kapsama göre süzer */
function sides_rapor_suz( $m, $kapsam, $ayir = false ) {
	if ( null === $kapsam || ! is_array( $m ) ) {
		return is_array( $m ) ? $m : array();
	}
	$o = array();
	foreach ( $m as $k => $v ) {
		$sid = $ayir ? strtok( (string) $k, '|' ) : (string) $k;
		if ( isset( $kapsam[ $sid ] ) ) {
			$o[ $k ] = $v;
		}
	}
	return $o;
}
function sides_rapor_liste_suz( $l, $kapsam ) {
	$l = is_array( $l ) ? $l : array();
	if ( null === $kapsam ) {
		return array_values( $l );
	}
	return array_values( array_filter( $l, function ( $s ) use ( $kapsam ) {
		return isset( $kapsam[ (string) $s ] );
	} ) );
}

/* Bir koleksiyonun belgelerini sayfa sayfa okur; $sql_ek ek WHERE koşulu (hazırlanmış) */
function sides_rapor_oku( $org, $coll, $sql_ek, $cb ) {
	global $wpdb;
	$t   = sides_docs();
	$off = 0;
	$n   = 0;
	while ( true ) {
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT id, token, data FROM $t WHERE org = %d AND coll = %s $sql_ek ORDER BY id LIMIT %d OFFSET %d", $org, $coll, SIDES_RAPOR_SAYFA, $off ) ); // phpcs:ignore
		foreach ( (array) $rows as $r ) {
			$d = json_decode( $r->data, true );
			if ( is_array( $d ) ) {
				$d['id'] = $r->id;
				$cb( $d, $r );
			}
			$n++;
		}
		if ( count( (array) $rows ) < SIDES_RAPOR_SAYFA ) {
			break;
		}
		$off += SIDES_RAPOR_SAYFA;
	}
	return $n;
}

function sides_rapor_veri( WP_REST_Request $req ) {
	global $wpdb;
	$org   = sides_org_id();
	$bas   = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $req['bas'] ) ? (string) $req['bas'] : '';
	$bit   = preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $req['bit'] ) ? (string) $req['bit'] : '';
	if ( ! $bas || ! $bit || $bit < $bas ) {
		return new WP_Error( 'sides_gecersiz', 'Tarih aralığı geçersiz.', array( 'status' => 400 ) );
	}
	if ( ( strtotime( $bit ) - strtotime( $bas ) ) > 400 * DAY_IN_SECONDS ) {
		return new WP_Error( 'sides_gecersiz', 'Aralık en çok 400 gün olabilir.', array( 'status' => 400 ) );
	}
	$sinif = preg_match( '/^[A-Za-z0-9]{1,6}$/', (string) $req['sinif'] ) ? (string) $req['sinif'] : '';
	$sube  = mb_strtoupper( preg_replace( '/[^A-Za-z0-9ÇĞİÖŞÜçğıöşü]/u', '', (string) $req['sube'] ), 'UTF-8' );
	$sube  = mb_substr( $sube, 0, 6 );
	$ogr   = substr( preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $req['ogr'] ), 0, 64 );
	$kap   = sides_rapor_kapsam( $org, $sinif, $sube, $ogr );
	if ( is_wp_error( $kap ) ) {
		return $kap;
	}
	$out = array_fill_keys( SIDES_RAPOR_COLL, array() );
	$out['bas']   = $bas;
	$out['bit']   = $bit;
	$out['kisit'] = null !== sides_sinif_kisit();
	$out['kapsamN'] = null === $kap ? null : count( $kap );
	$out['kapali'] = array();
	if ( ! sides_can( 'takip', 1 ) ) {   // takip verileri yalnızca modülü görebilenlere
		$out['kapali'][] = 'takip';
		$res = rest_ensure_response( $out );
		$res->header( 'Cache-Control', 'no-store' );
		return $res;
	}
	$tarihte = function ( $d ) use ( $bas, $bit ) {
		$t = isset( $d['tarih'] ) ? substr( (string) $d['tarih'], 0, 10 ) : ( preg_match( '/^\d{4}-\d{2}-\d{2}/', (string) $d['id'] ) ? substr( (string) $d['id'], 0, 10 ) : '' );
		return $t && $t >= $bas && $t <= $bit;
	};
	$ogr_ok = function ( $d ) use ( $kap ) {
		return null === $kap || ( ! empty( $d['studentId'] ) && isset( $kap[ (string) $d['studentId'] ] ) );
	};
	// etüt ve izin: belge kimliği tarihtir; SQL düzeyinde aralık
	$aralik = $wpdb->prepare( ' AND id >= %s AND id <= %s', $bas, $bit );
	sides_rapor_oku( $org, 'etut', $aralik, function ( $d ) use ( &$out, $kap ) {
		foreach ( defined( 'SIDES_ETUT_ANAHTAR' ) ? SIDES_ETUT_ANAHTAR : array( 'e1', 'e2', 'e3' ) as $e ) {   // v7: etüt sayısı ayarlanabilir (e1…e6)
			if ( ! isset( $d[ $e ] ) && $e > 'e3' ) {
				continue;
			}
			$d[ $e ] = (object) sides_rapor_suz( isset( $d[ $e ] ) ? $d[ $e ] : array(), $kap );
		}
		if ( isset( $d['gec'] ) ) {   // v7 geç dakikaları: anahtar "öğrenci|eN"
			$d['gec'] = (object) sides_rapor_suz( $d['gec'], $kap, true );
		}
		$out['etut'][] = $d;
	} );
	sides_rapor_oku( $org, 'izin', $aralik, function ( $d ) use ( &$out, $kap ) {
		$d['saat'] = (object) sides_rapor_suz( isset( $d['saat'] ) ? $d['saat'] : array(), $kap );
		$out['izin'][] = $d;
	} );
	$plan = sides_get_doc( $org, 'izin', '_plan' );
	if ( $plan ) {
		$out['izinPlan'] = array( 'sinir' => isset( $plan['sinir'] ) ? $plan['sinir'] : '', 'bas' => isset( $plan['bas'] ) ? $plan['bas'] : '', 'ekle' => isset( $plan['ekle'] ) ? $plan['ekle'] : array(), 'cikar' => isset( $plan['cikar'] ) ? $plan['cikar'] : array() );
	}
	// kitap: aralıkla kesişen her kitap (başlangıcı bitişten önce ve bitmemiş ya da bitişi başlangıçtan sonra) ya da aralıkta okuma girişi olan
	sides_rapor_oku( $org, 'kitap', '', function ( $d ) use ( &$out, $ogr_ok, $bas, $bit ) {
		if ( ! $ogr_ok( $d ) ) {
			return;
		}
		$kb = isset( $d['bas'] ) ? substr( (string) $d['bas'], 0, 10 ) : '';
		$kt = isset( $d['bitis'] ) && $d['bitis'] ? substr( (string) $d['bitis'], 0, 10 ) : '';
		$kesisir = ( '' === $kb || $kb <= $bit ) && ( '' === $kt || $kt >= $bas );
		if ( ! $kesisir && isset( $d['okuma'] ) && is_array( $d['okuma'] ) ) {
			foreach ( $d['okuma'] as $g => $v ) {
				if ( $g >= $bas && $g <= $bit ) {
					$kesisir = true;
					break;
				}
			}
		}
		if ( $kesisir ) {
			$out['kitap'][] = $d;
		}
	} );
	sides_rapor_oku( $org, 'takviye', '', function ( $d, $r ) use ( &$out, $kap, $tarihte ) {
		if ( ! $tarihte( $d ) ) {
			return;
		}
		$d['puan']       = (object) sides_rapor_suz( isset( $d['puan'] ) ? $d['puan'] : array(), $kap );
		$d['ogrenciler'] = sides_rapor_liste_suz( isset( $d['ogrenciler'] ) ? $d['ogrenciler'] : array(), $kap );
		unset( $d['token'] );
		$out['takviye'][] = $d;
	} );
	sides_rapor_oku( $org, 'sgunluk', '', function ( $d ) use ( &$out, $ogr_ok, $tarihte ) {
		if ( $ogr_ok( $d ) && $tarihte( $d ) ) {
			$out['sgunluk'][] = $d;
		}
	} );
	sides_rapor_oku( $org, 'hedef', '', function ( $d ) use ( &$out, $ogr_ok ) {
		if ( $ogr_ok( $d ) ) {
			$out['hedef'][] = $d;
		}
	} );
	sides_rapor_oku( $org, 'workwin', '', function ( $d ) use ( &$out, $kap, $ogr_ok ) {
		if ( ! empty( $d['studentId'] ) ) {
			if ( $ogr_ok( $d ) ) {
				$out['workwin'][] = $d;
			}
			return;
		}
		foreach ( array( 'hucre', 'hucreler', 'durum' ) as $a ) {
			if ( isset( $d[ $a ] ) && is_array( $d[ $a ] ) ) {
				$d[ $a ] = (object) sides_rapor_suz( $d[ $a ], $kap, true );
			}
		}
		$out['workwin'][] = $d;
	} );
	sides_rapor_oku( $org, 'dgrup', '', function ( $d ) use ( &$out, $kap ) {
		foreach ( array( 'isaret', 'serbest' ) as $a ) {
			$d[ $a ] = (object) sides_rapor_suz( isset( $d[ $a ] ) ? $d[ $a ] : array(), $kap, true );
		}
		$d['ogrenciler'] = sides_rapor_liste_suz( isset( $d['ogrenciler'] ) ? $d['ogrenciler'] : array(), $kap );
		$out['dgrup'][] = $d;
	} );
	sides_rapor_oku( $org, 'seviye', '', function ( $d ) use ( &$out ) {
		$out['seviye'][] = array( 'id' => $d['id'], 'ad' => isset( $d['ad'] ) ? $d['ad'] : '', 'sira' => isset( $d['sira'] ) ? $d['sira'] : 0, 'cizelge' => isset( $d['cizelge'] ) ? $d['cizelge'] : array() );
	} );
	$res = rest_ensure_response( $out );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}

/* ------------------------------------------------------------------ *
 * Anlık görüntü kaydetme / listeleme / açma
 * ------------------------------------------------------------------ */
function sides_rapor_kaydet( WP_REST_Request $req ) {
	$org = sides_org_id();
	if ( sides_is_observer() ) {
		return sides_deny( 'Gözlemci rapor kaydedemez.' );
	}
	$p = $req->get_json_params();
	if ( ! is_array( $p ) ) {
		return new WP_Error( 'sides_gecersiz', 'Geçersiz veri.', array( 'status' => 400 ) );
	}
	$baslik = mb_substr( sanitize_text_field( (string) ( isset( $p['baslik'] ) ? $p['baslik'] : '' ) ), 0, 200 );
	$html   = isset( $p['html'] ) ? (string) $p['html'] : '';
	if ( '' === $baslik ) {
		$baslik = 'Yönetim raporu';
	}
	if ( strlen( $html ) > SIDES_RAPOR_HTML_MAX ) {
		return new WP_Error( 'sides_buyuk', 'Rapor içeriği çok büyük (en çok 400 KB). Öğrenci detaylarını kapatıp yeniden deneyin.', array( 'status' => 413 ) );
	}
	/* v7.3.1 güvenlik: HTML karakter kodlarıyla gizlenmiş betik adresleri (java&#9;script:), form/base etiketleri ve SVG animasyonlarıyla adres değiştirme de reddedilir */
	$duz = preg_replace( '/[\x00-\x20]+/', '', html_entity_decode( html_entity_decode( $html, ENT_QUOTES | ENT_HTML5, 'UTF-8' ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
	if ( preg_match( '/<\s*(script|iframe|object|embed|link|meta|base|form|frame|frameset|animate|set|animatemotion|animatetransform|handler|listener|noscript|noembed|noframes|template|xmp|plaintext)\b/i', $html ) || false !== strpos( $html, '<!--' )   // v7.9.27 mXSS kalıpları || preg_match( '/\son[a-z]+\s*=/i', $html ) || preg_match( '/\sformaction\s*=/i', $html )
		|| preg_match( '/(javascript:|vbscript:|data:text\/html|data:image\/svg)/i', $duz ) ) {
		return new WP_Error( 'sides_gecersiz', 'Rapor içeriği kabul edilmedi.', array( 'status' => 400 ) );
	}
	$filtreler = isset( $p['filtreler'] ) && is_array( $p['filtreler'] ) ? $p['filtreler'] : array();
	$ozet      = isset( $p['ozet'] ) && is_array( $p['ozet'] ) ? $p['ozet'] : array();
	if ( strlen( wp_json_encode( $filtreler ) ) > 20000 ) {
		return new WP_Error( 'sides_buyuk', 'Filtre bilgisi çok büyük.', array( 'status' => 413 ) );
	}
	if ( strlen( wp_json_encode( $ozet ) ) > SIDES_RAPOR_OZET_MAX ) {
		$ozet = array( 'kirpildi' => true );
	}
	$u   = wp_get_current_user();
	$ms  = (int) round( microtime( true ) * 1000 );
	$id  = 'rp' . base_convert( (string) $ms, 10, 36 ) . wp_rand( 100, 999 );
	$doc = array(
		'baslik'      => $baslik,
		'filtreler'   => $filtreler,
		'sablonSurum' => isset( $p['sablonSurum'] ) ? (int) $p['sablonSurum'] : 1,
		'olusturma'   => $ms,
		'olusturan'   => $u && $u->ID ? $u->display_name : 'Sistem',
		'olusturanId' => get_current_user_id(),
		'kisit'       => sides_sinif_kisit(),   // v7.3.1: oluşturanın sınıf kapsamı (null = tüm okul)
		'ozet'        => $ozet,
		'html'        => $html,
		'boyut'       => strlen( $html ),
	);
	if ( false === sides_put_doc( $org, 'rapor', $id, $doc ) ) {
		return new WP_Error( 'sides_db', 'Rapor kaydedilemedi.', array( 'status' => 500 ) );
	}
	sides_log( $org, 'Rapor oluşturuldu: ' . $baslik );
	unset( $doc['html'] );
	$doc['id'] = $id;
	return $doc;
}

/* v7.3.1 güvenlik: sınıf kısıtlı kullanıcı yalnız kendi raporunu ya da kapsamı kendi sınıflarının içinde kalan raporu görür */
function sides_rapor_gorebilir( $d ) {
	$k = sides_sinif_kisit();
	if ( null === $k ) {
		return true;
	}
	if ( isset( $d['olusturanId'] ) && (int) $d['olusturanId'] === get_current_user_id() ) {
		return true;
	}
	$rk = isset( $d['kisit'] ) && is_array( $d['kisit'] ) ? $d['kisit'] : null;
	return null !== $rk && $rk && ! array_diff( array_map( 'strval', $rk ), array_map( 'strval', (array) $k ) );
}

function sides_rapor_liste() {
	global $wpdb;
	$org = sides_org_id();
	$t   = sides_docs();
	$out = array();
	$off = 0;
	while ( true ) {
		$rows = $wpdb->get_results( $wpdb->prepare( "SELECT id, data, updated_at FROM $t WHERE org = %d AND coll = 'rapor' ORDER BY id DESC LIMIT 60 OFFSET %d", $org, $off ) ); // phpcs:ignore
		foreach ( (array) $rows as $r ) {
			$d = json_decode( $r->data, true );
			if ( ! is_array( $d ) || ! sides_rapor_gorebilir( $d ) ) {
				continue;
			}
			$out[] = array(
				'id'          => $r->id,
				'baslik'      => isset( $d['baslik'] ) ? $d['baslik'] : '',
				'filtreler'   => isset( $d['filtreler'] ) ? $d['filtreler'] : array(),
				'sablonSurum' => isset( $d['sablonSurum'] ) ? $d['sablonSurum'] : 1,
				'olusturma'   => isset( $d['olusturma'] ) ? $d['olusturma'] : 0,
				'olusturan'   => isset( $d['olusturan'] ) ? $d['olusturan'] : '',
				'boyut'       => isset( $d['boyut'] ) ? (int) $d['boyut'] : strlen( isset( $d['html'] ) ? $d['html'] : '' ),
				'_g'          => $r->updated_at,
			);
		}
		if ( count( (array) $rows ) < 60 || count( $out ) >= 300 ) {
			break;
		}
		$off += 60;
	}
	usort( $out, function ( $a, $b ) {
		return (int) $b['olusturma'] <=> (int) $a['olusturma'];
	} );
	$res = rest_ensure_response( $out );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}

function sides_rapor_ac( WP_REST_Request $req ) {
	$org = sides_org_id();
	$d   = sides_get_doc( $org, 'rapor', (string) $req['id'] );
	if ( ! $d || ! sides_rapor_gorebilir( $d ) ) {
		return new WP_Error( 'sides_yok', 'Rapor bulunamadı.', array( 'status' => 404 ) );
	}
	$d['id'] = (string) $req['id'];
	$res = rest_ensure_response( $d );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}

/* Dışa aktarma günlüğü: yalnızca gerçekten üretilen dosya için istemci çağırır */
function sides_rapor_disa( WP_REST_Request $req ) {
	$org = sides_org_id();
	if ( sides_is_observer() ) {
		return sides_deny( 'Gözlemci dosya indiremez.' );
	}
	$p   = $req->get_json_params();
	$tip = isset( $p['tip'] ) && in_array( $p['tip'], array( 'pdf', 'csv' ), true ) ? $p['tip'] : 'pdf';
	$b   = mb_substr( sanitize_text_field( (string) ( isset( $p['baslik'] ) ? $p['baslik'] : '' ) ), 0, 200 );
	sides_log( $org, 'Rapor dışa aktarıldı (' . strtoupper( $tip ) . '): ' . $b );
	return array( 'ok' => true );
}
