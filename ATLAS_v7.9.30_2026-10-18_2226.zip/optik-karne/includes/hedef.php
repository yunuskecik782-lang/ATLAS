<?php
/**
 * Hedefler (Takip Modülü): öğrenci ve yazılı bazlı hedefler ile afiş şablonları.
 *
 * Hedef ve şablon belgeleri kurum belgelerinde tutulur (coll: hedef, hsablon) ve genel /doc ve /koleksiyon uçlarıyla
 * okunup yazılır. Burada yalnızca kurum düzeyindeki hedef ayarları için (ders listesi, yazılı sütunu sayısı) takip
 * yazma yetkisiyle çalışan küçük bir uç vardır: settings/main belgesinin yalnızca hedefDersler ve hedefYazili alanları
 * değişir; diğer kurum ayarlarına dokunulmaz.
 *
 * POST /hedef/ayar  { hedefDersler?: [{ad, gizli}], hedefYazili?: 2..4, hedefVarsayilan?: şablon kimliği,
 *                     hedefKarne?: { mod: 'otomatik'|'elle', saat: { '5'..'8': { dersAdı: 0..10 | null } } } }
 *                   →  { hedefDersler, hedefYazili, hedefVarsayilan, hedefKarne }
 * hedefVarsayilan: yerleşik tasarımlardan biri (y-tablo … y-cerceve) ya da kurumun arşivlenmemiş bir hsablon belgesi.
 * hedefKarne kurum geneli bir ayardır: yalnızca sınıf kısıtı olmayan (yönetici ya da kurum geneli takip yazma yetkili)
 * kullanıcı değiştirebilir.
 *
 * KARNE HEDEFİ (v7): karne ortalaması, okullarda takdir/teşekkür için kullanılan ağırlıklı ortalamadır:
 *   Σ(ders puanı × haftalık ders saati) ÷ Σ haftalık ders saati  (dersin ağırlığı = haftalık ders saati).
 * Bir hedef belgesinde (öğrenci × yıl × dönem; 1. ve 2. dönem ayrı belgelerdir) her dersin dönem hedefi, o derse girilmiş
 * yazılı hedeflerinin ortalamasıdır (boş hücreler atlanır; yalnızca kurumun yazılı sütunu sayısı kadar sütun). Saati
 * bilinmeyen (boş) dersler hesaba girmez ve uyarı olarak listelenir; saati 0 olan ders sayılmaz. sides_hedef_karne() ile
 * istemcideki hdKarneHedef() (src/hedef.js) aynı sırayla aynı işlemleri yapar; ikisi aynı sonucu verir.
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

function sides_hedef_dersler_temizle( $l ) {
	$out  = array();
	$gor  = array();
	if ( ! is_array( $l ) ) {
		return $out;
	}
	foreach ( $l as $d ) {
		$ad = is_array( $d ) ? ( isset( $d['ad'] ) ? $d['ad'] : '' ) : $d;
		$ad = trim( wp_strip_all_tags( (string) $ad ) );
		$ad = function_exists( 'mb_substr' ) ? mb_substr( $ad, 0, 40 ) : substr( $ad, 0, 40 );
		if ( '' === $ad ) {
			continue;
		}
		$k = function_exists( 'mb_strtolower' ) ? mb_strtolower( $ad ) : strtolower( $ad );
		if ( isset( $gor[ $k ] ) ) {
			continue;
		}
		$gor[ $k ] = 1;
		$out[]     = array( 'ad' => $ad, 'gizli' => is_array( $d ) && ! empty( $d['gizli'] ) );
		if ( count( $out ) >= 30 ) {
			break;
		}
	}
	return $out;
}

/* ------------------------------------------------------------------ *
 * Karne hedefi: varsayılan haftalık ders saatleri (ortaokul, 2025-2026 eğitim yılından itibaren)
 * Kaynak: MEB Talim ve Terbiye Kurulu Başkanlığı'nın 9 Mayıs 2025 tarihli 4 sayılı kararı (ortaokul haftalık ders
 * çizelgesi), egitim.net.tr ve unirehberi.com aktarımıyla. Rehberlik dersleri not verilmediği için 0 (sayılmaz).
 * Seçmeli dersler (Kur'an-ı Kerim, Peygamberimizin Hayatı vb.) ve imam hatip dersleri okula göre değiştiği için
 * varsayılan saatleri YOKTUR; kurum Hedefler › Ayarlar'dan girer. Anahtarlar sides_hedef_ders_anahtar() çıktısıdır.
 * ------------------------------------------------------------------ */
function sides_hedef_karne_varsayilan() {
	$a = array( 'turkce' => 6, 'matematik' => 5, 'fen' => 4, 'sosyal' => 3, 'ingilizce' => 3, 'din' => 2, 'bilisim' => 2, 'beden' => 2, 'gorsel' => 1, 'muzik' => 1, 'rehberlik' => 0 );
	return array(
		'5' => $a,
		'6' => $a,
		'7' => array( 'turkce' => 5, 'matematik' => 5, 'fen' => 4, 'sosyal' => 3, 'ingilizce' => 4, 'din' => 2, 'teknoloji' => 2, 'beden' => 2, 'gorsel' => 1, 'muzik' => 1 ),
		'8' => array( 'turkce' => 5, 'matematik' => 5, 'fen' => 4, 'inkilap' => 2, 'ingilizce' => 4, 'din' => 2, 'teknoloji' => 2, 'beden' => 2, 'gorsel' => 1, 'muzik' => 1, 'rehberlik' => 0 ),
	);
}
function sides_hedef_karne_siniflar() {
	return array( '5', '6', '7', '8' );
}
/* Ders adını karşılaştırma için sadeleştirir: Türkçe küçük harf, aksansız, noktalama yerine boşluk (istemcide hdDersNorm). */
function sides_hedef_ders_norm( $ad ) {
	$s = strtr( trim( (string) $ad ), array( 'İ' => 'i', 'I' => 'ı' ) );
	$s = function_exists( 'mb_strtolower' ) ? mb_strtolower( $s, 'UTF-8' ) : strtolower( $s );
	$s = strtr( $s, array( 'ı' => 'i', 'ğ' => 'g', 'ü' => 'u', 'ş' => 's', 'ö' => 'o', 'ç' => 'c', 'â' => 'a', 'î' => 'i', 'û' => 'u', "\xCC\x87" => '' ) );
	$s = preg_replace( '/[^a-z0-9]+/', ' ', $s );
	return trim( preg_replace( '/\s+/', ' ', $s ) );
}
/* Eş anlamlı ders adları: İngilizce ≈ Yabancı Dil, Din Kültürü ≈ Din Kültürü ve Ahlak Bilgisi, Bilişim ≈ Bilişim
   Teknolojileri (ve Yazılım), İnkılap ≈ T.C. İnkılap Tarihi ve Atatürkçülük, Beden Eğitimi ≈ Beden Eğitimi ve Spor.
   Tam eşleşme aranır: "Matematik Uygulamaları" gibi seçmeli dersler Matematik sayılmaz. (istemcide HD_DERS_ES) */
function sides_hedef_ders_anahtar( $ad ) {
	static $es = array(
		'turkce'    => '/^turkce$/',
		'matematik' => '/^matematik$/',
		'fen'       => '/^fen( bilimleri)?$/',
		'sosyal'    => '/^sosyal( bilgiler)?$/',
		'ingilizce' => '/^(ingilizce|yabanci dil)( (ingilizce|yabanci dil))?$/',
		'din'       => '/^(din( kulturu( ve ahlak bilgisi)?)?|dkab)$/',
		'bilisim'   => '/^bilisim( teknolojileri( ve yazilim)?)?$/',
		'beden'     => '/^beden egitimi( ve spor)?$/',
		'gorsel'    => '/^gorsel sanatlar$/',
		'muzik'     => '/^muzik$/',
		'teknoloji' => '/^teknoloji ve tasarim$/',
		'inkilap'   => '/^((t c|tc) )?inkilap( tarihi( ve ataturkculuk)?)?$/',
		'rehberlik' => '/^rehberlik( ve (yonlendirme|kariyer planlama))?$/',
	);
	$n = sides_hedef_ders_norm( $ad );
	foreach ( $es as $k => $re ) {
		if ( preg_match( $re, $n ) ) {
			return $k;
		}
	}
	return '';
}
/* Sınıf düzeyi: '5'..'8' ya da '' (Nehari 3, 4, N5 ve bilinmeyen sınıflar için tablo yoktur). */
function sides_hedef_karne_sinif( $sinif ) {
	return preg_match( '/^\s*([5-8])(?![0-9])/', (string) $sinif, $m ) ? $m[1] : '';
}
/* 0–100 arası puan, bir ondalığa yuvarlanmış (istemcide hdKSayi); geçersiz/boş → null */
function sides_hedef_karne_sayi( $v ) {
	if ( is_int( $v ) || is_float( $v ) ) {
		$n = (float) $v;
	} elseif ( is_string( $v ) && preg_match( '/^-?\d+(\.\d+)?$/', str_replace( ',', '.', trim( $v ) ) ) ) {
		$n = (float) str_replace( ',', '.', trim( $v ) );
	} else {
		return null;
	}
	if ( ! is_finite( $n ) ) {
		return null;
	}
	$n = max( 0, min( 100, $n ) );
	return floor( $n * 10 + 0.5 ) / 10;
}
function sides_hedef_karne_yuvarla( $x ) {
	return floor( $x * 100 + 0.5 + 1e-9 ) / 100;
}
/* Ayar temizliği: mod ∈ {otomatik, elle} (varsayılan otomatik); saat[sınıf][ders] ∈ 0..10 tamsayı ya da null (bilinmiyor) */
function sides_hedef_karne_ayar_temizle( $a ) {
	$a   = is_array( $a ) ? $a : array();
	$out = array( 'mod' => ( isset( $a['mod'] ) && 'elle' === $a['mod'] ) ? 'elle' : 'otomatik', 'saat' => array() );
	$S   = isset( $a['saat'] ) && is_array( $a['saat'] ) ? $a['saat'] : array();
	foreach ( sides_hedef_karne_siniflar() as $g ) {
		if ( ! isset( $S[ $g ] ) || ! is_array( $S[ $g ] ) ) {
			continue;
		}
		$t = array();
		foreach ( array_slice( $S[ $g ], 0, 40, true ) as $ad => $v ) {
			$ad = (string) $ad;
			if ( '' === trim( $ad ) ) {
				continue;
			}
			if ( null === $v || '' === $v ) {
				$t[ $ad ] = null;
			} elseif ( is_numeric( $v ) && (float) $v >= 0 && (float) $v <= 10 ) {
				$t[ $ad ] = (int) round( (float) $v );
			}
		}
		$out['saat'][ $g ] = $t;
	}
	return $out;
}
/* Kurumun karne ayarı (istek boyunca önbellekte; $taze ile yenilenir) */
function sides_hedef_karne_ayar( $org, $taze = false ) {
	static $c = array();
	$org = (int) $org;
	if ( $taze || ! isset( $c[ $org ] ) ) {
		$s         = sides_get_doc( $org, 'settings', 'main' );
		$s         = is_array( $s ) ? $s : array();
		$a         = sides_hedef_karne_ayar_temizle( isset( $s['hedefKarne'] ) ? $s['hedefKarne'] : null );
		$n         = isset( $s['hedefYazili'] ) ? (int) $s['hedefYazili'] : 2;
		$a['N']    = max( 2, min( 4, $n ? $n : 2 ) );
		$c[ $org ] = $a;
	}
	return $c[ $org ];
}
/* Bir dersin haftalık saati: kurum tablosu (tam ad → sade ad → eş anlamlı) yoksa varsayılan tablo; bilinmiyorsa null */
function sides_hedef_karne_saat( $ayar, $g, $ad ) {
	$tab = isset( $ayar['saat'][ $g ] ) && is_array( $ayar['saat'][ $g ] ) ? $ayar['saat'][ $g ] : null;
	$k   = sides_hedef_ders_anahtar( $ad );
	if ( $tab ) {
		if ( array_key_exists( $ad, $tab ) ) {
			return $tab[ $ad ];
		}
		$n = sides_hedef_ders_norm( $ad );
		foreach ( $tab as $ad2 => $v ) {
			if ( sides_hedef_ders_norm( $ad2 ) === $n ) {
				return $v;
			}
		}
		if ( '' !== $k ) {
			foreach ( $tab as $ad2 => $v ) {
				if ( sides_hedef_ders_anahtar( $ad2 ) === $k ) {
					return $v;
				}
			}
		}
	}
	$d = sides_hedef_karne_varsayilan();
	return '' !== $k && isset( $d[ $g ][ $k ] ) ? $d[ $g ][ $k ] : null;
}
/* Ayrıntılı hesap: { deger: float|null, dokum: [{ders, hedef, saat}], eksikSaat: [ders], sayilmayan: [ders], sinifYok: bool } */
function sides_hedef_karne_hesap( $ayar, $doc, $sinif ) {
	$r = array( 'deger' => null, 'dokum' => array(), 'eksikSaat' => array(), 'sayilmayan' => array(), 'sinifYok' => false );
	$g = sides_hedef_karne_sinif( $sinif );
	if ( '' === $g ) {
		$r['sinifYok'] = true;
		return $r;
	}
	$N    = isset( $ayar['N'] ) ? max( 2, min( 4, (int) $ayar['N'] ) ) : 2;
	$pay  = 0;
	$payd = 0;
	foreach ( isset( $doc['dersler'] ) && is_array( $doc['dersler'] ) ? array_values( $doc['dersler'] ) : array() as $d ) {
		$ad = is_array( $d ) && isset( $d['ad'] ) ? trim( (string) $d['ad'] ) : '';
		if ( '' === $ad ) {
			continue;
		}
		$t = 0;
		$n = 0;
		for ( $i = 1; $i <= $N; $i++ ) {
			$v = sides_hedef_karne_sayi( isset( $d[ 'h' . $i ] ) ? $d[ 'h' . $i ] : null );
			if ( null !== $v ) {
				$t += $v;
				$n++;
			}
		}
		if ( ! $n ) {
			continue;
		}
		$dh   = $t / $n;
		$saat = sides_hedef_karne_saat( $ayar, $g, $ad );
		if ( null === $saat ) {
			$r['eksikSaat'][] = $ad;
			continue;
		}
		if ( $saat <= 0 ) {
			$r['sayilmayan'][] = $ad;
			continue;
		}
		$pay          += $dh * $saat;
		$payd         += $saat;
		$r['dokum'][]  = array( 'ders' => $ad, 'hedef' => sides_hedef_karne_yuvarla( $dh ), 'saat' => (int) $saat );
	}
	if ( $payd > 0 ) {
		$r['deger'] = sides_hedef_karne_yuvarla( $pay / $payd );
	}
	return $r;
}
/**
 * SÖZLEŞME (TV ve diğer sunucu çağıranları): bir hedef belgesinin karne hedefi.
 * Otomatik kipte ağırlıklı ortalama (float, 2 ondalık) ya da hesaplanamıyorsa null; kurum "Elle" kipini seçtiyse
 * belgede elle saklanan değer (yoksa null). $sinif öğrencinin o yılki sınıfı ('7', '8' …).
 */
function sides_hedef_karne( $org, $hedefDoc, $sinif ) {
	if ( ! is_array( $hedefDoc ) ) {
		return null;
	}
	$a = sides_hedef_karne_ayar( $org );
	if ( 'elle' === $a['mod'] ) {
		return sides_hedef_karne_sayi( isset( $hedefDoc['karne'] ) ? $hedefDoc['karne'] : null );
	}
	$r = sides_hedef_karne_hesap( $a, $hedefDoc, $sinif );
	if ( null === $r['deger'] ) {   // v7.0.8: ders hedefi yoksa elle girilmiş karne hedefi kullanılır (kaybolmaz)
		return sides_hedef_karne_sayi( isset( $hedefDoc['karne'] ) ? $hedefDoc['karne'] : null );
	}
	return $r['deger'];
}

function sides_hedef_ayar( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	if ( ! is_array( $p ) ) {
		$p = array();
	}
	$s = sides_get_doc( $org, 'settings', 'main' );
	if ( ! is_array( $s ) ) {
		$s = array();
	}
	unset( $s['id'] );
	$degisti = array();
	if ( array_key_exists( 'hedefDersler', $p ) ) {
		$l = sides_hedef_dersler_temizle( $p['hedefDersler'] );
		if ( ! $l ) {
			return new WP_Error( 'sides_hedef', 'Ders listesi boş olamaz.', array( 'status' => 400 ) );
		}
		$s['hedefDersler'] = $l;
		$degisti[]         = 'ders listesi';
	}
	if ( array_key_exists( 'hedefYazili', $p ) ) {
		$n = (int) $p['hedefYazili'];
		if ( $n < 2 || $n > 4 ) {
			return new WP_Error( 'sides_hedef', 'Yazılı sütunu sayısı 2 ile 4 arasında olmalı.', array( 'status' => 400 ) );
		}
		$s['hedefYazili'] = $n;
		$degisti[]        = 'yazılı sütunu sayısı';
	}
	if ( array_key_exists( 'hedefVarsayilan', $p ) ) {
		$v      = (string) $p['hedefVarsayilan'];
		$yerles = array( 'y-tablo', 'y-kart', 'y-iki', 'y-rota', 'y-basamak', 'y-odak', 'y-karne', 'y-kontrol', 'y-cizgi', 'y-cerceve' );
		if ( ! in_array( $v, $yerles, true ) ) {
			if ( ! preg_match( '/^[A-Za-z0-9_\-]{1,64}$/', $v ) ) {
				return new WP_Error( 'sides_hedef', 'Geçersiz şablon kimliği.', array( 'status' => 400 ) );
			}
			$sab = sides_get_doc( $org, 'hsablon', $v );
			if ( ! is_array( $sab ) || ! empty( $sab['arsiv'] ) ) {
				return new WP_Error( 'sides_hedef', 'Şablon bulunamadı ya da arşivde.', array( 'status' => 400 ) );
			}
		}
		$s['hedefVarsayilan'] = $v;
		$degisti[]            = 'varsayılan şablon (' . $v . ')';
	}
	if ( array_key_exists( 'hedefKarne', $p ) ) {   // v7: karne hedefi kipi ve ders saatleri (kurum geneli)
		if ( null !== sides_sinif_kisit() || ( function_exists( 'sides_sayfa_herhangi' ) && ! sides_sayfa_herhangi( array( 'takip.hedef' ), 2 ) ) ) {
			return new WP_Error( 'sides_yetki', 'Karne hedefi ayarı kurum geneli bir ayardır; sınıf kısıtı olan kullanıcı değiştiremez.', array( 'status' => 403 ) );
		}
		$k = $p['hedefKarne'];
		if ( ! is_array( $k ) ) {
			return new WP_Error( 'sides_hedef', 'Geçersiz karne hedefi ayarı.', array( 'status' => 400 ) );
		}
		$eski = sides_hedef_karne_ayar_temizle( isset( $s['hedefKarne'] ) ? $s['hedefKarne'] : null );
		if ( array_key_exists( 'mod', $k ) ) {
			if ( ! in_array( $k['mod'], array( 'otomatik', 'elle' ), true ) ) {
				return new WP_Error( 'sides_hedef', 'Karne hedefi kipi "otomatik" ya da "elle" olmalı.', array( 'status' => 400 ) );
			}
			$eski['mod'] = $k['mod'];
		}
		if ( array_key_exists( 'saat', $k ) ) {
			if ( ! is_array( $k['saat'] ) ) {
				return new WP_Error( 'sides_hedef', 'Ders saatleri tablosu geçersiz.', array( 'status' => 400 ) );
			}
			$liste = isset( $s['hedefDersler'] ) && is_array( $s['hedefDersler'] ) && $s['hedefDersler'] ? $s['hedefDersler'] : array( array( 'ad' => 'Türkçe' ), array( 'ad' => 'Matematik' ), array( 'ad' => 'Fen Bilimleri' ), array( 'ad' => 'Sosyal Bilgiler' ), array( 'ad' => 'İngilizce' ) );
			$izin  = array();
			foreach ( $liste as $d ) {
				$izin[ (string) ( is_array( $d ) && isset( $d['ad'] ) ? $d['ad'] : '' ) ] = true;
			}
			foreach ( $k['saat'] as $g => $tab ) {
				$g = (string) $g;
				if ( ! in_array( $g, sides_hedef_karne_siniflar(), true ) ) {
					return new WP_Error( 'sides_hedef', 'Ders saati tablosunda geçersiz sınıf: ' . sanitize_text_field( $g ) . ' (yalnızca 5, 6, 7, 8).', array( 'status' => 400 ) );
				}
				if ( ! is_array( $tab ) ) {
					return new WP_Error( 'sides_hedef', $g . '. sınıf ders saatleri geçersiz.', array( 'status' => 400 ) );
				}
				$yeni = array();
				foreach ( $tab as $ad => $v ) {
					$ad = (string) $ad;
					if ( ! isset( $izin[ $ad ] ) ) {
						return new WP_Error( 'sides_hedef', 'Ders kurum hedef listesinde yok: ' . sanitize_text_field( $ad ), array( 'status' => 400 ) );
					}
					if ( null === $v || '' === $v ) {
						$yeni[ $ad ] = null;
						continue;
					}
					if ( ! is_numeric( $v ) || (float) $v < 0 || (float) $v > 10 || floor( (float) $v ) !== (float) $v ) {
						return new WP_Error( 'sides_hedef', $g . '. sınıf ' . sanitize_text_field( $ad ) . ': ders saati 0 ile 10 arasında tam sayı olmalı.', array( 'status' => 400 ) );
					}
					$yeni[ $ad ] = (int) $v;
				}
				$eski['saat'][ $g ] = $yeni;
			}
		}
		$s['hedefKarne'] = $eski;
		$degisti[]       = 'karne hedefi (' . ( 'elle' === $eski['mod'] ? 'elle' : 'otomatik, ders saatine göre' ) . ')';
	}
	if ( array_key_exists( 'hedefKart', $p ) ) {   // v7.2: veliye gönderilen hedef kartının stili (kurum geneli)
		if ( null !== sides_sinif_kisit() || ( function_exists( 'sides_sayfa_herhangi' ) && ! sides_sayfa_herhangi( array( 'takip.hedef' ), 2 ) ) ) {
			return new WP_Error( 'sides_yetki', 'Kart stili kurum geneli bir ayardır; sınıf kısıtı olan kullanıcı değiştiremez.', array( 'status' => 403 ) );
		}
		$k = $p['hedefKart'];
		if ( ! is_array( $k ) ) {
			return new WP_Error( 'sides_hedef', 'Geçersiz kart stili.', array( 'status' => 400 ) );
		}
		$t = sides_hedef_kart_temizle( $k, $hata );
		if ( $hata ) {
			return new WP_Error( 'sides_hedef', 'Kart stili geçersiz: ' . $hata, array( 'status' => 400 ) );
		}
		$s['hedefKart'] = $t;
		$degisti[]      = 'veli kartı (' . $t['stil'] . ', ' . $t['boyut'] . ', ' . $t['zemin'] . ', ' . $t['desen'] . ', ' . $t['kagit'] . ( '' !== $t['mesaj'] ? ', mesaj şablonu' : '' ) . ')';
	}
	if ( ! $degisti ) {
		return new WP_Error( 'sides_hedef', 'Değiştirilecek ayar gönderilmedi.', array( 'status' => 400 ) );
	}
	if ( false === sides_put_doc( $org, 'settings', 'main', $s ) ) {
		return new WP_Error( 'sides_db', 'Ayar kaydedilemedi.', array( 'status' => 500 ) );
	}
	sides_log( $org, 'Hedef ayarları güncellendi: ' . implode( ', ', $degisti ) );
	sides_hedef_karne_ayar( $org, true );
	$hk = sides_hedef_karne_ayar_temizle( isset( $s['hedefKarne'] ) ? $s['hedefKarne'] : null );
	$res = rest_ensure_response( array(
		'hedefDersler' => isset( $s['hedefDersler'] ) ? $s['hedefDersler'] : array(),
		'hedefYazili'  => isset( $s['hedefYazili'] ) ? (int) $s['hedefYazili'] : 2,
		'hedefVarsayilan' => isset( $s['hedefVarsayilan'] ) ? (string) $s['hedefVarsayilan'] : 'y-tablo',
		'hedefKarne'   => array( 'mod' => $hk['mod'], 'saat' => $hk['saat'] ? $hk['saat'] : new stdClass() ),
		'hedefKart'    => sides_hedef_kart_temizle( isset( $s['hedefKart'] ) ? $s['hedefKart'] : null, $bos ),
	) );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}

/* ------------------------------------------------------------------ *
 * v7.2 Veliye gönderilen hedef kartı (src/hedefkart.js)
 * - GET  /hedef/kart-ayar  → { esik, adlar, cerceve, desen, zemin, zirve, zirveAd, zirveStil, kart }: panonun Hedefler ayarındaki
 *        seviye eşikleri, adları, çerçeve/desen/zemin ve v7.7 "zirve" (100) seviyesi (tv/ayar.hedef; sides_tv_hedef_ayar_temiz ile
 *        aynı temizlik; alanlar yoksa varsayılan zirve 1, 'Zirve', 'isik') + kurumun kart ayarı (settings.hedefKart: stil
 *        minimal|serit|bolunmus|kartlar|mono|yumusak|grafit (sade ve modern) | berat|diploma|gece|modern|pastel|cini|metal|defne|kalkan|
 *        kristal|sade (klasik ve süslü), kayıt yoksa 'minimal'; boyut dikey|kare|a4, zemin, desen, kagit a4|a5, mesaj şablonu). Takip ≥ 1.
 * - POST /hedef/gonderim   { id | ids: [...], kanal: whatsapp|paylas|indir|toplu|yazdir, islemId } → gönderim kaydı hedef belgesine
 *        eklenir: gonderimler: [{ t, u, ad, kanal, islemId }] (son 30) ve işlem günlüğüne "Veli kartı hazırlandı" yazılır.
 *        Takip ≥ 2, gözlemci değil, sınıf kısıtı uygulanır, aynı islemId ikinci kez yazılmaz (günlüğe de bir kez düşer).
 *        Sunucu hiçbir mesaj göndermez; gönderim kullanıcının cihazından (paylaşım / WhatsApp) yapılır.
 * ------------------------------------------------------------------ */
function sides_hedef_kart_temizle( $k, &$hata ) {
	$hata = '';
	$k    = is_array( $k ) ? $k : array();
	if ( isset( $k['boyut'] ) && 'uzun' === $k['boyut'] ) {   // v7.2 ilk sürümündeki 9:16 boyutu kaldırıldı
		$k['boyut'] = 'dikey';
	}
	$sec  = array( 'stil' => array( 'minimal', 'serit', 'bolunmus', 'kartlar', 'mono', 'yumusak', 'grafit', 'berat', 'diploma', 'gece', 'modern', 'pastel', 'cini', 'metal', 'defne', 'kalkan', 'kristal', 'sade' ), 'boyut' => array( 'dikey', 'kare', 'a4' ), 'zemin' => array( 'krem', 'beyaz', 'mavi', 'yesil', 'lila', 'kagit' ), 'desen' => array( 'sade', 'nokta', 'cizgi', 'geo', 'yildiz', 'dalga' ), 'kagit' => array( 'a4', 'a5' ) );   // v7.7: sade ve modern şablonlar (7) + süslü şablonlar (11), A4 baskı boyutu, baskı kâğıdı
	$o    = array( 'stil' => 'minimal', 'boyut' => 'dikey', 'zemin' => 'krem', 'desen' => 'sade', 'kagit' => 'a4', 'mesaj' => '' );   // kayıt yoksa ilk sade şablon (kayıtlı şablon aynen kalır)
	foreach ( array_keys( $k ) as $a ) {
		if ( 'mesaj' !== $a && ! isset( $sec[ (string) $a ] ) ) {
			$hata = 'bilinmeyen alan ' . sanitize_text_field( (string) $a );
			return $o;
		}
	}
	if ( array_key_exists( 'mesaj', $k ) ) {   // WhatsApp mesaj şablonu: düz metin, satır sonu serbest, etiket yok, en çok 600 karakter
		$m = $k['mesaj'];
		if ( null !== $m && ! is_string( $m ) ) {
			$hata = 'mesaj metin olmalı';
			return $o;
		}
		$m = str_replace( "\r\n", "\n", (string) $m );
		if ( preg_match( '/[<>\x00-\x09\x0b-\x1f]/', $m ) ) {
			$hata = 'mesajda etiket ya da denetim karakteri olamaz';
			return $o;
		}
		if ( mb_strlen( $m ) > 600 ) {
			$hata = 'mesaj en çok 600 karakter olabilir';
			return $o;
		}
		$o['mesaj'] = trim( $m );
	}
	foreach ( $sec as $a => $L ) {
		if ( array_key_exists( $a, $k ) ) {
			if ( ! is_string( $k[ $a ] ) || ! in_array( $k[ $a ], $L, true ) ) {
				$hata = $a . ' değeri geçersiz';
				return $o;
			}
			$o[ $a ] = $k[ $a ];
		}
	}
	return $o;
}
/* v7.7 zirve (karne hedefi 100) alanları: $h pano temizliğinden geçmiş ayar; temizlik bu alanları döndürmüyorsa $ham (kayıt) aynı
   kurallarla okunur; geçersiz ya da yoksa varsayılan (1, 'Zirve', 'isik') */
function sides_hedef_kart_zirve( $h, $ham ) {
	$h   = is_array( $h ) ? $h : array();
	$ham = is_array( $ham ) ? $ham : array();
	$al  = function ( $a ) use ( $h, $ham ) {
		return array_key_exists( $a, $h ) ? $h[ $a ] : ( array_key_exists( $a, $ham ) ? $ham[ $a ] : null );
	};
	$z  = in_array( $al( 'zirve' ), array( 0, false, '0' ), true ) ? 0 : 1;
	$za = $al( 'zirveAd' );
	$za = is_string( $za ) ? trim( $za ) : '';
	if ( '' === $za || mb_strlen( $za ) > 20 || preg_match( '/[<>\x00-\x1f\x7f]/', $za ) ) {
		$za = 'Zirve';
	}
	$zs = $al( 'zirveStil' );
	$zs = is_string( $zs ) && in_array( $zs, array( 'isik', 'zumrut', 'muhur', 'kristal' ), true ) ? $zs : 'isik';
	return array( 'zirve' => $z, 'zirveAd' => $za, 'zirveStil' => $zs );
}
function sides_hedef_kart_ayar( WP_REST_Request $req ) {
	$org = sides_org_id();
	$tv  = sides_get_doc( $org, 'tv', 'ayar' );
	$h   = is_array( $tv ) && isset( $tv['hedef'] ) ? $tv['hedef'] : null;
	$hata = array();
	if ( function_exists( 'sides_tv_hedef_ayar_temiz' ) ) {
		$h = sides_tv_hedef_ayar_temiz( $h, $hata );
	} else {
		$h = is_array( $h ) ? $h : array();
	}
	$set = sides_get_doc( $org, 'settings', 'main' );
	$bos = '';
	$zv  = sides_hedef_kart_zirve( $h, is_array( $tv ) && isset( $tv['hedef'] ) && is_array( $tv['hedef'] ) ? $tv['hedef'] : array() );
	$res = rest_ensure_response( array(
		'esik'    => isset( $h['esik'] ) && is_array( $h['esik'] ) ? array_values( array_map( 'intval', $h['esik'] ) ) : array( 70, 80, 90, 95 ),
		'adlar'   => isset( $h['adlar'] ) && is_array( $h['adlar'] ) ? array_values( array_map( 'strval', $h['adlar'] ) ) : array( 'Bronz', 'Gümüş', 'Altın', 'Platin', 'Elmas' ),
		'cerceve' => isset( $h['cerceve'] ) ? (string) $h['cerceve'] : 'metal',
		'desen'   => isset( $h['desen'] ) ? (string) $h['desen'] : 'sade',
		'zemin'   => isset( $h['zemin'] ) ? (string) $h['zemin'] : 'krem',
		'zirve'     => $zv['zirve'],
		'zirveAd'   => $zv['zirveAd'],
		'zirveStil' => $zv['zirveStil'],
		'kart'    => sides_hedef_kart_temizle( is_array( $set ) && isset( $set['hedefKart'] ) ? $set['hedefKart'] : null, $bos ),
	) );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}
function sides_hedef_gonderim( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	if ( ! is_array( $p ) ) {
		$p = array();
	}
	$ids = isset( $p['ids'] ) && is_array( $p['ids'] ) ? $p['ids'] : ( isset( $p['id'] ) ? array( $p['id'] ) : array() );
	$ids = array_values( array_unique( array_map( 'strval', $ids ) ) );
	if ( ! $ids || count( $ids ) > 100 ) {
		return new WP_Error( 'sides_hedef', 'Hedef kimliği gönderilmedi (en çok 100).', array( 'status' => 400 ) );
	}
	$kanal = isset( $p['kanal'] ) ? (string) $p['kanal'] : '';
	if ( ! in_array( $kanal, array( 'whatsapp', 'paylas', 'indir', 'toplu', 'yazdir' ), true ) ) {   // v7.7: yazdir = Yazdır / PDF (tek ya da toplu)
		return new WP_Error( 'sides_hedef', 'Gönderim kanalı geçersiz.', array( 'status' => 400 ) );
	}
	$islem = isset( $p['islemId'] ) && is_string( $p['islemId'] ) && preg_match( '/^[A-Za-z0-9_\-]{4,40}$/', $p['islemId'] ) ? $p['islemId'] : '';
	if ( '' === $islem ) {
		return new WP_Error( 'sides_hedef', 'islemId gerekli.', array( 'status' => 400 ) );
	}
	$izin = function_exists( 'sides_takip_izin' ) ? sides_takip_izin( $org ) : null;
	$u    = wp_get_current_user();
	$kayit = array( 't' => time(), 'u' => (int) ( $u ? $u->ID : 0 ), 'ad' => $u && $u->ID ? mb_substr( (string) $u->display_name, 0, 60 ) : '', 'kanal' => $kanal, 'islemId' => $islem );
	$out  = array();
	$adlar = array();
	foreach ( $ids as $id ) {
		if ( ! preg_match( '/^h_([A-Za-z0-9_\-]+)_(\d{4})_([12])$/', $id, $m ) ) {
			return new WP_Error( 'sides_hedef', 'Geçersiz hedef kimliği.', array( 'status' => 400 ) );
		}
		$kilit = function_exists( 'sides_takip_kilit' ) ? sides_takip_kilit( $org . '|hedef|' . $id ) : '';
		if ( false === $kilit ) {
			return function_exists( 'sides_kilit_mesgul' ) ? sides_kilit_mesgul() : new WP_Error( 'sides_mesgul', 'Kayıt şu anda güncelleniyor; tekrar deneyin.', array( 'status' => 503 ) );
		}
		$d = sides_get_doc( $org, 'hedef', $id );
		$sid = is_array( $d ) && isset( $d['studentId'] ) ? (string) $d['studentId'] : '';
		if ( ! is_array( $d ) || '' === $sid || $sid !== $m[1] || ( null !== $izin && ! isset( $izin[ $sid ] ) ) ) {
			if ( function_exists( 'sides_takip_kilit_birak' ) ) {
				sides_takip_kilit_birak( $kilit );
			}
			return new WP_Error( 'sides_yok', 'Hedef bulunamadı ya da bu öğrenci sınıf yetkinizin dışında.', array( 'status' => 404 ) );
		}
		unset( $d['id'] );
		$L = isset( $d['gonderimler'] ) && is_array( $d['gonderimler'] ) ? array_values( $d['gonderimler'] ) : array();
		$var = false;
		foreach ( $L as $g ) {
			if ( is_array( $g ) && isset( $g['islemId'] ) && $g['islemId'] === $islem ) {
				$var = true;
				break;
			}
		}
		if ( ! $var ) {
			$L[] = $kayit;
			$L   = array_slice( $L, -30 );
			$d['gonderimler'] = $L;
			if ( false === sides_put_doc( $org, 'hedef', $id, $d ) ) {
				if ( function_exists( 'sides_takip_kilit_birak' ) ) {
					sides_takip_kilit_birak( $kilit );
				}
				return new WP_Error( 'sides_db', 'Gönderim kaydedilemedi.', array( 'status' => 500 ) );
			}
			$ogr = sides_get_doc( $org, 'students', $sid );
			$adlar[] = is_array( $ogr ) && isset( $ogr['ad'] ) ? (string) $ogr['ad'] : $sid;
		}
		if ( function_exists( 'sides_takip_kilit_birak' ) ) {
			sides_takip_kilit_birak( $kilit );
		}
		$out[ $id ] = $L;
	}
	if ( $adlar ) {
		sides_log( $org, 'Veli kartı hazırlandı (' . $kanal . '): ' . implode( ', ', array_slice( $adlar, 0, 8 ) ) . ( count( $adlar ) > 8 ? ' … (' . count( $adlar ) . ' öğrenci)' : '' ) );
	}
	$res = rest_ensure_response( array( 'gonderimler' => $out ) );
	$res->header( 'Cache-Control', 'no-store' );
	return $res;
}

add_action( 'rest_api_init', function () {
	register_rest_route( 'optik-karne/v1', '/hedef/ayar', array(
		'methods'             => 'POST',
		'callback'            => 'sides_hedef_ayar',
		'permission_callback' => function () {
			if ( sides_is_observer() ) {
				return sides_deny( 'Gözlemci hesabının işlem yetkisi yok. Yöneticinizden izin isteyin.' );
			}
			return sides_can( 'takip', 2 ) ? true : sides_deny( 'Takip modülünde değişiklik yapma yetkiniz yok.' );
		},
	) );
	register_rest_route( 'optik-karne/v1', '/hedef/kart-ayar', array(   // v7.2: veli kartı seviye/çerçeve ayarı (okuma)
		'methods'             => 'GET',
		'callback'            => 'sides_hedef_kart_ayar',
		'permission_callback' => function () {
			return sides_can( 'takip', 1 ) ? true : sides_deny( 'Takip modülünü görüntüleme yetkiniz yok.' );
		},
	) );
	register_rest_route( 'optik-karne/v1', '/hedef/gonderim', array(   // v7.2: veliye gönderim kaydı
		'methods'             => 'POST',
		'callback'            => 'sides_hedef_gonderim',
		'permission_callback' => function () {
			if ( sides_is_observer() ) {
				return sides_deny( 'Gözlemci hesabı veliye gönderim yapamaz.' );
			}
			return sides_can( 'takip', 2 ) ? true : sides_deny( 'Takip modülünde değişiklik yapma yetkiniz yok.' );
		},
	) );
} );
