<?php
/**
 * ATLAS yapay zekâ ile soru üretimi (Anthropic Claude API).
 *
 * API anahtarını yalnızca ana hesap girer; anahtar tarayıcıya hiç gönderilmez. Kurumlar kendi aylık soru sınırları
 * içinde soru üretir. Yapay zekâya öğrenci bilgisi gönderilmez; yalnızca ders, sınıf, konu, zorluk ve öğretmenin notu gider.
 *
 * @package SIDES
 */

defined( 'ABSPATH' ) || exit;

define( 'SIDES_AI_MODELLER', array( 'claude-sonnet-5', 'claude-opus-5-5', 'claude-haiku-4-5-20251001', 'claude-fable-5-1' ) );

function sides_ai_ayar() {
	$a = get_option( 'sides_ai' );
	$a = is_array( $a ) ? $a : array();
	return array(
		'anahtar' => isset( $a['anahtar'] ) ? (string) $a['anahtar'] : '',
		'model'   => ! empty( $a['model'] ) ? (string) $a['model'] : 'claude-sonnet-5',
		'sinir'   => isset( $a['sinir'] ) ? max( 0, (int) $a['sinir'] ) : 300,
		'acik'    => isset( $a['acik'] ) ? (bool) $a['acik'] : true,
	);
}
function sides_ai_kullanim( $org = null ) {
	$k = get_option( 'sides_ai_kullanim' );
	$k = is_array( $k ) ? $k : array();
	$ay = gmdate( 'Y-m' );
	$bu = isset( $k[ $ay ] ) ? $k[ $ay ] : array();
	return null === $org ? $bu : ( isset( $bu[ $org ] ) ? (int) $bu[ $org ] : 0 );
}
function sides_ai_say( $org, $n ) {
	$k  = get_option( 'sides_ai_kullanim' );
	$k  = is_array( $k ) ? $k : array();
	$ay = gmdate( 'Y-m' );
	$k[ $ay ][ $org ] = ( isset( $k[ $ay ][ $org ] ) ? (int) $k[ $ay ][ $org ] : 0 ) + $n;
	$k = array_slice( $k, -6, null, true );
	update_option( 'sides_ai_kullanim', $k, false );
}
/* Kuruma gösterilen durum (anahtar asla gönderilmez) */
function sides_ai_durum( $org ) {
	$a = sides_ai_ayar();
	$u = sides_ai_kullanim( $org );
	return array( 'acik' => $a['acik'] && '' !== $a['anahtar'], 'sinir' => $a['sinir'], 'kullanilan' => $u, 'kalan' => $a['sinir'] ? max( 0, $a['sinir'] - $u ) : null );
}

/* Anthropic Messages API çağrısı; yanıt JSON şemasına uygun metin olarak döner */
function sides_ai_istek( $a, $system, $prompt, $schema, $max_tokens = 8000 ) {
	$body = array(
		'model'      => $a['model'],
		'max_tokens' => $max_tokens,
		'messages'   => array( array( 'role' => 'user', 'content' => $prompt ) ),
	);
	if ( $system ) {
		$body['system'] = $system;
	}
	if ( $schema ) {
		$body['output_config'] = array( 'format' => array( 'type' => 'json_schema', 'schema' => $schema ) );
	}
	$r = wp_remote_post( 'https://api.anthropic.com/v1/messages', array(
		'timeout' => 150,
		'headers' => array( 'x-api-key' => $a['anahtar'], 'anthropic-version' => '2023-06-01', 'content-type' => 'application/json' ),
		'body'    => wp_json_encode( $body ),
	) );
	if ( is_wp_error( $r ) ) {
		return new WP_Error( 'sides_ai', 'Yapay zekâ servisine bağlanılamadı: ' . $r->get_error_message(), array( 'status' => 502 ) );
	}
	$kod = (int) wp_remote_retrieve_response_code( $r );
	$j   = json_decode( wp_remote_retrieve_body( $r ), true );
	if ( 200 !== $kod ) {
		$tip = isset( $j['error']['type'] ) ? $j['error']['type'] : '';
		$m   = array(
			'authentication_error' => 'API anahtarı geçersiz. Ana hesap, Ana Hesap > Yapay Zekâ sayfasından anahtarı kontrol etmeli.',
			'permission_error'     => 'API anahtarının bu modeli kullanma izni yok.',
			'not_found_error'      => 'Seçilen model bulunamadı. Ana Hesap > Yapay Zekâ sayfasından başka bir model seçin.',
			'rate_limit_error'     => 'Yapay zekâ servisinin kullanım sınırına ulaşıldı. Biraz sonra tekrar deneyin.',
			'overloaded_error'     => 'Yapay zekâ servisi şu an yoğun. Biraz sonra tekrar deneyin.',
			'billing_error'        => 'Yapay zekâ hesabında bakiye veya ödeme sorunu var. Ana hesap, Anthropic hesabını kontrol etmeli.',
		);
		$msg = isset( $m[ $tip ] ) ? $m[ $tip ] : 'Yapay zekâ servisi hata verdi (' . $kod . ')' . ( isset( $j['error']['message'] ) ? ': ' . $j['error']['message'] : '' );
		return new WP_Error( 'sides_ai', $msg, array( 'status' => 502 ) );
	}
	$txt = '';
	foreach ( (array) ( isset( $j['content'] ) ? $j['content'] : array() ) as $blok ) {
		if ( isset( $blok['type'] ) && 'text' === $blok['type'] ) {
			$txt .= $blok['text'];
		}
	}
	if ( isset( $j['stop_reason'] ) && 'max_tokens' === $j['stop_reason'] ) {
		return new WP_Error( 'sides_ai', 'Yanıt yarım kaldı; daha az soru isteyin.', array( 'status' => 502 ) );
	}
	return $txt;
}

function sides_ai_soru_semasi() {
	return array(
		'type'                 => 'object',
		'properties'           => array(
			'sorular' => array(
				'type'  => 'array',
				'items' => array(
					'type'                 => 'object',
					'properties'           => array(
						'soru'       => array( 'type' => 'string', 'description' => 'Soru kökü; gerekiyorsa kısa bir metin, tablo yerine düz metin.' ),
						'secenekler' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ), 'description' => 'Seçenek metinleri, harfsiz, sırayla.' ),
						'cevap'      => array( 'type' => 'string', 'enum' => array( 'A', 'B', 'C', 'D', 'E' ) ),
						'aciklama'   => array( 'type' => 'string', 'description' => 'Kısa çözüm; öğretmenin kontrolü için.' ),
						'kazanim'    => array( 'type' => 'string', 'description' => 'Sorunun ölçtüğü kazanım ya da alt konu.' ),
					),
					'required'             => array( 'soru', 'secenekler', 'cevap', 'aciklama', 'kazanim' ),
					'additionalProperties' => false,
				),
			),
		),
		'required'             => array( 'sorular' ),
		'additionalProperties' => false,
	);
}

add_action( 'rest_api_init', function () {
	$ns = 'optik-karne/v1';
	register_rest_route( $ns, '/ai/soru', array( 'methods' => 'POST', 'callback' => 'sides_rest_ai_soru', 'permission_callback' => function () {
		if ( ! sides_is_panel() ) {
			return sides_deny( 'Oturum açmanız gerekiyor.' );
		}
		if ( sides_is_observer() ) {
			return sides_deny( 'Gözlemci hesabının işlem yetkisi yok.' );
		}
		return sides_can_write_coll( 'testler' ) || sides_can_write_coll( 'havuz' ) ? true : sides_deny();
	} ) );
	register_rest_route( $ns, '/ana/ai', array(
		array( 'methods' => 'GET', 'callback' => 'sides_rest_ana_ai', 'permission_callback' => function () {
			return sides_is_super() ? true : sides_deny( 'Bu bölüm yalnızca ana hesaba açıktır.' );
		} ),
		array( 'methods' => 'POST', 'callback' => 'sides_rest_ana_ai_kaydet', 'permission_callback' => function () {
			return sides_is_super() ? true : sides_deny( 'Bu bölüm yalnızca ana hesaba açıktır.' );
		} ),
	) );
} );

function sides_rest_ai_soru( WP_REST_Request $req ) {
	$a   = sides_ai_ayar();
	$org = sides_org_id();
	if ( ! $a['acik'] || '' === $a['anahtar'] ) {
		return new WP_Error( 'sides_ai', 'Yapay zekâ ile soru üretimi etkin değil. Ana hesabın API anahtarını girmesi gerekiyor.', array( 'status' => 400 ) );
	}
	/* v7.3.1 güvenlik: her istek site sahibinin API hesabından ücretlendirilir; kullanıcı ve kurum başına saatlik sınır (eş zamanlı isteklerle aylık hak aşılmasın) */
	if ( ! sides_rl( 'ai_soru|' . get_current_user_id(), 15, HOUR_IN_SECONDS ) || ! sides_rl( 'ai_soru_kurum|' . $org, 40, HOUR_IN_SECONDS ) ) {
		return new WP_Error( 'sides_rl', 'Bir saat içinde çok fazla soru üretme isteği gönderildi. Biraz sonra tekrar deneyin.', array( 'status' => 429 ) );
	}
	$p       = $req->get_json_params();
	$adet    = max( 1, min( 10, isset( $p['adet'] ) ? (int) $p['adet'] : 5 ) );
	$secenek = isset( $p['secenek'] ) && 5 === (int) $p['secenek'] ? 5 : 4;
	$ders    = mb_substr( sanitize_text_field( isset( $p['ders'] ) ? (string) $p['ders'] : '' ), 0, 60 );
	$sinif   = preg_replace( '/\D/', '', isset( $p['sinif'] ) ? (string) $p['sinif'] : '' );
	$konu    = mb_substr( sanitize_text_field( isset( $p['konu'] ) ? (string) $p['konu'] : '' ), 0, 200 );
	$zorluk  = isset( $p['zorluk'] ) && in_array( $p['zorluk'], array( 'kolay', 'orta', 'zor' ), true ) ? $p['zorluk'] : 'orta';
	$not     = mb_substr( sanitize_textarea_field( isset( $p['not'] ) ? (string) $p['not'] : '' ), 0, 600 );
	$once    = array_map( function ( $s ) { return mb_substr( sanitize_text_field( is_scalar( $s ) ? (string) $s : '' ), 0, 160 ); }, array_slice( (array) ( isset( $p['once'] ) ? $p['once'] : array() ), 0, 30 ) );
	if ( ! $ders || ! $sinif || ! $konu ) {
		return new WP_Error( 'sides_eksik', 'Ders, sınıf ve konuyu seçin.', array( 'status' => 400 ) );
	}
	if ( $a['sinir'] && sides_ai_kullanim( $org ) + $adet > $a['sinir'] ) {
		$kalan = max( 0, $a['sinir'] - sides_ai_kullanim( $org ) );
		return new WP_Error( 'sides_ai', $kalan ? "Bu ay için {$kalan} soruluk hakkınız kaldı; daha az soru isteyin." : 'Bu ayki yapay zekâ soru hakkınız doldu. Yeni ayda yenilenir.', array( 'status' => 429 ) );
	}
	@set_time_limit( 180 ); // phpcs:ignore
	$zAd    = array( 'kolay' => 'kolay (temel düzey, doğrudan bilgi ve basit uygulama)', 'orta' => 'orta (LGS ortalamasına yakın, iki adımlı düşünme)', 'zor' => 'zor (LGS\'nin ayırt edici soruları gibi, çok adımlı akıl yürütme ve yorum)' );
	$harf   = 5 === $secenek ? 'A, B, C, D, E' : 'A, B, C, D';
	$system = 'Sen Türkiye\'de ortaokul öğrencilerine ders veren, Millî Eğitim Bakanlığı öğretim programını ve LGS soru tarzını çok iyi bilen deneyimli bir öğretmen ve soru yazarısın. Yazdığın her soru tek ve kesin doğru cevaplı, dil bilgisi kurallarına uygun, öğrencinin yaşına uygun ve bilimsel olarak doğrudur.';
	// Nehari 3. ve 4. sınıf: ilkokul düzeyi, LGS tarzı yok (N5 soruları 5. sınıf olarak yazılır)
	if ( in_array( $sinif, array( '3', '4' ), true ) ) {
		$zAd    = array( 'kolay' => 'kolay (temel düzey, doğrudan bilgi ve basit uygulama)', 'orta' => 'orta (sınıf düzeyine uygun, iki adımlı düşünme)', 'zor' => 'zor (dikkatli okuma ve birkaç adımlı düşünme gerektiren, yine de sınıf düzeyinde)' );
		$system = 'Sen Türkiye\'de ilkokul öğrencilerine ders veren, Millî Eğitim Bakanlığı öğretim programını çok iyi bilen deneyimli bir sınıf öğretmeni ve soru yazarısın. Soruları 8–10 yaşındaki çocukların anlayacağı kısa ve sade cümlelerle yazarsın. Yazdığın her soru tek ve kesin doğru cevaplı, dil bilgisi kurallarına uygun ve bilimsel olarak doğrudur.';
	}
	$prompt = "Ders: {$ders}\nSınıf: {$sinif}. sınıf\nKonu / kazanım: {$konu}\nZorluk: {$zAd[$zorluk]}\nSoru sayısı: {$adet}\nSeçenek sayısı: {$secenek} ({$harf})\n"
		. ( $not ? "Öğretmenin notu: {$not}\n" : '' )
		. ( $once ? "Daha önce üretilen soruların başları (bunları tekrar etme, farklı bağlamlar kullan):\n- " . implode( "\n- ", $once ) . "\n" : '' )
		. "\nKurallar:\n- Her soru yalnızca bu konuyu ölçsün ve {$sinif}. sınıf seviyesini aşmasın.\n- Tam olarak {$secenek} seçenek yaz; seçeneklerin başına harf koyma.\n- Yalnızca bir seçenek doğru olsun; çeldiriciler öğrencilerin sık yaptığı hatalara dayansın.\n- Doğru cevapların harflerini sorular arasında dengeli dağıt.\n- Şekil veya görsel gerektiren soru yazma; gerekirse bilgiyi metinle ver.\n- Matematik ifadelerinde LaTeX kullanma; ², ³, √, ·, ÷, ≤, ≥, π gibi karakterler ve 3/4 gibi kesirler kullan.\n- Her soru için kısa bir çözüm açıklaması ve ölçtüğü kazanımı yaz.";
	$txt = sides_ai_istek( $a, $system, $prompt, sides_ai_soru_semasi() );
	if ( is_wp_error( $txt ) ) {
		return $txt;
	}
	$j = json_decode( $txt, true );
	if ( ! is_array( $j ) || empty( $j['sorular'] ) ) {
		return new WP_Error( 'sides_ai', 'Yapay zekânın yanıtı okunamadı. Tekrar deneyin.', array( 'status' => 502 ) );
	}
	$out = array();
	foreach ( (array) $j['sorular'] as $q ) {
		$ops = array_values( array_filter( array_map( 'trim', array_map( 'strval', (array) ( isset( $q['secenekler'] ) ? $q['secenekler'] : array() ) ) ), 'strlen' ) );
		$ops = array_map( function ( $o ) {
			return preg_replace( '/^[A-E]\s*[\)\.\-:]\s*/u', '', $o );
		}, $ops );
		$cev = isset( $q['cevap'] ) ? strtoupper( (string) $q['cevap'] ) : '';
		if ( empty( $q['soru'] ) || count( $ops ) < $secenek || false === strpos( 'ABCDE', $cev ) || strpos( 'ABCDE', $cev ) >= $secenek ) {
			continue;
		}
		$out[] = array( 'soru' => trim( (string) $q['soru'] ), 'secenekler' => array_slice( $ops, 0, $secenek ), 'cevap' => $cev, 'aciklama' => isset( $q['aciklama'] ) ? trim( (string) $q['aciklama'] ) : '', 'kazanim' => isset( $q['kazanim'] ) ? trim( (string) $q['kazanim'] ) : '' );
	}
	if ( ! $out ) {
		return new WP_Error( 'sides_ai', 'Kullanılabilir soru üretilemedi. Konuyu biraz daha açık yazıp tekrar deneyin.', array( 'status' => 502 ) );
	}
	sides_ai_say( $org, count( $out ) );
	sides_log( $org, 'Yapay zekâ ile ' . count( $out ) . ' soru üretildi (' . $ders . ', ' . $sinif . '. sınıf, ' . $konu . ')' );
	return array( 'sorular' => $out, 'durum' => sides_ai_durum( $org ) );
}

function sides_rest_ana_ai() {
	global $wpdb;
	$a    = sides_ai_ayar();
	$u    = sides_ai_kullanim();
	$adlar = array();
	if ( $u ) {
		$ids = implode( ',', array_map( 'intval', array_keys( $u ) ) );
		foreach ( (array) $wpdb->get_results( 'SELECT id, ad FROM ' . sides_orgs() . " WHERE id IN ($ids)" ) as $o ) { // phpcs:ignore
			$adlar[ (int) $o->id ] = $o->ad;
		}
	}
	$kul = array();
	foreach ( $u as $oid => $n ) {
		$kul[] = array( 'ad' => isset( $adlar[ (int) $oid ] ) ? $adlar[ (int) $oid ] : '#' . $oid, 'n' => (int) $n );
	}
	usort( $kul, function ( $x, $y ) {
		return $y['n'] - $x['n'];
	} );
	return array(
		'anahtarVar' => '' !== $a['anahtar'],
		'anahtarSon' => $a['anahtar'] ? substr( $a['anahtar'], -4 ) : '',
		'model'      => $a['model'],
		'modeller'   => SIDES_AI_MODELLER,
		'sinir'      => $a['sinir'],
		'acik'       => $a['acik'],
		'kullanim'   => $kul,
	);
}
function sides_rest_ana_ai_kaydet( WP_REST_Request $req ) {
	$p = $req->get_json_params();
	$a = sides_ai_ayar();
	if ( isset( $p['anahtar'] ) && '' !== trim( (string) $p['anahtar'] ) ) {
		$a['anahtar'] = trim( sanitize_text_field( (string) $p['anahtar'] ) );
	}
	if ( ! empty( $p['anahtarSil'] ) ) {
		$a['anahtar'] = '';
	}
	if ( isset( $p['model'] ) ) {
		$a['model'] = preg_replace( '/[^a-z0-9\-\.]/', '', strtolower( (string) $p['model'] ) );
	}
	if ( isset( $p['sinir'] ) ) {
		$a['sinir'] = max( 0, min( 100000, (int) $p['sinir'] ) );
	}
	if ( isset( $p['acik'] ) ) {
		$a['acik'] = (bool) $p['acik'];
	}
	update_option( 'sides_ai', $a, false );
	if ( ! empty( $p['dene'] ) ) {
		if ( '' === $a['anahtar'] ) {
			return new WP_Error( 'sides_ai', 'Önce API anahtarını girin.', array( 'status' => 400 ) );
		}
		$t = sides_ai_istek( $a, '', 'Sadece "tamam" yaz.', null, 16 );
		if ( is_wp_error( $t ) ) {
			return $t;
		}
		return sides_rest_ana_ai() + array( 'deneme' => 'Bağlantı çalışıyor (' . $a['model'] . ').' );
	}
	return sides_rest_ana_ai();
}
