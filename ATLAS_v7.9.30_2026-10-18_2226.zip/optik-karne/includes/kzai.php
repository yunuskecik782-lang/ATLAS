<?php
/**
 * Kazanım önerileri (Test Modülü): yüklenen sorulara katalogdan kazanım önerisi.
 *
 * Mevcut yapay zekâ hizmeti (includes/ai.php: anahtar, model, aylık hak) kullanılır; model adı ayarlardan gelir.
 * Modele yalnızca soru metni/görseli ve ders–sınıf kataloğu gider; öğrenci bilgisi gönderilmez. Modelin döndürdüğü
 * her kod gönderilen katalogda aranır; katalog dışı kodlar atılır ve satır "inceleme" olur. Hata durumunda etiket üretilmez.
 *
 * Kayıtlar kurum belgelerinde (sides_docs, coll 'kzoneri') tutulur, böylece yedeğe otomatik girer:
 *   c<sha1>      önbellek: sha1(soru içeriği | katalog sürümü) → modelin ham yanıtı (tekrar yüklemede yeniden ücretlendirme yok)
 *   kat-<hash>   kurumun yüklediği resmî kodlu katalog { ders, sinif, yil, program, surum, kaynak, tarih, ogeler[{kod, ad, tema}] }
 *   ayar         { otoKabul, esik } (yalnız yönetici)
 *
 * GET    /kzai/durum          → { ai, model, ayar, kataloglar[meta], onbellek }
 * GET    /kzai/katalog/<id>   → katalog (ogeler dâhil)
 * POST   /kzai/katalog        { ders, sinif, yil, program, surum, kaynak, tarih, metin } → katalog
 * DELETE /kzai/katalog/<id>
 * POST   /kzai/ayar           { otoKabul, esik }
 * POST   /kzai/oner           { items[{qid, metin, secenekler, gorselDataUrl?}] (≤5), ders, sinif, yil, katalogId | katalog{ogeler}, yenile? }
 *                              → { sonuclar[{qid, durum: oneri|inceleme|atanamadi|hata, ana, ikincil, konu, gerekce, guven, onbellek, model, not}], cagri, surum, ai, uyari?, durdur? }
 *
 * Test kancası: sides_kzai_model_cagir() WP_DEBUG açıkken 'sides_kzai_sahte' geçici değeri tanımlıysa API yerine onu
 * döndürür ve 'sides_kzai_sahte_n' sayacını artırır (yalnız otomatik testler için; üretimde WP_DEBUG kapalıdır).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SIDES_KZAI_IS', 'kzai-1' );
define( 'SIDES_KZAI_DERSLER', array( 'Türkçe', 'Matematik', 'Fen Bilimleri', 'Sosyal Bilgiler', 'T.C. İnkılap Tarihi', 'İngilizce', 'Din Kültürü', 'Hayat Bilgisi' ) );

function sides_kzai_str( $s, $n ) {
	$s = trim( wp_strip_all_tags( (string) $s ) );
	return function_exists( 'mb_substr' ) ? mb_substr( $s, 0, $n ) : substr( $s, 0, $n );
}
function sides_kzai_yaz_izni() {
	if ( ! sides_is_panel() ) {
		return sides_deny( 'Oturum açmanız gerekiyor.' );
	}
	if ( sides_is_observer() ) {
		return sides_deny( 'Gözlemci hesabının işlem yetkisi yok.' );
	}
	if ( ! empty( sides_ctx()['onizleme'] ) ) {
		return sides_deny( 'Önizleme modunda değişiklik yapılamaz.' );
	}
	return sides_can( 'test', 2 ) || sides_can( 'nehari', 2 ) ? true : sides_deny();
}
function sides_kzai_okuma_izni() {
	return sides_is_panel() && ( sides_can( 'test', 1 ) || sides_can( 'nehari', 1 ) ) ? true : sides_deny();
}
function sides_kzai_ders_sinif_yil( $p ) {
	$ders  = isset( $p['ders'] ) ? (string) $p['ders'] : '';
	$sinif = strtoupper( trim( isset( $p['sinif'] ) ? (string) $p['sinif'] : '' ) );
	$yil   = isset( $p['yil'] ) ? (int) $p['yil'] : 0;
	if ( ! in_array( $ders, SIDES_KZAI_DERSLER, true ) ) {
		return new WP_Error( 'sides_eksik', 'Geçerli bir ders seçin.', array( 'status' => 400 ) );
	}
	if ( ! preg_match( '/^(N5|[1-9]|1[0-2])$/', $sinif ) ) {
		return new WP_Error( 'sides_eksik', 'Geçerli bir sınıf seçin.', array( 'status' => 400 ) );
	}
	if ( $yil < 2020 || $yil > 2040 ) {
		return new WP_Error( 'sides_eksik', 'Geçerli bir eğitim yılı seçin.', array( 'status' => 400 ) );
	}
	return array( $ders, $sinif, $yil );
}
function sides_kzai_katalog_id( $ders, $sinif, $yil ) {
	return 'kat-' . substr( md5( $ders . '|' . $sinif . '|' . $yil ), 0, 12 );
}
/* Katalog öğelerini temizler: kod benzersiz ve biçimli, ad zorunlu */
function sides_kzai_ogeler( $l ) {
	$out = array();
	foreach ( (array) $l as $o ) {
		if ( ! is_array( $o ) || count( $out ) >= 600 ) {
			continue;
		}
		$kod = isset( $o['kod'] ) ? trim( (string) $o['kod'] ) : '';
		$ad  = sides_kzai_str( isset( $o['ad'] ) ? $o['ad'] : '', 300 );
		if ( ! preg_match( '/^[\p{L}0-9][\p{L}0-9.\-_]{0,29}$/u', $kod ) || '' === $ad || isset( $out[ $kod ] ) ) {
			continue;
		}
		$out[ $kod ] = array( 'kod' => $kod, 'ad' => $ad, 'tema' => sides_kzai_str( isset( $o['tema'] ) ? $o['tema'] : '', 200 ) );
	}
	return $out;
}
function sides_kzai_surum( $ogeler ) {
	return substr( sha1( wp_json_encode( array_values( $ogeler ) ) ), 0, 16 );
}
function sides_kzai_ayar_oku( $org ) {
	$d = sides_get_doc( $org, 'kzoneri', 'ayar' );
	return array(
		'otoKabul' => ! empty( $d['otoKabul'] ),
		'esik'     => isset( $d['esik'] ) ? max( 0.5, min( 0.99, (float) $d['esik'] ) ) : 0.9,
	);
}

/* Model çağrısı (test kancası dâhil). Dönüş: JSON metni ya da WP_Error. */
function sides_kzai_model_cagir( $a, $system, $content, $schema, $max_tokens ) {
	if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
		$s = get_transient( 'sides_kzai_sahte' );
		if ( false !== $s ) {
			set_transient( 'sides_kzai_sahte_n', (int) get_transient( 'sides_kzai_sahte_n' ) + 1, HOUR_IN_SECONDS );
			return is_string( $s ) ? $s : wp_json_encode( $s );
		}
	}
	return sides_ai_istek( $a, $system, $content, $schema, $max_tokens );
}
function sides_kzai_sahte_mi() {
	return defined( 'WP_DEBUG' ) && WP_DEBUG && false !== get_transient( 'sides_kzai_sahte' );
}
function sides_kzai_sema() {
	return array(
		'type'                 => 'object',
		'properties'           => array(
			'sonuclar' => array(
				'type'  => 'array',
				'items' => array(
					'type'                 => 'object',
					'properties'           => array(
						'no'             => array( 'type' => 'integer', 'description' => 'Sorunun numarası (1’den başlar).' ),
						'ana_kod'        => array( 'type' => 'string', 'description' => 'Katalogdaki ana kazanım kodu; uygun kod yoksa boş.' ),
						'ikincil_kodlar' => array( 'type' => 'array', 'items' => array( 'type' => 'string' ), 'description' => 'En çok 2 ikincil katalog kodu.' ),
						'gerekce'        => array( 'type' => 'string', 'description' => 'En çok 200 karakterlik kısa eşleme gerekçesi.' ),
						'guven'          => array( 'type' => 'number', 'description' => '0 ile 1 arası güven.' ),
						'icerik_yeterli' => array( 'type' => 'boolean', 'description' => 'Soru içeriği okunabilir ve yeterli mi?' ),
					),
					'required'             => array( 'no', 'ana_kod', 'ikincil_kodlar', 'gerekce', 'guven', 'icerik_yeterli' ),
					'additionalProperties' => false,
				),
			),
		),
		'required'             => array( 'sonuclar' ),
		'additionalProperties' => false,
	);
}
/* Modelin ham yanıtını katalogla doğrular; katalog dışı kodlar atılır */
function sides_kzai_dogrula( $ham, $ogeler ) {
	$r = array( 'durum' => 'atanamadi', 'ana' => null, 'ikincil' => array(), 'konu' => '', 'gerekce' => '', 'guven' => 0, 'not' => '' );
	if ( ! is_array( $ham ) ) {
		$r['not'] = 'Model bu soru için yanıt vermedi.';
		return $r;
	}
	$r['gerekce'] = sides_kzai_str( isset( $ham['gerekce'] ) ? $ham['gerekce'] : '', 300 );
	$r['guven']   = round( max( 0, min( 1, isset( $ham['guven'] ) ? (float) $ham['guven'] : 0 ) ), 2 );
	$uydurma      = array();
	$ana          = isset( $ham['ana_kod'] ) ? trim( (string) $ham['ana_kod'] ) : '';
	if ( '' !== $ana ) {
		if ( isset( $ogeler[ $ana ] ) ) {
			$r['ana']  = array( 'kod' => $ana, 'ad' => $ogeler[ $ana ]['ad'], 'tema' => $ogeler[ $ana ]['tema'] );
			$r['konu'] = $ogeler[ $ana ]['tema'];
		} else {
			$uydurma[] = $ana;
		}
	}
	foreach ( array_slice( (array) ( isset( $ham['ikincil_kodlar'] ) ? $ham['ikincil_kodlar'] : array() ), 0, 4 ) as $k ) {
		$k = trim( (string) $k );
		if ( '' === $k || $k === $ana ) {
			continue;
		}
		if ( ! isset( $ogeler[ $k ] ) ) {
			$uydurma[] = $k;
		} elseif ( count( $r['ikincil'] ) < 2 && ! in_array( $k, array_column( $r['ikincil'], 'kod' ), true ) ) {
			$r['ikincil'][] = array( 'kod' => $k, 'ad' => $ogeler[ $k ]['ad'] );
		}
	}
	$yeterli = ! isset( $ham['icerik_yeterli'] ) || (bool) $ham['icerik_yeterli'];
	if ( $uydurma ) {
		$r['durum'] = 'inceleme';
		$r['not']   = 'Model katalogda olmayan kod önerdi (' . sides_kzai_str( implode( ', ', $uydurma ), 80 ) . '); bu kod kaydedilmedi.';
	} elseif ( ! $yeterli ) {
		$r['durum'] = $r['ana'] ? 'inceleme' : 'atanamadi';
		$r['not']   = 'Soru içeriği okunamadı veya eksik.';
	} elseif ( ! $r['ana'] ) {
		$r['durum'] = 'atanamadi';
		$r['not']   = 'Katalogda uygun kazanım bulunamadı.';
	} elseif ( $r['guven'] < 0.6 ) {
		$r['durum'] = 'inceleme';
		$r['not']   = 'Güven düşük.';
	} else {
		$r['durum'] = 'oneri';
	}
	return $r;
}

add_action( 'rest_api_init', function () {
	$ns = 'optik-karne/v1';
	register_rest_route( $ns, '/kzai/durum', array( 'methods' => 'GET', 'callback' => 'sides_rest_kzai_durum', 'permission_callback' => 'sides_kzai_okuma_izni' ) );
	register_rest_route( $ns, '/kzai/katalog', array( 'methods' => 'POST', 'callback' => 'sides_rest_kzai_katalog_kaydet', 'permission_callback' => 'sides_kzai_yaz_izni' ) );
	register_rest_route( $ns, '/kzai/katalog/(?P<id>kat-[a-f0-9]{12})', array(
		array( 'methods' => 'GET', 'callback' => 'sides_rest_kzai_katalog', 'permission_callback' => 'sides_kzai_okuma_izni' ),
		array( 'methods' => 'DELETE', 'callback' => 'sides_rest_kzai_katalog_sil', 'permission_callback' => 'sides_kzai_yaz_izni' ),
	) );
	register_rest_route( $ns, '/kzai/ayar', array( 'methods' => 'POST', 'callback' => 'sides_rest_kzai_ayar', 'permission_callback' => function () {
		$ok = sides_kzai_yaz_izni();
		if ( true !== $ok ) {
			return $ok;
		}
		return 'yonetici' === sides_ctx()['rol'] ? true : sides_deny( 'Otomatik kabul ayarını yalnızca kurum yöneticisi değiştirebilir.' );
	} ) );
	register_rest_route( $ns, '/kzai/oner', array( 'methods' => 'POST', 'callback' => 'sides_rest_kzai_oner', 'permission_callback' => 'sides_kzai_yaz_izni' ) );
} );

function sides_rest_kzai_durum() {
	global $wpdb;
	$org = sides_org_id();
	$a   = sides_ai_ayar();
	$t   = sides_docs();
	$kat = array();
	foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT id, data FROM $t WHERE org = %d AND coll = 'kzoneri' AND id LIKE %s", $org, 'kat-%' ) ) as $r ) { // phpcs:ignore
		$d = json_decode( $r->data, true );
		if ( is_array( $d ) ) {
			$n = isset( $d['ogeler'] ) ? count( (array) $d['ogeler'] ) : 0;
			unset( $d['ogeler'] );
			$kat[] = array( 'id' => $r->id, 'n' => $n ) + $d;
		}
	}
	$onb = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE org = %d AND coll = 'kzoneri' AND id LIKE %s", $org, 'c%' ) ); // phpcs:ignore
	return array( 'ai' => sides_ai_durum( $org ), 'model' => $a['model'], 'is' => SIDES_KZAI_IS, 'ayar' => sides_kzai_ayar_oku( $org ), 'kataloglar' => $kat, 'onbellek' => $onb );
}
function sides_rest_kzai_katalog( WP_REST_Request $req ) {
	$d = sides_get_doc( sides_org_id(), 'kzoneri', $req['id'] );
	return $d ? $d : new WP_Error( 'sides_yok', 'Katalog bulunamadı.', array( 'status' => 404 ) );
}
function sides_rest_kzai_katalog_sil( WP_REST_Request $req ) {
	global $wpdb;
	$org = sides_org_id();
	$wpdb->delete( sides_docs(), array( 'org' => $org, 'coll' => 'kzoneri', 'id' => $req['id'] ) );
	sides_log( $org, 'Kazanım kataloğu silindi' );
	return array( 'ok' => true );
}
function sides_rest_kzai_katalog_kaydet( WP_REST_Request $req ) {
	$p = $req->get_json_params();
	$v = sides_kzai_ders_sinif_yil( $p );
	if ( is_wp_error( $v ) ) {
		return $v;
	}
	list( $ders, $sinif, $yil ) = $v;
	$kaynak = esc_url_raw( isset( $p['kaynak'] ) ? (string) $p['kaynak'] : '', array( 'https', 'http' ) );
	$tarih  = isset( $p['tarih'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $p['tarih'] ) ? (string) $p['tarih'] : '';
	$surum  = sides_kzai_str( isset( $p['surum'] ) ? $p['surum'] : '', 80 );
	$prog   = isset( $p['program'] ) && in_array( $p['program'], array( 'TYMM', 'onceki' ), true ) ? $p['program'] : 'TYMM';
	if ( ! $kaynak || ! $tarih || '' === $surum ) {
		return new WP_Error( 'sides_eksik', 'Resmî kaynak adresi, sürüm ve alınma tarihi zorunludur.', array( 'status' => 400 ) );
	}
	$tema = '';
	$l    = array();
	$hata = array();
	foreach ( preg_split( '/\r?\n/', (string) ( isset( $p['metin'] ) ? $p['metin'] : '' ) ) as $sat ) {
		$sat = trim( $sat );
		if ( '' === $sat ) {
			continue;
		}
		if ( '#' === $sat[0] ) {
			$tema = trim( ltrim( $sat, '#' ) );
			continue;
		}
		if ( preg_match( '/^([\p{L}]{1,6}(?:\.[\p{L}0-9]{1,6}){1,5})\s*[|\t:\-–]?\s+(.+)$/u', $sat, $m ) ) {
			$l[] = array( 'kod' => $m[1], 'ad' => $m[2], 'tema' => $tema );
		} elseif ( count( $hata ) < 5 ) {
			$hata[] = sides_kzai_str( $sat, 60 );
		}
	}
	$og = sides_kzai_ogeler( $l );
	if ( ! $og ) {
		return new WP_Error( 'sides_eksik', 'Kodlu satır bulunamadı. Her satır “MAT.6.1.1 Açıklama” biçiminde olmalı.', array( 'status' => 400 ) );
	}
	if ( $hata ) {
		return new WP_Error( 'sides_eksik', 'Kodu okunamayan satırlar var: ' . implode( ' · ', $hata ), array( 'status' => 400 ) );
	}
	$org = sides_org_id();
	$id  = sides_kzai_katalog_id( $ders, $sinif, $yil );
	$d   = array( 'ders' => $ders, 'sinif' => $sinif, 'yil' => $yil, 'program' => $prog, 'surum' => $surum, 'kaynak' => $kaynak, 'tarih' => $tarih, 'icerik' => sides_kzai_surum( $og ), 'ogeler' => array_values( $og ), 'yukleyen' => wp_get_current_user()->display_name, 'guncelleme' => gmdate( 'c' ) );
	if ( false === sides_put_doc( $org, 'kzoneri', $id, $d ) ) {
		return new WP_Error( 'sides_db', 'Katalog kaydedilemedi.', array( 'status' => 500 ) );
	}
	sides_log( $org, 'Kazanım kataloğu yüklendi (' . $ders . ', ' . $sinif . '. sınıf, ' . count( $og ) . ' kazanım)' );
	return array( 'id' => $id ) + $d;
}
function sides_rest_kzai_ayar( WP_REST_Request $req ) {
	$p   = $req->get_json_params();
	$org = sides_org_id();
	$d   = array( 'otoKabul' => ! empty( $p['otoKabul'] ), 'esik' => max( 0.5, min( 0.99, isset( $p['esik'] ) ? (float) $p['esik'] : 0.9 ) ) );
	sides_put_doc( $org, 'kzoneri', 'ayar', $d );
	sides_log( $org, 'Kazanım önerisi otomatik kabul ' . ( $d['otoKabul'] ? 'açıldı (eşik ' . $d['esik'] . ')' : 'kapatıldı' ) );
	return $d;
}

function sides_rest_kzai_oner( WP_REST_Request $req ) {
	$org = sides_org_id();
	if ( ! sides_rl( 'kzai|' . get_current_user_id(), 40, MINUTE_IN_SECONDS ) || ! sides_rl( 'kzai_saat|' . sides_org_id(), 300, HOUR_IN_SECONDS ) ) {   // v7.3.1: kurum başına saatlik üst sınır (API maliyeti)
		return new WP_Error( 'sides_rl', 'Çok sık istek gönderildi. Bir dakika sonra devam edin.', array( 'status' => 429 ) );
	}
	$p = $req->get_json_params();
	$v = sides_kzai_ders_sinif_yil( $p );
	if ( is_wp_error( $v ) ) {
		return $v;
	}
	list( $ders, $sinif, $yil ) = $v;
	// katalog: kurumun kaydettiği resmî katalog sunucudan okunur; yoksa istemcinin gönderdiği konu listesi
	$katMeta = array( 'tur' => 'konu' );
	if ( ! empty( $p['katalogId'] ) ) {
		$kid = (string) $p['katalogId'];
		$kd  = preg_match( '/^kat-[a-f0-9]{12}$/', $kid ) ? sides_get_doc( $org, 'kzoneri', $kid ) : null;
		if ( ! $kd ) {
			return new WP_Error( 'sides_yok', 'Katalog bulunamadı.', array( 'status' => 404 ) );
		}
		$ogeler  = sides_kzai_ogeler( isset( $kd['ogeler'] ) ? $kd['ogeler'] : array() );
		$katMeta = array( 'tur' => 'resmi', 'id' => $kid, 'program' => isset( $kd['program'] ) ? $kd['program'] : '' );
	} else {
		$ogeler = sides_kzai_ogeler( isset( $p['katalog']['ogeler'] ) ? $p['katalog']['ogeler'] : array() );
	}
	if ( ! $ogeler ) {
		return new WP_Error( 'sides_eksik', 'Bu ders ve sınıf için katalog yok; kazanımı elle seçin.', array( 'status' => 400 ) );
	}
	$surum = sides_kzai_surum( $ogeler );
	$items = array_values( (array) ( isset( $p['items'] ) ? $p['items'] : array() ) );
	if ( ! $items || count( $items ) > 5 ) {
		return new WP_Error( 'sides_eksik', 'Her istekte 1–5 soru gönderilebilir.', array( 'status' => 400 ) );
	}
	$yenile = ! empty( $p['yenile'] );
	$a      = sides_ai_ayar();
	$out    = array();
	$bekle  = array();   // modele gidecekler
	foreach ( $items as $i => $it ) {
		$qid = isset( $it['qid'] ) ? (string) $it['qid'] : '';
		if ( ! preg_match( '/^[A-Za-z0-9_\-:.]{1,80}$/', $qid ) ) {
			return new WP_Error( 'sides_eksik', 'Geçersiz soru kimliği.', array( 'status' => 400 ) );
		}
		$metin = function_exists( 'mb_substr' ) ? mb_substr( trim( (string) ( isset( $it['metin'] ) ? $it['metin'] : '' ) ), 0, 4000 ) : '';
		$sec   = array();
		foreach ( array_slice( (array) ( isset( $it['secenekler'] ) ? $it['secenekler'] : array() ), 0, 6 ) as $s ) {
			$sec[] = sides_kzai_str( $s, 500 );
		}
		$gor = null;
		if ( ! empty( $it['gorselDataUrl'] ) ) {
			$g = (string) $it['gorselDataUrl'];
			if ( strlen( $g ) > 2800000 || ! preg_match( '#^data:image/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$#', $g, $m ) ) {
				$out[ $i ] = array( 'qid' => $qid, 'durum' => 'hata', 'not' => 'Soru görseli çok büyük ya da desteklenmeyen biçimde.' );
				continue;
			}
			$gor = array( 'tip' => 'image/' . $m[1], 'veri' => $m[2] );
		}
		if ( '' === $metin && ! $gor ) {
			$out[ $i ] = array( 'qid' => $qid, 'durum' => 'atanamadi', 'not' => 'Soru içeriği yok; cevap anahtarından kazanım belirlenemez. Görsel/metin ekleyin veya elle seçin.' ) + array( 'ana' => null, 'ikincil' => array(), 'guven' => 0 );
			continue;
		}
		$h   = sha1( $ders . '|' . $sinif . '|' . $metin . '|' . implode( "\x1f", $sec ) . '|' . ( $gor ? sha1( $gor['veri'] ) : '' ) );
		$cid = 'c' . sha1( $h . '|' . $surum );
		$c   = $yenile ? null : sides_get_doc( $org, 'kzoneri', $cid );
		if ( $c && isset( $c['ham'] ) ) {
			$out[ $i ] = array( 'qid' => $qid, 'onbellek' => true, 'model' => isset( $c['model'] ) ? $c['model'] : '', 'tarih' => isset( $c['tarih'] ) ? $c['tarih'] : '' ) + sides_kzai_dogrula( $c['ham'], $ogeler );
			continue;
		}
		$bekle[ $i ] = array( 'qid' => $qid, 'metin' => $metin, 'sec' => $sec, 'gor' => $gor, 'cid' => $cid, 'h' => $h );
	}
	$res = array( 'cagri' => 0, 'surum' => $surum, 'katalog' => $katMeta );
	if ( $bekle ) {
		$sahte = sides_kzai_sahte_mi();
		$engel = '';
		if ( ! $sahte && ( ! $a['acik'] || '' === $a['anahtar'] ) ) {
			$engel = 'Yapay zekâ hizmeti etkin değil (ana hesabın API anahtarı gerekli). Kazanımları katalogdan elle seçebilirsiniz.';
		} elseif ( ! $sahte && $a['sinir'] && sides_ai_kullanim( $org ) + 1 > $a['sinir'] ) {
			$engel = 'Bu ayki yapay zekâ hakkınız doldu. Kazanımları katalogdan elle seçebilirsiniz.';
		}
		if ( $engel ) {
			foreach ( $bekle as $i => $b ) {
				$out[ $i ] = array( 'qid' => $b['qid'], 'durum' => 'hata', 'not' => $engel );
			}
			$res['uyari']  = $engel;
			$res['durdur'] = true;
		} else {
			@set_time_limit( 180 ); // phpcs:ignore
			$prog = ! empty( $p['program'] ) && in_array( $p['program'], array( 'TYMM', 'onceki' ), true ) ? $p['program'] : ( isset( $katMeta['program'] ) ? $katMeta['program'] : '' );
			$kat  = '';
			foreach ( $ogeler as $o ) {
				$kat .= $o['kod'] . ' — ' . $o['ad'] . ( $o['tema'] ? ' [' . $o['tema'] . ']' : '' ) . "\n";
			}
			$system  = 'Sen Türkiye’de Millî Eğitim Bakanlığı öğretim programlarını iyi bilen bir ölçme ve değerlendirme uzmanısın. Görevin, verilen her sorunun ölçtüğü kazanımı YALNIZCA verilen katalogdaki kodlardan seçmek. Katalog dışında kod yazma, kod uydurma. Uygun kod yoksa ana_kod alanını boş bırak. Soru okunamıyor, eksik ya da bu ders ve sınıfla ilgisizse icerik_yeterli=false yaz. guven 0 ile 1 arasında olsun; emin değilsen düşük ver. Gerekçe Türkçe ve en çok 200 karakter olsun.';
			$content = array( array( 'type' => 'text', 'text' => "Ders: {$ders}\nSınıf: {$sinif}\nEğitim yılı: {$yil}-" . ( $yil + 1 ) . ( $prog ? "\nProgram: " . ( 'TYMM' === $prog ? 'Türkiye Yüzyılı Maarif Modeli' : 'önceki öğretim programı' ) : '' ) . "\n\nKatalog (kod — açıklama [ünite/tema]):\n" . $kat . "\nAşağıda " . count( $bekle ) . " soru var. Her soru için 'no' alanına sorunun numarasını yaz." ) );
			$no      = 0;
			$sira    = array();
			foreach ( $bekle as $i => $b ) {
				$sira[ ++$no ] = $i;
				$tx            = "Soru {$no}:" . ( '' !== $b['metin'] ? "\n" . $b['metin'] : ' (görselde)' );
				if ( $b['sec'] ) {
					foreach ( $b['sec'] as $k => $s ) {
						$tx .= "\n" . chr( 65 + $k ) . ') ' . $s;
					}
				}
				$content[] = array( 'type' => 'text', 'text' => $tx );
				if ( $b['gor'] ) {
					$content[] = array( 'type' => 'image', 'source' => array( 'type' => 'base64', 'media_type' => $b['gor']['tip'], 'data' => $b['gor']['veri'] ) );
				}
			}
			$txt          = sides_kzai_model_cagir( $a, $system, $content, sides_kzai_sema(), 400 + 350 * count( $bekle ) );
			$res['cagri'] = 1;
			/* v7.9.28 yapay zekâ kullanım kaydı (MEB YZ etik kılavuzu: şeffaflık, hesap verebilirlik); öğrenci bilgisi yazılmaz */
			sides_log( $org, 'Yapay zekâ kazanım önerisi: ' . count( $bekle ) . ' soru (' . $ders . ', ' . $sinif . '. sınıf, model ' . (string) $a['model'] . ')' . ( is_wp_error( $txt ) ? ' · hata' : '' ) );
			$j            = is_wp_error( $txt ) ? null : json_decode( $txt, true );
			if ( is_wp_error( $txt ) || ! is_array( $j ) || ! isset( $j['sonuclar'] ) ) {
				$m = is_wp_error( $txt ) ? $txt->get_error_message() : 'Yapay zekânın yanıtı okunamadı. Tekrar deneyin.';
				foreach ( $bekle as $i => $b ) {
					$out[ $i ] = array( 'qid' => $b['qid'], 'durum' => 'hata', 'not' => $m );
				}
				$res['uyari']  = $m;
				$res['durdur'] = true;
			} else {
				if ( ! $sahte ) {
					sides_ai_say( $org, 1 );
				}
				$hamNo = array();
				foreach ( (array) $j['sonuclar'] as $r ) {
					$n = isset( $r['no'] ) ? (int) $r['no'] : 0;
					if ( isset( $sira[ $n ] ) && ! isset( $hamNo[ $n ] ) ) {
						$hamNo[ $n ] = $r;
					}
				}
				$model = $sahte ? 'test' : $a['model'];
				foreach ( $sira as $n => $i ) {
					$b   = $bekle[ $i ];
					$ham = isset( $hamNo[ $n ] ) ? $hamNo[ $n ] : null;
					if ( $ham ) {
						unset( $ham['no'] );
						sides_put_doc( $org, 'kzoneri', $b['cid'], array( 'h' => $b['h'], 'surum' => $surum, 'ders' => $ders, 'sinif' => $sinif, 'model' => $model, 'is' => SIDES_KZAI_IS, 'tarih' => gmdate( 'c' ), 'ham' => $ham ) );
					}
					$out[ $i ] = array( 'qid' => $b['qid'], 'onbellek' => false, 'model' => $model, 'tarih' => gmdate( 'c' ) ) + sides_kzai_dogrula( $ham, $ogeler );
				}
			}
		}
	}
	ksort( $out );
	$res['sonuclar'] = array_values( $out );
	$res['ai']       = sides_ai_durum( $org );
	$res['is']       = SIDES_KZAI_IS;
	return $res;
}
