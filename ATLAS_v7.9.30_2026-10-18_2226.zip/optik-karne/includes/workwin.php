<?php
/**
 * v5.3 Workwin Doküman Kontrolü — sunucu uçları (Takip modülü)
 *
 * Belgeler (koleksiyon: workwin):
 *   ww_<studentId>_<yil>  : { studentId, yil, tarih: '<yil>-09-01', hucre: { '<YYYY-MM>|<ders>': { d, t, u, uid, not, ek } }, gecmis: [son 50 değişiklik] }
 *   islem_<islemId>       : toplu işlem kaydı { yil, key, d, not, t, uid, u, ogrenciler: { sid: { eski, yeni } }, atlanan: [], geriAlindi }
 * Uçlar (optik-karne/v1):
 *   POST workwin/hucre   { studentId, yil, key, d, not, ek }                         tek hücre (birleştirir, geçmişe yazar)
 *   POST workwin/toplu   { studentIds[], yil, key, d, not, islemId, uzerineYaz }     çok öğrenciye aynı durum; islemId ile yineleme koruması
 *   POST workwin/geriAl  { islemId }                                                 toplu işlemi geri alır (yönetici ya da işlemi yapan)
 *   POST workwin/ayar    { basAy, bitAy, dersler[], muafAcik }                       settings.main.workwin (yalnızca yönetici)
 * Okuma: GET koleksiyon/workwin?bas=<yil>-01-01&bit=<yil>-12-31 (ortak.php; sınıf kısıtı uygulanır).
 */
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'SIDES_WW_DERSLER', array( 'Türkçe', 'Matematik', 'İngilizce', 'Fen Bilimleri', 'Sosyal Bilgiler' ) );
define( 'SIDES_WW_DURUM', array( 'ok', 'no', 'muaf' ) );

add_action( 'rest_api_init', function () {
	$ns  = 'optik-karne/v1';
	$yaz = function () {
		if ( sides_is_observer() ) {
			return sides_deny( 'Gözlemci hesabının işlem yetkisi yok. Yöneticinizden izin isteyin.' );
		}
		return sides_can( 'takip', 2 ) ? true : sides_deny( 'Takip modülünde değişiklik yapma yetkiniz yok.' );
	};
	register_rest_route( $ns, '/workwin/hucre', array( 'methods' => 'POST', 'callback' => 'sides_ww_hucre', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/workwin/toplu', array( 'methods' => 'POST', 'callback' => 'sides_ww_toplu', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/workwin/geriAl', array( 'methods' => 'POST', 'callback' => 'sides_ww_geri_al', 'permission_callback' => $yaz ) );
	register_rest_route( $ns, '/workwin/ayar', array( 'methods' => 'POST', 'callback' => 'sides_ww_ayar', 'permission_callback' => function () use ( $yaz ) {
		$r = $yaz();
		if ( true !== $r ) {
			return $r;
		}
		return 'yonetici' === sides_ctx()['rol'] ? true : sides_deny( 'Workwin ayarlarını yalnızca kurum yöneticisi değiştirebilir.' );
	} ) );
} );

/* ---------- yardımcılar ---------- */
function sides_ww_ayar_oku( $org ) {
	$s = sides_get_doc( $org, 'settings', 'main' );
	$w = $s && isset( $s['workwin'] ) && is_array( $s['workwin'] ) ? $s['workwin'] : array();
	$dersler = isset( $w['dersler'] ) && is_array( $w['dersler'] ) ? array_values( array_filter( array_map( 'strval', $w['dersler'] ) ) ) : array();
	return array(
		'basAy'    => isset( $w['basAy'] ) ? max( 1, min( 12, (int) $w['basAy'] ) ) : 9,
		'bitAy'    => isset( $w['bitAy'] ) ? max( 1, min( 12, (int) $w['bitAy'] ) ) : 6,
		'dersler'  => $dersler ? $dersler : SIDES_WW_DERSLER,
		'muafAcik' => ! empty( $w['muafAcik'] ),
	);
}
function sides_ww_kim() {
	$u = wp_get_current_user();
	return array( 'uid' => $u && $u->ID ? (int) $u->ID : 0, 'u' => $u && $u->ID ? $u->display_name : 'Sistem' );
}
function sides_ww_yil( $v ) {
	$y = (int) $v;
	return $y >= 2020 && $y <= 2100 ? $y : 0;
}
/* Hücre anahtarı: YYYY-MM|ders (ders en çok 40 karakter). Ayarlardaki ders listesi dışında da (ör. arşiv yılı) kabul edilir. */
function sides_ww_key( $k ) {
	$k = trim( (string) $k );
	if ( ! preg_match( '/^(\d{4})-(0[1-9]|1[0-2])\|(.{1,40})$/u', $k, $m ) ) {
		return '';
	}
	$ders = sanitize_text_field( $m[3] );
	return ( '' === $ders || mb_strlen( $ders ) > 40 ) ? '' : $m[1] . '-' . $m[2] . '|' . $ders;
}
function sides_ww_metin( $v, $n ) {
	return mb_substr( sanitize_text_field( (string) $v ), 0, $n );
}
/* Ek: görsel kimliği (gXXXX) ya da http(s) bağlantısı; başka bir şey kabul edilmez */
function sides_ww_ek( $v ) {
	$v = trim( (string) $v );
	if ( '' === $v ) {
		return '';
	}
	if ( preg_match( '/^g[a-f0-9]{16,40}$/', $v ) ) {
		return $v;
	}
	$u = esc_url_raw( $v, array( 'http', 'https' ) );
	return $u && mb_strlen( $u ) <= 300 ? $u : '';
}
function sides_ww_ogrenci_var( $org, $sid ) {
	return preg_match( '/^[A-Za-z0-9_\-]{1,40}$/', $sid ) && sides_get_doc( $org, 'students', $sid ) ? true : false;
}
function sides_ww_doc( $org, $sid, $yil ) {
	$id = 'ww_' . $sid . '_' . $yil;
	$d  = sides_get_doc( $org, 'workwin', $id );
	if ( ! $d ) {
		$d = array( 'studentId' => $sid, 'yil' => $yil, 'tarih' => $yil . '-09-01', 'hucre' => array(), 'gecmis' => array() );
	}
	unset( $d['id'], $d['token'] );
	$d['studentId'] = $sid;
	$d['yil']       = $yil;
	$d['tarih']     = $yil . '-09-01';
	if ( ! isset( $d['hucre'] ) || ! is_array( $d['hucre'] ) ) {
		$d['hucre'] = array();
	}
	if ( ! isset( $d['gecmis'] ) || ! is_array( $d['gecmis'] ) ) {
		$d['gecmis'] = array();
	}
	return array( $id, $d );
}
function sides_ww_kaydet( $org, $id, $d ) {
	$d['hucre']  = (object) $d['hucre'];
	$d['gecmis'] = array_values( array_slice( $d['gecmis'], -50 ) );
	if ( false === sides_put_doc( $org, 'workwin', $id, $d ) ) {
		return null;
	}
	$d['id'] = $id;
	return $d;
}
/* Hücreyi değiştirir (null = Bekliyor'a al) ve geçmişe yazar; belgeyi döndürür */
function sides_ww_uygula( &$d, $key, $yeni, $islem ) {
	$kim  = sides_ww_kim();
	$eski = isset( $d['hucre'][ $key ] ) ? $d['hucre'][ $key ] : null;
	if ( null === $yeni ) {
		unset( $d['hucre'][ $key ] );
	} else {
		$d['hucre'][ $key ] = $yeni;
	}
	$d['gecmis'][] = array( 't' => (int) round( microtime( true ) * 1000 ), 'uid' => $kim['uid'], 'u' => $kim['u'], 'key' => $key, 'eski' => $eski, 'yeni' => $yeni, 'islem' => $islem );
	return $eski;
}
function sides_ww_hucre_yap( $d_kod, $not, $ek ) {
	$kim = sides_ww_kim();
	$h   = array( 'd' => $d_kod, 't' => (int) round( microtime( true ) * 1000 ), 'u' => $kim['u'], 'uid' => $kim['uid'] );
	if ( '' !== $not ) {
		$h['not'] = $not;
	}
	if ( '' !== $ek ) {
		$h['ek'] = $ek;
	}
	return $h;
}
/* Durum doğrulama: '' → Bekliyor (null); muaf için ayar açık ve gerekçe zorunlu */
function sides_ww_durum( $org, $v, $not ) {
	$v = (string) $v;
	if ( '' === $v || 'bekliyor' === $v ) {
		return null;
	}
	if ( ! in_array( $v, SIDES_WW_DURUM, true ) ) {
		return new WP_Error( 'sides_gecersiz', 'Geçersiz durum.', array( 'status' => 400 ) );
	}
	if ( 'muaf' === $v ) {
		if ( ! sides_ww_ayar_oku( $org )['muafAcik'] ) {
			return new WP_Error( 'sides_gecersiz', 'Muaf seçeneği bu kurumda kapalı; yönetici Workwin ayarlarından açabilir.', array( 'status' => 400 ) );
		}
		if ( '' === trim( (string) $not ) ) {
			return new WP_Error( 'sides_gecersiz', 'Muaf için gerekçe yazılması gerekir.', array( 'status' => 400 ) );
		}
	}
	return $v;
}

/* ---------- POST workwin/hucre ---------- */
function sides_ww_hucre( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	$sid = isset( $p['studentId'] ) ? (string) $p['studentId'] : '';
	$yil = sides_ww_yil( isset( $p['yil'] ) ? $p['yil'] : 0 );
	$key = sides_ww_key( isset( $p['key'] ) ? $p['key'] : '' );
	$not = sides_ww_metin( isset( $p['not'] ) ? $p['not'] : '', 300 );
	$ek  = sides_ww_ek( isset( $p['ek'] ) ? $p['ek'] : '' );
	if ( ! $yil || ! $key || ! sides_ww_ogrenci_var( $org, $sid ) ) {
		return new WP_Error( 'sides_gecersiz', 'Geçersiz kayıt (öğrenci, yıl ya da hücre anahtarı).', array( 'status' => 400 ) );
	}
	$izin = sides_takip_izin( $org );
	if ( null !== $izin && ! isset( $izin[ $sid ] ) ) {
		return sides_deny( 'Bu öğrenci, yetkili olduğunuz sınıfların dışında.' );
	}
	$durum = sides_ww_durum( $org, isset( $p['d'] ) ? $p['d'] : '', $not );
	if ( is_wp_error( $durum ) ) {
		return $durum;
	}
	$kilit = sides_takip_kilit( $org . '|workwin|ww_' . $sid . '_' . $yil );
	if ( false === $kilit ) {
		return sides_kilit_mesgul();   // T06: kilit alınamadı, hiçbir şey yazılmadı
	}
	list( $id, $d ) = sides_ww_doc( $org, $sid, $yil );
	$yeni = null === $durum ? null : sides_ww_hucre_yap( $durum, $not, $ek );
	$eski = sides_ww_uygula( $d, $key, $yeni, 'hucre' );
	$out  = sides_ww_kaydet( $org, $id, $d );
	sides_takip_kilit_birak( $kilit );
	if ( ! $out ) {
		return new WP_Error( 'sides_db', 'Kaydedilemedi.', array( 'status' => 500 ) );
	}
	return array( 'hucre' => $yeni, 'eski' => $eski, 'key' => $key, 'studentId' => $sid, 'yil' => $yil, 'doc' => $out );
}

/* ---------- POST workwin/toplu ----------
 * T07: işlem belgesi en başta 'basladi' durumu ve planlanan öğrenci listesiyle yazılır; her öğrenciden sonra ilerleme kaydedilir,
 * sonda 'tamam' (hepsi işlendi) ya da 'kismi' (bazı öğrenciler kaydedilemedi) olur. Aynı islemId ile yinelenen istek yalnızca eksik
 * öğrencileri işler: belgede kayıtlı ya da öğrencinin geçmişinde bu işlem kimliğiyle görünen hücreye ikinci kez dokunulmaz.
 * Plan (anahtar, durum, not, liste) ilk istekten gelir; aynı kimlikle farklı bir işlem gönderilirse reddedilir. Kısmi sonuçta yanıt 409
 * 'sides_ww_kismi' olur (istemci işlemi açık tutar, tekrar "Uygula" yalnız kalanları işler); geri alma kısmi işlemde de çalışır. */
function sides_ww_islem_ozet( $iid, $x, $docs, $ek = array() ) {
	$ogr = isset( $x['ogrenciler'] ) ? (array) $x['ogrenciler'] : array();
	$bas = isset( $x['basarisiz'] ) ? (array) $x['basarisiz'] : array();
	$x['id'] = 'islem_' . $iid;
	return array_merge( array(
		'islemId'     => $iid,
		'durum'       => isset( $x['durum'] ) ? $x['durum'] : 'tamam',
		'uygulanan'   => count( $ogr ),
		'uygulananlar' => array_map( 'strval', array_keys( $ogr ) ),
		'atlanan'     => count( isset( $x['atlanan'] ) ? (array) $x['atlanan'] : array() ),
		'atlananlar'  => array_values( isset( $x['atlanan'] ) ? (array) $x['atlanan'] : array() ),
		'basarisiz'   => array_map( function ( $sid, $n ) { return array( 'studentId' => (string) $sid, 'neden' => (string) $n ); }, array_keys( $bas ), array_values( $bas ) ),
		'docs'        => $docs,
		'islem'       => $x,
	), $ek );
}
function sides_ww_toplu( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	$ids = isset( $p['studentIds'] ) && is_array( $p['studentIds'] ) ? array_values( array_unique( array_map( 'strval', $p['studentIds'] ) ) ) : array();
	$yil = sides_ww_yil( isset( $p['yil'] ) ? $p['yil'] : 0 );
	$key = sides_ww_key( isset( $p['key'] ) ? $p['key'] : '' );
	$not = sides_ww_metin( isset( $p['not'] ) ? $p['not'] : '', 300 );
	$iid = isset( $p['islemId'] ) ? (string) $p['islemId'] : '';
	$uz  = ! empty( $p['uzerineYaz'] );
	if ( ! $yil || ! $key || ! $ids || count( $ids ) > 500 || ! preg_match( '/^[A-Za-z0-9_\-]{6,40}$/', $iid ) ) {
		return new WP_Error( 'sides_gecersiz', 'Geçersiz toplu işlem (öğrenci listesi, yıl, anahtar ya da işlem kimliği).', array( 'status' => 400 ) );
	}
	foreach ( $ids as $sid ) {
		if ( ! preg_match( '/^[A-Za-z0-9_\-]{1,40}$/', $sid ) ) {
			return new WP_Error( 'sides_gecersiz', 'Geçersiz öğrenci kimliği.', array( 'status' => 400 ) );
		}
	}
	if ( ! sides_rl( 'ww_toplu_' . get_current_user_id(), 60, 600 ) ) {
		return new WP_Error( 'sides_hiz', 'Çok sık toplu işlem; biraz bekleyin.', array( 'status' => 429 ) );
	}
	$durum = sides_ww_durum( $org, isset( $p['d'] ) ? $p['d'] : '', $not );
	if ( is_wp_error( $durum ) ) {
		return $durum;
	}
	$iidoc = 'islem_' . $iid;
	$ikilt = sides_takip_kilit( $org . '|workwin|' . $iidoc );   // aynı kimlikle eşzamanlı ikinci istek beklemeye girer
	if ( false === $ikilt ) {
		return sides_kilit_mesgul();
	}
	$islem = sides_get_doc( $org, 'workwin', $iidoc );
	if ( $islem ) {
		unset( $islem['id'], $islem['token'] );
		$durumX = isset( $islem['durum'] ) ? $islem['durum'] : 'tamam';   // eski sürüm kaydı: tamamlanmış sayılır
		if ( ! empty( $islem['geriAlindi'] ) ) {
			sides_takip_kilit_birak( $ikilt );
			return new WP_Error( 'sides_gecersiz', 'Bu toplu işlem geri alınmış; yeniden uygulamak için yeni bir toplu işlem başlatın.', array( 'status' => 409 ) );
		}
		if ( (string) $islem['key'] !== $key || (int) $islem['yil'] !== $yil || ( isset( $islem['d'] ) ? $islem['d'] : null ) !== $durum ) {
			sides_takip_kilit_birak( $ikilt );
			return new WP_Error( 'sides_gecersiz', 'Bu işlem kimliği farklı bir toplu işlem için kullanılmış.', array( 'status' => 409 ) );
		}
		if ( 'tamam' === $durumX ) {
			sides_takip_kilit_birak( $ikilt );
			return sides_ww_islem_ozet( $iid, $islem, array(), array( 'yinelenen' => true ) );
		}
		$plan = isset( $islem['plan'] ) ? array_values( array_map( 'strval', (array) $islem['plan'] ) ) : $ids;
		$uz   = ! empty( $islem['uzerineYaz'] );
		$not  = isset( $islem['not'] ) ? (string) $islem['not'] : $not;
	} else {
		$plan = $ids;
	}
	$izin = sides_takip_izin( $org );
	foreach ( $plan as $sid ) {
		if ( null !== $izin && ! isset( $izin[ $sid ] ) ) {
			sides_takip_kilit_birak( $ikilt );
			return sides_deny( 'Listede yetkili olduğunuz sınıfların dışında öğrenci var; işlem yapılmadı.' );
		}
	}
	$kim = sides_ww_kim();
	if ( ! $islem ) {
		$islem = array( 'tur' => 'toplu', 'durum' => 'basladi', 'yil' => $yil, 'tarih' => $yil . '-09-01', 'key' => $key, 'd' => $durum, 'not' => $not, 't' => (int) round( microtime( true ) * 1000 ), 'uid' => $kim['uid'], 'u' => $kim['u'], 'plan' => $plan, 'ogrenciler' => array(), 'uygulanan' => 0, 'atlanan' => array(), 'basarisiz' => array(), 'uzerineYaz' => $uz, 'geriAlindi' => false );
		if ( false === sides_put_doc( $org, 'workwin', $iidoc, array_merge( $islem, array( 'ogrenciler' => (object) array(), 'basarisiz' => (object) array() ) ) ) ) {
			sides_takip_kilit_birak( $ikilt );
			return new WP_Error( 'sides_db', 'İşlem kaydı yazılamadı; hiçbir öğrenci değişmedi.', array( 'status' => 500 ) );
		}
	} else {
		$islem['durum'] = 'basladi';
		$islem['devam'] = isset( $islem['devam'] ) ? (int) $islem['devam'] + 1 : 1;
	}
	$islem['ogrenciler'] = isset( $islem['ogrenciler'] ) ? (array) $islem['ogrenciler'] : array();
	$islem['atlanan']    = isset( $islem['atlanan'] ) ? array_values( (array) $islem['atlanan'] ) : array();
	$islem['basarisiz']  = array();   // her denemede yeniden hesaplanır
	$ilerle = function () use ( $org, $iidoc, &$islem ) {
		$x               = $islem;
		$x['uygulanan']  = count( $islem['ogrenciler'] );
		$x['ogrenciler'] = (object) $islem['ogrenciler'];
		$x['basarisiz']  = (object) $islem['basarisiz'];
		return false !== sides_put_doc( $org, 'workwin', $iidoc, $x );
	};
	$docs = array();
	$buSefer = 0;
	foreach ( $plan as $sid ) {
		if ( isset( $islem['ogrenciler'][ $sid ] ) || in_array( $sid, $islem['atlanan'], true ) ) {
			continue;   // önceki denemede işlendi
		}
		$hata = apply_filters( 'sides_ww_toplu_ogrenci_hata', '', $sid, $iid );   // sınama kancası (varsayılan: hata yok)
		if ( $hata ) {
			$islem['basarisiz'][ $sid ] = (string) $hata;
			$ilerle();
			continue;
		}
		if ( ! sides_ww_ogrenci_var( $org, $sid ) ) {
			$islem['basarisiz'][ $sid ] = 'Öğrenci kaydı bulunamadı (silinmiş olabilir).';
			$ilerle();
			continue;
		}
		$kilit = sides_takip_kilit( $org . '|workwin|ww_' . $sid . '_' . $yil );
		if ( false === $kilit ) {
			$islem['basarisiz'][ $sid ] = 'Kayıt başka bir işlemle güncelleniyordu.';
			$ilerle();
			continue;
		}
		list( $id, $d ) = sides_ww_doc( $org, $sid, $yil );
		$onceki = null;   // çökme sonrası: hücre bu işlemle zaten değişmiş mi (geçmişte aynı işlem kimliği)?
		foreach ( array_reverse( $d['gecmis'] ) as $g ) {
			if ( isset( $g['islem'], $g['key'] ) && $g['islem'] === $iid && $g['key'] === $key ) {
				$onceki = $g;
				break;
			}
		}
		if ( $onceki ) {
			sides_takip_kilit_birak( $kilit );
			$islem['ogrenciler'][ $sid ] = array( 'eski' => isset( $onceki['eski'] ) ? $onceki['eski'] : null, 'yeni' => isset( $onceki['yeni'] ) ? $onceki['yeni'] : null );
			$ilerle();
			continue;
		}
		$mevcut = isset( $d['hucre'][ $key ] ) ? $d['hucre'][ $key ] : null;
		if ( $mevcut && isset( $mevcut['d'] ) && 'ok' === $mevcut['d'] && ! $uz && 'ok' !== $durum ) {
			sides_takip_kilit_birak( $kilit );
			$islem['atlanan'][] = $sid;   // kontrol edilmiş hücre bilinçsizce sıfırlanmaz
			$ilerle();
			continue;
		}
		$yeni = null === $durum ? null : sides_ww_hucre_yap( $durum, $not, '' );
		if ( $mevcut && $yeni && isset( $mevcut['ek'] ) ) {
			$yeni['ek'] = $mevcut['ek'];   // eki koru
		}
		$eski = sides_ww_uygula( $d, $key, $yeni, $iid );
		$out  = sides_ww_kaydet( $org, $id, $d );
		sides_takip_kilit_birak( $kilit );
		if ( ! $out ) {
			$islem['basarisiz'][ $sid ] = 'Veritabanına yazılamadı.';
			$ilerle();
			continue;
		}
		$islem['ogrenciler'][ $sid ] = array( 'eski' => $eski, 'yeni' => $yeni );
		$docs[] = $out;
		$buSefer++;
		$ilerle();
	}
	$islem['durum'] = $islem['basarisiz'] ? 'kismi' : 'tamam';
	$kayit          = $ilerle();
	sides_takip_kilit_birak( $ikilt );
	$islem['uygulanan'] = count( $islem['ogrenciler'] );
	if ( $buSefer || ! empty( $islem['devam'] ) || $islem['basarisiz'] ) {
		sides_log( $org, 'Workwin toplu işlem: ' . $key . ' → ' . ( null === $durum ? 'Bekliyor' : $durum ) . ' (' . $buSefer . ' öğrenci' . ( $islem['atlanan'] ? ', ' . count( $islem['atlanan'] ) . ' atlandı' : '' ) . ( $islem['basarisiz'] ? ', ' . count( $islem['basarisiz'] ) . ' kaydedilemedi' : '' ) . ( ! empty( $islem['devam'] ) ? ', devam' : '' ) . ')' );
	}
	$ozet = sides_ww_islem_ozet( $iid, $islem, $docs, array( 'buSefer' => $buSefer ) );
	if ( ! $kayit ) {
		return new WP_Error( 'sides_db', 'Öğrenciler işlendi ancak işlem kaydının son hâli yazılamadı; aynı işlemi tekrar uygulayın (yalnızca eksikler işlenir).', array( 'status' => 500, 'sonuc' => $ozet ) );
	}
	if ( $islem['basarisiz'] ) {
		$n = count( $islem['basarisiz'] );
		return new WP_Error( 'sides_ww_kismi', $ozet['uygulanan'] . ' öğrenciye uygulandı, ' . $n . ' öğrenci kaydedilemedi (' . reset( $islem['basarisiz'] ) . '). Tekrar “Uygula”ya basarsanız yalnızca kalan öğrenciler işlenir; işlem geçmişinden geri alabilirsiniz.', array( 'status' => 409, 'sonuc' => $ozet ) );
	}
	return $ozet;
}

/* ---------- POST workwin/geriAl ---------- */
function sides_ww_geri_al( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	$iid = isset( $p['islemId'] ) ? (string) $p['islemId'] : '';
	if ( ! preg_match( '/^[A-Za-z0-9_\-]{6,40}$/', $iid ) ) {
		return new WP_Error( 'sides_gecersiz', 'Geçersiz işlem kimliği.', array( 'status' => 400 ) );
	}
	$iidoc = 'islem_' . $iid;
	$kilit = sides_takip_kilit( $org . '|workwin|' . $iidoc );
	if ( false === $kilit ) {
		return sides_kilit_mesgul();   // T06: kilit alınamadı, hiçbir şey yazılmadı
	}
	$islem = sides_get_doc( $org, 'workwin', $iidoc );
	if ( ! $islem || ! isset( $islem['ogrenciler'] ) ) {
		sides_takip_kilit_birak( $kilit );
		return new WP_Error( 'sides_yok', 'İşlem bulunamadı.', array( 'status' => 404 ) );
	}
	if ( ! empty( $islem['geriAlindi'] ) ) {
		sides_takip_kilit_birak( $kilit );
		return new WP_Error( 'sides_gecersiz', 'Bu işlem zaten geri alınmış.', array( 'status' => 409 ) );
	}
	$ctx = sides_ctx();
	if ( 'yonetici' !== $ctx['rol'] && (int) $islem['uid'] !== (int) $ctx['uid'] ) {
		sides_takip_kilit_birak( $kilit );
		return sides_deny( 'Toplu işlemi yalnızca yönetici ya da işlemi yapan kişi geri alabilir.' );
	}
	$izin  = sides_takip_izin( $org );
	$yil   = (int) $islem['yil'];
	$key   = (string) $islem['key'];
	$geri  = 0;
	$degis = array();
	$docs  = array();
	foreach ( (array) $islem['ogrenciler'] as $sid => $h ) {
		$sid = (string) $sid;
		if ( null !== $izin && ! isset( $izin[ $sid ] ) ) {
			$degis[] = $sid;
			continue;
		}
		$k2 = sides_takip_kilit( $org . '|workwin|ww_' . $sid . '_' . $yil );
		list( $id, $d ) = sides_ww_doc( $org, $sid, $yil );
		$mevcut = isset( $d['hucre'][ $key ] ) ? $d['hucre'][ $key ] : null;
		$yeni   = isset( $h['yeni'] ) ? $h['yeni'] : null;
		$ayni   = ( null === $mevcut && null === $yeni ) || ( $mevcut && $yeni && (int) $mevcut['t'] === (int) $yeni['t'] && $mevcut['d'] === $yeni['d'] );
		if ( ! $ayni ) {   // işlemden sonra elle değiştirilmiş hücreye dokunulmaz
			$degis[] = $sid;
			sides_takip_kilit_birak( $k2 );
			continue;
		}
		$eski = isset( $h['eski'] ) && is_array( $h['eski'] ) ? $h['eski'] : null;
		sides_ww_uygula( $d, $key, $eski, 'geri:' . $iid );
		$out = sides_ww_kaydet( $org, $id, $d );
		sides_takip_kilit_birak( $k2 );
		if ( ! $out ) {
			sides_takip_kilit_birak( $kilit );
			return new WP_Error( 'sides_db', 'Kaydedilemedi (' . $sid . ').', array( 'status' => 500 ) );
		}
		$geri++;
		$docs[] = $out;
	}
	$kim = sides_ww_kim();
	unset( $islem['id'], $islem['token'] );
	$islem['geriAlindi'] = true;
	$islem['geriAlan']   = array( 't' => (int) round( microtime( true ) * 1000 ), 'uid' => $kim['uid'], 'u' => $kim['u'], 'geri' => $geri, 'degismis' => $degis );
	sides_put_doc( $org, 'workwin', $iidoc, $islem );
	sides_takip_kilit_birak( $kilit );
	$islem['id'] = $iidoc;
	sides_log( $org, 'Workwin toplu işlem geri alındı: ' . $key . ' (' . $geri . ' öğrenci)' );
	return array( 'islemId' => $iid, 'geri' => $geri, 'degismis' => count( $degis ), 'docs' => $docs, 'islem' => $islem );
}

/* ---------- POST workwin/ayar ---------- */
function sides_ww_ayar( WP_REST_Request $req ) {
	$org = sides_org_id();
	$p   = $req->get_json_params();
	$bas = isset( $p['basAy'] ) ? (int) $p['basAy'] : 9;
	$bit = isset( $p['bitAy'] ) ? (int) $p['bitAy'] : 6;
	if ( $bas < 1 || $bas > 12 || $bit < 1 || $bit > 12 ) {
		return new WP_Error( 'sides_gecersiz', 'Ay 1 ile 12 arasında olmalı.', array( 'status' => 400 ) );
	}
	$dersler = array();
	foreach ( ( isset( $p['dersler'] ) && is_array( $p['dersler'] ) ? $p['dersler'] : array() ) as $x ) {
		$x = sides_ww_metin( $x, 40 );
		if ( '' !== $x && ! in_array( $x, $dersler, true ) ) {
			$dersler[] = $x;
		}
	}
	if ( ! $dersler || count( $dersler ) > 12 ) {
		return new WP_Error( 'sides_gecersiz', 'En az bir, en çok on iki ders yazın.', array( 'status' => 400 ) );
	}
	$ayar  = array( 'basAy' => $bas, 'bitAy' => $bit, 'dersler' => $dersler, 'muafAcik' => ! empty( $p['muafAcik'] ) );
	$kilit = sides_takip_kilit( $org . '|settings|main' );
	if ( false === $kilit ) {
		return sides_kilit_mesgul();   // T06: kilit alınamadı, hiçbir şey yazılmadı
	}
	$s     = sides_get_doc( $org, 'settings', 'main' );
	$s     = $s ? $s : array();
	unset( $s['id'], $s['token'] );
	$s['workwin'] = $ayar;
	$ok = sides_put_doc( $org, 'settings', 'main', $s );
	sides_takip_kilit_birak( $kilit );
	if ( false === $ok ) {
		return new WP_Error( 'sides_db', 'Ayar kaydedilemedi.', array( 'status' => 500 ) );
	}
	sides_log( $org, 'Workwin ayarları güncellendi' );
	return array( 'workwin' => $ayar );
}
