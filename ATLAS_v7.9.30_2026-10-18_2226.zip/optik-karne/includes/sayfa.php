<?php
/**
 * v5.5 · Alt başlık (sayfa) düzeyinde kullanıcı yetkileri.
 *
 * Modül yetkileri (sides_yetki) olduğu gibi kalır. Personel ve gözlemci için isteğe bağlı bir sayfa haritası
 * (user meta sides_sayfa: { "sinav.param": 0, "karne.liste": 1, "_paylas": 0 }) modül düzeyini sayfa bazında daraltır:
 *   etkin düzey = min( sayfanın modül yetkisi, haritadaki değer ); haritada olmayan sayfa modül yetkisini kullanır.
 * Harita yoksa her şey eskisi gibidir. Anahtarlar sayfanın sabit rota kimliğidir (menüde taşınsa da değişmez).
 * Özel anahtar: _paylas = 0 → paylaşım bağlantısı (veli, TV, okutma, takip linki) oluşturamaz.
 *
 * Sunucu denetimi: rest_request_before_callbacks süzgeci, haritası olan kullanıcının isteklerini
 * ilgili sayfa yetkisine göre süzer (okuma: GET → 1, değişiklik: diğer yöntemler → 2).
 *
 * @package SIDES
 */

defined( 'ABSPATH' ) || exit;

/* İstemcideki modOf() ile aynı kural */
function sides_sayfa_mod( $k ) {
	$k = (string) $k;
	if ( 'dash' === $k ) {
		return 'panel';
	}
	if ( 0 === strpos( $k, 'lgs.' ) || 'sinavEdit' === $k ) {
		return 'sinav';
	}
	if ( 'crm.takvim' === $k ) {
		return 'takvim';
	}
	if ( in_array( $k, array( 'test.havuz', 'test.kaynak', 'test.dosya' ), true ) ) {
		return 'havuz';
	}
	if ( in_array( $k, array( 'sistem.kullanici', 'sistem.yedek' ), true ) ) {
		return 'kullanici';
	}
	$p = strpos( $k, '.' );
	return false === $p ? $k : substr( $k, 0, $p );
}

function sides_sayfa_temizle( $h ) {
	$out = array();
	foreach ( (array) $h as $k => $v ) {
		$k = (string) $k;
		if ( count( $out ) >= 150 || ! preg_match( '/^(_paylas|[a-z]{2,12}(\.[A-Za-z]{2,20})?)$/', $k ) ) {
			continue;
		}
		$v = (int) $v;
		if ( '_paylas' === $k ) {
			if ( 0 === $v ) {
				$out[ $k ] = 0;
			}
			continue;
		}
		if ( $v >= 0 && $v < 2 ) {   // 2 = modülle aynı: kaydedilmez
			$out[ $k ] = $v;
		}
	}
	return $out;
}

function sides_sayfa_harita( $uid = null ) {
	$c = sides_ctx( $uid );
	if ( ! $c['org'] || ! in_array( $c['rol'], array( 'personel', 'gozlemci' ), true ) ) {
		return array();
	}
	$h = get_user_meta( $c['uid'], 'sides_sayfa', true );
	return is_array( $h ) ? $h : array();
}

/* Sayfanın etkin düzeyi (0 kapalı, 1 görüntüleme, 2 değiştirme) */
function sides_sayfa_duzey( $k ) {
	$c   = sides_ctx();
	$mod = sides_sayfa_mod( $k );
	if ( 'kullanici' === $mod ) {
		$base = 'yonetici' === $c['rol'] ? 2 : 0;
	} else {
		$base = isset( $c['yetki'][ $mod ] ) ? (int) $c['yetki'][ $mod ] : 0;
	}
	$h = sides_sayfa_harita();
	return isset( $h[ $k ] ) ? min( $base, (int) $h[ $k ] ) : $base;
}
function sides_sayfa_herhangi( $sayfalar, $lvl ) {
	foreach ( (array) $sayfalar as $k ) {
		if ( sides_sayfa_duzey( $k ) >= $lvl ) {
			return true;
		}
	}
	return false;
}
/* Modülün en az bir sayfası açık mı (bildirimlerde kullanılır) */
function sides_sayfa_mod_acik( $mod ) {
	$h = sides_sayfa_harita();
	$c = sides_ctx();
	if ( 'kullanici' === $mod ) {
		return 'yonetici' === $c['rol'];
	}
	if ( empty( $c['yetki'][ $mod ] ) ) {
		return false;
	}
	$sayfalar = array();
	foreach ( sides_sayfa_kurallari()['coll'] as $l ) {
		foreach ( $l as $k ) {
			if ( sides_sayfa_mod( $k ) === $mod ) {
				$sayfalar[ $k ] = 1;
			}
		}
	}
	if ( ! $h || ! $sayfalar ) {
		return true;
	}
	return sides_sayfa_herhangi( array_keys( $sayfalar ), 1 );
}

/* Koleksiyon ve uç → sayfa eşlemesi (herhangi biri yeterlidir; koleksiyonlar birden çok sayfada kullanılır) */
function sides_sayfa_kurallari() {
	static $k = null;
	if ( $k ) {
		return $k;
	}
	$neh_sinav = array( 'nehari.hbs', 'nehari.deneme', 'nehari.optik', 'nehari.karne' );
	$k         = array(
		'coll' => array(
			'students'  => array( 'kayit.ogr', 'kayit.sinif', 'nehari.ogr', 'crm.adaylar', 'crm.board' ),
			'exams'     => array_merge( array( 'sinav.denemeler', 'sinav.baski', 'sinav.takvim' ), $neh_sinav ),
			'results'   => array( 'karne.okut', 'karne.liste', 'sinav.denemeler', 'nehari.karne', 'nehari.optik' ),
			'duyurular' => array( 'sistem.duyuru' ),
			'adaylar'   => array( 'crm.dash', 'crm.board', 'crm.adaylar', 'crm.rapor', 'crm.link' ),
			'takvim'    => array( 'crm.takvim', 'sinav.takvim' ),
			'testler'   => array( 'test.liste', 'test.optik', 'nehari.test' ),
			'tsonuc'    => array( 'test.liste', 'test.optik', 'test.sonuc', 'test.karne', 'nehari.test', 'nehari.karne', 'nehari.optik' ),
			'havuz'     => array( 'test.havuz', 'test.dosya', 'test.kaynak', 'test.liste', 'nehari.havuz', 'nehari.test' ),
			'lgs'       => array( 'sinav.lgs', 'lgs.ogrenciler', 'lgs.profil', 'lgs.puan', 'lgs.kilavuz' ),   /* v7.9.9 tercih kılavuzu, puan hesaplama */
			'etut'      => array( 'takip.etut' ),
			'izin'      => array( 'takip.izin' ),
			'yoklama'   => array( 'takip.yoklama' ),
			'odev'      => array( 'takip.odev', 'takip.bugun' ),
			'dplan'     => array( 'takip.oturum', 'takip.bugun' ),
			'doturum'   => array( 'takip.oturum', 'takip.bugun' ),
			'kitap'     => array( 'takip.kitap', 'takip.kutuphane' ),   /* v7.9.4 kütüphane */
			'kutuphane' => array( 'takip.kutuphane', 'takip.kitap' ),
			'takviye'   => array( 'takip.takviye' ),
			'seviye'    => array( 'takip.seviye', 'takip.isleyis' ),
			'dgrup'     => array( 'takip.isleyis', 'takip.seviye' ),
			'hedef'     => array( 'takip.hedef' ),
			'hsablon'   => array( 'takip.hedef' ),
			'workwin'   => array( 'takip.workwin' ),
			'sgunluk'   => array( 'takip.gunluk' ),
			'stsinav'   => array( 'takip.sinav' ),   /* v7.9.2 sınav takip */
			'stsonuc'   => array( 'takip.sinav' ),
			'pkriter'   => array( 'puan.kriter', 'puan.elle' ),   /* v7.9.13 elle puan girişi (Elle Puan kriteri) */
			'phareket'  => array( 'puan.gunluk', 'puan.genel', 'puan.elle' ),
			'pgun'      => array( 'puan.gunluk' ),
			'podul'     => array( 'puan.siralama' ),
			'tv'        => array( 'puan.tv', 'puan.tvayar' ),
			'rsablon'   => array( 'rapor.sablon', 'rapor.olustur' ),
			'rapor'     => array( 'rapor.olustur', 'rapor.arsiv' ),
			'birlesik'  => array( 'analiz.birlestir' ),
			'velirapor' => array( 'analiz.tek' ),
		),
		// [rota deseni, sayfalar, paylaşım mı]
		'uc'   => array(
			array( '#^/gform(/|$)#', array( 'kayit.gform' ), false ),   // v7.9.25 ÖDS Kayıt (Google Form)
			array( '#^/takip$#', array( 'takip.etut', 'takip.yoklama', 'takip.izin', 'takip.kitap', 'takip.kutuphane', 'takip.takviye', 'takip.seviye', 'takip.isleyis', 'takip.sinav' ), false ),
			array( '#^/takip/link/#', array( 'takip.takviye', 'takip.kitap' ), true ),
			array( '#^/takip/olink#', array( 'takip.takviye' ), true ),
			array( '#^/dyoklama#', array( 'sinav.yoklama', 'sinav.denemeler' ), false ),   // v7.4: deneme yoklaması
			array( '#^/dklasor/#', array( 'sinav.denemeler' ), false ),   // v7.5: deneme klasörleri   // v7.3.1: öğretmen linkleri de paylaşım bağlantısıdır
			array( '#^/puan/(hareket|iptal|gun)$#', array( 'puan.gunluk', 'puan.elle' ), false ),
			array( '#^/puan/(haftaKapat|haftaAc|haftaOdul)$#', array( 'puan.siralama', 'puan.gunluk' ), false ),   // v7.9.27 haftaOdul: ödül listesi düzenleme
			array( '#^/puan/(ayar|kriterSil)$#', array( 'puan.kriter' ), false ),
			array( '#^/puan/#', array( 'puan.genel', 'puan.gunluk', 'puan.elle', 'puan.kriter', 'puan.siralama', 'puan.tv', 'puan.tvayar' ), false ),
			array( '#^/tv/link#', array( 'puan.tv', 'puan.tvayar' ), true ),
			array( '#^/rapor/(veri|kaydet)$#', array( 'rapor.olustur' ), false ),
			array( '#^/rapor/(liste|ac/)#', array( 'rapor.arsiv', 'rapor.olustur' ), false ),
			array( '#^/rapor/disa$#', array( 'rapor.olustur', 'rapor.arsiv' ), false ),
			array( '#^/analiz2/link#', array( 'analiz.tek' ), true ),
			array( '#^/workwin/#', array( 'takip.workwin' ), false ),
			array( '#^/kzai/#', array( 'test.kzai' ), false ),
			array( '#^/havuz/toplu$#', array( 'test.dosya', 'test.kaynak', 'test.havuz', 'nehari.havuz' ), false ),
			array( '#^/havuz$#', array( 'test.havuz', 'test.liste', 'test.dosya', 'test.kaynak', 'nehari.havuz', 'nehari.test' ), false ),
			array( '#^/tsonuc$#', array( 'test.sonuc', 'test.karne', 'test.liste', 'nehari.karne', 'nehari.test' ), false ),
			array( '#^/links$#', array( 'karne.liste', 'karne.link', 'nehari.karne' ), true ),
			array( '#^/okut-link$#', array( 'karne.link', 'karne.okut', 'nehari.optik', 'test.optik' ), true ),
			array( '#^/sinavtakip#', array( 'takip.sinav' ), false ),   // v7.9.2 sınav takip
			array( '#^/odev/kontrol$#', array( 'takip.odev' ), false ),   // v6 kurs takibi
			array( '#^/oturum/(yama|ogretmenler)$#', array( 'takip.oturum' ), false ),
		),
	);
	return $k;
}

/* Parametreler sayfasına ait ayar alanları (kurum logosu yükleme alanı Test Şablonu'nda da görünür; yetki yine Parametreler'dir) */
function sides_sayfa_ayar_alanlari() {
	return array(
		'kurum'      => array( 'sinav.param' ),
		'nehariAyri' => array( 'sinav.param' ),
		'logo'       => array( 'sinav.param' ),
	);
}

function sides_sayfa_istek_denetimi( $request ) {
	$route = (string) $request->get_route();
	if ( 0 !== strpos( $route, '/optik-karne/v1/' ) ) {
		return null;
	}
	$h = sides_sayfa_harita();
	if ( ! $h ) {
		return null;
	}
	$r   = substr( $route, strlen( '/optik-karne/v1' ) );
	$yaz = 'GET' !== $request->get_method() && 'HEAD' !== $request->get_method();
	$lvl = $yaz ? 2 : 1;
	$K   = sides_sayfa_kurallari();
	$red = function ( $m = '' ) {
		return sides_deny( $m ? $m : 'Bu sayfaya erişim yetkiniz yok. Yöneticinizden izin isteyin.' );
	};
	if ( preg_match( '#^/(doc|koleksiyon)/([a-z]+)(/|$)#', $r, $m ) ) {
		$coll = $m[2];
		if ( 'settings' === $coll ) {
			if ( ! $yaz ) {
				return null;
			}
			$yeni = json_decode( $request->get_body(), true );
			$eski = sides_get_doc( sides_org_id(), 'settings', (string) $request['id'] );
			$eski = is_array( $eski ) ? $eski : array();
			foreach ( sides_sayfa_ayar_alanlari() as $alan => $sayfalar ) {
				$a = isset( $eski[ $alan ] ) ? $eski[ $alan ] : null;
				$b = is_array( $yeni ) && isset( $yeni[ $alan ] ) ? $yeni[ $alan ] : null;
				if ( $a !== $b && ! sides_sayfa_herhangi( $sayfalar, 2 ) ) {
					return $red( 'Parametreler (kurum adı, logo) alanını değiştirme yetkiniz yok. Yöneticinizden izin isteyin.' );
				}
			}
			return null;
		}
		if ( isset( $K['coll'][ $coll ] ) && ! sides_sayfa_herhangi( $K['coll'][ $coll ], $lvl ) ) {
			return $red();
		}
		return null;
	}
	if ( preg_match( '#^/takip/(yama|yapi)$#', $r ) ) {
		$p    = $request->get_json_params();
		$coll = is_array( $p ) && isset( $p['coll'] ) ? (string) $p['coll'] : '';
		$s    = isset( $K['coll'][ $coll ] ) ? $K['coll'][ $coll ] : array( 'takip.etut', 'takip.izin', 'takip.kitap', 'takip.takviye', 'takip.seviye', 'takip.isleyis' );
		return sides_sayfa_herhangi( $s, 2 ) ? null : $red();
	}
	foreach ( $K['uc'] as $u ) {
		if ( preg_match( $u[0], $r ) ) {
			if ( $u[2] && $yaz && isset( $h['_paylas'] ) && 0 === (int) $h['_paylas'] ) {
				return $red( 'Paylaşım bağlantısı oluşturma yetkiniz yok. Yöneticinizden izin isteyin.' );
			}
			return sides_sayfa_herhangi( $u[1], $lvl ) ? null : $red();
		}
	}
	return null;
}
add_filter( 'rest_request_before_callbacks', function ( $response, $handler, $request ) {
	if ( is_wp_error( $response ) || ! function_exists( 'sides_ctx' ) ) {
		return $response;
	}
	$e = sides_sayfa_istek_denetimi( $request );
	return $e ? $e : $response;
}, 10, 3 );
