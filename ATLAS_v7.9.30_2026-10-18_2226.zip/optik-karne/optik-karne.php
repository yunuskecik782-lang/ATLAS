<?php
/**
 * Plugin Name:       ATLAS — Akademik Takip ve Analiz Sistemi
 * Description:       ATLAS · Akademik Takip ve Analiz Sistemi — Gelişiminin haritasını keşfet. Deneme ve kurum yönetim paneli: aday takip, öğrenci kayıt, sınav, analiz, hata karnesi, QR kodlu optik form okutma ve veli karnesi. Her hesap kendi kurum alanında çalışır.
 * Version:           7.9.30
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Yunus Keçik
 * License:           GPL-2.0-or-later
 * Text Domain:       optik-karne
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'OPTIK_KARNE_VER', '7.9.30' );
/* v7.9.27 güvenlik: WordPress REST adreslerini harf ayırmadan eşler ('@^…$@i'); ATLAS'ın ek süzgeçleri (sayfa haritası, bakım kapısı,
   TV sınıf kısıtı, ödev sahipliği, haftalık arşiv, önizleme) adresi birebir karşılaştırır. /OPTIK-KARNE/… ya da /…/DOC/… gibi farklı
   harfli bir adres o süzgeçleri atlatmasın diye, ATLAS ad alanına gelen istek kayıtlı rotaya harfi harfine uymuyorsa en başta reddedilir.
   Rotadaki değişken kısımlar (kimlikler) kendi desenlerine göre büyük harf içerebilir; yalnız sabit kısımların harfi denetlenir. */
add_filter( 'rest_pre_dispatch', function ( $result, $server, $req ) {
	$route = (string) $req->get_route();
	if ( null !== $result || 0 !== stripos( $route, '/optik-karne/v1' ) ) {
		return $result;
	}
	if ( 0 !== strpos( $route, '/optik-karne/v1' ) ) {
		return new WP_Error( 'rest_no_route', 'Adres bulunamadı.', array( 'status' => 404 ) );
	}
	foreach ( array_keys( $server->get_routes( 'optik-karne/v1' ) ) as $desen ) {
		if ( preg_match( '@^' . $desen . '$@i', $route ) ) {   // WordPress'in eşleyeceği ilk rota
			return preg_match( '@^' . $desen . '$@', $route ) ? $result : new WP_Error( 'rest_no_route', 'Adres bulunamadı.', array( 'status' => 404 ) );
		}
	}
	return $result;
}, -1000, 3 );
/* v7.9.27 güvenlik: kurum görselleri (coll 'gorsel') yalnız resim türüyle sunulur. Kayıttaki 'm' alanı yedekten ya da genel yazım ucundan
   gelebileceği için Content-Type olarak doğrudan kullanılmaz (text/html ile site kökeninde betik çalıştırılabiliyordu). ods.php logo ucuyla aynı. */
function sides_gorsel_tur( $d ) {
	$m = is_array( $d ) && isset( $d['m'] ) ? strtolower( (string) $d['m'] ) : '';
	return in_array( $m, array( 'image/jpeg', 'image/png', 'image/webp', 'image/gif' ), true ) ? $m : 'image/jpeg';
}
function sides_gorsel_basliklar( $d, $bin ) {
	header( 'Content-Type: ' . sides_gorsel_tur( $d ) );
	header( 'Content-Length: ' . strlen( $bin ) );
	header( 'X-Content-Type-Options: nosniff' );
	header( "Content-Security-Policy: default-src 'none'; style-src 'unsafe-inline'; sandbox" );
	header( 'Content-Disposition: inline; filename="gorsel"' );
}
/* v7.0.2: her REST yanıtında sunucudaki sürüm; açık sekme eski koddaysa istemci yenileme önerir (src/app.js surumBak) */
add_filter( 'rest_post_dispatch', function ( $res, $server, $req ) {
	if ( $res instanceof WP_HTTP_Response && 0 === strpos( (string) $req->get_route(), '/optik-karne/v1' ) ) {
		$res->header( 'X-Atlas-Surum', OPTIK_KARNE_VER );
	}
	return $res;
}, 10, 3 );
define( 'SIDES_DB_VER', '5' );
define( 'OPTIK_KARNE_CAP', 'optik_karne_yonet' );   // eski sürüm: site yöneticileri (1 numaralı kurum)
define( 'OPTIK_KARNE_SCAN', 'optik_karne_okut' );   // eski sürüm: "Öğretmen" rolü
define( 'OPTIK_KARNE_FILE', __FILE__ );
/* panel: Kontrol Paneli, takvim: Genel Takvim, nehari: 3, 4 ve N5. sınıflar (öğrenci kaydı, HBS, deneme, test, soru havuzu, karneler) */
define( 'SIDES_MODS', array( 'panel', 'takvim', 'takip', 'crm', 'kayit', 'nehari', 'test', 'havuz', 'sinav', 'analiz', 'karne', 'puan', 'rapor', 'sistem', 'sosyal', 'ek' ) );
define( 'SIDES_ROLLER', array( 'yonetici', 'personel', 'gozlemci', 'ogretmen' ) );
define( 'SIDES_YONTEMLER', array( 'kapali', 'kod', 'kod_onay', 'sonra_kod', 'acik' ) );

require_once __DIR__ . '/includes/rest.php';
require_once __DIR__ . '/includes/auth.php';
require_once __DIR__ . '/includes/guvenlik.php';
require_once __DIR__ . '/includes/admin.php';
require_once __DIR__ . '/includes/ana.php';
require_once __DIR__ . '/includes/yedek.php';
require_once __DIR__ . '/includes/ai.php';
require_once __DIR__ . '/includes/takip.php';
require_once __DIR__ . '/includes/ortak.php';
foreach ( array( 'puan', 'tv', 'hedef', 'workwin', 'rapor', 'analiz2', 'trafik', 'kzai', 'duzen', 'animasyon', 'sayfa', 'bildirim', 'odev', 'oturum', 'bakim', 'yildevri', 'rapor2', 'plink', 'yarisma', 'ek', 'ekakademik', 'fazilet', 'beceri', 'kelime', 'ods', 'odsform', 'karnesablon', 'optiksablon', 'dyoklama', 'sinavtakip', 'gform', 'asistan' ) as $sides_inc ) {
	if ( file_exists( __DIR__ . '/includes/' . $sides_inc . '.php' ) ) {
		require_once __DIR__ . '/includes/' . $sides_inc . '.php';
	}
}

function sides_docs() {
	global $wpdb;
	return $wpdb->prefix . 'sides_docs';
}
function sides_orgs() {
	global $wpdb;
	return $wpdb->prefix . 'sides_orgs';
}

/* ------------------------------------------------------------------ *
 * Kurulum ve eski verinin taşınması
 * ------------------------------------------------------------------ */
register_activation_hook( __FILE__, 'sides_activate' );
function sides_activate() {
	sides_install_db();
	sides_roles();
	sides_rewrite();
	flush_rewrite_rules();
	update_option( 'optik_karne_rw', OPTIK_KARNE_VER );
}
register_deactivation_hook( __FILE__, function () {
	flush_rewrite_rules();
	wp_clear_scheduled_hook( 'sides_gunluk_yedek' );
} );

function sides_install_db() {
	global $wpdb;
	require_once ABSPATH . 'wp-admin/includes/upgrade.php';
	$c    = $wpdb->get_charset_collate();
	$docs = sides_docs();
	$orgs = sides_orgs();
	dbDelta( "CREATE TABLE $docs (
  org bigint(20) unsigned NOT NULL DEFAULT 0,
  coll varchar(20) NOT NULL,
  id varchar(64) NOT NULL,
  exam_id varchar(64) NOT NULL DEFAULT '',
  token varchar(40) DEFAULT NULL,
  data longtext NOT NULL,
  snapshot longtext NULL,
  updated_at datetime NOT NULL,
  updated_by bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY  (org,coll,id),
  KEY org_exam (org,exam_id),
  KEY token (token)
) $c;" );
	dbDelta( "CREATE TABLE $orgs (
  id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  ad varchar(190) NOT NULL DEFAULT '',
  anahtar varchar(40) NOT NULL DEFAULT '',
  sahip bigint(20) unsigned NOT NULL DEFAULT 0,
  olusturma datetime NOT NULL,
  durum varchar(20) NOT NULL DEFAULT 'aktif',
  bitis datetime NULL,
  plan varchar(60) NOT NULL DEFAULT '',
  notlar text NULL,
  PRIMARY KEY  (id),
  KEY anahtar (anahtar)
) $c;" );
	$kod = $wpdb->prefix . 'sides_kodlar';
	dbDelta( "CREATE TABLE $kod (
  kod varchar(40) NOT NULL,
  plan varchar(60) NOT NULL DEFAULT '',
  gun int(11) NOT NULL DEFAULT 365,
  durum varchar(20) NOT NULL DEFAULT 'bos',
  notlar varchar(255) NOT NULL DEFAULT '',
  olusturma datetime NOT NULL,
  kullanan bigint(20) unsigned NOT NULL DEFAULT 0,
  kullanma datetime NULL,
  PRIMARY KEY  (kod)
) $c;" );
	sides_migrate();
	update_option( 'sides_db_ver', SIDES_DB_VER );
}

/* 3.x sürümündeki tek kurumlu tablo 1 numaralı kurum alanına kopyalanır; eski tablo yedek olarak kalır. */
function sides_migrate() {
	global $wpdb;
	$orgs = sides_orgs();
	$docs = sides_docs();
	if ( ! (int) $wpdb->get_var( "SELECT COUNT(*) FROM $orgs" ) ) { // phpcs:ignore
		$wpdb->insert( $orgs, array( 'ad' => get_bloginfo( 'name' ), 'anahtar' => '1', 'sahip' => 0, 'olusturma' => current_time( 'mysql', true ) ) );
	}
	if ( get_option( 'sides_migrated' ) ) {
		return;
	}
	$old = $wpdb->prefix . 'optik_karne_docs';
	if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $old ) ) === $old && ! (int) $wpdb->get_var( "SELECT COUNT(*) FROM $docs WHERE org = 1" ) ) { // phpcs:ignore
		foreach ( $wpdb->get_results( "SELECT * FROM $old" ) as $r ) { // phpcs:ignore
			$wpdb->insert( $docs, array( 'org' => 1, 'coll' => $r->coll, 'id' => $r->id, 'exam_id' => $r->exam_id, 'token' => $r->token, 'data' => $r->data, 'snapshot' => $r->snapshot, 'updated_at' => $r->updated_at, 'updated_by' => $r->updated_by ) );
		}
	}
	// 1 numaralı kurumun logosu (eklentiyle gelen kurum logosu) ve adı
	$set = sides_get_doc( 1, 'settings', 'main' );
	$set = $set ? $set : array();
	unset( $set['id'] );
	$f = __DIR__ . '/assets/kurum-logo.png';
	if ( empty( $set['logo'] ) && file_exists( $f ) ) {
		$set['logo'] = 'data:image/png;base64,' . base64_encode( file_get_contents( $f ) ); // phpcs:ignore
	}
	sides_put_doc( 1, 'settings', 'main', $set );
	if ( ! empty( $set['kurum'] ) ) {
		$wpdb->update( $orgs, array( 'ad' => $set['kurum'] ), array( 'id' => 1 ) );
	}
	update_option( 'sides_migrated', 1 );
}

/* Rolün görünen adı yeni marka adıyla güncellenir (sürüm değişince bir kez çalışır). */
function sides_rol_adi() {
	$wr = wp_roles();
	if ( isset( $wr->roles['sides_uye'] ) && 'ATLAS kullanıcısı' !== $wr->roles['sides_uye']['name'] ) {
		$wr->roles['sides_uye']['name'] = 'ATLAS kullanıcısı';
		$wr->role_names['sides_uye']    = 'ATLAS kullanıcısı';
		update_option( $wr->role_key, $wr->roles );
	}
}

function sides_roles() {
	if ( ! get_role( 'sides_uye' ) ) {
		add_role( 'sides_uye', 'ATLAS kullanıcısı', array( 'read' => true ) );
	}
	if ( ! get_role( 'ogretmen' ) ) {
		add_role( 'ogretmen', 'Öğretmen (Optik okutma)', array( 'read' => true, OPTIK_KARNE_SCAN => true ) );
	}
	foreach ( array( 'administrator', 'editor' ) as $r ) {
		$role = get_role( $r );
		if ( $role ) {
			$role->add_cap( OPTIK_KARNE_CAP );
			$role->add_cap( OPTIK_KARNE_SCAN );
		}
	}
}

add_action( 'plugins_loaded', function () {
	// güncellemeden sonraki ilk açılışta, veritabanı güncellenmeden önce otomatik yedek
	sides_yedek_guncelleme_oncesi();
	if ( get_option( 'sides_db_ver' ) !== SIDES_DB_VER ) {
		sides_install_db();
		sides_roles();
	}
} );

/* ------------------------------------------------------------------ *
 * Kullanıcı bağlamı: kurum alanı, rol, modül yetkileri
 * ------------------------------------------------------------------ */
function sides_ctx( $uid = null ) {
	static $cache = array();
	if ( null === $uid && ( $hedef = sides_onizleme_hedef() ) ) {
		$c             = sides_ctx( $hedef );
		$c['onizleme'] = get_current_user_id();
		return $c;
	}
	$u = null === $uid ? wp_get_current_user() : get_userdata( $uid );
	if ( ! $u || ! $u->ID ) {
		return array( 'uid' => 0, 'org' => 0, 'rol' => '', 'yetki' => sides_yetki_of( '', 0 ) );
	}
	if ( isset( $cache[ $u->ID ] ) ) {
		return $cache[ $u->ID ];
	}
	$org = (int) get_user_meta( $u->ID, 'sides_org', true );
	$rol = (string) get_user_meta( $u->ID, 'sides_rol', true );
	$legacy_admin = user_can( $u, OPTIK_KARNE_CAP );
	$legacy_scan  = user_can( $u, OPTIK_KARNE_SCAN );
	if ( ! $org && ( $legacy_admin || $legacy_scan ) ) {
		$org = 1;
	}
	if ( ! $rol ) {
		$rol = $legacy_admin ? 'yonetici' : ( $legacy_scan ? 'ogretmen' : '' );
	}
	if ( ! in_array( $rol, SIDES_ROLLER, true ) || ! $org ) {
		$rol = '';
	}
	$blok = '';
	if ( $rol && $org && ! user_can( $u, 'manage_options' ) ) {
		$blok = sides_org_blok( sides_org( $org ) );
	}
	if ( $blok ) {
		$c               = array( 'uid' => $u->ID, 'org' => 0, 'rol' => '', 'yetki' => sides_yetki_of( '', 0 ), 'blok' => $blok, 'blokOrg' => $org );
		$cache[ $u->ID ] = $c;
		return $c;
	}
	$c                 = array( 'uid' => $u->ID, 'org' => $rol ? $org : 0, 'rol' => $rol, 'yetki' => sides_org_modul_kisit( $rol ? $org : 0, sides_yetki_of( $rol, $u->ID ) ) );
	$cache[ $u->ID ] = $c;
	return $c;
}

/* 2: tam yetki, 1: yalnızca görüntüleme, 0: kapalı. Personel varsayılanı tam yetkidir;
   soru havuzuna ekleme ise varsayılan olarak yöneticidedir (personel havuzu kullanır, düzenleyemez). */
function sides_yetki_of( $rol, $uid ) {
	$out = array();
	$def = array( 'havuz' => 1 );
	foreach ( SIDES_MODS as $m ) {
		$out[ $m ] = 'yonetici' === $rol ? 2 : ( 'gozlemci' === $rol ? 1 : ( 'personel' === $rol ? ( isset( $def[ $m ] ) ? $def[ $m ] : 2 ) : 0 ) );
	}
	if ( 'personel' === $rol ) {
		$y = get_user_meta( $uid, 'sides_yetki', true );
		if ( is_array( $y ) ) {
			foreach ( SIDES_MODS as $m ) {
				if ( isset( $y[ $m ] ) ) {
					$out[ $m ] = max( 0, min( 2, (int) $y[ $m ] ) );
				}
			}
			// Sonradan eklenen modüller: kaydı olmayan eski kullanıcıda ilgili eski modülün düzeyi geçerlidir
			if ( ! isset( $y['takvim'] ) && isset( $y['crm'] ) ) {
				$out['takvim'] = $out['crm'];
			}
			if ( ! isset( $y['nehari'] ) && ( isset( $y['test'] ) || isset( $y['sinav'] ) ) ) {
				$out['nehari'] = max( $out['test'], $out['sinav'] );
			}
			// v7: Sosyal Aktiviteler ve Ek Modüller kaydı olmayan eski kullanıcıda Takip düzeyini alır
			foreach ( array( 'sosyal', 'ek' ) as $yeni ) {
				if ( ! isset( $y[ $yeni ] ) && isset( $y['takip'] ) ) {
					$out[ $yeni ] = $out['takip'];
				}
			}
		}
	}
	if ( 'ogretmen' === $rol ) {
		$out['karne'] = 2;
	}
	return $out;
}

function sides_can( $mod, $lvl ) {
	$c = sides_ctx();
	return $c['org'] && isset( $c['yetki'][ $mod ] ) && $c['yetki'][ $mod ] >= $lvl;
}
function sides_is_panel() {
	$c = sides_ctx();
	return $c['org'] && in_array( $c['rol'], array( 'yonetici', 'personel', 'gozlemci' ), true );
}
function sides_is_observer() {
	return 'gozlemci' === sides_ctx()['rol'];
}
/* ------------------------------------------------------------------ *
 * Ekran önizlemesi: kurum yöneticisi kendi kurumundaki, ana hesap (site yöneticisi) herhangi bir kurumdaki kullanıcının
 * ATLAS'ı nasıl gördüğünü salt okunur açar. İstek: sayfa ve görsellerde ?onizle=<id>, uygulama isteklerinde X-Atlas-Onizle başlığı.
 * Önizlemede veriler hedef kullanıcının yetki ve sınıf kısıtıyla gelir; hiçbir değişiklik kaydedilmez.
 * ------------------------------------------------------------------ */
function sides_onizleme_istek() {
	if ( isset( $_SERVER['HTTP_X_ATLAS_ONIZLE'] ) ) {
		return (int) $_SERVER['HTTP_X_ATLAS_ONIZLE'];
	}
	return isset( $_GET['onizle'] ) ? (int) $_GET['onizle'] : 0; // phpcs:ignore
}
function sides_onizleme_hedef() {
	static $h = null;
	if ( null !== $h ) {
		return $h;
	}
	$v   = sides_onizleme_istek();
	$ben = get_current_user_id();
	if ( ! $v || ! $ben ) {
		return 0;
	}
	$h = 0; // izin denetimi sırasında kendi bağlamı kullanılsın
	$h = sides_onizleme_izinli( $ben, $v ) ? $v : 0;
	return $h;
}
function sides_onizleme_izinli( $ben, $v ) {
	$hedef = get_userdata( $v );
	if ( $v === $ben || ! $hedef || user_can( $hedef, 'manage_options' ) ) {
		return false;
	}
	$hc  = sides_ctx( $v );
	$org = $hc['org'] ? (int) $hc['org'] : ( isset( $hc['blokOrg'] ) ? (int) $hc['blokOrg'] : 0 );
	if ( ! $org ) {
		return false;
	}
	if ( user_can( $ben, 'manage_options' ) ) {
		return true;
	}
	$gc = sides_ctx( $ben );
	return 'yonetici' === $gc['rol'] && (int) $gc['org'] === $org;
}
add_filter( 'rest_pre_dispatch', function ( $res, $server, $req ) {
	if ( ! sides_onizleme_istek() || 0 !== strpos( $req->get_route(), '/optik-karne/v1/' ) ) {
		return $res;
	}
	if ( ! sides_onizleme_hedef() ) {
		return new WP_Error( 'sides_onizleme', 'Bu kullanıcının ekranını önizleme izniniz yok.', array( 'status' => 403 ) );
	}
	if ( 'GET' !== $req->get_method() ) {
		return new WP_Error( 'sides_onizleme', 'Önizleme modunda değişiklik yapılamaz.', array( 'status' => 403 ) );
	}
	return $res;
}, 10, 3 );

function sides_org_id() {
	return (int) sides_ctx()['org'];
}
function sides_org( $id ) {
	global $wpdb;
	$t = sides_orgs();
	return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE id = %d", $id ) ); // phpcs:ignore
}
function sides_org_by_key( $k ) {
	global $wpdb;
	$k = preg_replace( '/[^a-z0-9]/', '', strtolower( (string) $k ) );
	if ( '' === $k ) {
		return null;
	}
	$t = sides_orgs();
	return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM $t WHERE anahtar = %s", $k ) ); // phpcs:ignore
}

/* ------------------------------------------------------------------ *
 * Belge yardımcıları (her sorgu kurum alanıyla sınırlı)
 * ------------------------------------------------------------------ */
function sides_row_out( $r, $mask = false ) {
	$d = json_decode( $r->data, true );
	if ( ! is_array( $d ) ) {
		$d = array();
	}
	$d['id'] = $r->id;
	if ( 'results' === $r->coll ) {
		$d['token'] = $r->token ? $r->token : null;
	}
	if ( 'exams' === $r->coll || 'testler' === $r->coll ) {
		$d['okutToken'] = $r->token ? $r->token : null;
	}
	return $mask ? sides_mask( $r->coll, $d ) : $d;
}

function sides_get_doc( $org, $coll, $id ) {
	global $wpdb;
	$t   = sides_docs();
	$row = $wpdb->get_row( $wpdb->prepare( "SELECT coll, id, token, data FROM $t WHERE org = %d AND coll = %s AND id = %s", $org, $coll, $id ) ); // phpcs:ignore
	return $row ? sides_row_out( $row ) : null;
}

function sides_put_doc( $org, $coll, $id, $d, $exam = '' ) {
	global $wpdb;
	$t = sides_docs();
	unset( $d['id'], $d['token'], $d['okutToken'], $d['yonetimToken'] );
	$json   = wp_json_encode( $d );
	$now    = current_time( 'mysql', true );
	$uid    = get_current_user_id();
	$exists = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM $t WHERE org = %d AND coll = %s AND id = %s", $org, $coll, $id ) ); // phpcs:ignore
	if ( $exists ) {
		$ok = $wpdb->update( $t, array( 'exam_id' => $exam, 'data' => $json, 'updated_at' => $now, 'updated_by' => $uid ), array( 'org' => $org, 'coll' => $coll, 'id' => $id ) );
	} else {
		$ok = $wpdb->insert( $t, array( 'org' => $org, 'coll' => $coll, 'id' => $id, 'exam_id' => $exam, 'data' => $json, 'updated_at' => $now, 'updated_by' => $uid ) );
	}
	return false === $ok ? false : ( $exists ? 'update' : 'insert' );
}

/* Gözlemci kişisel verileri göremez: adlar kısaltılır, telefon ve notlar gizlenir. */
function sides_mask_name( $s ) {
	$w = preg_split( '/\s+/u', trim( (string) $s ) );
	$o = array();
	foreach ( $w as $x ) {
		if ( '' !== $x ) {
			$o[] = mb_substr( $x, 0, 1 ) . '***';
		}
	}
	return implode( ' ', $o );
}
function sides_mask( $coll, $d ) {
	if ( 'students' === $coll ) {
		$d['ad']      = sides_mask_name( isset( $d['ad'] ) ? $d['ad'] : '' );
		$d['no']      = '•••';
		$d['veliTel'] = '';
	} elseif ( 'results' === $coll || 'tsonuc' === $coll ) {
		if ( isset( $d['ogr'] ) && is_array( $d['ogr'] ) ) {
			$d['ogr']['ad']      = sides_mask_name( isset( $d['ogr']['ad'] ) ? $d['ogr']['ad'] : '' );
			$d['ogr']['no']      = '•••';
			$d['ogr']['veliTel'] = '';
		}
		$d['token'] = null;
	} elseif ( 'adaylar' === $coll ) {
		$d['ad']      = sides_mask_name( isset( $d['ad'] ) ? $d['ad'] : '' );
		$d['veliAd']  = sides_mask_name( isset( $d['veliAd'] ) ? $d['veliAd'] : '' );
		$d['telefon'] = '';
		$n            = array();
		foreach ( (array) ( isset( $d['notlar'] ) ? $d['notlar'] : array() ) as $x ) {
			$n[] = array( 't' => isset( $x['t'] ) ? $x['t'] : 0, 'u' => '•••', 'm' => 'Not içeriği gözlemciye kapalı' );
		}
		$d['notlar'] = $n;
	} elseif ( 'exams' === $coll || 'testler' === $coll ) {
		$d['okutToken']   = null;
		$d['yonetimToken'] = null;
	}
	return $d;
}

/* ------------------------------------------------------------------ *
 * Uygulama adresi: /optik-karne/
 * ------------------------------------------------------------------ */
/* Asıl adres /atlas/. /ATLAS/, /Atlas/, eski /sides/ (tüm yazılışları) ve /optik-karne/ adresleri de açılır ve /atlas/'a yönlenir;
   daha önce paylaşılan veli, okutma ve kayıt bağlantıları çalışmaya devam eder. */
define( 'SIDES_SLUG', 'atlas' );
function sides_rewrite() {
	add_rewrite_rule( '^(?:[aA][tT][lL][aA][sS]|[sS](?:i|I|ı|İ)[dD][eE][sS]|optik-karne)/?$', 'index.php?optik_karne=1', 'top' );
}
add_action( 'init', function () {
	sides_rewrite();
	if ( get_option( 'optik_karne_rw' ) !== OPTIK_KARNE_VER ) {
		sides_rol_adi();
		flush_rewrite_rules();
		update_option( 'optik_karne_rw', OPTIK_KARNE_VER );
	}
} );
add_filter( 'query_vars', function ( $vars ) {
	$vars[] = 'optik_karne';
	return $vars;
} );

/* Site yalnızca ATLAS için kullanılıyorsa (ör. www.sides-alanadi.com) ATLAS ana sayfada açılır. */
function sides_ana_sayfa() {
	return '1' === (string) get_option( 'sides_ana_sayfa', '0' );
}
function optik_karne_url( $args = array() ) {
	if ( sides_ana_sayfa() ) {
		$u = home_url( '/' );
	} else {
		$u = get_option( 'permalink_structure' ) ? home_url( '/' . SIDES_SLUG . '/' ) : add_query_arg( 'optik_karne', '1', home_url( '/' ) );
	}
	return $args ? add_query_arg( $args, $u ) : $u;
}

add_action( 'template_redirect', function () {
	$ana = sides_ana_sayfa() && ( is_front_page() || is_home() );
	if ( ! $ana && ! get_query_var( 'optik_karne' ) && ! isset( $_GET['optik_karne'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
		return;
	}
	// Farklı yazılışlar ve eski adresler tek adrese (/atlas/) yönlenir; sorgu (veli, okutma linki vb.) korunur.
	if ( ! $ana && get_option( 'permalink_structure' ) && 'GET' === ( isset( $_SERVER['REQUEST_METHOD'] ) ? $_SERVER['REQUEST_METHOD'] : 'GET' ) ) {
		$want = wp_parse_url( optik_karne_url(), PHP_URL_PATH );
		$have = rawurldecode( (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ) ); // phpcs:ignore
		if ( $have && $want && $have !== $want && ! isset( $_GET['optik_karne'] ) ) { // phpcs:ignore
			$qs = isset( $_SERVER['QUERY_STRING'] ) ? (string) wp_unslash( $_SERVER['QUERY_STRING'] ) : ''; // phpcs:ignore
			wp_safe_redirect( optik_karne_url() . ( $qs ? '?' . $qs : '' ), 301 );
			exit;
		}
	}
	$veli = isset( $_GET['k'] ) ? preg_replace( '/[^a-f0-9]/', '', strtolower( wp_unslash( $_GET['k'] ) ) ) : ''; // phpcs:ignore
	$okut = isset( $_GET['okut'] ) ? preg_replace( '/[^a-f0-9]/', '', strtolower( wp_unslash( $_GET['okut'] ) ) ) : ''; // phpcs:ignore
	if ( $veli ) {
		sides_render_app( 'veli', $veli );
		exit;
	}
	$tk = isset( $_GET['tk'] ) ? preg_replace( '/[^a-f0-9]/', '', strtolower( wp_unslash( $_GET['tk'] ) ) ) : ''; // phpcs:ignore
	if ( $tk ) {
		sides_render_app( 'takviye', $tk );
		exit;
	}
	$st = isset( $_GET['st'] ) ? preg_replace( '/[^a-f0-9]/', '', strtolower( wp_unslash( $_GET['st'] ) ) ) : ''; // phpcs:ignore
	if ( $st ) {   // v7.9.2 Sınav Takip online çözüm sayfası (hesapsız; belirteç her istekte sunucuda denetlenir)
		header( 'Referrer-Policy: no-referrer' );
		sides_render_app( 'sinav', $st );
		exit;
	}
	$pl = isset( $_GET['pl'] ) ? preg_replace( '/[^a-f0-9]/', '', strtolower( wp_unslash( $_GET['pl'] ) ) ) : ''; // phpcs:ignore
	if ( $pl ) {   // v6 R03 süreli puan / yoklama giriş linki (hesapsız; belirteç her istekte sunucuda denetlenir)
		header( 'Referrer-Policy: no-referrer' );
		sides_render_app( 'plink', $pl );
		exit;
	}
	$yrp = isset( $_GET['yrp'] ) ? preg_replace( '/[^a-f0-9]/', '', strtolower( wp_unslash( $_GET['yrp'] ) ) ) : ''; // phpcs:ignore
	if ( $yrp ) {   // v7.9.17 bilgi yarışması puan girişi linki (hesapsız; anahtar her istekte sunucuda denetlenir)
		header( 'Referrer-Policy: no-referrer' );
		sides_render_app( 'yrpuan', substr( $yrp, 0, 24 ) );
		exit;
	}
	if ( isset( $_GET['yr'] ) ) { // phpcs:ignore   v7 EK16 canlı yarışma oyuncu sayfası (hesapsız; PIN yalnız oyunu bulur, sonrası oyuncu anahtarıyla)
		header( 'Referrer-Policy: no-referrer' );
		sides_render_app( 'yarisma', is_string( $_GET['yr'] ) ? substr( preg_replace( '/\D/', '', wp_unslash( $_GET['yr'] ) ), 0, 6 ) : '' ); // phpcs:ignore
		exit;
	}
	$tv = isset( $_GET['tv'] ) ? preg_replace( '/[^a-f0-9]/', '', strtolower( wp_unslash( $_GET['tv'] ) ) ) : ''; // phpcs:ignore
	if ( $tv ) {   // televizyon panosu (yalnızca gösterim; kapsamı dar, iptal edilebilir bağlantı)
		sides_render_app( 'tv', $tv );
		exit;
	}
	$vr = isset( $_GET['vr'] ) ? preg_replace( '/[^a-f0-9]/', '', strtolower( wp_unslash( $_GET['vr'] ) ) ) : ''; // phpcs:ignore
	if ( $vr ) {   // veli raporu görüntüleme bağlantısı (salt okunur, tek öğrenci)
		sides_render_app( 'velirapor', $vr );
		exit;
	}
	if ( $okut ) {
		sides_render_app( 'okut', $okut );
		exit;
	}
	if ( isset( $_GET['kayit'] ) ) { // phpcs:ignore
		sides_render_app( 'kayit', preg_replace( '/[^a-z0-9]/', '', strtolower( wp_unslash( $_GET['kayit'] ) ) ) ); // phpcs:ignore
		exit;
	}
	sides_auth_route(); // giriş, kayıt, doğrulama, şifre sıfırlama (gerekirse sayfayı basıp çıkar)
	$c = sides_ctx();
	if ( ! empty( $c['blok'] ) ) {
		sides_auth_page( 'blok', array( 'blok' => $c['blok'], 'org' => sides_org( $c['blokOrg'] ) ) );
		exit;
	}
	if ( in_array( $c['rol'], array( 'yonetici', 'personel', 'gozlemci' ), true ) ) {
		if ( empty( $c['onizleme'] ) ) {
			update_user_meta( $c['uid'], 'sides_son_giris', time() );
		}
		sides_render_app( 'app', '' );
	} elseif ( 'ogretmen' === $c['rol'] ) {
		sides_render_app( 'okut', '' );
	} else {
		sides_auth_page( 'yetkisiz' );
	}
	exit;
} );

/* Giriş yapmış ATLAS kullanıcıları WordPress yönetim çubuğunu ve panelini görmez. */
add_filter( 'show_admin_bar', function ( $show ) {
	$u = wp_get_current_user();
	return ( $u && in_array( 'sides_uye', (array) $u->roles, true ) ) ? false : $show;
} );
add_action( 'admin_init', function () {
	$u = wp_get_current_user();
	if ( $u && in_array( 'sides_uye', (array) $u->roles, true ) && ! wp_doing_ajax() && ! current_user_can( 'edit_posts' ) ) {
		wp_safe_redirect( optik_karne_url() );
		exit;
	}
} );

function sides_render_app( $mode, $token ) {
	status_header( 200 );
	nocache_headers();
	if ( ! defined( 'DONOTCACHEPAGE' ) ) {
		define( 'DONOTCACHEPAGE', true );   // v7.0.2: sayfa önbelleği eklentileri (WP Super Cache, W3TC, LiteSpeed) uygulama sayfasını saklamasın
	}
	header( 'X-LiteSpeed-Cache-Control: no-cache' );
	if ( 'ods' === $mode && function_exists( 'sides_ods_sayfa' ) ) {   // ÖDS tanıtım sayfası: sunucuda basılır, dizine eklenebilir (noindex yok), uygulama paketi yüklenmez (includes/ods.php)
		sides_ods_sayfa( $token );
		return;
	}
	header( 'X-Robots-Tag: noindex, nofollow' );
	$user   = wp_get_current_user();
	$c      = sides_ctx();
	$logged = in_array( $mode, array( 'app', 'okut' ), true ) && ! $token && $c['org'];
	$org    = $logged ? sides_org( $c['org'] ) : null;
	$oniz   = $logged && ! empty( $c['onizleme'] ) ? get_userdata( $c['uid'] ) : null;
	$kim    = $oniz ? $oniz : $user;
	$okut_tip = '';
	if ( 'okut' === $mode ) {
		$sc       = $token ? sides_okut_token( $token ) : null;
		$okut_tip = $sc ? $sc['tip'] : ( 'ogretmen' === $c['rol'] ? 'okutucu' : 'yonetici' );
	}
	$cfg    = array(
		'okutTip'  => $okut_tip,
		'rest'     => esc_url_raw( rest_url( 'optik-karne/v1/' ) ),
		'nonce'    => $logged ? wp_create_nonce( 'wp_rest' ) : '',
		'mode'     => $mode,
		'token'    => $token,
		'appUrl'   => optik_karne_url(),
		'user'     => $logged ? $kim->display_name : '',
		'email'    => $logged ? $kim->user_email : '',
		'avatar'   => $logged ? (string) get_user_meta( $kim->ID, 'sides_avatar', true ) : '',
		'userId'   => $logged ? $kim->ID : 0,
		'logout'   => $logged && ! $oniz ? sides_logout_url() : '',
		'role'     => $logged ? $c['rol'] : '',
		'perms'    => $logged ? $c['yetki'] : null,
		'sayfa'    => $logged && function_exists( 'sides_sayfa_harita' ) ? (object) sides_sayfa_harita() : null,
		'ek'       => $logged && function_exists( 'sides_ek_boot' ) ? sides_ek_boot( (int) $c['org'] ) : null,   // v7 Ek Kataloğu görünürlüğü (includes/ek.php)
		'siniflar' => $logged ? (array) sides_sinif_kisit() : array(),
		'kayitKey' => $org ? $org->anahtar : '',
		'orgId'    => $logged ? (int) $c['org'] : 0,
		'super'    => $logged && 'app' === $mode && ! $oniz && sides_is_super(),
		'kapali'   => $logged ? sides_kapali_moduller( $c['org'] ) : array(),
		'onizle'   => $oniz ? array( 'id' => $oniz->ID, 'ad' => $oniz->display_name, 'rol' => $c['rol'], 'kurum' => $org ? $org->ad : '' ) : null,
		'bitis'    => $org && ! empty( $org->bitis ) ? gmdate( 'Y-m-d', strtotime( $org->bitis . ' UTC' ) ) : '',
	);
	$base  = plugin_dir_url( OPTIK_KARNE_FILE ) . 'assets/';
	$ver   = OPTIK_KARNE_VER . '.' . filemtime( __DIR__ . '/assets/app.js' );
	$cfg['mark'] = $base . 'atlas-mark-192.png';
	$perde = in_array( $mode, array( 'app', 'okut' ), true ) && function_exists( 'sides_anim_acilis' ) ? sides_anim_acilis( $logged ? (int) $c['org'] : 0, $logged ? $kim->ID : 0 ) : '';   // v7.9.24 açılış ekranı şablonu
	$title = array( 'tv' => 'Pano · ATLAS', 'velirapor' => 'Öğrenci Raporu · ATLAS', 'takviye' => 'Takviye Ders Puanları · ATLAS', 'plink' => 'Giriş Linki · ATLAS', 'yarisma' => 'Bilgi Yarışması · ATLAS', 'veli' => 'Sınav Karnesi · ATLAS', 'okut' => 'Optik Okutma · ATLAS', 'kayit' => 'Ön Kayıt · ATLAS', 'app' => 'ATLAS' );
	?><!doctype html>
<html lang="tr"<?php echo in_array( $mode, array( 'app', 'okut' ), true ) ? ' class="acilis' . ( $perde ? ' ap-var' : '' ) . '"' : ''; ?>>
<head>
<meta charset="utf-8">
<script>try{var t=localStorage.getItem('ok-theme');if(t)document.documentElement.setAttribute('data-theme',t)}catch(e){}</script>
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="robots" content="noindex,nofollow">
<title><?php echo esc_html( isset( $title[ $mode ] ) ? $title[ $mode ] : 'ATLAS' ); ?></title>
<link rel="icon" type="image/png" href="<?php echo esc_url( $base . 'atlas-mark-32.png' ); ?>">
<link rel="apple-touch-icon" href="<?php echo esc_url( $base . 'atlas-mark-192.png' ); ?>">
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Rubik:wght@400;500;600;700&family=IBM+Plex+Mono:wght@500;600&family=Dancing+Script:wght@700&display=swap">
<link rel="stylesheet" href="<?php echo esc_url( $base . 'app.css?v=' . $ver ); ?>">
</head>
<body>
<?php
	if ( $perde ) {
		echo sides_acilis_perde( $base . 'atlas-mark-192.png', $perde ); // phpcs:ignore -- sabit işaretleme, şablon adı beyaz listeden
	}
	// body.html eklentiyle gelen sabit bir şablondur.
	echo file_get_contents( __DIR__ . '/assets/body.html' ); // phpcs:ignore
?>
<script>window.OK_CFG = <?php echo wp_json_encode( $cfg ); ?>;</script>
<script src="https://cdn.jsdelivr.net/npm/jspdf@2.5.1/dist/jspdf.umd.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/html2canvas@1.4.1/dist/html2canvas.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/qrcode-generator@1.4.4/qrcode.js"></script>
<script src="https://cdn.jsdelivr.net/npm/jsqr@1.4.0/dist/jsQR.js"></script>
<script src="<?php echo esc_url( $base . 'app.js?v=' . $ver ); ?>"></script>
</body>
</html>
	<?php
}

/* ------------------------------------------------------------------ *
 * İşlem geçmişi
 * ------------------------------------------------------------------ */
function sides_log( $org, $m, $who = null ) {
	global $wpdb;
	if ( ! $m || ! $org ) {
		return;
	}
	$t = sides_docs();
	if ( null === $who ) {
		$u   = wp_get_current_user();
		$who = $u && $u->ID ? $u->display_name : 'Sistem';
	}
	$ms = (int) round( microtime( true ) * 1000 );
	$wpdb->insert( $t, array( 'org' => $org, 'coll' => 'log', 'id' => str_pad( (string) $ms, 14, '0', STR_PAD_LEFT ) . '-' . wp_rand( 1000, 9999 ), 'exam_id' => '', 'data' => wp_json_encode( array( 't' => $ms, 'u' => $who, 'm' => mb_substr( $m, 0, 300 ) ) ), 'updated_at' => current_time( 'mysql', true ), 'updated_by' => get_current_user_id() ) );
	if ( 1 === wp_rand( 1, 25 ) ) {
		$th = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM $t WHERE org = %d AND coll = 'log' ORDER BY id DESC LIMIT 1 OFFSET 600", $org ) ); // phpcs:ignore
		if ( $th ) {
			$wpdb->query( $wpdb->prepare( "DELETE FROM $t WHERE org = %d AND coll = 'log' AND id <= %s", $org, $th ) ); // phpcs:ignore
		}
	}
}

function sides_log_list( $org, $n, $mask = false ) {
	global $wpdb;
	$t   = sides_docs();
	$out = array();
	foreach ( $wpdb->get_results( $wpdb->prepare( "SELECT data FROM $t WHERE org = %d AND coll = 'log' ORDER BY id DESC LIMIT %d", $org, $n ) ) as $r ) { // phpcs:ignore
		$d = json_decode( $r->data, true );
		if ( $d ) {
			if ( $mask ) {
				$d['m'] = preg_replace( '/:\s.*$/u', ': •••', (string) $d['m'] );
				$d['u'] = sides_mask_name( isset( $d['u'] ) ? $d['u'] : '' );
			}
			$out[] = $d;
		}
	}
	return $out;
}

function sides_log_text( $coll, $d, $is_new, $del ) {
	$ad = isset( $d['ad'] ) ? $d['ad'] : ( isset( $d['baslik'] ) ? $d['baslik'] : '' );
	if ( 'results' === $coll ) {
		if ( $del ) {
			return 'Sonuç silindi: ' . ( isset( $d['ogr']['ad'] ) ? $d['ogr']['ad'] : '' );
		}
		$e = isset( $d['examId'] ) ? sides_get_doc( sides_org_id(), 'exams', $d['examId'] ) : null;
		return 'Form okutuldu: ' . ( isset( $d['ogr']['ad'] ) ? $d['ogr']['ad'] : '' ) . ( $e ? ' · ' . $e['ad'] : '' );
	}
	if ( 'tsonuc' === $coll ) {
		if ( $del ) {
			return 'Test sonucu silindi: ' . ( isset( $d['ogr']['ad'] ) ? $d['ogr']['ad'] : '' );
		}
		$tt = isset( $d['testId'] ) ? sides_get_doc( sides_org_id(), 'testler', $d['testId'] ) : null;
		return 'Test formu okutuldu: ' . ( isset( $d['ogr']['ad'] ) ? $d['ogr']['ad'] : '' ) . ( $tt ? ' · ' . $tt['ad'] : '' );
	}
	if ( 'settings' === $coll ) {
		return 'Ayarlar güncellendi';
	}
	if ( 'havuz' === $coll ) {
		return 'Soru havuzu ' . ( $del ? 'sorusu silindi' : ( $is_new ? 'sorusu eklendi' : 'sorusu güncellendi' ) ) . ( ! empty( $d['ders'] ) ? ': ' . $d['ders'] : '' );
	}
	if ( 'kitap' === $coll ) {
		$k = isset( $d['kitap'] ) ? $d['kitap'] : '';
		$o = ! empty( $d['studentId'] ) ? sides_get_doc( sides_org_id(), 'students', (string) $d['studentId'] ) : null;
		$k = ( $o && isset( $o['ad'] ) ? $o['ad'] . ' — ' : '' ) . $k;
		return $del ? 'Kitap kaydı silindi: ' . $k : ( $is_new ? 'Kitap okumaya başlandı: ' . $k : ( ! empty( $d['bitis'] ) ? 'Kitap bitirildi: ' . $k : 'Kitap kaydı güncellendi: ' . $k ) );
	}
	if ( 'takviye' === $coll ) {
		return 'Takviye ders ' . ( $del ? 'silindi' : ( $is_new ? 'oluşturuldu' : 'güncellendi' ) ) . ': ' . ( isset( $d['ders'] ) ? $d['ders'] : '' );
	}
	$l = array( 'exams' => 'Deneme', 'testler' => 'Test', 'students' => 'Öğrenci', 'adaylar' => 'Aday', 'duyurular' => 'Duyuru', 'takvim' => 'Etkinlik', 'seviye' => 'Dahili ders seviyesi', 'dgrup' => 'Dahili ders grubu' );
	if ( ! isset( $l[ $coll ] ) ) {
		return '';
	}
	return $l[ $coll ] . ' ' . ( $del ? 'silindi' : ( $is_new ? ( 'duyurular' === $coll ? 'yayınlandı' : 'eklendi' ) : 'güncellendi' ) ) . ': ' . $ad;
}

/* Basit IP başına sınır. sides_rl: say ve kontrol et; _check/_hit: yalnızca başarısız denemeleri saymak için */
function sides_rl_key( $key ) {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	return 'sides_rl_' . md5( $key . '|' . $ip );
}
function sides_rl_check( $key, $max ) {
	return (int) get_transient( sides_rl_key( $key ) ) < $max;
}
function sides_rl_hit( $key, $ttl ) {
	$k = sides_rl_key( $key );
	set_transient( $k, (int) get_transient( $k ) + 1, $ttl );
}
function sides_rl( $key, $max, $ttl ) {
	$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
	$k  = 'sides_rl_' . md5( $key . '|' . $ip );
	$v  = get_transient( $k );
	$v  = is_array( $v ) && isset( $v['n'], $v['t'] ) && $v['t'] > time() ? $v : array( 'n' => 0, 't' => time() + $ttl );   // v6.0.3: sabit pencere (eskiden her istek süreyi uzatıyordu; sürekli sorgulayan TV saatler sonra kilitleniyordu)
	if ( $v['n'] >= $max ) {
		return false;
	}
	$v['n']++;
	set_transient( $k, $v, max( 1, $v['t'] - time() ) );
	return true;
}
